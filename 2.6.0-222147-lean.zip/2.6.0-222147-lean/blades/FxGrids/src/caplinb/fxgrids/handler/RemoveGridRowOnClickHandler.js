/**
 * @fileoverview
 * 
 * This handler traps click events and passes an 'trade' the {@link caplin.element.RendererEventListener}.
 */

caplin.namespace("caplinb.fxgrids.handler");

caplin.include("caplin.element.Handler", true);

/**
 * RemoveGridRowOnClickHandler is a flyweight singleton, and therefore this constructor should never be invoked directly.
 * <p/>
 * Instead, it is instantiated by the RendererFactory, which reads RendererType specifications from XML and
 * instantiates the handlers by name.
 * 
 * @extends {caplin.element.Handler}
 * @constructor
 */
caplinb.fxgrids.handler.RemoveGridRowOnClickHandler = function() {
};

caplin.extend(caplinb.fxgrids.handler.RemoveGridRowOnClickHandler, caplin.element.Handler);

/**
 * Traps the <code>onclick</code> event and returns an 'trade' event for passing up to the RendererEventListener.
 * 
 * All the functions that begin with <code>on</code> are assumed to be event handler functions, and are attached
 * to DOM elements by reflection.
 * 
 * @param {Object} oDomEvent  The DOM event
 * @param {Object} oRenderer  The renderer 
 *  
 * @type Map
 * @return  An 'trade' event
 */
caplinb.fxgrids.handler.RemoveGridRowOnClickHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes) {
	var oControl = oRenderer.getControl();
	if (oControl.isEnabled()) {
		oRenderer.raiseEvent("removeRowClick", {"event":oDomEvent});
	}
};

/**
 * Returns a human-readable string representation of the handler, which is useful for debugging.
 * 
 * @return  The string representation
 * @type String
 */
caplinb.fxgrids.handler.RemoveGridRowOnClickHandler.prototype.toString = function() {
	return "caplinb.fxgrids.handler.RemoveGridRowOnClickHandler";
};

caplin.singleton("caplinb.fxgrids.handler.RemoveGridRowOnClickHandler");
