caplin.namespace("caplinb.fxgrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinb.fxgrids.dataprovider.expandable.FxBlotterSL4BSubjectChildRowConfig = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
};

caplinb.fxgrids.dataprovider.expandable.FxBlotterSL4BSubjectChildRowConfig.prototype.getSubjectToExpanded = function(mRowData, sSubject)
{
	return sSubject;
};

caplinb.fxgrids.dataprovider.expandable.FxBlotterSL4BSubjectChildRowConfig.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return [];
};

caplinb.fxgrids.dataprovider.expandable.FxBlotterSL4BSubjectChildRowConfig.prototype.getNumberOfChildRowsRows = function(oGridColumnModel)
{
	return 2;
};

caplinb.fxgrids.dataprovider.expandable.FxBlotterSL4BSubjectChildRowConfig.prototype.getChildRows = function(sSubject, oFieldData)
{
	var pRows = [{}, {}];

	var mFieldMap = oFieldData.getFieldMap();
	for(var sFieldName in mFieldMap)
	{
		var pMatchArray = sFieldName.match(/^L([0-9])_.*/);
		if(pMatchArray)
		{
			var nRow = parseInt(pMatchArray[1], 10) - 1;
			pRows[nRow][sFieldName] = mFieldMap[sFieldName];
		}
	}
	return pRows;
};

caplinb.fxgrids.dataprovider.expandable.FxBlotterSL4BSubjectChildRowConfig.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	var mRowRecords = {};
	for(var sFieldName in mRecordUpdates)
	{
		var pMatchArray = sFieldName.match(/^L([0-9])_(.*)/);
		if(pMatchArray)
		{
			mRowRecords['L1_' + pMatchArray[2]] = mRecordUpdates[sFieldName];
		}
	}
	return mRowRecords;
};
