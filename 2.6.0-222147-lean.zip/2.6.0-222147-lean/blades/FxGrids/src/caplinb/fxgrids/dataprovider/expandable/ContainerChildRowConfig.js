caplin.namespace("caplinb.fxgrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfig = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getContainerToExpanded = function(mRowData, sRendererId)
{
	return '/CONTAINER/FX/Emerging';
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return oGridColumnModel.getRequiredFields();
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfig.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	if (mRecordUpdates.InstrumentDescription && mRecordUpdates.InstrumentDescription.substring(0, 3)!="...") 
	{
		mRecordUpdates = caplin.core.MapUtility.clone(mRecordUpdates);
		mRecordUpdates.MagicInstrumentDescription = mRecordUpdates.InstrumentDescription;
		mRecordUpdates.InstrumentDescription = "";
	}
	return mRecordUpdates;
};
