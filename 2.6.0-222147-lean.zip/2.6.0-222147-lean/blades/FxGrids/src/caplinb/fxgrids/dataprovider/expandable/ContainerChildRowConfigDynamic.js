caplin.namespace("caplinb.fxgrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
	this.m_mIdToContainer = {};
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.INDEX = 2;

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.getContainerToExpanded = function(mRowData, sRendererId)
{
	caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.INDEX++;
	if (!this.m_mIdToContainer[sRendererId]) {
		this.m_mIdToContainer[sRendererId] = '/TEST/CONTAINER/Items5Grow' + caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.INDEX + this.randomString(); 
	}
	return this.m_mIdToContainer[sRendererId];
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return oGridColumnModel.getRequiredFields();
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	if (mRecordUpdates && mRecordUpdates.InstrumentDescription && mRecordUpdates.InstrumentDescription.substring(0, 3)!="...") 
	{
		mRecordUpdates = caplin.core.MapUtility.clone(mRecordUpdates);
		mRecordUpdates.MagicInstrumentDescription = mRecordUpdates.InstrumentDescription;
		mRecordUpdates.InstrumentDescription = "";
	}
	return mRecordUpdates;
};

caplinb.fxgrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.randomString = function()
{
	var pChars = 'ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
    var nLength = 5;
    
    var sString = '';
    for (var i = 0; i < nLength; i++) {
        sString += pChars[Math.floor(Math.random() * pChars.length)];
    }
    return sString;
};
