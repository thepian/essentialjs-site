caplin.namespace("workbench.tradelist");

caplin.include("caplin.event.Hub");

workbench.tradelist.Main = function(eWatchlistContainer, eTradeListPanel, eTradeListGrid) {
	var oHub = new caplin.event.Hub(caplin.event.registry);
	
	var oWatchlistModel = workbench.tradelist.WatchlistModel;
	var oWatchlistView = new workbench.tradelist.WatchlistView(oHub);
	oWatchlistView.renderLaunchButtonTo(eWatchlistContainer, "Create Trade List");
	oWatchlistView.renderTradesTo(eWatchlistContainer, oWatchlistModel.getWatchListHeaders(), oWatchlistModel.getWatchListGridRows());
	
	var sTradeListAddSubject = "ui.tradelist.add";
	var oWorkbenchView = new workbench.tradelist.WorkbenchView(oHub, sTradeListAddSubject, eTradeListPanel, eTradeListGrid);
	new workbench.tradelist.WorkbenchController(oHub, oWatchlistView, oWorkbenchView, oWatchlistModel);
};