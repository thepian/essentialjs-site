caplin.namespace("workbench.tradelist");

workbench.tradelist.WatchlistView = function(oHub) {
	this.m_oHub = oHub;
	this.m_pListeners = [];
};

workbench.tradelist.WatchlistView.prototype.renderLaunchButtonTo = function(eWatchlistContainer, sButtonText) {
	var eLaunchTradeListButton = document.createElement("button");
	eLaunchTradeListButton.innerHTML = sButtonText;
	var oSelf = this;
	eLaunchTradeListButton.onclick = function() {
		oSelf.m_oHub.publish("ui.tradelist.launch");		
	};
	eWatchlistContainer.appendChild(eLaunchTradeListButton);
};

workbench.tradelist.WatchlistView.prototype.renderTradesTo = function(eWatchlistContainer, pHeader, pTrades) {
	var eTable = document.createElement("table");
	eTable.border = "1";
	
	this._renderRow(eTable, pHeader);
	for(var i = 0; i < pTrades.length; i++){
		this._renderRow(eTable, pTrades[i]);
	}
	eWatchlistContainer.appendChild(eTable);
};

workbench.tradelist.WatchlistView.prototype._renderRow = function(eTable, pRowData) {
	var eTr = document.createElement('TR');					
	for(var i=0; i < pRowData.length; i++) {
		var eTd = document.createElement('TD');
		eTd.innerHTML = pRowData[i];
		eTr.appendChild(eTd);
	}
	eTable.appendChild(eTr);
};

workbench.tradelist.WatchlistView.prototype.displayResult = function(oTradeAfoSet) {
	var pAfos = oTradeAfoSet.getTradeAfos();
	for (var i = 0; i < pAfos.length; ++i) {
		var sAfo = "";
			for (var sField in pAfos[i]) {
				sAfo = sAfo + "," + sField + ":" + pAfos[i][sField];
			}
			caplin.core.Logger.log(caplin.core.LogLevel.INFO, "Trade Afo {0}: {1}",i, sAfo);
	}
};
