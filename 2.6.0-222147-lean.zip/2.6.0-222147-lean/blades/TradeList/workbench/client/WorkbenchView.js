caplin.namespace("workbench.tradelist");
caplin.include("caplinx.tradelist.util.TradeListNameGenerator", true);

//Place holder to actual Trade List
workbench.tradelist.WorkbenchView = function(oHub, sTradeListAddSubject, eTradeListPanel, eTradeListGridContainer) {
	this.m_oHub = oHub;
	this.m_eTradeListPanel = eTradeListPanel;
	this.m_eTradeListGridContainer = eTradeListGridContainer;
	//the tradelist injector subscribes onto this subject
	this.m_sTradeListAddSubject = sTradeListAddSubject;
};

workbench.tradelist.WorkbenchView.prototype.launch = function(pInstruments) {
	this._showPanel();
	var sTradeListName = caplinx.tradelist.util.TradeListNameGenerator.generate();
	var oPresentationModel = caplin.framework.ApplicationFactory.INSTANCE.getPresentationModel();
	oPresentationModel.setTradeListName(sTradeListName);
	oPresentationModel.setPostSubmitEventName("tradelist.sendInstruments");
	oPresentationModel.getFiAccounts();
	oPresentationModel.getT7SettlementDates();
	this.m_oHub.publish(this.m_sTradeListAddSubject, pInstruments);
};

workbench.tradelist.WorkbenchView.prototype.close = function() {
	this._hidePanel();
};

workbench.tradelist.WorkbenchView.prototype._hidePanel = function() {
	this.m_eTradeListPanel.style.display = 'none';
};

workbench.tradelist.WorkbenchView.prototype._showPanel = function() {
	this.m_eTradeListPanel.style.display = 'block';
};