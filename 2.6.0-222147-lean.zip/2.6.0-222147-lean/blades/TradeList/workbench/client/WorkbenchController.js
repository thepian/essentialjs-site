caplin.namespace("workbench.tradelist");

workbench.tradelist.WorkbenchController = function(oHub, oWatchlistView, oWorkbenchView, oWatchlistModel) {
	this.m_oHub = oHub;	
	this.m_oWatchlistModel = oWatchlistModel;
	this.m_oWatchlistView = oWatchlistView;
	this.m_oWorkbenchView = oWorkbenchView;
	
	this.m_oHub.subscribe("ui.tradelist.launch", this._onTriggerReceived, this);
	this.m_oHub.subscribe("ui.tradelist.close", this._onClose, this);
	this.m_oHub.subscribe("tradelist.sendInstruments", this._renderCreatedTrades, this);
};

workbench.tradelist.WorkbenchController.prototype._renderCreatedTrades = function(sSubject, oTradeAfoSet) {
	this.m_oWatchlistView.displayResult(oTradeAfoSet);
};

workbench.tradelist.WorkbenchController.prototype._onClose = function() {
	this.m_oWorkbenchView.close();
};

workbench.tradelist.WorkbenchController.prototype._onTriggerReceived = function() {
	var pInstruments = this._toInstrumentSubjects(this.m_oWatchlistModel.getWatchListGridRows());
	this.m_oWorkbenchView.launch(pInstruments);
};

workbench.tradelist.WorkbenchController.prototype._toInstrumentSubjects = function(pTrades) {
	var pIntruments = [];
	for ( var index = 0; index < pTrades.length; index++) {
		pIntruments.push(pTrades[index][0]);
	}
	return pIntruments;
};