caplin.namespace("workbench.tradelist");
caplin.include("caplinx.tradelist.afo.TradeAfo");

workbench.tradelist.WatchlistModel = function() {
	this.m_pGridContents = [];	
	var pWatchListContents = this._getGridRowModel(this.getWatchListGridRows());
	this.populateGridContents(pWatchListContents);
};

workbench.tradelist.WatchlistModel.INSTANCE = null;

workbench.tradelist.WatchlistModel.prototype.getWatchListHeaders = function() {
	return ['Subject', 
	        'Description',
	        'Coupon',
	        'Maturity Date', 
	        'Bid Yield',
	        'Bid Price', 
	        'Ask Price',
	        'Ask Yield', 
	        ];
};

workbench.tradelist.WatchlistModel.prototype.getWatchListGridRows = function() {
	return [ 
		['FI/Trade1','GS1 5.25 12/04/2015','11.0000','Oct 5 2014', '3.751', '112.543', '102.559', '3.742'],
		['FI/Trade2','GS2 6.25 12/04/2015','12.0000','Oct 6 2014', '3.752', '122.543', '102.559', '3.742'],
		['FI/Trade3','GS3 7.25 12/04/2015','13.0000','Oct 7 2014', '3.753', '132.543', '102.559', '3.742'],
		['FI/Trade4','GS4 8.25 12/04/2015','14.0000','Oct 8 2014', '3.754', '142.543', '102.559', '3.742'],
		['FI/Trade5','GS5 9.25 12/04/2015','15.0000','Oct 9 2014', '3.755', '152.543', '102.559', '3.742'],
		['FI/Trade6','GS6 1.25 12/04/2015','16.0000','Nov 1 2014', '3.756', '162.543', '102.559', '3.742'],
		['FI/Trade7','GS7 2.25 12/04/2015','17.0000','Nov 2 2014', '3.757', '172.543', '102.559', '3.742'],
		['FI/Trade8','GS8 3.25 12/04/2015','18.0000','Nov 3 2014', '3.758', '182.543', '102.559', '3.742'],
		['FI/Trade9','GS9 4.25 12/04/2015','19.0000','Nov 4 2014', '3.759', '192.543', '102.559', '3.742'],	
		['FI/Trade10','GS10 6.25 12/04/2015','21.0000','Nov 5 2014', '3.762', '202.543', '102.559', '3.742'],
		['FI/Trade11','GS11 7.25 12/04/2015','22.0000','Nov 6 2014', '3.761', '302.543', '102.559', '3.742'],
		['FI/Trade12','GS12 8.25 12/04/2015','23.0000','Nov 7 2014', '3.763', '402.543', '102.559', '3.742']
	]
};

workbench.tradelist.WatchlistModel.prototype._getGridRowModel = function(pSourceGridRows) {
	var pTradeListGridRows = [];
	for (var index = 0; index < pSourceGridRows.length; index++) {
		var mTradeListGridRow = {};
		mTradeListGridRow['subject'] = pSourceGridRows[index][0];
		mTradeListGridRow['Description'] = pSourceGridRows[index][1];
		mTradeListGridRow['CpnRate'] = pSourceGridRows[index][2];
		mTradeListGridRow['MaturityDate'] = pSourceGridRows[index][3];
		mTradeListGridRow['BidPrice'] = pSourceGridRows[index][5];
		mTradeListGridRow['AskPrice'] = pSourceGridRows[index][6];
		mTradeListGridRow['Amount'] = "";
		pTradeListGridRows.push(mTradeListGridRow);
	}	
	return pTradeListGridRows;
};

workbench.tradelist.WatchlistModel.prototype.populateGridContents = function(pWatchListContents) {
	for(var index = 0; index < pWatchListContents.length ; index++) {
		var mTradeListRow = pWatchListContents[index];
		mGridRow = {};
		for(var sFieldName in mTradeListRow) {
			mGridRow[sFieldName]= mTradeListRow[sFieldName];
		}
		this.m_pGridContents.push(mGridRow);
	}
};


workbench.tradelist.WatchlistModel.prototype.removeInstrument = function(sSubject) {
	for(var i = 0; i < this.m_pGridContents.length; i++) {
		if(this.m_pGridContents[i]['subject'] == sSubject) {
			this.m_pGridContents.splice(i, 1);
		}
	}
	return this.m_pGridContents;
};


workbench.tradelist.WatchlistModel.prototype.getGridContents = function() {
	return this.m_pGridContents;
};

caplin.singleton("workbench.tradelist.WatchlistModel");