SL4B_StreamingType6HTMLFile = new function(){var _transferDoc=null;
this.m_bDomainSet=false;this.onunload = function(){_transferDoc=null;CollectGarbage();};
this.loaded = function(){this.setDomain();
try {window.parent.SL4B_ConnectionProxy.getInstance().setResponseHttpRequest(null,this.getParameter("uniqueid"));}catch(e){alert("failed to set setResponseHttpRequest");}
_transferDoc=new ActiveXObject("htmlfile");_transferDoc.open();_transferDoc.write("<html><script>"+"document.domain='"+document.domain+"';"+"</script></html>");_transferDoc.close();var ifrDiv=_transferDoc.createElement("div");
_transferDoc.body.appendChild(ifrDiv);_transferDoc.a=parent.a;_transferDoc.z=parent.z;ifrDiv.innerHTML="<iframe src='"+"/RTTP-TYPE5?X-RTTP-Type5-Pad-Length="+this.getParameter("X-RTTP-Type5-Pad-Length")+"&domain="+document.domain+"&connectiontype=6'></iframe>";window.onunload=this.onunload;};
this.stop = function(){if(_transferDoc!==null){
try {this._getIFrameFromTransferDoc().contentWindow.stop();}catch(e){}
}};
this._getIFrameFromTransferDoc = function(){return _transferDoc.body.firstChild.firstChild;
};
this.getParameter = function(A){var l_oMatch=window.location.search.match(new RegExp("[?&]"+A+"=([^&]*)"));
return ((l_oMatch==null) ? null : l_oMatch[1]);
};
this.setDomain = function(){if(!this.m_bDomainSet){var l_sCommonDomain=this.getParameter("domain");
if(l_sCommonDomain!=null){this.m_bDomainSet=true;document.domain=l_sCommonDomain;}}};
};
function stop(){SL4B_StreamingType6HTMLFile.stop();}
SL4B_StreamingType6HTMLFile.loaded();