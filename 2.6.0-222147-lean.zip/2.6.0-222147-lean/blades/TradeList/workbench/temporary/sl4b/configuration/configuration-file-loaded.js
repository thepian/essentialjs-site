function SL_HV(){SL4B_Accessor.getConfiguration().loaded();}
SL_HV();