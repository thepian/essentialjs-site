SL4B_ContributionFieldData = FieldData;

SL4B_Accessor.getStatistics = function(){
	return {
		getResponseQueueStatistics: function(){
			return new SL4B_ResponseQueueStatistics();
		}
	};
};

SL4B_Accessor.getRttpProvider = function(){
	return DummyRttpProvider;
};

//SL4B Stub Container Handler
function DummyRttpProvider(){
	this.m_mContainerUpdate = null;	
	this._resetState();
};

DummyRttpProvider.prototype.contribObject = function(source, sRttpChannelName, oContributionData){
	var oContainerUpdateData = this._resolveContainerData(oContributionData.getFieldMap());
	this._$setContainerUpdate(oContainerUpdateData);
};

DummyRttpProvider.prototype._resolveContainerData = function(mContribData) {
	var sPersonalGridId = mContribData["PersonalContainerId"];
	var sPersonalGridSubject = "/PERSONAL/CONTAINER/" + sPersonalGridId;
	var gridContents = {};
	if(mContribData["RemoveSubject"] != undefined && mContribData["RemoveSubject"]!= '') {
		gridContents = workbench.tradelist.WatchlistModel.removeInstrument(mContribData["RemoveSubject"]);
	}
	if(mContribData["AddSubject"] != undefined && mContribData["AddSubject"]!= '') {
		gridContents = workbench.tradelist.WatchlistModel.getGridContents();
	}
	
	var mContainerData = { 
			subject: sPersonalGridSubject,
			status: "statusOk",
			contents: gridContents
	};
	return mContainerData;
};

DummyRttpProvider.prototype.getObjects = function(source, sRttpChannelName){
};

DummyRttpProvider.prototype.getObject = function(source, sRttpChannelName){
};

DummyRttpProvider.prototype.addConnectionListener = function(source){
};

DummyRttpProvider.prototype._$setContainerUpdate = function(mContainerUpdate){
	this.m_mContainerUpdate = mContainerUpdate;
	this._sendUpdatesOnTimeout();
};

DummyRttpProvider.prototype._resetState = function(){
	this.m_pSubscribers = [];
	this.m_sContainerName = null;
	this.m_mWindow = null;
};

DummyRttpProvider.prototype.getContainer = function(oSubscriber, sContainerName, sFieldList, nWindowStart, nWindowEnd){
	this.m_pSubscribers.push(oSubscriber);
	this.m_sContainerName = sContainerName;
	this._setWindowSize(nWindowStart, nWindowEnd);
	
	this._sendUpdatesOnTimeout();
	return {
		
	};
};

DummyRttpProvider.prototype._setWindowSize = function(nWindowStart, nWindowEnd){
	this.m_mWindow = {
		start: nWindowStart,
		end: nWindowEnd
	};
};

DummyRttpProvider.prototype._sendUpdatesOnTimeout = function() {
	if (this._doesSubscriptionExist()) {
		var oSelf = this;
		setTimeout(function() { oSelf._sendUpdates(); }, 100);	
	}
};

DummyRttpProvider.prototype._doesSubscriptionExist = function(){
	return (this.m_pSubscribers.length != 0);
};

DummyRttpProvider.prototype._sendUpdates = function(){
	if (this._doesContainerExist())	{
		this._sendContainerUpdate();
	} else {
		this._sendContainerError();
	}
};

DummyRttpProvider.prototype._doesContainerExist = function(){
	if (this.m_mContainerUpdate == null || this.m_sContainerName != this.m_mContainerUpdate["subject"])	{
		return false;
	}
	if (this.m_mContainerUpdate["status"] == "objectNotFound" || this.m_mContainerUpdate["status"] == "objectReadDenied"){
		return false;
	}
	return true;
};

DummyRttpProvider.prototype._sendContainerUpdate = function(){
	var mContainerUpdateData = { structureChanges: [], orderChanges: [], recordUpdates: [] };
	mContainerUpdateData = this._populateContainerUpdateData(mContainerUpdateData);
	this._sendContainerUpdateData(mContainerUpdateData);
	
};

DummyRttpProvider.prototype._populateContainerUpdateData = function(mContainerUpdateData){
	var pContents = this.m_mContainerUpdate["contents"];
	for (var i = 0, nLength = pContents.length; i < nLength; ++i) {
		mContainerUpdateData = this._populateContainerUpdateDataForSingleRow(mContainerUpdateData, pContents[i], i);
	}
	return mContainerUpdateData;
};

DummyRttpProvider.prototype._populateContainerUpdateDataForSingleRow = function(mContainerUpdateData, mContentData, nIndex){
	mContainerUpdateData["structureChanges"].push(this._createStructureChange(mContentData));
	mContainerUpdateData["orderChanges"].push(this._createOrderChange(mContentData, nIndex));
	mContainerUpdateData["recordUpdates"].push(this._createRecordUpdate(mContentData));
	return mContainerUpdateData;
};

DummyRttpProvider.prototype._createStructureChange = function(mContentData) {
	return new SL4B_ContainerStructureChange(mContentData["subject"], "222", true);
};

DummyRttpProvider.prototype._createOrderChange = function(mContentData, nIndex){
	var sObjectNumber = "000" + (nIndex + 1);
	return new SL4B_ContainerOrderChange(mContentData["subject"], sObjectNumber, nIndex);
};

DummyRttpProvider.prototype._createRecordUpdate = function(mContentData){
	var mRecordUpdate = {
		subject: mContentData["subject"],
		fieldData: this._createFieldData(mContentData),
		isImage: true
	};
	return mRecordUpdate;
};

DummyRttpProvider.prototype._createFieldData = function(mData){
	return { 
			getFieldMap: function() { return mData;} 
		};
};

DummyRttpProvider.prototype.removeSubscriber = function(oSubscriber) {
	var pNewSubscribers = this.m_pSubscribers;
	for(var i = 0; i < this.m_pSubscribers.length; i++) {
		if(this.m_pSubscribers[i] === oSubscriber) {
			this.m_pSubscribers[i] = undefined;
			var pNewSubscribers = this.m_pSubscribers.splice(i, 1);
		}
	}
	this.m_pSubscribers = pNewSubscribers;
};

DummyRttpProvider.prototype._sendContainerUpdateData = function(mContainerUpdateData) {
	for(var i = 0, nLength = this.m_pSubscribers.length; i < nLength; ++i) {
		if(this.m_pSubscribers[i]) {
			this.m_pSubscribers[i].structureMultiChange(this.m_sContainerName, mContainerUpdateData["structureChanges"], mContainerUpdateData["orderChanges"], mContainerUpdateData["structureChanges"].length);
		}
	}
	
	var pRecordUpdates = mContainerUpdateData["recordUpdates"];
	for (var i = 0, nLength = pRecordUpdates.length; i < nLength; ++i) {
		var mRecordUpdate = pRecordUpdates[i];
		for(var j = 0, n = this.m_pSubscribers.length; j < n; ++j) {
			if(this.m_pSubscribers[j]) {
				this.m_pSubscribers[j].recordMultiUpdated(mRecordUpdate["subject"], mRecordUpdate["fieldData"], mRecordUpdate["isImage"]);
			}
		}
	}
};

DummyRttpProvider.prototype._sendContainerError = function(){
	if (this.m_mContainerUpdate == null || this.m_sContainerName != this.m_mContainerUpdate["subject"] || this.m_mContainerUpdate["status"] == "objectNotFound"){
		for(var i = 0, nLength = this.m_pSubscribers.length; i < nLength; ++i) {
			this.m_pSubscribers[i].objectNotFound(this.m_sContainerName);
		}
	} else {
		for(var i = 0, nLength = this.m_pSubscribers.length; i < nLength; ++i) {
			this.m_pSubscribers[i].objectReadDenied(this.m_sContainerName);
		}
	}
};

DummyRttpProvider.prototype.setContainerWindow = function(sContainerKey, nWindowStart, nWindowEnd){
	this._setWindowSize(nWindowStart, nWindowEnd);
	this._sendUpdatesOnTimeout();
};

DummyRttpProvider.prototype.clearContainerWindow = function(sContainerKey){
	this._setWindowSize(undefined, undefined);
	this._sendUpdatesOnTimeout();
};

DummyRttpProvider.prototype.removeContainer = function(oSubscriber, sContainerKey) {
	this._resetState();
};

DummyRttpProvider = new DummyRttpProvider();

SL4B_ConnectionProxy.getInstance = function(){
	return {
		getResponseQueueStatistics: function() {
			return new SL4B_ResponseQueueStatistics();
		}
	};
};

SL4B_AbstractSubscriber.prototype.initialise = function(){
	this.ready();
};
