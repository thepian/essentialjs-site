caplin.namespace("caplinx.tradelist.view.command");

caplinx.tradelist.view.command.ToggleTradeCommand = function(){
};

caplinx.tradelist.view.command.ToggleTradeCommand.prototype.ASKPRICE_ID = "askPrice";
caplinx.tradelist.view.command.ToggleTradeCommand.prototype.BIDPRICE_ID = "bidPrice";

caplinx.tradelist.view.command.ToggleTradeCommand.prototype.execute = function(oGridColumnModel, oForm, bBuyTradeType) {
	if(bBuyTradeType) 
		this._toggleTrade(oForm, this.ASKPRICE_ID, this.BIDPRICE_ID, oGridColumnModel, caplinx.tradelist.TradeListConstants.BUY_CLASS, caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS);
	else  
		this._toggleTrade(oForm, this.BIDPRICE_ID, this.ASKPRICE_ID, oGridColumnModel, caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS, caplinx.tradelist.TradeListConstants.SELL_CLASS);
};

caplinx.tradelist.view.command.ToggleTradeCommand.prototype._toggleTrade = function(oForm, showColumnId, hideColumnId, oGridColumnModel, sBuyClass, sSellClass){
	this._toggleTradePrice(showColumnId, hideColumnId, oGridColumnModel);
	this._toggleTradeButtons(oForm, sBuyClass, sSellClass);
};

caplinx.tradelist.view.command.ToggleTradeCommand.prototype._toggleTradePrice = function(showColumnId, hideColumnId, oGridColumnModel){
	var nColumnIndex = oGridColumnModel.getColumnById(hideColumnId).getColumnIndex();
	oGridColumnModel.replaceColumn(nColumnIndex, showColumnId);	
};

caplinx.tradelist.view.command.ToggleTradeCommand.prototype._toggleTradeButtons = function(oForm, sBuyClass, sSellClass){
	oForm.set(caplinx.tradelist.TradeListConstants.SHOW_BUY,sBuyClass);
	oForm.set(caplinx.tradelist.TradeListConstants.SHOW_SELL, sSellClass);
};