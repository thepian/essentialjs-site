caplin.namespace("caplinx.tradelist.view.decorator");

caplin.include("caplin.grid.GridViewListener", true);

caplinx.tradelist.view.decorator.DefaultValueDecorator = function(mConfig) {
    this.m_sColumnId = mConfig["column"];
    this.m_sDefaultValue = mConfig["defaultValue"];
};

caplin.implement(caplinx.tradelist.view.decorator.DefaultValueDecorator, caplin.grid.decorator.GridDecorator);
caplin.implement(caplinx.tradelist.view.decorator.DefaultValueDecorator, caplin.grid.GridViewListener);
caplin.implement(caplinx.tradelist.view.decorator.DefaultValueDecorator, caplin.grid.GridDataProviderSnapshotListener);

caplinx.tradelist.view.decorator.DefaultValueDecorator.prototype.setGridView = function(oGridView) {
    this.m_oGridView = oGridView;
    this.m_sFieldId = this._getFieldNameFromColumnId(oGridView.getGridColumnModel(), this.m_sColumnId);
    oGridView.addGridViewListener(this); 
};

caplinx.tradelist.view.decorator.DefaultValueDecorator.prototype._getFieldNameFromColumnId = function(oGridColumnModel, sColumnId) {
    var oGridColumn = oGridColumnModel.getColumnById(sColumnId);
	return oGridColumn.getPrimaryFieldName();
};

caplinx.tradelist.view.decorator.DefaultValueDecorator.prototype.onAllRowsReceived = function() {
	this._setDefaultValue();
};

caplinx.tradelist.view.decorator.DefaultValueDecorator.prototype._setDefaultValue = function() {
	this.m_oGridView.getGridRowModel()._$getDataProvider().fetchSnapshot(this);
};

caplinx.tradelist.view.decorator.DefaultValueDecorator.prototype.onGridSnapshotAvailable = function(mGridSnapshot) {
	var oGridRowModel = this.m_oGridView.getGridRowModel();
	for (var sSubject in mGridSnapshot) {
		if( sSubject != 'remove') {
			var mRowData = mGridSnapshot[sSubject];
			if(mRowData[this.m_sFieldId] == null || mRowData[this.m_sFieldId] == "") {
				var defaultFieldValue = [];
				defaultFieldValue[this.m_sFieldId] = this.m_sDefaultValue;
				oGridRowModel.setRowDataBySubject(sSubject, defaultFieldValue);
			}
		}
	}
};