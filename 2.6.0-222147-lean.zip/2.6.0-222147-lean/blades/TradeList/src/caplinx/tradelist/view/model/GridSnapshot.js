/**
 * @author admin
 * Responsibility - GridSnapshot - consists of the GridRowModel and GridColumnModel for the tradelist panel
 * 
 */
caplin.namespace("caplinx.tradelist.view.model");

caplin.include("caplin.core.Observable");
caplin.include("caplin.grid.GridDataProviderSnapshotListener");

caplinx.tradelist.view.model.GridSnapshot = function(oRowModel, oColumnModel) {
	this.m_oRowModel = oRowModel;
	this.m_oColumnModel = oColumnModel;
	this.m_oObservable = new caplin.core.Observable();
};

caplin.implement(caplinx.tradelist.view.model.GridSnapshot, caplin.grid.GridDataProviderSnapshotListener);

caplinx.tradelist.view.model.GridSnapshot.prototype.getRowModel = function() {
	return this.m_oRowModel;
};

caplinx.tradelist.view.model.GridSnapshot.prototype.getColumnModel = function() {
	return this.m_oColumnModel;
};

caplinx.tradelist.view.model.GridSnapshot.prototype.addGridRowModelListener = function(oGridRowModelListener) {
	this.m_oRowModel.addRowModelListener(oGridRowModelListener);
};

caplinx.tradelist.view.model.GridSnapshot.prototype.getRowData = function(nIndex) {
	return this.m_oRowModel.getRowData(nIndex);
};

caplinx.tradelist.view.model.GridSnapshot.prototype.getVisibleRowRange = function() {
	return this.m_oRowModel.getRowRangeSize();
};

caplinx.tradelist.view.model.GridSnapshot.prototype.getTotalRowSize = function() {
	return this.m_oRowModel.getSize();
};

caplinx.tradelist.view.model.GridSnapshot.prototype.getAllRecords = function() {
	var oDataProvider = this.m_oRowModel._$getDataProvider();
	oDataProvider.fetchSnapshot(this);
};

caplinx.tradelist.view.model.GridSnapshot.prototype.onGridSnapshotAvailable = function(mGridSnapshot) {
	this.m_oObservable.notifyObservers("onGridDataReceived", [mGridSnapshot]);
};

caplinx.tradelist.view.model.GridSnapshot.prototype.addGridSnapshotListener = function(oListener) {
	this.m_oObservable.addObserver(oListener);
};

caplinx.tradelist.view.model.GridSnapshot.prototype.removeGridSnapshotListener = function(oListener) {
	this.m_oObservable.removeObserver(oListener);
};
