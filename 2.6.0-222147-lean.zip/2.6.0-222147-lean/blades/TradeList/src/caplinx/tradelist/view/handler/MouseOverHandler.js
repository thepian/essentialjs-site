caplin.namespace("caplinx.tradelist.view.handler");

caplin.include("caplin.element.Handler", true);

/**
 * @deprecated
 * @class
 * 
 * Applies the specified CSS class while the control is being edited by the user.
 *
 * @attribute class  CSS class to apply
 * 
 * @extends caplin.element.Handler
 * @singleton
 */
caplinx.tradelist.view.handler.MouseOverHandler = function() {
};

caplin.extend(caplinx.tradelist.view.handler.MouseOverHandler, caplin.element.Handler);

caplinx.tradelist.view.handler.MouseOverHandler.prototype.onmouseover = function(oDomEvent, oRenderer, mAttributes) {
	this._setElementClassNameIfNotDisabled(oRenderer, "button-hover");
};

caplinx.tradelist.view.handler.MouseOverHandler.prototype.onmouseout = function(oDomEvent, oRenderer, mAttributes) {
	this._setElementClassNameIfNotDisabled(oRenderer, "button");
};


caplinx.tradelist.view.handler.MouseOverHandler.prototype._setElementClassNameIfNotDisabled = function(oRenderer, className) {
	var oControl = oRenderer.getControl();
   	var eControlElement = oControl.getElement();
   	for(var index = 0; index < eControlElement.childNodes.length; index++) {
   		var node = eControlElement.childNodes[index];
   		if(node.nodeType == 1 && !node.disabled) {
   			node.className = className;
   		}
   	}
};


/**
 * @private
 */
caplinx.tradelist.view.handler.MouseOverHandler.prototype.toString = function() {
	return "caplinx.tradelist.view.handler.MouseOverHandler";
};

caplin.singleton("caplinx.tradelist.view.handler.MouseOverHandler");
