/**
 * EditableGridDecorator enables editing a grid row field 
 * Responsibility:
 * on renderer event (change event) updates the row data with the specified field value.
 * 
 */

caplin.namespace("caplinx.tradelist.view.decorator");

caplin.include("caplin.grid.decorator.GridDecorator", true);
caplin.include("caplin.element.RendererEventListener", true);

caplinx.tradelist.view.decorator.EditableGridDecorator = function(mConfig) {
    this.m_oGridView = null;
    this.m_mConfig = mConfig;
};

caplin.implement(caplinx.tradelist.view.decorator.EditableGridDecorator, caplin.grid.decorator.GridDecorator);
caplin.implement(caplinx.tradelist.view.decorator.EditableGridDecorator, caplin.element.RendererEventListener);

caplinx.tradelist.view.decorator.EditableGridDecorator.prototype.setGridView = function(oGridView) {
    this.m_oGridView = oGridView;
    oGridView.addRendererEventListener(this);
};

caplinx.tradelist.view.decorator.EditableGridDecorator.prototype.onContainerHtmlRendered = function() {
};

caplinx.tradelist.view.decorator.EditableGridDecorator.prototype.onRendererEvent = function(oRenderer, sRendererEvent, mAttributes) {
	if (sRendererEvent === caplinx.tradelist.TradeListConstants.TRADELIST_EDIT_EVENT && oRenderer.getName() != undefined) {
		var sSubjectId = oRenderer.getNamespace();
		var mRowData = {};
		mRowData[oRenderer.getName()] = oRenderer.getValue();		
		this.m_oGridRowModel = this.m_oGridView.getGridRowModel();
		var nIndex = this.m_oGridRowModel.getIndexBySubject(sSubjectId);
		//adds field to rowdata
		this.m_oGridRowModel.setRowData(nIndex, mRowData);		
	}
};
