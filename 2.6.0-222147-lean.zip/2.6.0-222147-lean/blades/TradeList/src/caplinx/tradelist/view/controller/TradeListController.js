caplin.namespace("caplinx.tradelist.view.controller");

caplin.include("caplinx.form.BaseFormController", true);
caplin.include("caplinx.tradelist.view.TradeListPresentationModel");
caplin.include("caplinx.tradelist.view.command.SubmitTradeListCommand");
caplin.include("caplinx.tradelist.view.command.ToggleTradeCommand");
caplin.include("caplinx.form.Form");
caplin.include("caplin.event.Hub");

caplinx.tradelist.view.controller.TradeListController = function() {
};

caplin.extend(caplinx.tradelist.view.controller.TradeListController, caplinx.form.BaseFormController);

caplinx.tradelist.view.controller.TradeListController.prototype.setTradeListName = function(sTradeListName) {
	this.m_sTradeListName = sTradeListName;
};

caplinx.tradelist.view.controller.TradeListController.prototype.setPostSubmitEventName = function(sPostSubmitEventName) {
	this.m_sPostSubmitEventName = sPostSubmitEventName;
};

caplinx.tradelist.view.controller.TradeListController.prototype.setFormData = function(oFormData) {
	var oHub = new caplin.event.Hub(caplin.event.registry);
	this.m_oPresentationModel = new caplinx.tradelist.view.TradeListPresentationModel(oHub, this._createCommandFactory());
	var oForm = new caplinx.form.Form(this.m_oPresentationModel);
	oForm.setFormData(oFormData);
	this.m_oPresentationModel.initialise(oForm, this.m_sTradeListName, this.m_sPostSubmitEventName);
	this.bindViewToProperties(oFormData, oForm);
	
	//hack to make blade work without caplintrader impl
	if (caplin.framework.ApplicationFactory.INSTANCE.setPresentationModel) 	{
		caplin.framework.ApplicationFactory.INSTANCE.setPresentationModel(this.m_oPresentationModel);
	} 
	caplinx.form.BaseFormController.call(this, oForm);
};

caplinx.tradelist.view.controller.TradeListController.prototype._createCommandFactory = function() {
	var m_mCommandFactory = {};
	m_mCommandFactory[caplinx.tradelist.TradeListConstants.SUBMIT_TRADELIST] = new caplinx.tradelist.view.command.SubmitTradeListCommand();
	m_mCommandFactory[caplinx.tradelist.TradeListConstants.TOGGLE_TRADETYPE] = new caplinx.tradelist.view.command.ToggleTradeCommand();
	return m_mCommandFactory;
};

caplinx.tradelist.view.controller.TradeListController.prototype.initializeView = function() {
	var tradeListNames = Ext.query("form input[name=tradeListName]");
	if (tradeListNames.length > 0) {
		tradeListNames[tradeListNames.length-1].select();
	}
	if(this.m_oPresentationModel) {
		this.m_oPresentationModel.getFiAccounts();
		this.m_oPresentationModel.getT7SettlementDates();
	}
	
};