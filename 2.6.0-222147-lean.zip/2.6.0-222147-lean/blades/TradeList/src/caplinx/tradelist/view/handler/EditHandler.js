caplin.namespace("caplinx.tradelist.view.handler");

caplin.include("caplin.element.Handler", true);

/**
 * @deprecated
 * @class
 * 
 * Applies the specified CSS class while the control is being edited by the user.
 *
 * @attribute class  CSS class to apply
 * 
 * @extends caplin.element.Handler
 * @singleton
 */
caplinx.tradelist.view.handler.EditHandler = function() {
};

caplin.extend(caplinx.tradelist.view.handler.EditHandler, caplin.element.Handler);

caplinx.tradelist.view.handler.EditHandler.prototype.onfocus = function(oDomEvent, oRenderer, mAttributes) {
	var sClass = mAttributes["class"];
	this._highlight(oRenderer, sClass);
};

caplinx.tradelist.view.handler.EditHandler.prototype.onblur = function(oDomEvent, oRenderer, mAttributes) {
	var sClass = mAttributes["class"];
	this._unhighlight(oRenderer, sClass);
};

caplinx.tradelist.view.handler.EditHandler.prototype.onkeydown = function(oDomEvent, oRenderer, mAttributes) {
	if (this._isBlurKeystroke(oDomEvent)) {
		var sClass = mAttributes["class"];
		this._unhighlight(oRenderer, sClass);
	}
};

caplinx.tradelist.view.handler.EditHandler.prototype._highlight = function(oRenderer, sClass) {
	var oControl = oRenderer.getControl(oRenderer);
	oControl.addClass(sClass);			
	oControl.refresh();
};

caplinx.tradelist.view.handler.EditHandler.prototype._unhighlight = function(oRenderer, sClass) {
	var oControl = oRenderer.getControl();
	oControl.removeClass(sClass);			
	oControl.refresh();
};

/**
 * @private
 */
caplinx.tradelist.view.handler.EditHandler.prototype._isTextKey = function(nKeyCode) {
	return nKeyCode == 8
	    || nKeyCode >= 46 && nKeyCode <= 90
        || nKeyCode >= 96 && nKeyCode <= 111
        || nKeyCode >= 186 && nKeyCode <= 223;
};

/**
 * @private
 */
caplinx.tradelist.view.handler.EditHandler.prototype._isBlurKeystroke = function(oDomEvent) {
	return oDomEvent.keyCode == 13 || oDomEvent.keyCode == "\r".charCodeAt(0) || oDomEvent.keyCode == "\t".charCodeAt(0);
};

/**
 * @private
 */
caplinx.tradelist.view.handler.EditHandler.prototype.toString = function() {
	return "caplinx.tradelist.view.handler.EditHandler";
};

caplin.singleton("caplinx.tradelist.view.handler.EditHandler");
