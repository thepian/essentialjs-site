caplin.namespace("caplinx.tradelist.afo");

caplinx.tradelist.afo.TradeAfoSet = function() {
	this.m_pTradeAfos = [];	
};

caplinx.tradelist.afo.TradeAfoSet.prototype.add = function(oTradeAfo) {
	this.m_pTradeAfos.push(oTradeAfo);
};

caplinx.tradelist.afo.TradeAfoSet.prototype.getTradeAfos = function() {
	return this.m_pTradeAfos;
};


