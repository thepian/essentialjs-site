ToggleTradeCommandTest = TestCase("ToggleTradeCommandTest");

ToggleTradeCommandTest.prototype.setUp = function() {
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	this.m_oCommand = new caplinx.tradelist.view.command.ToggleTradeCommand();
	this.m_oColumnModel = mock(caplin.grid.GridColumnModel);
	this.m_oForm =new caplinx.form.Form();
};

ToggleTradeCommandTest.prototype.tearDown = function() {
	Mock4JS.verifyAllMocks();
};

ToggleTradeCommandTest.prototype.testItShowsAskPriceColumnAndToggleTradeTypeButtonsWhenTradeTypeIsBuy = function() {
	
	var nBidPriceColumnIndex = 1;
	var oBidPriceColumn = {'getColumnIndex' : function() { return nBidPriceColumnIndex;}};
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.SHOW_BUY, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.SHOW_SELL, caplinx.tradelist.TradeListConstants.NAMESPACE, "sell");
	
	//expectations
	this.m_oColumnModel.expects(once()).getColumnById(this.m_oCommand.BIDPRICE_ID).will(returnValue(oBidPriceColumn));
	this.m_oColumnModel.expects(once()).replaceColumn(nBidPriceColumnIndex, this.m_oCommand.ASKPRICE_ID);
	
	//when
	this.m_oCommand.execute(this.m_oColumnModel.proxy(), this.m_oForm, true);
	
	//then
	this.m_oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.SHOW_BUY).shouldBe(caplinx.tradelist.TradeListConstants.BUY_CLASS);	
	this.m_oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.SHOW_SELL).shouldBe(caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS);	
};

ToggleTradeCommandTest.prototype.testItShowsBidPriceColumnAndToggleTradeTypeButtonsWhenTradeTypeIsSell = function() {
	
	var nAskPriceColumnIndex = 1;
	var oBidPriceColumn = {'getColumnIndex' : function() { return nAskPriceColumnIndex;}};
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.SHOW_BUY, caplinx.tradelist.TradeListConstants.NAMESPACE, "buy");
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.SHOW_SELL, caplinx.tradelist.TradeListConstants.NAMESPACE, "");

		
	//expectations
	this.m_oColumnModel.expects(once()).getColumnById(this.m_oCommand.ASKPRICE_ID).will(returnValue(oBidPriceColumn));
	this.m_oColumnModel.expects(once()).replaceColumn(nAskPriceColumnIndex, this.m_oCommand.BIDPRICE_ID);
	
	//when
	this.m_oCommand.execute(this.m_oColumnModel.proxy(), this.m_oForm, false);
	
	//then
	this.m_oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.SHOW_BUY).shouldBe(caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS);	
	this.m_oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.SHOW_SELL).shouldBe(caplinx.tradelist.TradeListConstants.SELL_CLASS);	

};

