/**
 * @author ADMIN
 */
SL4B_AbstractSubscriber = function() {};
SL4B_AbstractSubscriber.prototype.initialise = function() {};