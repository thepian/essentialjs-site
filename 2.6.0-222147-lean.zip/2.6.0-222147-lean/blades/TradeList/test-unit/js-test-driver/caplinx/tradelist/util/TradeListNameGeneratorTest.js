TradeListNameGeneratorTest = TestCase("TradeListNameGeneratorTest");

TradeListNameGeneratorTest.prototype.setUp = function() {
	
};

TradeListNameGeneratorTest.prototype.tearDown = function(){
	
};

TradeListNameGeneratorTest.prototype.testItShouldGenerateUniqueName = function() {
	//given
	var sNameOne = caplinx.tradelist.util.TradeListNameGenerator.generate();
	
	//when
	var sNameTwo = caplinx.tradelist.util.TradeListNameGenerator.generate();
	
	//then
	assertNotEquals(sNameOne, sNameTwo);
	
};
