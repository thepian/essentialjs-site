/**
 * @author ADMIN
 */

ConditionalInitialValueDecoratorTest = TestCase("ConditionalInitialValueDecoratorTest");


ConditionalInitialValueDecoratorTest.prototype.setUp = function(){
	Mock4JS.addMockSupport(window);
	this.m_mConfig = { column : "tradeAmount" ,
					subscribeTo : "askSize|bidSize",
					whenColumnVisibile : "columnOne|columnTwo"
				};
	this.m_oDecorator = new caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator(this.m_mConfig);
	
};

ConditionalInitialValueDecoratorTest.prototype.tearDown = function(){
	Mock4JS.verifyAllMocks();
};


ConditionalInitialValueDecoratorTest.prototype.testItThrowsExceptionWhenInvalidConfiguration = function(){
	//given
	this.m_mConfig = {column : "tradeAmount" ,
				subscribeTo : "askSize",
				whenColumnVisibile:"columnOne|columnTwo"};
	
	try{
		//when
		new caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator(this.m_mConfig);
		fail("Should have thrown exception");
	} catch(e) {
		//then
		assertSame("Invalid Configuration", e.getMessage());
	}
	
};

ConditionalInitialValueDecoratorTest.prototype.testItSetsFieldNameFromColumn = function(){
	//given
	var oMockGridView = mock(caplin.grid.GridView);
	var oGridView = oMockGridView.proxy();
	var oMockGridColumnModel = mock(caplin.grid.GridColumnModel);
	var oGridColumnModel = oMockGridColumnModel.proxy();
	var oMockGridColumn = mock(caplin.grid.GridColumn);
	var oGridColumn = oMockGridColumn.proxy();
	
	//stubs
	oMockGridView.stubs().addGridViewListener(ANYTHING);
	oMockGridView.stubs().getGridRowModel();
	oMockGridView.stubs().getGridColumnModel().will(returnValue(oGridColumnModel));
	oMockGridColumnModel.stubs().addColumnModelListener(ANYTHING);
	
	//expectations
	oMockGridColumnModel.expects(once()).getColumnById(this.m_mConfig["column"]).will(returnValue(oGridColumn));
	oMockGridColumn.expects(once()).getPrimaryFieldName().will(returnValue("Amount"));
	
	//when
	this.m_oDecorator.setGridView(oGridView);
	
	//then
	assertEquals(this.m_oDecorator.m_sFieldName, "Amount");
		
};

ConditionalInitialValueDecoratorTest.prototype.testItMapsTheVisibleColumnsToTheSubscriberFields = function(){
	//given
	var oMockGridView = mock(caplin.grid.GridView);
	var oGridView = oMockGridView.proxy();
	var oMockGridColumnModel = mock(caplin.grid.GridColumnModel);
	var oGridColumnModel = oMockGridColumnModel.proxy();
	var oMockGridColumn = mock(caplin.grid.GridColumn);
	var oGridColumn = oMockGridColumn.proxy();
	
	//stubs
	oMockGridView.stubs().getGridRowModel();
	oMockGridView.stubs().getGridColumnModel().will(returnValue(oGridColumnModel));
	oMockGridColumnModel.stubs().getColumnById(ANYTHING).will(returnValue(oGridColumn));
	oMockGridColumn.stubs().getPrimaryFieldName();

	oMockGridColumnModel.stubs().addColumnModelListener(ANYTHING);
	oMockGridView.stubs().addGridViewListener(ANYTHING);
	
	//when
	this.m_oDecorator.setGridView(oGridView);
	
	//then
	assertEquals("askSize", this.m_oDecorator.m_mColumnFieldsMap["columnOne"]);
	assertEquals("bidSize", this.m_oDecorator.m_mColumnFieldsMap["columnTwo"]);
		
};
	