caplin.namespace("caplinx.preferences.util");

caplin.include("caplinx.preferences.util.PreferencesAdaptor");

caplinx.preferences.util.WebcentricAdaptor = function() {
	
};


caplinx.preferences.util.WebcentricAdaptor.prototype.save = function(mPreferences)
{
	var preferences = {};
	Application.setPreferences(mPreferences);
	if (mPreferences.locale) {
		this.createCookie("locale", mPreferences.locale, 365);
	}
	Application.savePreferences(false);
};


caplinx.preferences.util.WebcentricAdaptor.prototype.getPreferences = function()
{
	return Application.getPreferences();
};

/**
 * 
 * Any attributes set in the mPreferences object passed in will be set in the Webcentric preferences object
 * which is saved on logout.
 * 
 * @param {Object} mPreferences map of preference name to preference value
 */
caplinx.preferences.util.WebcentricAdaptor.prototype.setPreferences = function(mPreferences)
{
	return Application.setPreferences(mPreferences);
};

caplinx.preferences.util.WebcentricAdaptor.prototype.handleViewReady = function(event) {
	//Gather values from cookies, prefs and page load
	var cookieValue = this.readCookie("locale");
	var mPreferences = Application.getPreferences();
	var sSavedLocalePreference = mPreferences.locale;
	var oTranslator = caplin.i18n.getTranslator();
	var sLocale = oTranslator.getLocale();

	if (this.readCookie("locale") == "undefined") {
		this.createCookie("locale",sLocale,365);
	}

	var mLocalizationPreferences = {};
	mLocalizationPreferences["dateFormat"] = mPreferences.dateFormat;
	var sNumberFormat = mPreferences.numberFormat;
	if (sNumberFormat)
	{
		mLocalizationPreferences["thousandsSeparator"] = sNumberFormat.charAt(0);
		mLocalizationPreferences["decimalRadixCharacter"] = sNumberFormat.charAt(1);
	}
	oTranslator.setLocalizationPreferences(mLocalizationPreferences);
	
	//allow locale param override and ignore preferences
	if (document.location.search && document.location.search.indexOf("locale") > -1) {
		return;
	}
	
	//if the locale has been changed on the login page then set the user's preference to
	//match the new locale
	if (this.readCookie("localeChanged")) {
		this.createCookie("locale", sLocale, 365);
		this.eraseCookie("localeChanged");
		this.setPreferences({locale: sLocale});
	}
	//If the page has loaded in a locale that doesn't match the user's preference, 
	//then set the user's cookie to their prefs locale and reload
	else if (mPreferences.locale && mPreferences.locale != oTranslator.getLocale()) {
		//as this only happens at page load time, release the window unload check.
		Application.logout = true;
		this.createCookie("locale", mPreferences.locale, 100);
		document.location.reload();
	}
};

caplinx.preferences.util.WebcentricAdaptor.prototype.createCookie = function(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
};

caplinx.preferences.util.WebcentricAdaptor.prototype.readCookie = function(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
};

caplinx.preferences.util.WebcentricAdaptor.prototype.eraseCookie = function(name) {
	this.createCookie(name,"",-1);
};

caplinx.preferences.util.WebcentricAdaptor.loadHandler = function(event) {
	var instance = new caplinx.preferences.util.WebcentricAdaptor();
	caplinx.preferences.util.PreferencesAdaptor.INSTANCE = instance;
	instance.handleViewReady(event);
};

caplinx.preferences.util.WebcentricAdaptor.prototype.chooseLocale = function(locale) {
	var url = document.location + "";
	
	//Strip any &locale=xx_XX or ?locale=xx_XX out of the url.
	url = url.replace(/[\?&]?locale=[\w_]+/,"");
	this.createCookie("locale",locale,365);
	document.location.reload();
}



caplin.webcentric.core.EventManager.registerAsEventListener(
	"ViewReady", 
	caplinx.preferences.util.WebcentricAdaptor.loadHandler, 
	"Check and manage user locale preferences after page loads",
	2);
	
	

	
	
	
	