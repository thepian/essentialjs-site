caplin.namespace("caplinb.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.element.formatter.BondNotationFormatter");
caplin.include("caplin.element.formatter.DecimalFormatter");

caplinb.figrids.formatter.ActivesBondNotationFormatter = function() {
};

caplin.implement(caplinb.figrids.formatter.ActivesBondNotationFormatter, caplin.element.Formatter);

caplinb.figrids.formatter.ActivesBondNotationFormatter.prototype.format = function(sValue, mAttributes) {
	if (sValue > 0) {
		if (mAttributes["QuoteType"] == "F") {
			sValue = caplin.element.formatter.BondNotationFormatter.format(sValue, mAttributes);
		} else {
			sValue = caplin.element.formatter.DecimalFormatter.format(sValue, mAttributes);
		}
	}
	return sValue;
};

caplinb.figrids.formatter.ActivesBondNotationFormatter.prototype.toString = function() {
	return "caplinb.figrids.formatter.ActivesBondNotationFormatter";
};

caplin.singleton("caplinb.figrids.formatter.ActivesBondNotationFormatter");
