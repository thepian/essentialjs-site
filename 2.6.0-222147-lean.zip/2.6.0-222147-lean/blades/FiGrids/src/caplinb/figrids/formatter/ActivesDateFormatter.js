caplin.namespace("caplinb.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.element.formatter.DateFormatter");

caplinb.figrids.formatter.ActivesDateFormatter = function() {
};

caplin.implement(caplinb.figrids.formatter.ActivesDateFormatter, caplin.element.Formatter);

caplinb.figrids.formatter.ActivesDateFormatter.prototype.format = function(sValue, mAttributes) {
	mAttributes["viewFormat"] = mAttributes["ActiveGroup"] == "Bills" ? "m/d/Y" : "m/Y";
	return caplin.element.formatter.DateFormatter.format(sValue, mAttributes);
};

caplinb.figrids.formatter.ActivesDateFormatter.prototype.toString = function() {
	return "caplinb.figrids.formatter.ActivesDateFormatter";
};

caplin.singleton("caplinb.figrids.formatter.ActivesDateFormatter");
