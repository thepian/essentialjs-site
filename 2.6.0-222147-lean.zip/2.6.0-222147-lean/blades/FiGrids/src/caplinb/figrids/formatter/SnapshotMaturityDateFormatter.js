/*
 * SNAPSHOT MATURITY DATE FORMATTER
 */

caplin.namespace("caplinb.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.core.Number");

/**
 * @class
 * 
 * Converts a fraction number of years into a formatted month or year expression.
 * <p/>
 * <code>SnapshotMaturityDateFormatter<code/> is typically used in the XML Renderer Framework, but can be invoked programmatically
 * as in the following example which evaluates to "6 m":
 * <p/>
 * <code>caplin.element.formatter.PercentFormatter.format(0.5, {})</code>
 * 
 * @extends caplin.element.Formatter
 * @singleton
 */
caplinb.figrids.formatter.SnapshotMaturityDateFormatter = function() {
};

caplin.implement(caplinb.figrids.formatter.SnapshotMaturityDateFormatter, caplin.element.Formatter);

/**
 * Converts a number to a month or year expression.  If the number is less than one, then it expressed as a
 * number of months, otherwise it is expressed as a number of years. 
 * 
 * @param {Variant} vValue  the number of years (String or Number type).
 * @param {Map} mAttributes  not used
 * @return  the number expressed in months or years.
 * @type  String
 */
caplinb.figrids.formatter.SnapshotMaturityDateFormatter.prototype.format = function(vValue, mAttributes) {
	if (vValue > 0) {
		vValue = vValue < 1 ? caplin.core.Number.round(vValue * 12) + " m" : vValue + " year";	
	}
	return vValue;
};

caplinb.figrids.formatter.SnapshotMaturityDateFormatter.prototype.toString = function() {
	return "caplinb.figrids.formatter.SnapshotMaturityDateFormatter";
};

caplin.singleton("caplinb.figrids.formatter.SnapshotMaturityDateFormatter");
