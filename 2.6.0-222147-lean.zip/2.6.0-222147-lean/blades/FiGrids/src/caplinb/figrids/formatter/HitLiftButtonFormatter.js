/*
 * SNAPSHOT MATURITY DATE FORMATTER
 */

caplin.namespace("caplinb.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.core.Number");

/**
 * @class
 * 
 * @extends caplin.element.Formatter
 * @singleton
 */
caplinb.figrids.formatter.HitLiftButtonFormatter = function() {
};

caplin.implement(caplinb.figrids.formatter.HitLiftButtonFormatter, caplin.element.Formatter);

/**
 * 
 * @param {Variant} vValue  not used
 * @param {Map} mAttributes  not used
 * @return  the number expressed in months or years.
 * @type  String
 */
caplinb.figrids.formatter.HitLiftButtonFormatter.prototype.format = function(vValue, mAttributes)
{
	if(mAttributes["BuySell"]=== "Bid")
	{
		return "Hit";
	}
	else
	{
		return "Lift";
	}
};

caplinb.figrids.formatter.HitLiftButtonFormatter.prototype.toString = function() {
	return "caplinb.figrids.formatter.HitLiftButtonFormatter";
};

caplin.singleton("caplinb.figrids.formatter.HitLiftButtonFormatter");