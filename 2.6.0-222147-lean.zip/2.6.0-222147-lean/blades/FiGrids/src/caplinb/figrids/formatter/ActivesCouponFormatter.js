caplin.namespace("caplinb.figrids.formatter");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.element.formatter.Fractional8thsFormatter");

caplinb.figrids.formatter.ActivesCouponFormatter = function() {
};

caplin.implement(caplinb.figrids.formatter.ActivesCouponFormatter, caplin.element.Formatter);

caplinb.figrids.formatter.ActivesCouponFormatter.prototype.format = function(sValue, mAttributes) {
	if (mAttributes["ActiveGroup"] == "Bills") {
		// bills only: ignore coupon, replacing with OTR term expressed as months or years
		var nMonths = Math.floor(mAttributes["OTRTerm"] * 12 + 0.5);
		sValue = nMonths == 12 ? ct.i18n("cx.element.formatter.actives.coupon.one_year") : ct.i18n("cx.element.formatter.actives.coupon.months", {months:nMonths});
	} else {
		// other groups: use coupon
		sValue = caplin.element.formatter.Fractional8thsFormatter.format(sValue, mAttributes);
	}
	return sValue;
};

caplinb.figrids.formatter.ActivesCouponFormatter.prototype.toString = function() {
	return "caplinb.figrids.formatter.ActivesCouponFormatter";
};

caplin.singleton("caplinb.figrids.formatter.ActivesCouponFormatter");
