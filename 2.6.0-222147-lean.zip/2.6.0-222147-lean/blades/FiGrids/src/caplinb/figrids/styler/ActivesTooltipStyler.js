caplin.namespace("caplinb.figrids.styler");

caplin.include("caplin.element.Styler", true);

caplinb.figrids.styler.ActivesTooltipStyler = function() {
};

caplin.extend(caplinb.figrids.styler.ActivesTooltipStyler, caplin.element.Styler);

caplinb.figrids.styler.ActivesTooltipStyler.prototype.style = function(sValue, mAttributes, oControl) {
	oControl.setAttribute("tooltip", sValue);
	return sValue;
};

caplinb.figrids.styler.ActivesTooltipStyler.prototype.toString = function() {
	return "caplinb.figrids.styler.ActivesTooltipStyler";
};

caplin.singleton("caplinb.figrids.styler.ActivesTooltipStyler");
