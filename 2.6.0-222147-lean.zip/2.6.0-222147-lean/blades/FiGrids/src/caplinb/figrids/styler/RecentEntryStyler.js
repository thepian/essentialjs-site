caplin.namespace("caplinb.figrids.styler");

caplin.include("caplin.element.Styler", true);

caplinb.figrids.styler.RecentEntryStyler = function()
{
	// 24 hours
	this.m_nRecentEntryDuration = (1000 * 60 * 60 * 24);
};
caplin.extend(caplinb.figrids.styler.RecentEntryStyler, caplin.element.Styler);

caplinb.figrids.styler.RecentEntryStyler.prototype.style = function(sValue, mAttributes, oControl)
{
	// portfolios updated within the last 24 hours are bolded
	if(mAttributes.lastModifiedTime > (new Date().getTime() - this.m_nRecentEntryDuration))
	{
		oControl.addClass("recentlyModifiedPortfolio");
	}
	else
	{
		oControl.removeClass("recentlyModifiedPortfolio");
	}
	
	return sValue;
};

caplinb.figrids.styler.RecentEntryStyler.prototype.toString = function()
{
	return "caplinx.portfolio.RecentEntryStyler";
};

caplin.singleton("caplinb.figrids.styler.RecentEntryStyler");
