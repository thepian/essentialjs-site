caplin.namespace("caplinb.figrids.styler");

caplin.include("caplin.element.Styler", true);
caplin.include("caplin.framework.ApplicationFactory");

caplinb.figrids.styler.ActivesPermissionsStyler = function() {
};

caplin.extend(caplinb.figrids.styler.ActivesPermissionsStyler, caplin.element.Styler);

caplinb.figrids.styler.ActivesPermissionsStyler.prototype.style = function(sValue, mAttributes, oControl) {
	var bIsPermissioned = this._getPermission(mAttributes["PermBitmap"]);
	if (bIsPermissioned) {
		oControl.addClass(mAttributes["tradableClass"]);
	} else {
		oControl.removeClass(mAttributes["tradableClass"]);		
	}
	return sValue;
};

caplinb.figrids.styler.ActivesPermissionsStyler.prototype._getPermission = function(sPermissionBitmap) {
// TODO: remove this when the real TradePermissionManager is available
return true;
	var pPermissionBitmap = eval("(" + sPermissionBitmap + ")");
	var oTradePermissionManager = caplin.framework.ApplicationFactory.INSTANCE.getTradePermissionManager();
	return this.m_oTradePermissionManager.checkTradePermission(pPermissionBitmap);
};

caplinb.figrids.styler.ActivesPermissionsStyler.prototype.toString = function() {
	return "caplinb.figrids.styler.ActivesPermissionsStyler";
};

caplin.singleton("caplinb.figrids.styler.ActivesPermissionsStyler");
