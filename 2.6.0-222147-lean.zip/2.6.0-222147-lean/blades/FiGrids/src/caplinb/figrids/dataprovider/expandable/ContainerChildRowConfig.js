caplin.namespace("caplinb.figrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinb.figrids.dataprovider.expandable.ContainerChildRowConfig = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
};

caplinb.figrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getContainerToExpanded = function(mRowData, sRendererId)
{
	return '/CONTAINER/FX/Emerging';
};

caplinb.figrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return oGridColumnModel.getRequiredFields();
};

caplinb.figrids.dataprovider.expandable.ContainerChildRowConfig.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	if (mRecordUpdates.InstrumentDescription && mRecordUpdates.InstrumentDescription.substring(0, 3)!="...") 
	{
		mRecordUpdates = caplin.core.MapUtility.clone(mRecordUpdates);
		mRecordUpdates.MagicInstrumentDescription = mRecordUpdates.InstrumentDescription;
		mRecordUpdates.InstrumentDescription = "";
	}
	return mRecordUpdates;
};
