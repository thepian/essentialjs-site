caplin.namespace("caplinb.figrids.handler");

caplin.include("caplin.element.Handler");

/**
 * @class
 * 
 * ExpandableRowHandler is a flyweight singleton, and therefore this constructor should never be invoked directly.
 * <p/>
 * Instead, it is instantiated by the RendererFactory, which reads RendererType specifications from XML and
 * instantiates the handlers by name.
 * 
 * @extends caplin.element.Handler
 * @singleton
 */
caplinb.figrids.handler.ExpandableRowHandler = function(){
};
caplin.extend(caplinb.figrids.handler.ExpandableRowHandler, caplin.element.Handler);

/**
 * Raises a 'rowToggle' renderer event when the user clicks the expand or collapse
 * icons.
 * 
 * @param {Object} oEvent The DOM event
 * @param {Object} oRenderer The renderer
 * @param {Object} mAttributes Atributes that have been defined in the renderer definitions file
 */
caplinb.figrids.handler.ExpandableRowHandler.prototype.onclick = function(oEvent, oRenderer, mAttributes){
	oRenderer.raiseEvent('rowToggle', oEvent);
};

/**
 * Returns a human-readable string representation of the handler, which is useful for debugging.
 * 
 * @return  The string representation
 * @type String
 */
caplinb.figrids.handler.ExpandableRowHandler.prototype.toString = function(){
    return "caplinb.figrids.handler.ExpandableRowHandler";
};

caplin.singleton("caplinb.figrids.handler.ExpandableRowHandler");
