caplin.namespace("caplinb.figrids.handler");

caplin.include("caplin.element.Handler", true);

caplinb.figrids.handler.ActivesTradeOnDoubleClickHandler = function() {
};

caplin.extend(caplinb.figrids.handler.ActivesTradeOnDoubleClickHandler, caplin.element.Handler);

caplinb.figrids.handler.ActivesTradeOnDoubleClickHandler.prototype.ondblclick = function(oDomEvent, oRenderer, mAttributes) {
	oRenderer.raiseEvent("doubleClick");
};

caplinb.figrids.handler.ActivesTradeOnDoubleClickHandler.prototype.toString = function() {
	return "caplinb.figrids.handler.ActivesTradeOnDoubleClickHandler";
};

caplin.singleton("caplinb.figrids.handler.ActivesTradeOnDoubleClickHandler");
