/**
 * @fileoverview
 * 
 * This handler traps click events and passes an 'trade' the {@link caplin.element.RendererEventListener}.
 */

caplin.namespace("caplinb.figrids.handler");

caplin.include("caplin.element.Handler", true);
caplin.include("caplin.dom.Utility");

/**
 * CancelOnClickHandler is a flyweight singleton, and therefore this constructor should never be invoked directly.
 * <p/>
 * Instead, it is instantiated by the RendererFactory, which reads RendererType specifications from XML and
 * instantiates the handlers by name.
 * 
 * @extends {caplin.element.Handler}
 * @constructor
 */
caplinb.figrids.handler.CancelOnClickHandler = function() {
};

caplin.extend(caplinb.figrids.handler.CancelOnClickHandler, caplin.element.Handler);

/**
 * Traps the <code>onclick</code> event and returns an 'trade' event for passing up to the RendererEventListener.
 * 
 * All the functions that begin with <code>on</code> are assumed to be event handler functions, and are attached
 * to DOM elements by reflection.
 * 
 * @param {Object} oDomEvent  The DOM event
 * @param {Object} oRenderer  The renderer 
 *  
 * @type Map
 * @return  An 'trade' event
 */
caplinb.figrids.handler.CancelOnClickHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes) {
	var oControl = oRenderer.getControl();
	if(oControl.isEnabled())
	{
		var sRequestID = mAttributes["RequestID"];
		var oTrade = this._getTradeService().getTradeByID(sRequestID);
		oTrade.processClientEvent("CustReject");
	}
	caplin.dom.Utility.stopEventPropagation(oDomEvent);
	return false;
};

/**
 * Returns a human-readable string representation of the handler, which is useful for debugging.
 * 
 * @return  The string representation
 * @type String
 */
caplinb.figrids.handler.CancelOnClickHandler.prototype.toString = function() {
	return "caplinb.figrids.handler.CancelOnClickHandler";
};

/**
 * @private
 */
caplinb.figrids.handler.CancelOnClickHandler.prototype._getTradeService = function()
{
	if(!this.m_oTradeService)
	{
		this.m_oTradeService = caplin.framework.ApplicationFactory.getInstance().getTradeService();
	}
	
	return this.m_oTradeService;
};

caplin.singleton("caplinb.figrids.handler.CancelOnClickHandler");
