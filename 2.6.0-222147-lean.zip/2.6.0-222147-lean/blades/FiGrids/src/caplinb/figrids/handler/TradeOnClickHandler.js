caplin.namespace("caplinb.figrids.handler");

caplin.include("caplin.element.Handler", true);
caplin.include("caplinx.tobo.TOBOUserManager");
caplin.include("caplin.framework.ApplicationFactory");

caplinb.figrids.handler.TradeOnClickHandler = function() {
};

caplin.extend(caplinb.figrids.handler.TradeOnClickHandler, caplin.element.Handler);

caplinb.figrids.handler.TradeOnClickHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes) {
	
	if (oRenderer.getVariable("TRADABLE") == "true" && caplinx.tobo.TOBOUserManager.canPerformTrade())  {
		var sPrimaryFieldName = oRenderer.getAllFieldNames()[0];
		var sSide = (sPrimaryFieldName.match(/bid/i)) ? "Bid" : "Ask";
		caplin.framework.ApplicationFactory.getInstance().openTradeTicketV4(oRenderer, sSide);
	}
};

caplinb.figrids.handler.TradeOnClickHandler.prototype.toString = function() {
	return "caplinb.figrids.handler.TradeOnClickHandler";
};

caplin.singleton("caplinb.figrids.handler.TradeOnClickHandler");
