/**
 * @fileoverview
 * Defines the caplinb.figrids.decorator.ChartCreationDecorator class.
 */
caplin.namespace("caplinb.figrids.decorator");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.grid.decorator.GridDecorator", true);
caplin.include("caplin.dom.Utility");
caplin.include("caplin.core.XmlParser");
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplinx.historicdata.BenchmarkController");
caplin.include("caplinx.historicdata.TimeSeriesController");

/**
 * Constructs a <code>caplinb.figrids.decorator.ChartCreationDecorator</code> instance &mdash; end-users
 * will never need to do this themselves since grids are fully constructed based on their XML
 * definition files by the {@link caplin.grid.GridGenerator GridGenerator} class.
 * 
 * @class
 * The <code>RightClickMenuDecorator</code> class provides immediate visual feedback of a rows pending
 * removal until the server round-trip has completed, and the row is actually removed from the view.
 * The remove row decorator is not required for the
 * {@link caplin.element.handler.RemoveGridRowOnClickHandler} class to function correctly, but
 * merely improves the responsiveness of the UI during such an operation.
 * 
 * @implements caplin.grid.decorator.GridDecorator
 * @implements caplin.grid.GridViewListener
 * @constructor
 */
caplinb.figrids.decorator.ChartCreationDecorator = function(mDecoratorConfig)
{
};
caplin.implement(caplinb.figrids.decorator.ChartCreationDecorator, caplin.grid.decorator.GridDecorator);


//************************ GridDecorator Interface Methods ************************

/**
 * @private
 * @see caplin.grid.decorator.GridDecorator#setGridView
 */
caplinb.figrids.decorator.ChartCreationDecorator.prototype.setGridView = function(oGridView)
{
	this.m_oGridView = oGridView;

	this.m_oOpenAjaxSubjectAddedHelper =
		new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(oGridView, "*", "insertBenchmark", this, this._insertBenchmark);
	this.m_oOpenAjaxSubjectRemovedHelper =
		new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(oGridView, "*", "insertTimeseries", this, this._insertTimeseries);
};

//************************ Private Methods ************************

/**
 * @private
 */
caplinb.figrids.decorator.ChartCreationDecorator.prototype._insertBenchmark = function(sEvent, oEventObject) 
{	
	// NOTE: The 'id' property of each component needs to be set using '_id', as webcentric strips any 'id'
	// properties.

	var sXml = 	'<caplin:Panel xmlns:caplin="http://www.caplin.com" caption="'+ct.i18n("cx.grid.decorator.chart.caption") +'" drop_target="SNAP_FRAMEITEM" colour="colour-1" decorators="basicDecorator" handleContribs="hdcContribs" style="Chart">';
		sXml += '<state>';
		sXml += 	'<compositeComponent controller="caplinx.historicdata.BenchmarkController">'; 
		sXml += 		'<tower>';
		sXml += 			'<component _id="chartSettingsPanel" height="0%">'; 
		sXml += 				'<simpleForm src="source/html-templates/chartSettingsPanel.html"/>'; 
		sXml += 			'</component>';
		sXml += 			'<terrace height="100%">'; 
		sXml += 				'<component _id="chart" width="100%">'; 
		sXml += 					'<chart baseTemplate="benchmarkCurve">';
		sXml += 						'<chartModel>';
		sXml += 							'<seriesState>';
		sXml += 								'<chartSeries>';
		sXml += 									'<chartSeriesRequest subject="' + oEventObject.subject + '"/>';
		sXml += 								'</chartSeries>';
		sXml += 							'</seriesState>';
		sXml += 						'</chartModel>';
		sXml += 					'</chart>';
		sXml += 				'</component>'; 
		sXml += 				'<component _id="grid" width="0%">'; 
		sXml += 				'	<grid baseTemplate="fiBenchmarkGrid"/>'; 
		sXml += 				'</component>';
		sXml += 			'</terrace>';
		sXml += 		'</tower>';
		sXml += 	'</compositeComponent>'; 
		sXml += '</state></caplin:Panel>';
		
		this._addComponent(sXml);
};

/**
 * @private
 */
caplinb.figrids.decorator.ChartCreationDecorator.prototype._insertTimeseries = function(sEvent, oEventObject) 
{
	// NOTE: The 'id' property of each component needs to be set using '_id', as webcentric strips any 'id'
	// properties.
	
	var sXml = 	'<caplin:Panel xmlns:caplin="http://www.caplin.com" caption="'+ ct.i18n("cx.grid.decorator.chart.caption_historical") + '" drop_target="SNAP_FRAMEITEM" colour="colour-1" decorators="basicDecorator" handleContribs="hdcContribs" style="Chart">';	
		sXml += '<state>';
		sXml += 	'<compositeComponent controller="caplinx.historicdata.TimeSeriesController">'; 
		sXml += 		'<tower>';
		sXml += 			'<terrace height="100%">'; 
		sXml += 				'<component _id="chart" width="100%">'; 
		sXml += 					'<chart baseTemplate="timeSeriesChart">';
		sXml += 						'<chartModel>';
		sXml += 							'<seriesState>';
		sXml += 								'<chartSeries>';
		sXml += 									'<chartSeriesRequest subject="' + oEventObject.subject + '"/>';
		sXml += 								'</chartSeries>';
		sXml += 							'</seriesState>';
		sXml += 						'</chartModel>';
		sXml += 					'</chart>';
		sXml += 				'</component>'; 
		sXml += 				'<component _id="grid" width="0%">'; 
		sXml += 				'	<grid baseTemplate="fiTimeseriesGrid"/>'; 
		sXml += 				'</component>';
		sXml += 			'</terrace>';
		sXml += 		'</tower>';
		sXml += 	'</compositeComponent>'; 
		sXml += '</state></caplin:Panel>';
		
		this._addComponent(sXml);
};

/**
 * @private
 */
caplinb.figrids.decorator.ChartCreationDecorator.prototype._addComponent = function(sXml)
{
	var oXml = caplin.core.XmlParser.getInstance().parseString(sXml);
 	oComponent = caplin.webcentric.model.XMLAdaptor.buildDataNode(oXml);
 	webcentric.addComponent(oComponent);
}


















