
//namespace to prevent global varibles
(function () 
{

	function _getValueFromQueryString(sField) 
	{
		var sQueryString = window.location.search.substring(1);
		var sFieldValuePair = sQueryString.split("&");
		for (var i = 0, nLength = sFieldValuePair.length; i < nLength; ++i) 
		{
			var pFieldValuePair = sFieldValuePair[i].split("=");
			if (pFieldValuePair[0] === sField) 
			{
				return pFieldValuePair[1];
			}
		}
	}
	
	var oConfiguration = SL4B_Accessor.getConfiguration();
	oConfiguration.setAttribute("rttpprovider", "javascript");
	oConfiguration.setAttribute("maxgetlength", "0");
	oConfiguration.setAttribute("commondomain", "caplin.com");
	oConfiguration.setAttribute("applicationId", "CaplinTraderReferenceImplementation");
	oConfiguration.setAttribute("timestampfield", "LATENCY_TIMESTAMP");
	oConfiguration.setAttribute("enablelatency", "true");
	oConfiguration.setAttribute("enableautoloading", "true");
	
	var xaquaHost = _getValueFromQueryString('xaquahostname');
	if (!xaquaHost){
		xaquaHost = 'xaqua.caplin.com';
	} 
	
	oConfiguration.setAttribute("serverurl", "http://" + xaquaHost + ":40180");
	
	if(window.location.protocol == "http:")
    {
		oConfiguration.setAttribute("serverurl", "http://" + xaquaHost + ":40180");
	}
    else // https
    {
    	oConfiguration.setAttribute("serverurl", "https://" + xaquaHost + ":40181");   
    }
	
	if(this.enhanceSl4bConfig)
	{
		this.enhanceSl4bConfig(oConfiguration);
	};

})();