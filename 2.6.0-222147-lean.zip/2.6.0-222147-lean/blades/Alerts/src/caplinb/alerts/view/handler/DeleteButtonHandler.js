caplin.namespace("caplinb.alerts.view.handler");

caplin.include("caplin.alerts.NotificationService");
caplin.include("caplinb.alerts.view.handler.GridBarButtonHandler", true);

caplinb.alerts.view.handler.DeleteButtonHandler = function(eButton)
{
};

caplin.implement(caplinb.alerts.view.handler.DeleteButtonHandler, caplinb.alerts.view.handler.GridBarButtonHandler)

caplinb.alerts.view.handler.DeleteButtonHandler.prototype.handleGridRowSelection = function(pSelectedRows) {
	
};

caplinb.alerts.view.handler.DeleteButtonHandler.prototype.execute = function(pSelectedRows)
{
	if (pSelectedRows.length > 0) {
		caplin.alerts.TriggerService.removeTriggers(pSelectedRows);
	}
};

