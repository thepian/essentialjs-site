caplin.namespace("caplinb.alerts.view.handler");

caplin.include("caplin.alerts.NotificationService");
caplin.include("caplinb.alerts.view.handler.GridBarButtonHandler", true);

caplinb.alerts.view.handler.DismissButtonHandler = function(oButton)
{
	this.m_oButton = oButton;	
};

caplin.implement(caplinb.alerts.view.handler.DismissButtonHandler, caplinb.alerts.view.handler.GridBarButtonHandler)

caplinb.alerts.view.handler.DismissButtonHandler.prototype.handleGridRowSelection = function(oGridRowModel, pSelectedRows) {
	if(this._isStale(oGridRowModel, pSelectedRows)) {
		this.m_oButton.disable(true);
	} else {
		this.m_oButton.disable(false);
	}
	
};

caplinb.alerts.view.handler.DismissButtonHandler.prototype._isStale = function(oGridRowModel, pSelectedRows) {
	for(var index = 0 ; index < pSelectedRows.length; index++) {
		var nIndex = oGridRowModel.getIndexBySubject(pSelectedRows[index]);
		var oNotificationRow = oGridRowModel.getRowData(nIndex);
		if(oNotificationRow.RECORD_STATUS === SL4B_ObjectStatus.STALE) {
			return true;
		}
	}
	return false;
};

caplinb.alerts.view.handler.DismissButtonHandler.prototype.execute = function(pSelectedRows)
{
	if (pSelectedRows.length > 0) {
		caplin.alerts.NotificationService.dismissNotifications(pSelectedRows);
	}
};
