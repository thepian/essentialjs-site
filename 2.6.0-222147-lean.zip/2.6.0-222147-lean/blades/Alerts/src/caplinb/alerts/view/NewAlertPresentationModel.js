caplin.namespace("caplinb.alerts.view");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.form.presentation.Form");
caplin.include("caplin.form.presentation.PresentationProperty");
caplin.include("caplinb.alerts.AlertFieldNameMap", true);
caplin.include("caplin.alerts.TriggerService");
caplin.include("caplinb.alerts.view.InstrumentSubscriber");
caplin.include("caplin.core.StringUtility");
caplin.include("caplin.core.Number");

caplinb.alerts.view.NewAlertPresentationModel = function(oController)
{
	/** @private */
	this.m_oForm = null;
	/** @private */
	this.m_oDomainModel;
	
	/** @private */
	this.m_mFieldValidators = {
			"name":this._isFieldNonEmpty,
			"field":this._isFieldNonEmpty,
			"operator":this._isFieldNonEmpty,
			"value":caplin.core.Number.isNumber
	};
	
	var responseConfirmed = {
		"header":ct.i18n("blade.alerts.form.alert_added_message.header"),
		"text":ct.i18n("blade.alerts.form.alert_added_message.text"),
		"imageClass":"add-alert-status-image-success"
	};
	
	this.m_mStatusMessages = {
			"ADDED": responseConfirmed,
			"ADDED_AND_REMOVED": responseConfirmed,
			"PERMISSION_DENIED": {
				"header":ct.i18n("blade.alerts.form.alert_invalid_message.header"),
				"text":ct.i18n("blade.alerts.form.alert_permission_denied_message.text"),
				"imageClass":"add-alert-status-image-failure"
			},
			"INVALID": {
				"header":ct.i18n("blade.alerts.form.alert_invalid_message.header"),
				"text":ct.i18n("blade.alerts.form.alert_invalid_message.text"),
				"imageClass":"add-alert-status-image-failure"
			},
			"RETRY": {
				"header":ct.i18n("blade.alerts.form.alert_invalid_message.header"),
				"text":ct.i18n("blade.alerts.form.alert_invalid_message.text"),
				"imageClass":"add-alert-status-image-failure"
			},
			"IN_PROGRESS" : {
				"header":ct.i18n("blade.alerts.form.alert_inprogress_message.header"),
				"text":ct.i18n("blade.alerts.form.alert_inprogress_message.text"),
				"imageClass" : "add-alert-status-image-in-progress"
			} 
	};

	this.m_mSubjectFormatters = {
			"FX" : [{
				"formatter" : caplin.element.formatter.ThousandsFormatter,
				"attributes" : {"nullValue" : ""},
				"form-fields" : ["current-field-value"]
			}],
			"FI" : [{
				"formatter" : caplin.element.formatter.DecimalFormatter,
				"attributes" : {"dp" : "3"},
				"form-fields" : ["current-field-value", "value"]
			},
			{
				"formatter" : caplin.element.formatter.ThousandsFormatter,
				"attributes" : {"nullValue" : ""},
				"form-fields" : ["current-field-value"]
			}],
			"COMMANDHTTPD" : [{
				"formatter" : caplin.element.formatter.ThousandsFormatter,
				"attributes" : {"nullValue" : ""},
				"form-fields" : ["current-field-value"]
			}]
	};
	
	this.m_pOperators = [">=", "<="];
	
	/**
	 * @private
	 * key for the map is xaqua field name.
	 */
	this.m_mFieldValues = {}; 	
	this.m_sSubject = null;
	this.m_oInstrumentSubscriber = null;
	this.m_sSelectedXaquaFieldName = null;
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.setInitialValues = function() {
	//Do Nothing
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.initialise = function(oForm)
{
	this.m_oForm = oForm;
	var pProperties = oForm.autoGenerateProperties();
	oForm.bindProperties(pProperties);
	oForm.setValue("submitEnabled", false);
	oForm.setValue("inputsEnabled", true);
	oForm.setValue("closeEnabled", true);
	oForm.setValue("form-save-retry", ct.i18n("blade.alerts.form.button.save"));
	oForm.setValue("form-save-retry-visible", true);
	oForm.setValue("form-cancel-close", ct.i18n("blade.alerts.form.button.cancel"));
	this._addValidationListeners();
	this._addTriggerFieldChangeListener("field");
	oForm.setValue("name-valid", "control-wrapper form-field-valid");
	oForm.setValue("value-valid", "control-wrapper form-field-valid");
	oForm.setValue("field-valid", "control-wrapper form-field-valid");
	oForm.setValue("operator-valid", "control-wrapper form-field-valid");
	oForm.setValue("current-field", "hide-current-fields");
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._addValidationListeners = function()
{
	for(var sFieldName in this.m_mFieldValidators)
	{
		this._addValidationListenerToProperty(sFieldName);
	}
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._addValidationListenerToProperty = function(sPropertyName)
{
	var oProperty = this.m_oForm.getProperty(sPropertyName);
	var self = this;
	oProperty.addListener(function(sNamespace, sName, sValue){
		self._validateField(sName, sValue);
		self._updateStateBasedOnFieldValidity();
	});
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._addTriggerFieldChangeListener = function(sPropertyName)
{
	var oProperty = this.m_oForm.getProperty(sPropertyName);
	var self = this;
	oProperty.addListener(function(sNamespace, sName, sValue){
		if(sValue && sName === "field")
		{
			var sXaquaFieldName = caplinb.alerts.AlertFieldNameMap.getXaquaFieldNameFor(self.m_sSubject, sValue);
			self._setDefaultOperator(sXaquaFieldName);
			if(sXaquaFieldName === self.m_sSelectedXaquaFieldName) {
				return;
			} else {
				self.m_sSelectedXaquaFieldName = sXaquaFieldName;
				self.m_oForm.setValue("current-field", "show-current-fields");
				var sXaquaFieldValue = self.m_mFieldValues[self.m_sSelectedXaquaFieldName];
				
				if(sXaquaFieldValue) 
				{
					self.updateField(sXaquaFieldName, sXaquaFieldValue, true);
				}
				else
				{
					self.m_oForm.setValue("current-field-value", "");
				}
			}
		}
	});
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._setDefaultOperator = function(sXaquaFieldName)
{
	var sFieldDefaultOperator = caplinb.alerts.AlertFieldNameMap.getDefaultOperatorFor(this.m_sSubject, sXaquaFieldName);
	if (caplin.core.ArrayUtility.inArray(this.m_pOperators, sFieldDefaultOperator))
	{
		this.m_oForm.setValue("operator", sFieldDefaultOperator);
	}	
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._validateField = function(sPropertyName, sPropertyValue)
{
	var fValidator = this.m_mFieldValidators[sPropertyName];
	var sClassName = fValidator(sPropertyValue) ? "control-wrapper form-field-valid" : "control-wrapper form-field-invalid";
	this.m_oForm.setValue(sPropertyName + "-valid", sClassName);
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._updateStateBasedOnFieldValidity = function()
{
	this.m_oForm.setValue("submitEnabled", this._allFieldsAreValid());
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._allFieldsAreValid = function()
{
	for(var sFieldName in this.m_mFieldValidators)
	{
		var sValue = this.m_oForm.getProperty(sFieldName).getValue();
		var fValidator = this.m_mFieldValidators[sFieldName];
		if(!fValidator(sValue))
		{
			return false;
		}
	}
	return true;
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._isFieldNonEmpty = function(sField)
{
	sField = caplin.core.StringUtility.trim(sField);
	return sField.length > 0;
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.execute = function()
{
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.initialiseExternalComponents = function()
{
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.getFieldOptions = function() {
	 return caplinb.alerts.AlertFieldNameMap.getFieldsAsArray(this.m_oForm.getValue("subject"));
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.getOperatorOptions = function()
{
	return this.m_pOperators;
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.sendTrigger = function(oView) {
	this._setStatus("IN_PROGRESS");
	this.m_oForm.setValue("inputsEnabled", false);
	this.m_oForm.setValue("submitEnabled", false);
	this.m_oForm.setValue("closeEnabled", false);
	var sSubject = this.m_oForm.getValue("subject");
	var sCondition = this.m_oForm.getValue("field")  + " " + this.m_oForm.getValue("operator") + " " + this.m_oForm.getValue("value");
	var sMonitoredCondition = caplinb.alerts.AlertFieldNameMap.replaceWithMonitoredName(sSubject, sCondition);  

	var triggerData = {
		"subject": sSubject,
		"instrument": this.m_oForm.getValue("instrument"),  
		"name": this.m_oForm.getValue("name"),  
		"alertCondition": sMonitoredCondition
	};
	caplin.alerts.TriggerService.addTrigger(triggerData, this._getAddTriggerCallback());
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.close = function()
{
	this.m_oInstrumentSubscriber.unsubscribe();
	if (this.m_oContainer) {
		this.m_oContainer.close();
	}
	
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._getAddTriggerCallback = function()
{
	var self = this;
	return function(sAlertOperation)
	{
		if(sAlertOperation==="INVALID" || sAlertOperation === "RETRY") {
			self.m_oForm.setValue("submitEnabled", true);
			self.m_oForm.setValue("form-save-retry", ct.i18n("blade.alerts.form.button.retry"));
		}
		else if (sAlertOperation==="ADDED_AND_REMOVED" || sAlertOperation==="ADDED" || sAlertOperation==="PERMISSION_DENIED")
		{
			self.m_oForm.setValue("form-save-retry-visible", false);
			self.m_oForm.setValue("form-cancel-close", ct.i18n("blade.alerts.form.button.close"));
		}
		self.m_oForm.setValue("closeEnabled", true);
		self._setStatus(sAlertOperation);
	};
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.setSubject = function(sSubject) {
	this.m_oForm.setValue("subject", sSubject);
	this.m_sSubject = sSubject;
	this.m_oInstrumentSubscriber = this._createInstrumentSubscriber(sSubject);
	this.m_oInstrumentSubscriber.start();
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._createInstrumentSubscriber = function(sSubject) 
{
	var pFieldNames = caplinb.alerts.AlertFieldNameMap.getXaquaFieldsAsArray(sSubject);
	return new caplinb.alerts.view.InstrumentSubscriber(sSubject, pFieldNames, this);
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.setInstrument = function(sInstrument) {
	this.m_oForm.setValue("instrument", sInstrument);
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.setField = function(sField) {
	if (sField != "")
	{
		var sAlertSubject = this.m_oForm.getValue("subject");
		var pFields = caplinb.alerts.AlertFieldNameMap.getXaquaFieldsAsArray(sAlertSubject);
		if (caplin.core.ArrayUtility.inArray(pFields, sField))
		{
			var sFieldDisplayName = caplinb.alerts.AlertFieldNameMap.getDisplayFieldNameFor(sAlertSubject, sField);
			var sFieldDefaultOperator = caplinb.alerts.AlertFieldNameMap.getDefaultOperatorFor(sAlertSubject, sField);
			
			var pDropdownFields = caplinb.alerts.AlertFieldNameMap.getFieldsAsArray(this.m_oForm.getValue("subject"));
			if (caplin.core.ArrayUtility.inArray(pDropdownFields, sFieldDisplayName))
			{
				this.m_oForm.setValue("field", sFieldDisplayName);
				if (caplin.core.ArrayUtility.inArray(this.m_pOperators, sFieldDefaultOperator))
				{
					this.m_oForm.setValue("operator", sFieldDefaultOperator);
				}
			}
		}
	}
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._formatValue = function(sFieldValue, sFormFieldName) {
	var pFormatters = this.m_mSubjectFormatters[this.m_sSubject.split('/')[1]]; 
	var sFormattedValue = sFieldValue;
	for(var i = 0 ; i < pFormatters.length; i++) {
		var mFormatter = pFormatters[i];
		var oFormatterObject = mFormatter["formatter"];
		var mFormatterAttribs = mFormatter["attributes"];
		var pFormatterFormFields = mFormatter["form-fields"];
		if (caplin.core.ArrayUtility.inArray(pFormatterFormFields, sFormFieldName))
		{
			sFormattedValue = oFormatterObject.format(sFormattedValue, mFormatterAttribs);
		}
	}
	return sFormattedValue;
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.updateField = function(sXaquaFieldName, sFieldValue, bEnforceValueChange) {
	var sFormattedValueStreamedPrice = this._formatValue(sFieldValue, "current-field-value");
	this.m_mFieldValues[sXaquaFieldName] = sFieldValue;
	if (sXaquaFieldName === this.m_sSelectedXaquaFieldName) {
		this.m_oForm.setValue("current-field-value", sFormattedValueStreamedPrice);
		var sValue = this.m_oForm.getValue("value");
		if(bEnforceValueChange || sValue === "" || sValue === undefined) {
			var sFormattedValueSpinnerField = this._formatValue(sFieldValue, "value");
			this.m_oForm.setValue("value", sFormattedValueSpinnerField);
		}
	}
};

caplinb.alerts.view.NewAlertPresentationModel.prototype._setStatus = function(sStatus) 
{
	var mStatusMessage = this.m_mStatusMessages[sStatus];
	
	this.m_oForm.setValue("alert-status-header", mStatusMessage["header"]);
	this.m_oForm.setValue("alert-status-text", mStatusMessage["text"]);
	this.m_oForm.setValue("add-alert-status-image", mStatusMessage["imageClass"]);
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.available = function(){
	this.m_oForm.setValue("field-value-class", "");
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.stale = function(){
	this.m_oForm.setValue("field-value-class", "stale");
};

caplinb.alerts.view.NewAlertPresentationModel.prototype.setContainer = function(oContainer){
	this.m_oContainer = oContainer;
};
