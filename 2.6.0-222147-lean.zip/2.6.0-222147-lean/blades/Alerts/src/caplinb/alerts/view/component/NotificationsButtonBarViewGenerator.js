caplin.namespace("caplinb.alerts.view.component");
 
caplin.include("caplin.component.ComponentFactory", true);
caplin.include("caplinb.alerts.view.component.NotificationsButtonBarComponent");
 
/**
 * @singleton
 */
caplinb.alerts.view.component.NotificationsButtonBarViewGenerator = function()
{
	caplin.notifyAfterClassLoad(this);
};
 
caplinb.alerts.view.component.NotificationsButtonBarViewGenerator.prototype.createFromSerializedState = function (sComponentXML)
{
	var oXml = caplin.core.XmlParser.parse(sComponentXML);
	var pButtons = oXml.getElementsByTagName('button');
    return new caplinb.alerts.view.component.NotificationsButtonBarComponent(pButtons);
};

caplinb.alerts.view.component.NotificationsButtonBarViewGenerator.prototype.onAfterClassLoad = function()
{
	caplin.component.ComponentFactory.registerComponent('gridButtonBar', caplinb.alerts.view.component.NotificationsButtonBarViewGenerator.createFromSerializedState);
};

caplin.singleton("caplinb.alerts.view.component.NotificationsButtonBarViewGenerator");
