caplin.namespace("caplinb.alerts.view.component");

caplin.include("caplin.component.Component");
caplin.include("caplin.core.Utility");
caplin.include("caplin.core.Observable");
 
/**
 * Constructs a new <code>NotificationsButtonBarComponent</code>.
 *
 * @constructor
 *
 */
caplinb.alerts.view.component.NotificationsButtonBarComponent = function(pButtons)
{
    /**
     * The base element for this component.
     */
	this.m_pButtons = pButtons ? pButtons : [];
    this.m_eHolderElem = document.createElement("div");
    this.m_eHolderElem.className = "buttonHeader";
    
    this.m_pButtonHandlers = [];
    for(var i = 0; i < pButtons.length; ++i)
    {
    	this._addButton(pButtons[i]);
    }
 
    //TODO this.m_eHolderElem.appendChild(oEditButton.getElement());
    
    this.m_oObservable = new caplin.core.Observable();
};
 
caplin.implement(caplinb.alerts.view.component.NotificationsButtonBarComponent, caplin.component.Component);
 
caplinb.alerts.view.component.NotificationsButtonBarComponent.prototype.addListener = function(oListener)
{
	this.m_oObservable.addObserver(oListener);
};

/****************************************************
 *      Event Handlers
 ****************************************************/

caplinb.alerts.view.component.NotificationsButtonBarComponent.prototype.handleClick = function(oButtonHandler)
{
	this.m_oObservable.notifyObservers("handleClick",[oButtonHandler]);
};

/****************************************************
 *      caplin.component.Component Interface
 ****************************************************/
 
/**
 * @see caplin.component.Component#getElement
 */
caplinb.alerts.view.component.NotificationsButtonBarComponent.prototype.getElement = function()
{
    return this.m_eHolderElem;
};
 
/****************************************************
 *      private functions
 ****************************************************/

caplinb.alerts.view.component.NotificationsButtonBarComponent.prototype._addButton = function(oButtonXml)
{
	var mAttributes = caplin.core.XmlUtility.convertXmlNodeToAttributesMap(oButtonXml);
    var sButtonTitle = mAttributes["title"];
    var oButton = new caplin.widget.formcontrols.ThreeImageButton(sButtonTitle, "source/images/buttons/capbutton");
    var oButtonHandlerClass = caplin.getClass(mAttributes["handler"]);
    var oButtonHandler = new oButtonHandlerClass(oButton);
    var fButtonEvent = caplin.core.Utility.getFunctionPointerFromMethod(this, "handleClick", [oButtonHandler]);
    oButton.addOnClickListener(fButtonEvent);
    this.m_eHolderElem.appendChild(oButton.getElement());
    this.m_pButtonHandlers.push(oButtonHandler);
};

caplinb.alerts.view.component.NotificationsButtonBarComponent.prototype.getButtonHandlers = function() {
	return this.m_pButtonHandlers;
};

/**
 * @see caplin.component.Component#getSerializedState
 */
caplinb.alerts.view.component.NotificationsButtonBarComponent.prototype.getSerializedState = function()
{
	var sXml = '<gridButtonBar>\n';
	for(var i = 0; i < this.m_pButtons.length; ++i)
	{
		var oButton = this.m_pButtons[i];
		sXml += caplin.core.XmlSerializer.serialize(oButton) + '\n';
		
	}
	sXml += '</gridButtonBar>';
    return sXml;
};