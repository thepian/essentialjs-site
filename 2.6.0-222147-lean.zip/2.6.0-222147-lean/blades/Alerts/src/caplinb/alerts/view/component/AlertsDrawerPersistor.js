caplin.namespace("caplinb.alerts.view.component");

caplin.include("caplin.grid.GridColumnModelListener");

caplinb.alerts.view.component.AlertsDrawerPersistor = function(sKey) {
	this.m_oUserPropertyStore = caplin.core.AbstractFactory.getInstance().getUserPropertyStore();
	this.m_sKey = "alert.config." + sKey;
};

caplin.implement(caplinb.alerts.view.component.AlertsDrawerPersistor, caplin.grid.GridColumnModelListener);

caplinb.alerts.view.component.AlertsDrawerPersistor.prototype.addAsListenerTo = function(oComponent) 
{
	this.m_oComponent = oComponent;
	var oGridComponent = this._getComponent();
	if(oGridComponent) {
		oGridComponent.getGridColumnModel().addColumnModelListener(this);
	}
};

caplinb.alerts.view.component.AlertsDrawerPersistor.prototype.onColumnsRemoved = function()
{
	this._saveXMLTemplate();
};

caplinb.alerts.view.component.AlertsDrawerPersistor.prototype.onColumnsAdded = function()
{
	this._saveXMLTemplate();
}; 

caplinb.alerts.view.component.AlertsDrawerPersistor.prototype.getXMLTemplate = function() {
	var sXml = (this.m_oUserPropertyStore.getUserProperty(this.m_sKey));
	if(sXml) {
		return caplin.core.XmlParser.parse(sXml);
	}
	return null;
};

caplinb.alerts.view.component.AlertsDrawerPersistor.prototype._saveXMLTemplate = function() {
	var sXml = this.m_oComponent.getSerializedState().replace(/\n/g, " ").replace(/\r/g, " ");;
	this.m_oUserPropertyStore.setUserProperty(this.m_sKey, (sXml));
};

caplinb.alerts.view.component.AlertsDrawerPersistor.prototype._getComponent = function() 
{
	if(!this.m_oComponent){
		return null;
	}
	var mChildComponents = this.m_oComponent.getChildComponents();
	if(mChildComponents["notificationsGrid"])
	{
		return mChildComponents["notificationsGrid"];
	}
	
	if(mChildComponents["activeAlertsGrid"])
	{
		return mChildComponents["activeAlertsGrid"];		
	}
	
	if(mChildComponents["historyGrid"])
	{
		return mChildComponents["historyGrid"];		
	}	
	
};