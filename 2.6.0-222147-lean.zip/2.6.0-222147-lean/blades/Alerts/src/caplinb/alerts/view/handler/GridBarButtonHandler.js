caplin.namespace("caplinb.alerts.view.handler");

caplinb.alerts.view.handler.GridBarButtonHandler = function()
{
};

caplinb.alerts.view.handler.GridBarButtonHandler.prototype.execute = function()
{
};

caplinb.alerts.view.handler.GridBarButtonHandler.prototype.handleGridRowSelection = function() {
	
};

caplinb.alerts.view.handler.GridBarButtonHandler.prototype.addObserver = function()
{
};