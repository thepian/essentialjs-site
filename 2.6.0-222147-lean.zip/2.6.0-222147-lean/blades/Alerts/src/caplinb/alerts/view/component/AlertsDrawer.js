caplin.namespace("caplinb.alerts.view.component");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.core.XmlParser");
caplin.include("caplin.webcentric.model.XMLAdaptor");
caplin.include("caplin.webcentric.presentation.FrameworkItem");
caplin.include("caplin.webcentric.presentation.factory.PresentationFactory");
caplin.include("caplin.webcentric.presentation.Application");

caplinb.alerts.view.component.AlertsDrawer = function()
{
	this.m_bVisible = false;
	this.m_oComponent;
	caplin.notifyAfterClassLoad(this);
};

caplinb.alerts.view.component.AlertsDrawer.prototype.onAfterClassLoad = function()
{
	caplinb.alerts.view.component.AlertsDrawer.XMLTEMPLATE = '<Stack xmlns:caplin="http://www.caplin.com" id="AlertsDrawer" height="300" auto_width="true" decorators="drawerDecorator" align="bottom" bottom="24" hidden="true">' +
	'<FrameItems>' +
		'<caplin:Panel caption="'+ ct.i18n("blade.alerts.grid.tab.notification.caption") +'" type="caplinb.alerts.view.component.AlertsDrawerComponent">' +
			'<param name="model" value="{.}" />' +
			'<state>' +
				'<compositeComponent refId=\"notificationsGridButtonHeader\"/>'+
			'</state>' +
		'</caplin:Panel>' +
		'<caplin:Panel caption="'+ ct.i18n("blade.alerts.grid.tab.activealerts.caption") +'" type="caplinb.alerts.view.component.AlertsDrawerComponent">' +
			'<param name="model" value="{.}" />' +
			'<state>' +
				'<compositeComponent refId=\"activeTriggersGridButtonHeader\"/>'+
			'</state>' +
		'</caplin:Panel>' +
		'<caplin:Panel caption="'+ ct.i18n("blade.alerts.grid.tab.history.caption") +'" type="caplinb.alerts.view.component.AlertsDrawerComponent">' +
			'<param name="model" value="{.}" />' +
			'<state>' +
				'<compositeComponent refId=\"historyGridButtonHeader\"/>'+
			'</state>' +
		'</caplin:Panel>' +
	'</FrameItems>' +
	'</Stack>';
};

caplinb.alerts.view.component.AlertsDrawer.prototype.toggle = function()
{
	if(this.m_bVisible)
	{
		this.hide();
	}
	else
	{
		this.show();
	}
};

caplinb.alerts.view.component.AlertsDrawer.prototype.hide = function()
{
	if(!this.m_oComponent)
	{
		this.m_oComponent = this._buildComponent();
	}
	this.m_oComponent.hide();
	this.m_bVisible = false;
};

caplinb.alerts.view.component.AlertsDrawer.prototype.show = function()
{
	if(!this.m_oComponent)
	{
		this.m_oComponent = this._buildComponent();
	}
	this.m_oComponent.show();
	this._showAndSelectNotificationsGrid();
	this.m_bVisible = true;
};

caplinb.alerts.view.component.AlertsDrawer.prototype._buildComponent = function()
{
	var oGUIModel = Application.model.selectSingleNode("GUI");
	var oGUI = caplin.webcentric.presentation.FrameworkItem.presentationForModel(oGUIModel);
	var oXml = caplin.core.XmlParser.parse(caplinb.alerts.view.component.AlertsDrawer.XMLTEMPLATE); 
	var oModel = caplin.webcentric.model.XMLAdaptor.buildDataNode(oXml);
	var oComponent = webcentric.PresentationFactory.createPresentation(oModel);
	
	oGUIModel.selectSingleNode("FrameItems").addChildNode(oModel, undefined, false);
	oGUI.addFrameItem(oComponent);
	
	return oComponent;
};

caplinb.alerts.view.component.AlertsDrawer.prototype._showAndSelectNotificationsGrid = function()
{
	this.m_oComponent.model.setProperties({'selected_ind':0});
	this.m_oComponent.frames[0].handleClick();
};

caplin.singleton("caplinb.alerts.view.component.AlertsDrawer");