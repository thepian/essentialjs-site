/**
 * @fileoverview
 * Defines the caplinb.alerts.view.AlertsService class.
 */
caplin.namespace("caplinb.alerts.view.handler");
caplin.include("caplin.alerts.AlertsService", true);
caplin.include("caplinb.alerts.view.NewAlertFormInitialiser");
caplin.include("caplinb.alerts.view.component.AlertsDrawer");

/**
 * @class
 * Registers an instance of caplinb.alerts.view.AlertsService into the caplin.core.ServiceRegistry to allow access to the Alert Blade view features from the main application
 * @implements caplin.alerts.AlertsService
 * @constructor
 */
caplinb.alerts.view.AlertsService = function() {};

caplin.implement(caplinb.alerts.view.AlertsService, caplin.alerts.AlertsService);

/**
 * Creates a new form builder element to create a new alert and opens it in a webcentric dialog.
 *
 * @param {caplinb.alerts.view.AlertsService} sInstrument: The currency pair the new alert will monitor, GBPUSD
 * @param {caplinb.alerts.view.AlertsService} sField: The field that is attached to column that is clicked on. Used to set the default bid/ask drop down in the form.
 * @param {caplinb.alerts.view.AlertsService} sSubject: The Liberator symbol for the currency pair, /FX/GBPUSD
 */
caplinb.alerts.view.AlertsService.prototype.openAlertCreateDialog = function(sInstrument, sField, sSubject) {
	var mAttributes = {field: sField, instrument: sInstrument, subject:sSubject};
	new caplinb.alerts.view.NewAlertFormInitialiser().execute(mAttributes);
};

/**
 * Toggles the visibility of a composite component element that lists notifications, alerts and history
 */
caplinb.alerts.view.AlertsService.prototype.openAlertManagerDialog = function() {
	caplinb.alerts.view.component.AlertsDrawer.toggle();
};

/**
 * Creates a element that displays the current notification count and appends it to a parent element.
 */
caplinb.alerts.view.AlertsService.prototype.createNotificationCounter = function(eContainer) {
	new caplinb.alerts.view.NotificationCounter(eContainer);
};

/**
 * @private
 */
caplinb.alerts.view.AlertsService.onAfterClassLoad = function() {
	var alertService = new caplinb.alerts.view.AlertsService();
	caplin.core.ServiceRegistry.registerService("caplin.alerts.AlertService", alertService);
};

caplin.notifyAfterClassLoad(caplinb.alerts.view.AlertsService);