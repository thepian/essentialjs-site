caplin.namespace("caplinb.alerts.view.handler");

caplin.include("caplin.alerts.NotificationService");
caplin.include("caplinb.alerts.view.handler.GridBarButtonHandler", true);

caplinb.alerts.view.handler.ClearButtonHandler = function(eButton)
{
};

caplin.implement(caplinb.alerts.view.handler.ClearButtonHandler, caplinb.alerts.view.handler.GridBarButtonHandler)

caplinb.alerts.view.handler.ClearButtonHandler.prototype.handleGridRowSelection = function(oGridRowModel, pSelectedRows) {
	
};

caplinb.alerts.view.handler.ClearButtonHandler.prototype.execute = function(pSelectedRows)
{
	caplin.alerts.NotificationService.clearHistory();
};