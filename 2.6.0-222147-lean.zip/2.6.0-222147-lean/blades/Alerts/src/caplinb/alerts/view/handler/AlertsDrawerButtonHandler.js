caplin.namespace("caplinb.alerts.view.handler");

caplin.include("caplin.element.Handler", true);
caplin.include("caplin.dom.Utility");

caplinb.alerts.view.handler.AlertsDrawerButtonHandler = function()
{
};

caplin.extend(caplinb.alerts.view.handler.AlertsDrawerButtonHandler, caplin.element.Handler);

caplinb.alerts.view.handler.AlertsDrawerButtonHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes)
{
	var alertService = caplin.core.ServiceRegistry.getService("caplin.alerts.AlertService");
	alertService.openAlertManagerDialog();

	caplin.dom.Utility.stopEventPropagation(oDomEvent);
	return false;
};

caplinb.alerts.view.handler.AlertsDrawerButtonHandler.prototype.toString = function()
{
	return "caplinb.alerts.view.handler.AlertsDrawerButtonHandler";
};

caplin.singleton("caplinb.alerts.view.handler.AlertsDrawerButtonHandler");
