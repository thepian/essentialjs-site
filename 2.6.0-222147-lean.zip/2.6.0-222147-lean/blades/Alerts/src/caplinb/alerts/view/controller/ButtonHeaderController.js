caplin.namespace("caplinb.alerts.view.controller");

caplin.include("caplin.component.container.Container", true);
caplin.include("caplin.component.composite.CompositeComponentController", true);
caplin.include("caplin.grid.GridRowSelectionModelListener", true);
caplin.include("caplin.alerts.NotificationService");

/**
 * 
 * @implements caplin.component.composite.CompositeComponentController
 * @constructor
 */
caplinb.alerts.view.controller.ButtonHeaderController = function()
{
};

caplin.implement(caplinb.alerts.view.controller.ButtonHeaderController, caplin.component.composite.CompositeComponentController);
caplin.implement(caplinb.alerts.view.controller.ButtonHeaderController, caplin.component.container.Container);
caplin.implement(caplinb.alerts.view.controller.ButtonHeaderController, caplin.grid.GridRowSelectionModelListener);

/*******************************************************************************
 *      caplin.component.composite.CompositeComponentController Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#initialize
 */
caplinb.alerts.view.controller.ButtonHeaderController.prototype.initialize = function(mComponents, oCompositeComponent)
{
	this.m_mComponents = mComponents;
	this._getComponent().setContainer(this);	
	this._getComponent().getGridRowSelectionModel().addRowSelectionListener(this);
	
	for(sComponentId in this.m_mComponents)
	{
		var oComponent = this.m_mComponents[sComponentId];
		if(oComponent.addListener)
		{
			oComponent.addListener(this);
		}
	}	
};

caplinb.alerts.view.controller.ButtonHeaderController.prototype.onRowSelectionChanged = function() {
	var oGridRowSelectionModel = this._getComponent().getGridRowSelectionModel();
	var pSelectedRows = oGridRowSelectionModel.getSelectedRows();
	var oGridRowModel = this._getComponent().getGridRowModel();
	for(sComponentId in this.m_mComponents)	{
		var oComponent = this.m_mComponents[sComponentId];
		if(oComponent.getButtonHandlers) {
			for(var index = 0 ;index < oComponent.getButtonHandlers().length; index++) {
				var oButtonHandler = oComponent.getButtonHandlers()[index];
				oButtonHandler.handleGridRowSelection(oGridRowModel, pSelectedRows);
			}
		}
	}		
};


/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#finalize
 */
caplinb.alerts.view.controller.ButtonHeaderController.prototype.finalize = function(){
	//TODO 
};

caplinb.alerts.view.controller.ButtonHeaderController.prototype.setComponentModified = function() {
	//Do Nothing;
};

caplinb.alerts.view.controller.ButtonHeaderController.prototype.handleClick = function(oButtonHandler)
{
	var oGridRowSelectionModel = this._getComponent().getGridRowSelectionModel();
	var pSelectedRows = oGridRowSelectionModel.getSelectedRows();
	oButtonHandler.execute(pSelectedRows);
	oGridRowSelectionModel.deselectAllRows();
};

caplinb.alerts.view.controller.ButtonHeaderController.prototype._getComponent = function()
{
	if(this.m_mComponents["notificationsGrid"])
	{
		return this.m_mComponents["notificationsGrid"];
	}
	
	if(this.m_mComponents["activeAlertsGrid"])
	{
		return this.m_mComponents["activeAlertsGrid"];		
	}
	
	if(this.m_mComponents["historyGrid"])
	{
		return this.m_mComponents["historyGrid"];		
	}
};
