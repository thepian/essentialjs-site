caplin.namespace("caplinb.alerts.view");

caplin.include("caplin.alerts.NotificationServiceListener", true);
caplin.include("caplin.alerts.NotificationService");
caplin.include("caplin.dom.Utility");

caplinb.alerts.view.NotificationCounter = function(eContainer) {
	this.m_eContainer = eContainer;
	this.m_nCounter = 0;
	this._initialise();	
};

caplin.implement(caplinb.alerts.view.NotificationCounter, caplin.alerts.NotificationServiceListener);

caplinb.alerts.view.NotificationCounter.prototype._initialise = function() {
	caplin.alerts.NotificationService.addListener(this);
	this._createCounterElement();
	this.m_nCounter = caplin.alerts.NotificationService.getNewNotifications().length;
	this._renderUpdatedCount();
};

caplinb.alerts.view.NotificationCounter.prototype.onDataUnavailable = function() {
	caplin.dom.Utility.addClassName(this.m_eIndicator, "notification-counter-hide");
};

caplinb.alerts.view.NotificationCounter.prototype.onNotificationAdded = function(oNotification)
{
	if(oNotification['status'] === caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW)
	{
		this.m_nCounter++;
		this._renderUpdatedCount();
	}
};
caplinb.alerts.view.NotificationCounter.prototype.onNotificationDismissed = function(oNotification)
{
	if (this.m_nCounter > 0) 
	{
		this.m_nCounter--;
	}
	this._renderUpdatedCount();
};

caplinb.alerts.view.NotificationCounter.prototype.onDataAvailable = function() {
	if(this.m_nCounter!==0){		
		caplin.dom.Utility.removeClassName(this.m_eIndicator, "notification-counter-hide");
	}
};

caplinb.alerts.view.NotificationCounter.prototype._createCounterElement = function() {
	this.m_eIndicator = document.createElement("SPAN");
	this.m_eIndicator.setAttribute("id", "notificationsCounter");
	caplin.dom.Utility.addClassName(this.m_eIndicator, "notification-counter notification-counter-hide");
	this.m_eContainer.appendChild(this.m_eIndicator);
};

caplinb.alerts.view.NotificationCounter.prototype._renderUpdatedCount = function() {
	if(this.m_nCounter > 0) {
		if(caplin.dom.Utility.hasClassName(this.m_eIndicator, "notification-counter-hide")) {
			caplin.dom.Utility.removeClassName(this.m_eIndicator, "notification-counter-hide");
		}
	} else {
		caplin.dom.Utility.addClassName(this.m_eIndicator, "notification-counter-hide");
	}
	this.m_eIndicator.innerHTML = this.m_nCounter ;
};
