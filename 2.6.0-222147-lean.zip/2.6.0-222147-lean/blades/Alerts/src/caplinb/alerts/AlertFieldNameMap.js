caplin.namespace("caplinb.alerts");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.core.XmlParser");


caplinb.alerts.AlertFieldNameMap = function()
{
	this.m_mFieldOptions = {};
	this.ALERT_FIELD_NAME_MAP_ELEMENT_NAME = "alertFields";
	caplin.notifyAfterClassLoad(this);
};

caplinb.alerts.AlertFieldNameMap.prototype.onAfterClassLoad = function()
{
	caplinb.alerts.AlertFieldNameMap.XMLTEMPLATE = '<alertFields><alertPriceFields>' +
	'<alertSubject regex="/FX/.*">' +
		'<field fieldName="BestBid" name="'+ct.i18n("blade.alerts.form.fx.bid")+'" operator="&gt;="/>' +
		'<field fieldName="BestAsk" name="'+ct.i18n("blade.alerts.form.fx.ask")+'" operator="&lt;="/>' +
	'</alertSubject>' +
	'<alertSubject regex="/FI/.*">' +
		'<field fieldName="BidYield" name="'+ct.i18n("blade.alerts.form.fi.bid")+'" operator="&gt;="/>' +
		'<field fieldName="AskYield" name="'+ct.i18n("blade.alerts.form.fi.ask")+'" operator="&lt;="/>' +
	'</alertSubject>' +
	'<alertSubject regex="/COMMANDHTTPD/.*">' +
		'<field fieldName="BestBid" name="'+ct.i18n("blade.alerts.form.fx.bid")+'" operator="&gt;="/>' +
		'<field fieldName="BestAsk" name="'+ct.i18n("blade.alerts.form.fx.ask")+'" operator="&lt;="/>' +
	'</alertSubject>' +
	'</alertPriceFields></alertFields>';
	
	this.m_eAlertDefinitionsXml = caplin.core.XmlParser.parse(caplinb.alerts.AlertFieldNameMap.XMLTEMPLATE);
	if (this.m_eAlertDefinitionsXml)
	{
		var eFieldsXml = this.m_eAlertDefinitionsXml.getElementsByTagName("alertPriceFields")[0];
		this._defineAlertFieldMap(eFieldsXml);
	}
};

/**
 * @private
 */
caplinb.alerts.AlertFieldNameMap.prototype._defineAlertFieldMap = function(eFieldsXml)
{
	if (eFieldsXml)
	{
		var pSubjectsXml = eFieldsXml.childNodes;
		var nSubjectsXml = pSubjectsXml.length;
		for (var i = 0; i < nSubjectsXml; ++i)
		{
			var eSubjectXml = pSubjectsXml[i];
			var sSubjectRegex = eSubjectXml.getAttribute("regex");
			var mAlertFieldMap = {};
			
			var pSubjectFieldsXml = eSubjectXml.childNodes;
			var nSubjectFieldsXml = pSubjectFieldsXml.length;
			for (var j = 0; j < nSubjectFieldsXml; ++j)
			{
				var eSubjectFieldXml = pSubjectFieldsXml[j];
				var sFieldName = eSubjectFieldXml.getAttribute("fieldName");
				var sName = eSubjectFieldXml.getAttribute("name");
				var sOperator = eSubjectFieldXml.getAttribute("operator");
				
				mAlertFieldMap[sFieldName] = {"name": sName, "operator": sOperator};
			}
			this.m_mFieldOptions[sSubjectRegex] = mAlertFieldMap;
		}
	}
};


/**
 * Returns an array of display names mapped to the specified subject
 * @param {String} sSubject Instrument type (e.g.: /FX/GBPUSD or /FI/US060=R)
 * @return array of the values mapped to the specified subject (e.g.: ["Bid", "Ask"])
 * @type Array
 */
caplinb.alerts.AlertFieldNameMap.prototype.getFieldsAsArray = function(sSubject){
	var mSubjectFieldMap = this._getFieldMap(sSubject);
	var pFields = [];
	for(var sKey in mSubjectFieldMap)
	{
		var mField = mSubjectFieldMap[sKey];
		pFields.push(mField["name"]);
	}
	return pFields;
};

/**
 * Returns an array of xaqua field names mapped to the specified subject
 * @param {String} sSubject Instrument type (e.g.: /FX/GBPUSD or /FI/US060=R)
 * @return array of the fields under the specified subject against which upon 
 * alert trigger can be created (e.g.: ["BidYield", "AskYield"])
 * @type Array
 */
caplinb.alerts.AlertFieldNameMap.prototype.getXaquaFieldsAsArray = function(sSubject){
	return  caplin.core.MapUtility.keysToArray(this._getFieldMap(sSubject));
};

/**
 * Returns the xaqua field name corresponding to a displayed field name for a specific subject.
 * @param {String} sSubject Instrument type (e.g.: /FX/GBPUSD or /FI/US060=R)
 * @param {String} sLookupDisplayName Field display name (e.g.: "Bid" or "Ask")
 * @return xaqua field name (e.g.: BestBid) 
 * @type String
 */
caplinb.alerts.AlertFieldNameMap.prototype.getXaquaFieldNameFor = function(sSubject, sLookupDisplayName){
	var mFieldMap = this._getFieldMap(sSubject);
	
	for(var sKey in mFieldMap) {
		var mField = mFieldMap[sKey];
		var sDisplayName = mField["name"];
		if(sLookupDisplayName === sDisplayName) {
			return sKey;
		}
	}
	return null;
};

/**
 * Returns the display field name corresponding to a xaqua field for a specific subject.
 * @param {String} sSubject Instrument type (e.g.: /FX/GBPUSD or /FI/US060=R)
 * @param {String} sXaquaFieldName Xaqua field name (e.g.: "BestBid" or "BestAsk")
 * @return display field name (e.g.: Bid) 
 * @type String
 */
caplinb.alerts.AlertFieldNameMap.prototype.getDisplayFieldNameFor = function(sSubject, sXaquaFieldName){
	var mFieldMap = this._getFieldMap(sSubject);
	var mField = mFieldMap[sXaquaFieldName];
	if (mField)
	{
		return mField["name"];
	}
	return null;
};

/**
 * Returns the default trigger operator corresponding to a xaqua field for a specific subject.
 * @param {String} sSubject Instrument type (e.g.: /FX/GBPUSD or /FI/US060=R)
 * @param {String} sXaquaFieldName Xaqua field name (e.g.: "BestBid" or "BestAsk")
 * @return default opertor (e.g.: >=) 
 * @type String
 */
caplinb.alerts.AlertFieldNameMap.prototype.getDefaultOperatorFor = function(sSubject, sLookupFieldName){
	var mFieldMap = this._getFieldMap(sSubject);
	var mField = mFieldMap[sLookupFieldName];
	if (mField)
	{
		if(mField["operator"])
		{
			return mField["operator"];
		}
	}
	return null;
};


/**
 * Replaces display name with xaqua field (monitored) name in the alerts condition. 
 * @param {String} sSubject intrument type
 * @param {String} sCondition alerts condition
 * @return alerts condition using monitored name 
 * @type String
 */
caplinb.alerts.AlertFieldNameMap.prototype.replaceWithMonitoredName = function(sSubject, sCondition){
	return this._replaceFieldName(sSubject, sCondition, false);
};

/**
 * Replaces monitored xaqua field name in a alerts condition with the corresponding
 * display name.
 * @param {String} sSubject instrument type
 * @param {String} sCondition alerts condition
 * @return alerts condition using display name 
 * @type String
 */
caplinb.alerts.AlertFieldNameMap.prototype.replaceWithDisplayName = function(sSubject, sCondition){
	return this._replaceFieldName(sSubject, sCondition, true);
};

caplinb.alerts.AlertFieldNameMap.prototype._replaceFieldName = function(sSubject, sCondition, bReplaceWithDisplayName){
	for(sSubjectRegex in this.m_mFieldOptions) 
	{
		if(sSubject.match(sSubjectRegex)) 
		{
			var mFields = this.m_mFieldOptions[sSubjectRegex];
			for(sFieldName in mFields) 
			{
				var mField = mFields[sFieldName];
				var sFieldValue = mField["name"];
				if(bReplaceWithDisplayName)
				{
					sCondition = sCondition.replace(sFieldName, sFieldValue);
				}
				else
				{
					sCondition = sCondition.replace(sFieldValue, sFieldName);
				}
			}
		}
	}
	return sCondition;
};	
	
	
/**
 * @private
 * @return Map entry defined for the specified subject if found else empty map
 * @type Map
 */
caplinb.alerts.AlertFieldNameMap.prototype._getFieldMap = function(sSubject){
	for(var sSubjectRegex in this.m_mFieldOptions) 
	{
		if(sSubject.match(sSubjectRegex))
		{
			return this.m_mFieldOptions[sSubjectRegex];
		}
	}
	return {};
};

caplin.singleton("caplinb.alerts.AlertFieldNameMap");

