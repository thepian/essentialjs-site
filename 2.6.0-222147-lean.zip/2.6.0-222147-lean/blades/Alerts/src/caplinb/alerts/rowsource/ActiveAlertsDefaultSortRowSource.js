caplin.namespace("caplinb.alerts.rowsource");

caplin.include("caplin.grid.rowsource.SortRowSource", true);

caplinb.alerts.rowsource.ActiveAlertsDefaultSortRowSource = function(eXmlConfig, oPreviousRowSource)
{
	caplin.grid.rowsource.SortRowSource.apply(this,arguments);
	caplin.grid.rowsource.SortRowSource.prototype.setSortRule.apply(this, [new caplin.component.sort.FieldSortRule("timeCreated",caplin.component.sort.FieldSortRule.NUMERIC_SORT,caplin.component.sort.FieldSortRule.DESCENDING)]);
};

caplin.extend(caplinb.alerts.rowsource.ActiveAlertsDefaultSortRowSource, caplin.grid.rowsource.SortRowSource);

caplinb.alerts.rowsource.ActiveAlertsDefaultSortRowSource.prototype.setSortRule = function(oSortRule){};

caplinb.alerts.rowsource.ActiveAlertsDefaultSortRowSource.prototype.clearSortRule = function(){};