caplin.namespace("caplinb.alerts.rowsource");

caplin.include("caplin.grid.RowDataUnavailable", true);
caplin.include("caplin.grid.rowsource.RowSource", true);
caplin.include("caplin.alerts.TriggerServiceListener", true);
caplin.include("caplin.alerts.TriggerService", true);
caplin.include("caplin.core.Observable");

caplinb.alerts.rowsource.TriggerManagerRowSource = function(){
	caplin.alerts.TriggerService.addListener(this);
	/** @private */
	this.m_oObservable = new caplin.core.Observable();
};

caplin.implement(caplinb.alerts.rowsource.TriggerManagerRowSource, caplin.grid.rowsource.RowSource);
caplin.implement(caplinb.alerts.rowsource.TriggerManagerRowSource, caplin.alerts.TriggerServiceListener);

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.addRowSourceListener = function(oRowSourceListener) {
	this.m_oObservable.addObserver(oRowSourceListener);
};

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.getAllRows = function() {
	var pRows = [];
	var oTriggers = caplin.alerts.TriggerService.getAllTriggers(); 
	
	for(var i = oTriggers.length - 1; i >= 0; --i) {
		var oTrigger = oTriggers[i];
		pRows.push({"id": oTrigger.id, "data": this._createRowDataMapFromTrigger(oTrigger)});
	}
	return pRows;
};

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.onTriggerAdded = function(oTrigger) {
	oTrigger["alertCondition"] = caplinb.alerts.AlertFieldNameMap.replaceWithDisplayName(oTrigger.subject, oTrigger.alertCondition);
	this.m_oObservable.notifyObservers('rowAdded', [oTrigger.id, this._createRowDataMapFromTrigger(oTrigger), 0]);
	this.m_oObservable.notifyObservers('structureChangeCompleted', []);
};

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.onTriggerRemoved = function(sId) {
	this.m_oObservable.notifyObservers('rowRemoved', [sId]);
	this.m_oObservable.notifyObservers('structureChangeCompleted', []);
};

/**
 * @private
 */
caplinb.alerts.rowsource.TriggerManagerRowSource.prototype._getDataUnavailableMessage = function(nReason)
{
	if(!this.m_mDataUnavailableMessages)
	{
		this.m_mDataUnavailableMessages = {};
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_FOUND] = caplin.grid.RowDataUnavailable.NOT_FOUND;
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_PERMISSIONED] = caplin.grid.RowDataUnavailable.NOT_PERMISSIONED;
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.UNKNOWN_ERROR] = caplin.grid.RowDataUnavailable.ERROR;
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.RTTP_CONTAINER_DELETED] = caplin.grid.RowDataUnavailable.DELETED;
	}
	
	return this.m_mDataUnavailableMessages[nReason];
};

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.onInitialSession = function(){
};

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.onDataUnavailable = function(nReason) {
	this.m_oObservable.notifyObservers("allRowsRemoved", []);
	this.m_oObservable.notifyObservers("structureChangeCompleted", []);
	var sReason = this._getDataUnavailableMessage(nReason);
	this.m_oObservable.notifyObservers("dataUnavailable", [sReason]);
};

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype.onDataAvailable = function() {
	var oTriggers = caplin.alerts.TriggerService.getAllTriggers(); 

	if(oTriggers.length === 0) {
		this.m_oObservable.notifyObservers('rowAdded', ["-1", {}, 0]);		
		this.m_oObservable.notifyObservers('structureChangeCompleted', []);
		this.m_oObservable.notifyObservers('rowRemoved', ["-1"]);		
		this.m_oObservable.notifyObservers('structureChangeCompleted', []);
	} else {
		for(var i = oTriggers.length - 1; i >= 0; --i) {
			var oTrigger = oTriggers[i];
			oTrigger["alertCondition"] = caplinb.alerts.AlertFieldNameMap.replaceWithDisplayName(oTrigger.subject, oTrigger.alertCondition);
			this.m_oObservable.notifyObservers('rowAdded', [oTrigger.id, this._createRowDataMapFromTrigger(oTrigger), 0]);		
		}
		this.m_oObservable.notifyObservers('structureChangeCompleted', []);
	}
}

caplinb.alerts.rowsource.TriggerManagerRowSource.prototype._createRowDataMapFromTrigger = function(oTrigger) {
	var mFieldData = {};
	for (oField in oTrigger){
		mFieldData[oField] = oTrigger[oField];
	}
	return mFieldData;
};
