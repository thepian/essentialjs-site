caplin.namespace("caplin.alerts.workbench");

caplin.alerts.workbench.DataSource = function() {
	this.m_nAlerts = 0;
	if (this.initialise){
		this.initialise();
	};
};

caplin.extend(caplin.alerts.workbench.DataSource, SL4B_AbstractSubscriber);

caplin.alerts.workbench.DataSource.prototype = new SL4B_AbstractSubscriber();

caplin.alerts.workbench.DataSource.prototype.ready = function() 
{
	SL4B_Accessor.getRttpProvider().getObject(this, "/DSNOTIFICATIONS");
};

caplin.alerts.workbench.DataSource.prototype.recordMultiUpdated = function(sObjectName, oFieldData) 
{
	var mFields = oFieldData.getFieldMap();
	var sAlertOperation = mFields['AlertOperation'];
	var sAlertId = mFields['AlertId'];
	
	if (sAlertOperation && sAlertId)
	{
		var currentLog = document.getElementById("notification-datasource-event-log").innerHTML;
		document.getElementById("notification-datasource-event-log").innerHTML =
			sAlertOperation + " on "  + sAlertId + "<br>" + 
			currentLog;
	}
};			

caplin.alerts.workbench.DataSource.prototype.sendEventOnNotification = function() {
	var sAlertNameField = document.getElementById("dsEvent-alert-name").value;
	var sAlertCategoryField = document.getElementById("dsAction-alert").value;
	
	caplin.alerts.NotificationService.raiseEventOnNotifications([sAlertNameField],sAlertCategoryField);
};

caplin.alerts.workbench.DataSource.prototype.contribToDataSource = function() {
	var sAlertNameField = document.getElementById("ds-alert-name").value;
	var sAlertName = sAlertNameField ? sAlertNameField : " ";

	var sAlertTypeField = document.getElementById("ds-alert-type").value;
	var sAlertType = sAlertTypeField ? sAlertTypeField : " ";
	
	var sAlertCategoryField = document.getElementById("ds-alert-category").value;
	var sAlertCategory = sAlertCategoryField ? sAlertCategoryField : " ";
	
	var sAlertDescField = document.getElementById("ds-alert-description").value;
	var sAlertDescription = sAlertDescField ? sAlertDescField : " ";

	var sAlertExampleCustomFieldData = document.getElementById("ds-alert-custom-field").value;
	var sAlertExampleCustomField = sAlertExampleCustomFieldData ? sAlertExampleCustomFieldData : " ";
	
	///DSNOTIFICATIONS/notificationname-type
	var oContribData = new SL4B_ContributionFieldData();
	var sSubject = "/DSNOTIFICATIONS";
	oContribData.addField("AlertName", sAlertName);
	oContribData.addField("AlertId", sAlertName);
	oContribData.addField("AlertType", sAlertType);
	oContribData.addField("AlertCategory", sAlertCategory);
	oContribData.addField("AlertDescription", sAlertDescription);
	oContribData.addField("AlertExampleCustomField", sAlertExampleCustomField);
	SL4B_Accessor.getRttpProvider().contribObject(this, "/DSNOTIFICATIONS", oContribData);
};

caplin.singleton("caplin.alerts.workbench.DataSource");
