function SL_IF(){SL4B_Accessor.getConfiguration().loaded();}
SL_IF();