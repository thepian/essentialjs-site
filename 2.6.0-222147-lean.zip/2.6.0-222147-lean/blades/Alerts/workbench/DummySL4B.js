
SL4B_ConnectionListener = function(){};
SL4B_Accessor = {
		bob: "1234",
		 getStatistics : function(){
			 return {
				 getResponseQueueStatistics: function(){
					 return {
						 getTimeOldestBatchWasQueued : function(){
							 return new Date();
						 }
					 };
				 }
			 };
		 },
		 getRttpProvider : function(){
			 return {
				 addConnectionListener : function(){
					 return {};
				 }
			 };
		 }
};

SL4B_ObjectStatus = {
	INFO:0,
	STALE:1,
	REMOVED:2,
	OK:3,
	LIMITED:5
};

var SL4B_AbstractSubscriber =  function(){};
SL4B_AbstractSubscriber.prototype.initialise = function() {};

SL4B_ContainerKey = function() {
};

////////////////////////
//
////////////////////////	
function FieldData(oMap)
{
	this.m_oMap = oMap;
	this.m_pData = this._convert(oMap);
};

function FieldData(oMap)
{
	 if(oMap === undefined) {
		 this.m_oMap = {};
	 } else {
		 this.m_oMap = oMap;
	 }
	 this.m_pData = this._convert(oMap);
};

FieldData.prototype._convert = function(oMap){
	
	var pResult = [];
	for(var sName in oMap){
		var sValue = oMap[name];
		pResult.push({name: sName,  value: sValue});
	}
	return pResult;
};

FieldData.prototype.size = function(){
	return this.m_pData.length;
};

FieldData.prototype.getFieldValue = function(nIndex){
	return this.m_pData[nIndex].value;
};

FieldData.prototype.getFieldName = function(nIndex){
	return this.m_pData[nIndex].name;
};

FieldData.prototype.getFieldMap = function(){
	return this.m_oMap;
};
FieldData.prototype.addField = function(sFieldName, sFieldValue){
	this.m_pData[sFieldName] = sFieldValue;
	this.m_oMap[sFieldName]= sFieldValue;
};
FieldData.prototype.toString = function(){ 
	var sData = "";
	for (field in this.m_oMap){
		sData += "[" + field + "=" + this.m_oMap[field] + "]";
	}
	return sData; 
};

SL4B_ContributionFieldData = function()
{
	/**
	 * An array of {@link GF_Field}s, representing the field names and their corresponding values to
	 * be contributed to the Liberator.
	 *
	 * @type Array
	 * @private
	 */
	this.m_pFieldNameAndValues = new Array();
};

/**
 * Adds the specified field name/value pair to the data to be contributed to the Liberator.
 *
 * @param {String} l_sFieldName The name of the field.
 * @param {String} l_sFieldValue The value of the field.
 */
SL4B_ContributionFieldData.prototype.addField = function(l_sFieldName, l_sFieldValue) { this.m_pFieldNameAndValues.push(new GF_Field(l_sFieldName, l_sFieldValue)); };

/**
 * Gets the number of fields that have been added to the <code>SL4B_ContributionFieldData</code>.
 *
 * @type int
 * @return The number of fields that have been added.
 */
SL4B_ContributionFieldData.prototype.size = function() { return this.m_pFieldNameAndValues.length; };

/**
 * Gets the field with the specified index.
 *
 * @type GF_Field
 * @return The field with the specified index.
 * @throws SL4B_Exception If the specified index is greater than or equal to
 *         {@link SL4B_ContributionFieldData#size}, or if it is negative.
 */
SL4B_ContributionFieldData.prototype.getField = function(l_nIndex) {
	if (l_nIndex >= this.m_pFieldNameAndValues.length || l_nIndex < 0)
	{
		throw new SL4B_Exception("getField: specified field index \"" + l_nIndex + "\" is out of bounds");
	}
	return this.m_pFieldNameAndValues[l_nIndex];
};

SL4B_ContributionFieldData.prototype.getFieldMap = function() {
	var mFieldMap = {};
	for (var i=0; i < this.m_pFieldNameAndValues.length; i++){
		var field = this.m_pFieldNameAndValues[i];
		mFieldMap[field.m_sName] = field.m_sValue;
	}
	return mFieldMap;
};

SL4B_ContributionFieldData.prototype.updateFieldData = function(sName, sValue) {
	var mFieldMap = {};
	for (var i=0; i < this.m_pFieldNameAndValues.length; i++){
		var field = this.m_pFieldNameAndValues[i];
		if (field.m_sName == sName){
			field.m_sValue = sValue;
			break;
		}
	}
};

/**
 * Gets a string representation of the <code>SL4B_ContributionFieldData</code>.
 *
 * @type String
 * @return A string representation of the <code>SL4B_ContributionFieldData</code>.
 */
SL4B_ContributionFieldData.prototype.toString = function() { return this.m_pFieldNameAndValues.join(" "); };

/**
 * Constructs a <code>GF_Field</code> with the specified field name and value.
 *
 * @param {String} l_sName The name of the field.
 * @param {String} l_sValue The value of the field.
 *
 * @class Represents a single field name/value pair to be contributed to the Liberator.
 * @private
 */
function GF_Field(l_sName, l_sValue)
{
	// Note: this class is also used by the AbstractJavaScriptRttpProvider

	/**
	 * The name of the field.
	 *
	 * @type String
	 * @private
	 */
	this.m_sName = l_sName;

	/**
	 * The value of the field.
	 *
	 * @type String
	 * @private
	 */
	this.m_sValue = l_sValue;
}

/**
 * Gets a string representation of the field name/value pair.
 *
 * @type String
 * @return A string representation of the field.
 */
GF_Field.prototype.toString = function() { return "[" + this.m_sName + "=" + this.m_sValue + "]"; };


