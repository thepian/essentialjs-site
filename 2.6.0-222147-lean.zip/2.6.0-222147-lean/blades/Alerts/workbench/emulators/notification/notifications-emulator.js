caplin.namespace("caplinb.alerts");

caplinb.alerts.NotificationsEmulator = function(){
	this.sNotificationSubject = "/ALERTS/NOTIFICATIONS";
	this.pNotifications = [];
	this.nNewNotifications = 0;
	this.mNotificationRowNumbers = {};
	this.pNotificationsToRemove = [];
	this.AlertRequestedTimestamp = new Date();
	caplinb.emulators.SL4BEmulator.addContribListener(this, "/NOTIFICATIONS/CONTROL");
};


caplinb.alerts.NotificationsEmulator.prototype.sendImage = function(){
	for(var i = 0; i < this.nNewNotifications; ++i)
	{
		caplinb.alerts.NotificationsEmulator.onEmulatedSendNotificationAction(i);			
	}
};

caplinb.alerts.NotificationsEmulator.prototype.uniqueId = 0;
caplinb.alerts.NotificationsEmulator.prototype.quickAddDSNotification = function(){
	var updateData = {
			"AlertId": "DSNotification_" + this.uniqueId++,
			"AlertSubject": "Subject",
			"AlertDescription": "Description",
			"AlertVersion": "Version",
			"AlertTime": "12345",
			"AlertCategory": "QuickNotification",
			"AlertSource" : "Standalone"
			
	};
	this.addTriggeredNotification(updateData);
};

caplinb.alerts.NotificationsEmulator.prototype._setLastClientAction = function(sIds, sOperation)
{
	pIds = sIds.split(" ");
	for (var i=0; i < pIds.length; i++ )
	{
		var eLastClientAction = document.getElementById('notifications-emulator-client-action-' + this.mNotificationRowNumbers[pIds[i]]);
		if(eLastClientAction)
		{
			eLastClientAction.innerHTML = sOperation;
		}
	}
};

caplinb.alerts.NotificationsEmulator.prototype._dismissNotifications = function(oSubscriber, sIds){
	var pDismissedNotifications = sIds.split(" ");
	for(var j = 0; j < pDismissedNotifications.length; j++)
	{
		this.nNewNotifications--;
	}
	caplinb.emulators.SL4BEmulator.removeItemFromContainer(oSubscriber, "/NOTIFICATIONS/NOTIFY", this.nNewNotifications);
};

caplinb.alerts.NotificationsEmulator.prototype.addTriggeredNotification = function(mNotificationData){
	this.mNotificationRowNumbers[mNotificationData['AlertId']] = this.pNotifications.length;

	var notificationRow = document.createElement("tr");
	notificationRow.className = "notificationRow";
	
	var alertId = document.createElement("td");
	alertId.innerHTML = mNotificationData['AlertId'];
	notificationRow.appendChild(alertId);

	if(mNotificationData['AlertName'] && mNotificationData['AlertInstrument'] && mNotificationData['AlertExpression'])
	{
		mNotificationData['AlertDescription'] = mNotificationData['AlertName'] + " " + mNotificationData['AlertInstrument'] + " " + mNotificationData['AlertExpression'];
		delete mNotificationData['AlertName'];
		delete mNotificationData['AlertInstrument'];
		delete mNotificationData['AlertExpression'];
	}
	
	var triggerDescription = document.createElement("td");
	triggerDescription.innerHTML = mNotificationData['AlertDescription'];
	notificationRow.appendChild(triggerDescription);
	
	var actionTime = document.createElement("td");
	actionTime.innerHTML = mNotificationData['AlertTime'];
	notificationRow.appendChild(actionTime);
	
	var lastClientActionData = document.createElement("td");
	lastClientActionData.id = "notifications-emulator-client-action-" + this.pNotifications.length;
	notificationRow.appendChild(lastClientActionData);
	
	var availabilityButton = document.createElement("td");
	availabilityButton.innerHTML =  '<input id="toggle-availability-action-button-' + (this.pNotifications.length) + '" type="submit" value="STALE" disabled="true"' + 
	' onClick="caplinb.alerts.NotificationsEmulator.onEmulatedToggleAvailabilityAction('+ (this.pNotifications.length) + ');">';
	notificationRow.appendChild(availabilityButton);

	var persistButton = document.createElement("td");
	persistButton.innerHTML =  '<input id="toggle-persist-action-button-' + (this.pNotifications.length) + '" type="submit" value="Yes" disabled="true"' + 
	' onClick="caplinb.alerts.NotificationsEmulator.onEmulatedTogglePersistAction('+ (this.pNotifications.length) + ');">';
	notificationRow.appendChild(persistButton);

	var actionButtonData = document.createElement("td");
	actionButtonData.innerHTML =  '<input id="send-notification-action-button-' + (this.pNotifications.length) + '" type="submit" value="Send"' + 
		' onClick="caplinb.alerts.NotificationsEmulator.onEmulatedSendNotificationAction('+ (this.pNotifications.length) + ');">';
	notificationRow.appendChild(actionButtonData);
	
	this.nNewNotifications++;
	
	document.getElementById("notifications-emulator-form").appendChild(notificationRow);
	
	this.pNotifications.push(mNotificationData);
};

caplinb.alerts.NotificationsEmulator.onEmulatedSendNotificationAction = function(nTriggerRowId){
	document.getElementById("send-notification-action-button-"+nTriggerRowId).disabled = true;
	document.getElementById("toggle-availability-action-button-"+nTriggerRowId).disabled = false;
	document.getElementById("toggle-persist-action-button-"+nTriggerRowId).disabled = false;
	var updateData = this.pNotifications[nTriggerRowId];
	caplinb.emulators.SL4BEmulator.addItemToContainer(updateData, caplin.alerts.NotificationService.m_oAlertsMonitor, this.sNotificationSubject, nTriggerRowId);
};

caplinb.alerts.NotificationsEmulator.onEmulatedToggleAvailabilityAction = function(nTriggerRowId)
{
	var sState = document.getElementById("toggle-availability-action-button-" + nTriggerRowId).value;
	var sNewState;
	var nObjectStatus;
	
	if(sState.match("NOTSTALE"))
	{
		newState="STALE";
		nObjectStatus=3;
	}
	else
	{
		newState="NOTSTALE";
		nObjectStatus = SL4B_ObjectStatus.STALE;
	}

	document.getElementById("toggle-availability-action-button-"+nTriggerRowId).value = newState;
	var updateData = this.pNotifications[nTriggerRowId];
	var sSubject = "/NOTIFICATIONS/DATASOURCES/RECORD/" +  updateData["AlertId"];
	caplinb.emulators.SL4BEmulator.fireObjectStatus( caplin.alerts.NotificationService.m_oAlertsMonitor, sSubject, nObjectStatus);
};

caplinb.alerts.NotificationsEmulator.onEmulatedTogglePersistAction = function(nTriggerRowId)
{
	var updateData = this.pNotifications[nTriggerRowId];
	
	if(caplin.core.ArrayUtility.inArray(this.pNotificationsToRemove, updateData["AlertId"]))
	{
		this.pNotificationsToRemove = caplin.core.ArrayUtility.removeItem(this.pNotificationsToRemove, updateData["AlertId"]);
		document.getElementById("toggle-persist-action-button-"+nTriggerRowId).value = "Yes";
	}
	else
	{
		this.pNotificationsToRemove.push(updateData["AlertId"]);
		document.getElementById("toggle-persist-action-button-"+nTriggerRowId).value = "No";
	}
};

caplinb.alerts.NotificationsEmulator.contribObject = function(oSubscriber, mData){
	if(mData["AlertOperation"] === "DISMISS"){
		this._dismissNotifications(oSubscriber, mData["AlertId"]);
	}
	this._setLastClientAction(mData["AlertId"], mData["AlertOperation"]);
};

caplinb.alerts.NotificationsEmulator.simulateFailover = function()
{
	var pStructureChanges = [];
	for(var i=0; i<this.pNotificationsToRemove.length; i++)
	{
		pStructureChanges.push(this._createStructureChange({subject : "/NOTIFICATIONS/DATASOURCES/RECORD/"+this.pNotificationsToRemove[i], add : false}));
	}
	caplinb.emulators.SL4BEmulator.fireStructureMultiChange(caplin.alerts.NotificationService.m_oAlertsMonitor, "NOTIFICATIONS/CONTAINER", pStructureChanges, [], -1);
};

caplinb.alerts.NotificationsEmulator._createStructureChange = function(mOptions) {
	return {
		getAdded: function(){return mOptions.add;},
		getObjectName: function(){return mOptions.subject;}
	};
};

caplinb.alerts.NotificationsEmulator.sendPlaceholder = function(nStatus, bUpdateTime)
{
	if(nStatus === 3)
	{
		if(bUpdateTime === true)
		{
			this.AlertRequestedTimestamp = new Date();
		}
				
		var updateData = {
				"AlertTimeRequested":  this.AlertRequestedTimestamp
		};
		
		caplinb.emulators.SL4BEmulator.fireRecordMultiUpdated(updateData, caplin.alerts.NotificationService.m_oAlertsMonitor, "/ALERTS/PLACEHOLDER/");
	}
	caplinb.emulators.SL4BEmulator.fireObjectStatus(caplin.alerts.NotificationService.m_oAlertsMonitor, "/ALERTS/PLACEHOLDER/", nStatus);
};


caplin.singleton("caplinb.alerts.NotificationsEmulator");
