caplin.namespace("caplinb.emulators");

caplin.include("caplin.core.ApplicationProperties", true);
caplin.include("caplin.alerts.AlertsProperties", true);

caplinb.emulators.PropertiesEmulator = function()
{
	this.original_MAX_ALERTS_TRIGGERS = caplin.alerts.AlertsProperties.getMaxAlertsTriggers();
	this.original_MAX_ALERTS_NOTIFICATIONS_HISTORY =  caplin.alerts.AlertsProperties.getMaxAlertsNotificationsHistory();};

caplinb.emulators.PropertiesEmulator.prototype.resetProperties = function()
{
	caplin.core.ApplicationProperties.setProperty("CAPLIN.ALERTS.MAX.ALERTS.TRIGGERS",this.original_MAX_ALERTS_TRIGGERS);
	caplin.core.ApplicationProperties.setProperty("CAPLIN.ALERTS.MAX.ALERTS.NOTIFICATIONS.HISTORY",this.original_MAX_ALERTS_NOTIFICATIONS_HISTORY);
};

caplinb.emulators.PropertiesEmulator.prototype.updateMaxAlerts = function(maxNumberOfAlerts)
{
	if(isNaN(maxNumberOfAlerts) || (maxNumberOfAlerts<1))
	{
		alert("Incorrect Input");
	}
	else
	{
		caplin.core.ApplicationProperties.setProperty("CAPLIN.ALERTS.MAX.ALERTS.TRIGGERS",maxNumberOfAlerts+"");
	}
};

caplinb.emulators.PropertiesEmulator.prototype.updateMaxNotifications = function(maxNumberOfNotifications)
{
	if(isNaN(maxNumberOfNotifications) || (maxNumberOfNotifications<1))
	{
		alert("Incorrect Input");
	}
	else
	{
		caplin.core.ApplicationProperties.setProperty("CAPLIN.ALERTS.MAX.ALERTS.NOTIFICATIONS.HISTORY",maxNumberOfNotifications+"");
	}
};


caplin.singleton("caplinb.emulators.PropertiesEmulator");
