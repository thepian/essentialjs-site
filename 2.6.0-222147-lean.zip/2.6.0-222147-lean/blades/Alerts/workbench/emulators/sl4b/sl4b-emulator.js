caplin.namespace("caplinb.emulators");

caplinb.emulators.SL4BEmulator = function(){
	this.m_bReady = false;
	this.sSubscribedSubject = "";
	this.m_mContainerSubscriptions = {};
	this.m_pObjectSubscriptions = [];
	this.m_mContribObservables = {};
	this.m_oOnReadyListeners = new caplin.core.Observable();
	this.m_pAllActions = ["not-found", "not-permissioned", "unavailable", "deleted", "empty-container", "object-stale", "object-not-stale"];
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedImageResponse = function(sSubject){
	var subscription = this.m_mContainerSubscriptions[sSubject];
	if (subscription.type == "CONTAINER")
	{
		document.getElementById("sl4b-emulator-log").value += "< " + sSubject + " size=0 \n";		
		this._onAction("structureMultiChange",[sSubject, [], [], 1]);
		this._onAction("objectStatus",[sSubject,3]);	
	}
	else if (subscription.type == "RECORD") 
	{
		var blankResponse = new FieldData({"Type":"211","SID":"alerts"});
		document.getElementById("sl4b-emulator-log").value += "< IMAGE " + blankResponse.toString() + "\n";		
		this._onAction("recordMultiUpdated",[sSubject,  blankResponse, false]);
	}
	this.statusLive(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedNotFound = function(sSubject){
	document.getElementById("sl4b-emulator-log").value += "< NOT FOUND " + sSubject + "\n";
	this._onAction("objectNotFound",[sSubject]);
	this.statusNotFound(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedReadDenied = function(sSubject){
	document.getElementById("sl4b-emulator-log").value += "< READ DENIED " + sSubject + "\n";
	this._onAction("objectReadDenied",[sSubject]);
	this.statusReadDenied(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedDeleted = function(sSubject){
	document.getElementById("sl4b-emulator-log").value += "< DELETED " + sSubject + "\n";
	this._onAction("objectDeleted",[sSubject]);
	this.statusDeleted(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedUnavailable = function(sSubject){
	document.getElementById("sl4b-emulator-log").value += "< UNAVAILABLE " + sSubject + "\n";
	this._onAction("objectUnavailable",[sSubject]);
	this.statusUnavailable(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedStaleResponse = function(sSubject){

	document.getElementById("sl4b-emulator-log").value += "< StaleResponse " + sSubject + "\n";
	this._onAction("objectStatus",[sSubject,1]);
	this.statusStale(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedNonStaleResponse = function(sSubject){
	document.getElementById("sl4b-emulator-log").value += "< NonStaleResponse " + sSubject + "\n";
	this._onAction("objectStatus",[sSubject,3]);	
	this.statusNotStale(sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedSL4BAction = function(sSubject){
	var sAction = document.getElementById("sl4b-emulator-actions-" + sSubject).value;
	if(sAction)
	{
		this["onEmulated" + sAction](sSubject);
	}
};

caplinb.emulators.SL4BEmulator.prototype.onEmulatedPriceUpdate = function(mData){
	var nObjectSubscribers = this.m_pObjectSubscriptions.length;
	for(var i=0; i<nObjectSubscribers; ++i)
	{
		var oSubscriber = this.m_pObjectSubscriptions[i].subscriber;
		var sSubject = this.m_pObjectSubscriptions[i].subject;
		this.fireRecordMultiUpdated(mData, oSubscriber, sSubject);
	}
};

caplinb.emulators.SL4BEmulator.prototype.sendRecordResponse = function(sReceivedSubject, nStatus, sMessage){
	var nObjectSubscribers = this.m_pObjectSubscriptions.length;
	for(var i=0; i<nObjectSubscribers; ++i)	{
		var oSubscriber = this.m_pObjectSubscriptions[i].subscriber;
		var sSubject = this.m_pObjectSubscriptions[i].subject;
		if(sReceivedSubject === sSubject) {
			this.fireObjectStatus(oSubscriber, sSubject, nStatus);
		}
	}
};


caplinb.emulators.SL4BEmulator.prototype._onAction = function(sAction, pArguments)
{
	var sSubject = pArguments[0];
	
	var pSubscribers = this.m_mContainerSubscriptions[sSubject].subscribers;
	
	for(var i=0; i<pSubscribers.length; ++i)
	{
		var oSubscriber = this.m_mContainerSubscriptions[sSubject].subscribers[i];
		var fHandler = oSubscriber[sAction];
		if(fHandler)
		{
			fHandler.apply(oSubscriber,pArguments);
		}
	}
};

/** SUBSCRIPTION STATES **/
caplinb.emulators.SL4BEmulator.prototype.statusStale = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "STALE";
	this._changeActions(["object-not-stale"], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusNotStale = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "NOT STALE";
	this._changeActions(["not-found", "deleted","not-permissioned", "unavailable", "empty-container", "object-stale"], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusRequested = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "REQUESTED";
	this._changeActions(["not-found", "not-permissioned", "unavailable", "empty-container", "object-stale"], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusNotFound = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "NOT FOUND";
	this._changeActions([], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusUnavailable = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "UNAVAILABLE";
	this._changeActions([], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusReadDenied = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "READ DENIED";
	this._changeActions([], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusDeleted = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "DELETED";
	this._changeActions([], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype.statusLive = function(sSubject){
	document.getElementById("sl4b-emulator-subscribed-" + sSubject).innerHTML = "SUBSCRIBED";
	this._changeActions(["not-permissioned", "unavailable", "deleted", "object-stale"], sSubject);
};

caplinb.emulators.SL4BEmulator.prototype._changeActions = function(pEnabledActions, sSubject)
{
	var bNoActions = pEnabledActions.length === 0;
	document.getElementById("sl4b-emulator-action-button-" + sSubject).disabled = bNoActions;
	document.getElementById("sl4b-emulator-actions-" + sSubject).disabled = bNoActions;
	
	for(var i = 0; i < this.m_pAllActions.length; ++i)
	{
		var sAction = this.m_pAllActions[i];
		document.getElementById("sl4b-emulator-"+sAction+"-"+sSubject).disabled = !caplin.core.ArrayUtility.inArray(pEnabledActions, sAction);
	}

	document.getElementById("sl4b-emulator-actions-" + sSubject).selectedIndex = -1;
};

caplinb.emulators.SL4BEmulator.prototype.toggleSL4BLog = function(){
	var eLogContainer = document.getElementById("sl4b-emulator-log-container");
	var sCurrentDisplayState = eLogContainer.style.display;
	if(sCurrentDisplayState === "none")
	{
		eLogContainer.style.display = "";
	}
	else
	{
		eLogContainer.style.display = "none";
	}
};


/** STUBBED SL4B **/
caplinb.emulators.SL4BEmulator.prototype.getContainer = function(oSubscriber, sSubject)
{
	document.getElementById("sl4b-emulator-log").value += "> REQUEST " + sSubject + "\n";
	
	if(!this.m_mContainerSubscriptions[sSubject])
	{
		this.m_mContainerSubscriptions[sSubject] = {"subscribers":[oSubscriber], "type":"CONTAINER"};
		this._createNewRow(sSubject, 'container');
	}
	else
	{
		/**
		 * if(selected option = unavailable)
		 * 	then 
		 * 	change status to Requested
		 * 	enable the options
		 * 
		 */
		var eSubscriptionStatus =  document.getElementById("sl4b-emulator-subscribed-" + sSubject);
		if(eSubscriptionStatus.innerHTML === "UNAVAILABLE") {
			this._setStatusToRequestedAndEnableOptions(eSubscriptionStatus, sSubject);
		}
		var pSubscribers = this.m_mContainerSubscriptions[sSubject].subscribers;
		pSubscribers.push(oSubscriber);
	}
};

caplinb.emulators.SL4BEmulator.prototype._setStatusToRequestedAndEnableOptions = function(eSubscriptionStatus, sSubject){
	eSubscriptionStatus.innerHTML = "REQUESTED";
	this._changeActions(this.m_pAllActions, sSubject);
};

caplinb.emulators.SL4BEmulator.prototype._createNewRow = function(sSubject, sType){
	var tableBody = document.getElementById("sl4b-emulator-subscriptions").tBodies[0];
	var newRow = tableBody.insertRow(1);
	var newCell0 = newRow.insertCell(0);
	newCell0.innerHTML = sSubject;

	var newCell1 = newRow.insertCell(1);
	newCell1.innerHTML = sType;

	var newCell2 = newRow.insertCell(2);
	newCell2.innerHTML = '<p id="sl4b-emulator-subscribed-' + sSubject + '">REQUESTED</p>';
	
	var newCell3 = newRow.insertCell(3);
	newCell3.innerHTML = 
		'<select id="sl4b-emulator-actions-' + sSubject + '">' +
				'<option id="sl4b-emulator-not-found-' + sSubject + '" value="NotFound">Not Found</option>' +
				'<option id="sl4b-emulator-not-permissioned-' + sSubject + '" value="ReadDenied">Not Permissioned</option>' +
				'<option id="sl4b-emulator-unavailable-' + sSubject + '" value="Unavailable">Unavailable</option>' +
				'<option id="sl4b-emulator-deleted-' + sSubject + '" value="Deleted">Deleted</option>' +
				'<option id="sl4b-emulator-empty-container-' + sSubject + '" value="ImageResponse">Blank Response</option>' +
				'<option id="sl4b-emulator-object-stale-' + sSubject + '" value="StaleResponse">Stale Response</option>' +
				'<option id="sl4b-emulator-object-not-stale-' + sSubject + '" value="NonStaleResponse">Non Stale Response</option>' +
		'</select>';
	
	var newCell4 = newRow.insertCell(4);
	newCell4.innerHTML = '<input id="sl4b-emulator-action-button-' + sSubject + '" type="submit" value="Go"' + 
			'onClick="caplinb.emulators.SL4BEmulator.onEmulatedSL4BAction(\'' + sSubject + '\')"/>';
};

caplinb.emulators.SL4BEmulator.prototype.getObject = function(oSubscriber, sSubject){
	document.getElementById("sl4b-emulator-log").value += "> REQUEST " + sSubject + "\n";
	this.m_mContainerSubscriptions[sSubject] = {"subscriber":oSubscriber, "type":"RECORD"};
	this._createNewRow(sSubject, 'object');
};

/**
 * Adds ContribObject Listeners
 * 
 * @param {object} oListener should implement contribObject method which is a callback for this oListener
 * @param {String} sSubject subject for oListener
 */
caplinb.emulators.SL4BEmulator.prototype.addContribListener = function(oListener, sSubject){
	if(!this.m_mContribObservables[sSubject])
	{
		this.m_mContribObservables[sSubject] = new caplin.core.Observable();
	}
	this.m_mContribObservables[sSubject].addObserver(oListener);
}

caplinb.emulators.SL4BEmulator.prototype.contribObject = function(oSubscriber, sSubject, oData){
	document.getElementById("sl4b-emulator-log").value += "> CONTRIB " + sSubject + "\n" + oData.toString() + "\n";

	//update notifications grid
	var mData = oData.getFieldMap();
	mData["Subject"] = sSubject;
	for(var sObservedSubject in this.m_mContribObservables)
	{
		if(sSubject.indexOf(sObservedSubject) === 0)
		{
			this.m_mContribObservables[sObservedSubject].notifyObservers("contribObject", [oSubscriber, mData]);		
		}
	}
};

//stub for grid library
caplinb.emulators.SL4BEmulator.prototype.addConnectionListener = function(){
	return {};
};

/**
 * Calls recordMultiupdated on subscriber
 * 
 * @param {object} mData data for contrib data
 * @param {SL4B_AbstractSubscriber} oSubscriber an object which has implemented recordMultiUpdated
 * @param {string} sSubject instrument subject
 */
caplinb.emulators.SL4BEmulator.prototype.addOnEmulaterReadyListener = function(oEmulaterReadyListener){
	this.m_oOnReadyListeners.addObserver(oEmulaterReadyListener);
	if (this.m_bReady) {
		oEmulaterReadyListener.ready();
	}
}

caplinb.emulators.SL4BEmulator.prototype.onEmulatedReady = function(){
	document.getElementById("sl4b-emulator-ready").disabled = true;
	this.m_oOnReadyListeners.notifyObservers("ready", []);
	this.m_bReady = true;
};

/**
 * Calls recordMultiupdated on subscriber
 * 
 * @param {object} mData data for contrib data
 * @param {SL4B_AbstractSubscriber} oSubscriber an object which has implemented recordMultiUpdated
 * @param {string} sSubject instrument subject
 */
caplinb.emulators.SL4BEmulator.prototype.fireRecordMultiUpdated = function(mData, oSubscriber, sSubject){
	var contribData = new SL4B_ContributionFieldData();
	for(var sKey in mData)
	{
		contribData.addField(sKey, mData[sKey]);
	}
	var eSL4BLog =  document.getElementById("sl4b-emulator-log");
	if(eSL4BLog)
	{
		document.getElementById("sl4b-emulator-log").value += "< UPDATE " + sSubject + "\n" + contribData.toString() + "\n";
	}
	oSubscriber.recordMultiUpdated(sSubject, contribData);
};

caplinb.emulators.SL4BEmulator.prototype.fireStructureMultiChange = function(oSubscriber, sSubject, pContainerStructureChanges, nNotifications){
	if(oSubscriber.structureMultiChange)
	{
		oSubscriber.structureMultiChange(sSubject, pContainerStructureChanges, [], nNotifications);
	}
};

caplinb.emulators.SL4BEmulator.prototype.fireContribFailed = function(oSubscriber, sSubject, sReason){
	if(oSubscriber.contribFailed)
	{
		oSubscriber.contribFailed(sSubject, sReason, null, null);
	}
};

caplinb.emulators.SL4BEmulator.prototype.fireObjectStatus = function(oSubscriber, sObjectName, nStatus){
	if(oSubscriber.objectStatus)
	{
		oSubscriber.objectStatus(sObjectName, nStatus, "", "");
	}
};

/**
 * Calls fireStructureMultiChange and fireRecordMultiUpdated on subscriber 
 * 
 * @param {object} mData data for contrib data
 * @param {SL4B_AbstractSubscriber} oSubscriber an object which has implemented recordMultiUpdated
 * @param {string} sSubject instrument subject
 * @param {int} nNotifications container size
 */
caplinb.emulators.SL4BEmulator.prototype.addItemToContainer = function(mData, oSubscriber, sSubject, nNotifications){
	this.fireStructureMultiChange(oSubscriber, sSubject, [], nNotifications);
	this.fireRecordMultiUpdated(mData, oSubscriber, sSubject);
};

/**
 * Calls fireStructureMultiChange on subscriber 
 * 
 * @param {SL4B_AbstractSubscriber} oSubscriber an object which has implemented recordMultiUpdated
 * @param {string} sSubject instrument subject
 * @param {int} nNotifications container size 
 */
caplinb.emulators.SL4BEmulator.prototype.removeItemFromContainer = function(oSubscriber, sSubject, nNotifications){
	var pContainerStructureChanges = [
	                              {
	                              	   getAdded: function(){return false;},
	                              	   getObjectName: function(){return sSubject;}
	                              }
	                              ];
	this.fireStructureMultiChange(oSubscriber, sSubject, pContainerStructureChanges, nNotifications);
};

caplinb.emulators.SL4BEmulator.prototype.getObject = function(oSubscriber, sSubject, sFieldNames) {
	this.m_pObjectSubscriptions.push({"subscriber" : oSubscriber, "subject" : sSubject });
	return {};
};

caplinb.emulators.SL4BEmulator.prototype.removeObject = function(oSubscriber, sSubject, sFieldNames) {
	return {};
};

caplin.singleton("caplinb.emulators.SL4BEmulator");

/** STUBBING OUT SL4B **/
SL4B_Accessor.getRttpProvider = function(){
	return caplinb.emulators.SL4BEmulator;
};
