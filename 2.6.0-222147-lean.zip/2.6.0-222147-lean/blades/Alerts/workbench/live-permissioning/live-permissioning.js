caplin.namespace("caplin.alerts.workbench");

caplin.alerts.workbench.PermissioningControl = {};

caplin.alerts.workbench.PermissioningControl.sPermissionsHttpdUrl = "http://" + workbenchConfig.get('xaquahostname') + ":40190/PermissioningDynamicAcceptance/TestController?";

caplin.alerts.workbench.PermissioningControl.startTransaction = function()
{
	document.getElementById("livePermissioning").src = this.sPermissionsHttpdUrl + "operation=startTransaction";
};

caplin.alerts.workbench.PermissioningControl.commitTransaction = function()
{
	document.getElementById("livePermissioning").src = this.sPermissionsHttpdUrl + "operation=commitTransaction";
};

caplin.alerts.workbench.PermissioningControl.changeSubjectMapping = function()
{
	var tier = document.getElementById("permissioning-Tier").value;	
	document.getElementById("livePermissioning").src = this.sPermissionsHttpdUrl + "operation=setSubjectMapping&userName=alerts&subjectMappingPattern=(%2FCOMMANDHTTPD%2FRECORD%2F.*)|(%2FALERTS%2FTRIGGERCONTROL%2F.*)|(%2FALERTS%2FTRIGGER%2F.*)&mappedSubjectSuffix=%2F" + tier;
};

parent.statusUpdate = function(status)
{
	document.getElementById("live-permissions-log").innerHTML = status;
};
