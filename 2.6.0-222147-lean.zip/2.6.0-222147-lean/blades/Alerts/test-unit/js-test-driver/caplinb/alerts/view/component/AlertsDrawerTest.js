AlertsDrawerTest = TestCase("AlertsDrawerTest");

AlertsDrawerTest.prototype.setUp = function()
{
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	this.m_oMockComponent = mock(caplin.webcentric.presentation.FrameItem);
	this.m_oMockComponent.stubs().show();
	this.m_oMockComponent.stubs().hide();

	this.originalAlertsDrawer = caplinb.alerts.view.component.AlertsDrawer;
	caplinb.alerts.view.component.AlertsDrawer = new caplin.singletons["caplinb.alerts.view.component.AlertsDrawer"]();
	
	var self = this;
	caplinb.alerts.view.component.AlertsDrawer._buildComponent = function()
	{
		return self.m_oMockComponent.proxy();
	};
	caplinb.alerts.view.component.AlertsDrawer._showAndSelectNotificationsGrid = function()
	{
	};
};

AlertsDrawerTest.prototype.tearDown = function()
{
	caplinb.alerts.view.component.AlertsDrawer = this.originalAlertsDrawer;
	Mock4JS.verifyAllMocks();
};

AlertsDrawerTest.prototype.testComponentIsShown = function()
{
	this.m_oMockComponent.expects(once()).show();
	caplinb.alerts.view.component.AlertsDrawer.show();
};

AlertsDrawerTest.prototype.testComponentIsHidden = function()
{
	this.m_oMockComponent.expects(once()).hide();
	caplinb.alerts.view.component.AlertsDrawer.hide();
};

AlertsDrawerTest.prototype.testToggleAfterShowHidesComponent = function()
{
	caplinb.alerts.view.component.AlertsDrawer.show();
	this.m_oMockComponent.expects(once()).hide();
	caplinb.alerts.view.component.AlertsDrawer.toggle();
};

AlertsDrawerTest.prototype.testToggleAfterHideShowsComponent = function()
{
	caplinb.alerts.view.component.AlertsDrawer.hide();
	this.m_oMockComponent.expects(once()).show();
	caplinb.alerts.view.component.AlertsDrawer.toggle();
};

AlertsDrawerTest.prototype.testToggleBeforeHideOrShowShowsComponent = function()
{
	this.m_oMockComponent.expects(once()).show();
	caplinb.alerts.view.component.AlertsDrawer.toggle();
};