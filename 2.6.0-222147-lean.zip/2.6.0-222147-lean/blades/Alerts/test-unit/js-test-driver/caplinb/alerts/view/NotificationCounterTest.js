NotificationCounterTest = TestCase("NotificationCounterTest");

NotificationCounterTest.prototype.setUp = function() {
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	this.mockNotificationService = Mock4JS.mockObject(caplin.alerts.NotificationService);
	this.realNotificationService = caplin.alerts.NotificationService;
	caplin.alerts.NotificationService = this.mockNotificationService.proxy();
	this.mockNotificationService.stubs().addListener(ANYTHING);
	
	this.m_oNewNotification = {"status":caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW};
	this.m_oDismissedNotification = {"status":caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_DISMISSED};
	
	eContainer = document.createElement("DIV");
};

NotificationCounterTest.prototype.tearDown = function()
{
	caplin.alerts.NotificationService = this.realNotificationService;
	Mock4JS.verifyAllMocks();
};


NotificationCounterTest.prototype.testDoesNotDisplayTheCounterIfThereAreNoNotifications = function() {
	//given
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([]));
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	
	//assert
	assertEquals("0", oNotificationCounter.m_eIndicator.innerHTML);
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	
};

NotificationCounterTest.prototype.testDisplaysCounterOnlyIfThereIsAtleastOneNotification = function() {
	//given
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([]));
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	
	//when
	oNotificationCounter.onNotificationAdded(this.m_oNewNotification);
	
	//assert
	assertEquals("1", oNotificationCounter.m_eIndicator.innerHTML);
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testCounterIsNotIncrementedIfAddedNotificationIsDismissed = function() {
	//given
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([]));
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	
	//when
	oNotificationCounter.onNotificationAdded(this.m_oDismissedNotification);
	
	//assert
	assertEquals("0", oNotificationCounter.m_eIndicator.innerHTML);
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testDoesNotDisplayTheCounterIfDataIsUnavailable = function() {
	//given
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([{},{}]));
	
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	
	//when
	oNotificationCounter.onDataUnavailable(caplin.alerts.NotificationService.UNKNOWN_ERROR);

	//assert
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testDoesNotDisplayTheCounterIfDataIsAvailableButContainsNoNewNotifications = function() {
	//given
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([]));
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	
	//when
	oNotificationCounter.onDataUnavailable();
	oNotificationCounter.onDataAvailable();
	
	//assert
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testShouldDisplayTheCounterIfDataIsAvailableAndContainsNewNotifications = function(){
	//given
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([{}]));
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	
	//when
	oNotificationCounter.onDataAvailable();	
	
	//assert
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testDisplaysTheCounterWhenDataBecomesAvailableAgain = function() {
	//given
	
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([]));
	
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	
	oNotificationCounter.onNotificationAdded(this.m_oNewNotification);
	
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	oNotificationCounter.onDataUnavailable(caplin.alerts.NotificationService.UNKNOWN_ERROR);
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	
	//when
	oNotificationCounter.onDataAvailable();
	//assert
	assertEquals("1", oNotificationCounter.m_eIndicator.innerHTML);
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testShouldDisplayTheCounterWithCorrectValueOnInitialise= function() {
	//expectations 
	this.mockNotificationService.expects(once()).getNewNotifications().will(returnValue([{},{}]));
	
	//when
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	
	//assert
	assertEquals("2", oNotificationCounter.m_eIndicator.innerHTML);
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};

NotificationCounterTest.prototype.testShouldUpdateCounterIfNotificationIsAddedOrDismissed= function() {
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([]));	
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	//when
	oNotificationCounter.onNotificationAdded(this.m_oNewNotification);
	assertEquals("1", oNotificationCounter.m_eIndicator.innerHTML);
	oNotificationCounter.onNotificationAdded(this.m_oNewNotification);
	assertEquals("2", oNotificationCounter.m_eIndicator.innerHTML);
	oNotificationCounter.onNotificationDismissed(this.m_oNewNotification);
	assertEquals("1", oNotificationCounter.m_eIndicator.innerHTML);
	oNotificationCounter.onNotificationDismissed(this.m_oNewNotification);
	assertEquals("0", oNotificationCounter.m_eIndicator.innerHTML);
};

NotificationCounterTest.prototype.testShouldHideCounterIfAllNotificaitonsRemoved = function() {
	this.mockNotificationService.stubs().getNewNotifications().will(returnValue([{},{}]));
	
	var oNotificationCounter = new caplinb.alerts.view.NotificationCounter(eContainer);
	assertFalse(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
	
	//when
	oNotificationCounter.onNotificationDismissed(this.m_oNewNotification);
	oNotificationCounter.onNotificationDismissed(this.m_oNewNotification);
	
	//assert
	assertTrue(caplin.dom.Utility.hasClassName(oNotificationCounter.m_eIndicator, "notification-counter-hide"));
};
