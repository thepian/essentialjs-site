CAPLIN TRADER QUICK START:
==========================

Objective: To unzip and see Caplin Trader running as quickly as possible with no hassle.

Prerequisites:

  *  MySQL is running on port 3306 on your local(or remote) machine
  *  You have Sun's JDK 1.6 installed, and JAVA_HOME is set accordingly or Sun's JRE 1.6 installed, and JRE_HOME set.
  *  You have installed Caplin Xaqua and have it running on your network

Instructions to run Caplin Trader:

   1. In a suitable directory (e.g. X:/scm_root), unzip the caplintrader and thirdparty ZIP files.
	 This creates the following directory structure:

         X:/scm_root/CT2/2.3.X-nnnnnn/sdk                  - Caplin Trader 
                                     /caplintrader         - Caplin Trader
                        /thirdparty/                       - Associated thirdparty software

  2. In sdk/build/common/database/common.properties change the AUTHENTICATION.DATABASE.HOST and WEBCENTRIC.DATABASE.PASSWORD to the hostname of the MySQL server. 
  It is recommended for development purposes you use localhost for this. The database username can also be changed by editing mysql.properties in the same folder


  3. In caplintrader/user.properties change the following properties appropriately.
	# currently supported databases are mysql, sqlserver & sybase
	DATABASE.TYPE=mysql
	AUTHENTICATION.DATABASE.PASSWORD=mysqlpassword
	WEBCENTRIC.DATABASE.PASSWORD=mysqlpassword
	USER.PASSWORD=applicationpassword

	Again, for development it is suggested you use the default settings and setup the MySQL root account accordingly.

  4. Configure your hosts file 'C:\Windows\System32\drivers\etc\hosts' and change:
        127.0.0.1                     localhost.<domainName>.com
        [IP address of Liberator]     xaqua.<domainName>.com 
		
	Where 'domainName' is your network domain name (e.g. localhost.novobank.com).

  5. Edit 'X:/cm_root/CT2/2.3.X-nnnnnn/caplintrader/trader.properties' and change:
  
        TRADER.DOMAIN=<domainName>.com
        XAQUA.HOSTNAME=xaqua.<domainName>.com
        XAQUA.SSL.LIBERATOR.HOSTNAME=xaqua.<domainName>.com
        XAQUA.SSL.LIBERATOR.COMMON.NAME=*.<domainName>.com
        XAQUA.FAILOVER.LIBERATOR.HOSTNAME=xaqua.<domainName>.com
        XAQUA.FAILOVER.SSL.LIBERATOR.HOSTNAME=xaqua.<domainName>.com
        
    Where 'domainName' is your network domain name(e.g. localhost.novobank.com).

  6. Change directory to 'X:/scm_root/CT2/2.3.X-nnnnnn/caplintrader and run trader.bat', which does the following:
  
     * Checks the prerequisites
     * Generates and prompts you to install self-signed certificates for Tomcat and Liberator.
     * Restarts Tomcat
     * Opens Firefox from the directory referenced by the FIREFOX.HOME property 
     	in 'X:/scm_root/CT2/2.3.X-nnnnnn/sdk/thirdparty-win32.properties'. By default, 
     	the FIREFOX.HOME property is set to 'C:/Program Files/Mozilla Firefox' (the default Firefox installation 
     	directory). Firefox is launched pointing to the URL for Caplin Trader 2.3.X.
     * Displays instructions on changing environment variables, should you wish to do so
	 
    NB: To open Caplin Trader in another browser, you can either copy the URL from 
    the command window or the URL address from the launched Firefox browser.

Additional notes for Caplin Trader:
 
  A. Some of the Caplin Trader ant targets look to restart Caplin Xaqua components. In doing this, by default it makes an assumption where Caplin Xaqua is installed.
     
     See 'README-creating-your-xaqua-restart-ant-target.txt' for instructions on how to override this.
	
  B. If you wish to run, develop and test Caplin Trader via SSL (https), instructions are provided for how to generate self signed certificates.
     Please note that this is enabled by default.
    
     See 'README-generating-self-signed-certificates.txt' for further information.
	

    
		

    