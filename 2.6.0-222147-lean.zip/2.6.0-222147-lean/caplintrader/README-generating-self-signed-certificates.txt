To generate and install self-signed certificates for Tomcat and the Liberator 
for use during development and testing over Secure Sockets Layer (SSL) you can 
do the following:
	
	1.	On the command-line:
	
		a.	change the directory to X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader
		b.	run �ant install-certificates�
		c.	install the certificate for Tomcat within the Web browser
		d.	install the certificate for Liberator within the Web browser
		
		
Executing �ant install-certificates� generally does the following:

	�	generates a self-signed certificate for Tomcat
	�	restarts Tomcat
	�	launches the Web browser (allows you to install the new certificate)
	�	generates a self-signed certificate for the Liberator.
	�	restarts all Xaqua components*
	�	launches the Web browser (allows you to install the new certificate)

    *Note: It is assumed that the installation directory for Xaqua components is 
    		~/standard_environments/CaplinTrader. If this is not your Xaqua 
    		installation directory a change will be required to restart Xaqua 
    		components. Please see the release note for more information.

When the Web browser is launched you will need to install the certificates. 
This can be done as follows:

In Firefox:

	1.	You will see a page that states �This Connection is Untrusted�, click 
		the link titled �I Understand the Risks�.
	2.	Click the �Add Exception� button.
	3.	View the certificate to verify the details (note that the Common Name 
		should match the fully qualified domain name of the server you wish to 
		connect to).
	4.	Ensure the �Permanently store this exception� checkbox is checked.
	5.	Click the �Confirm Security Exception� button.
	
	Note that once you have installed the certificate for both Tomcat and the 
	Liberator, you will need to close all instances of Firefox and hit the 
	return key at the prompt on the console where you executed the ANT target.

In Internet Explorer:

	1.	You will see a page that states ��There is a problem with this website�s 
		security certificate.�, click the link titled �Continue to this website 
		(not recommended).�.
	2.	Click on the �Certificate Error� shield next to the address bar and 
		click �View Certificates�.
	3.	View the certificate to verify the details (note that the Common Name 
		should match the fully qualified domain name of the server you wish to 
		connect to).
	4.	Click the �Install Certificate...� button � this will launch the 
		Certificate Import Wizard.
	5.	Click the radio button to �Place all certificates in the following 
		store�, then click �Browse...�
	6.	Select �Trusted Root Certification Authorities� from the tree to 
		permanently install the certificate as a trusted root certificate. 
		Click the �OK� button.
	7.	Click �Next, then click �Finish�.
	8.	A �Security Warning� pop-up dialog will appear to confirm that you want 
		to install the certificate. Click �Yes�.

The process described above is configurable via the properties detailed below 
(categorised according to location):

	X:/scm_root/CT2/2.0.X-nnnnnn /build.properties
	
		TOMCAT.HTTPS.PORT - The port configured for SSL communication with the 
								Tomcat. This is required to launch the Web 
								browser at the correct location so you can 
								install your certificate.
		TOMCAT.KEYSTORE.PASS - the keystore password for Tomcat.

	X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader /trader.properties
	
		TRADER.BROWSER - Specifies the default browser. This will determine 
							which browser automatically gets launched. Valid 
							values are one of {firefox, chrome, ie}.
		TRADER.HOSTNAME - The hostname of the machine from which Tomcat will 
							serve the application. If it is served locally, set 
							to �localhost�. Note that this is used to determine 
							the Common Name for your Tomcat certificate.
		TRADER.DOMAIN � The domain of the machine from which Tomcat will serve 
							the application. Note that this is used to determine 
							the Common Name for your Tomcat certificate.
		
		XAQUA.SSL.LIBERATOR.HOSTNAME � The hostname of the machine on which 
											Liberator is installed.
		XAQUA.SSL.LIBERATOR.COMMON.NAME - The Common Name for your Liberator 
											certificate. In most cases this will
											be the same as the 
											XAQUA.SSL.LIBERATOR.HOSTNAME.
		XAQUA.SSL.LIBERATOR.USERNAME � The username for any user with 
											permissions to access the Liberator 
											via SSH. This is required to install 
											a new Liberator certificate.
		XAQUA.SSL.LIBERATOR.PASSWORD � The password for any user with 
											permissions to access the Liberator 
											via SSH. This is required to install 
											a new Liberator certificate.
		XAQUA.SSL.LIBERATOR.CERTS.DIR � The directory on the Liberator machine 
											where the Liberator certificates are 
											stored.
		XAQUA.SSL.LIBERATOR.PORT - The port configured for SSL communication 
											with the Liberator. This is required 
											to launch the Web browser at the 
											correct location so you can install 
											your certificate.

		CERT.KEY.PASS � The keystore password for Liberator.
		CERT.VALIDITY � How many days the certificate will be valid for.
		CERT.ORGANISATIONAL.UNIT � e.g. Novobank Development.
		CERT.ORGANISATION � e.g. Novobank.
		CERT.CITY � e.g. London.
		CERT.STATE � e.g. London.
		CERT.COUNTRY.CODE � e.g. GB.

In the event you encounter difficulties in generating, installing or using 
self-signed certificates you should read the troubleshooting tips provided 
below:

	1. I run �ant install-certificates� but it fails at 
		�generate-tomcat-certificate due to a NumberFormatException.

		This will occur if you run �ant install-certificates� from the wrong 
		location on the command line. The solution is to run the 
		install-certificates target from 
		X:/scm_root/CT2/2.0.X-nnnnnn/<novobank/caplin/whatever>trader on the 
		command line.

	2. When Tomcat starts up, I see exceptions relating to the keystore in the 
		console.

		This is typically down to one of two factors.
			1.	Tomcat cannot find its keystore file.
			2.	The keystore password is not correct.
	
		The location of the keystore file is defined by the TOMCAT.KEYSTORE.FILE 
		property in X:/scm_root/CT2/2.0.X-nnnnnn /build.properties. A valid 
		keystore file needs to be present at the location defined by the 
		property.
		The keystore password is defined by TOMCAT.KEYSTORE.PASS property in 
		X:/scm_root/CT2/2.0.X-nnnnnn /build.properties.

	3. I run �ant install-certificates� but when my Web-browser is launched I 
		get a message indicating that the connection to the server was reset.

		This is likely to occur because more than one instance of Tomcat is 
		attempting to serve the same port. The solution is to ensure you only 
		have one instance of Tomcat running. Note that Tomcat may be installed 
		and running as a service. You can terminate a service via the Services 
		dialog as accessed from Administrative Tools. You may also wish to 
		ensure the start-up type is set to manual as opposed to automatic to 
		avoid this problem in the future.

	4. After running �ant install-certificates�, I open my Firefox Web-browser 
		(pointing at the URL for my trading application) and receive a message 
		that the connection is untrusted.

		This occurs because the certificate has not been installed in the 
		Firefox profile�s certificate database. The solution is to install the 
		certificate as per the instructions in 
		README-generating-self-signed-certificates.txt.
		The reason you have to do this twice (i.e. once as part of running 
		�ant install-certificates� using Firefox and once when launching Firefox 
		from the desktop) is because the build uses a different Firefox profile 
		(and hence a different certificate database) to the profile used when 
		starting Firefox via a desktop short-cut.

	5. I have run �ant install-certificates�, I have opened my Firefox 
		Web-browser (pointing at the URL for my trading application) and I have 
		installed the certificate for the application server hosting the trading 
		application. When I try to login the application appears to hang.

		This is likely to occur if you have not installed the self-signed 
		certificate for the Liberator to which your application is trying to 
		connect. The solution is to install the certificate as per the 
		instructions in README-generating-self-signed-certificates.txt. To 
		install the certificate you will need to point your browser to the URL 
		of your Liberator (e.g. https://xaqua.novobank.com:50181).
		See also: '4. After running �ant install-certificates�, I open my 
		Firefox Web-browser (pointing at the URL for my trading application) and 
		receive a message that the connection is untrusted.'.

	6. I have run �ant install-certificates� but when I try to run a Selenium 
		test using Firefox I still get a message indicating that the connection 
		is untrusted or that there is a problem with the website�s certificate.

		This can happen for any of three reasons:
			1.	The self-signed certificates have not been installed in the 
				Firefox profile�s certificate database.
			2.	The contents of the Firefox profile directory have been deleted.
			3.	The build�s Firefox profile is not being used (the 
				FIREFOX.PROFILE.DIR property has been modified to reference 
				another directory).

		The solution is to ensure that the FIREFOX.PROFILE.DIR property is 
		correctly set. If this does not resolve the issue try running 
		�ant install-certificates� again. If you specifically wish to use a 
		different Firefox profile (not recommended) you will need to launch 
		Firefox using that profile, navigate to the appropriate URLs and install 
		the certificates. To launch Firefox against a specific profile start it 
		from the command line using either the -profile option or the 
		�profilemanager option.

	7. When I attempt to run a Selenium test the build fails with the error:

		�Failed to copy X:/scm_root /CT2/thirdparty/win32/firefox/3.6.6/profile
		/parent.lock to C:/DOCUME~1/<username>/LOCALS~1/Temp
		/customProfileDir<some number>/parent.lock due 
		 to java.io.FileNotFoundException X:/scm_root /CT2/thirdparty/win32
		 /firefox/3.6.6/profile/parent.lock (The process cannot access the file 
		 because it is being used by another process)�

		This occurs because another Firefox instance is running against the same 
		Firefox profile used by the build. The solution is to terminate the 
		other Firefox instance before re-running the Selenium test.

	8. When I try to run a Selenium test the build fails with the following 
		message: �Firefox profile template doesn't exist: 
		X:/scm_root /CT2/thirdparty/win32/firefox/3.6.6/profile�.

		This will occur if the build�s Firefox profile directory does not exist. 
		The solution is to either create the directory and run 
		�ant install-certificates� or alternatively, if the contents of the 
		directory are under source control management you can force-synchronise 
		with your depot.

	9. When I start Firefox using the build�s Firefox profile (i.e. the profile 
		located at X:/scm_root /CT2/thirdparty/win32/firefox/3.6.6/profile), 
		Firefox�s Add-on Manager Dialog pops-up.

		This will typically occur if the profile directory contains unnecessary 
		files (for the build�s purpose). You will encounter this problem if you 
		run �ant browser-firefox�. The solution is to run 
		�ant clean-firefox-profile�.

	10. When I try to launch Firefox using the build�s Firefox profile (i.e. the 
		profile located at X:/scm_root /CT2/thirdparty/win32/firefox
		/3.6.6/profile) I encounter a dialog that states:

		'Firefox is already running, but is not responding.
		 To open a new window, you must first close the existing Firefox 
		 process, or restart your system.'

		This can happen for several reasons, the most likely among them being an 
		unavailable profile directory. To solve this problem you should ensure 
		the profile directory exists and is writeable (i.e. ensure it does not 
		have read-only permissions). You will also need to re-run 
		�ant install-certificates�. If the above solution fails to work, it may 
		be necessary to delete all Firefox profiles; see 
		http://support.mozilla.com/en-us/kb/firefox+is+already+running+but+is+
		not+responding for further information. 

	11. When I attempt to start Firefox using the build�s Firefox profile 
		(i.e. the profile located at X:/scm_root /CT2/thirdparty/win32/firefox
		/3.6.6/profile) I see an Alert Dialog containing the message: 

		�Could not initialise the application's security component.
		 The most probable cause is problems with files in your browser's 
		 profile directory. Please check that this directory has no read/write 
		 restrictions and your hard drive is not full or close to full. It is 
		 recommended that you exit the browser and fix the problem. If you 
		 continue to use this browser session, you might see incorrect browser 
		 behaviour when accessing security features.�

		This occurs when the contents of the profile directory are marked as 
		read-only. The solution is to remove the read-only permissions from the 
		profile directory and if the directory contents are under source control 
		management � ensure the contents have been added as writeable. See 
		http://support.mozilla.com/en-US/kb/could+not+initialize+the+browser
		+security+component for further information.

	