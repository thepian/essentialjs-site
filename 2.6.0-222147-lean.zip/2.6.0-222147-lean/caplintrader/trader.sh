#!/bin/sh

######################################################
###       UNIX shell script to set up environment
######################################################

CAPLIN_THIRDPARTY_DIR=`dirname $CAPLIN_SDK_DIR`/thirdparty
if [ ! -d "$CAPLIN_THIRDPARTY_DIR" ]; then
	echo "ERROR: expected to find thirdparty unzipped in $CAPLIN_THIRDPARTY_DIR" 1>&2
	exit 1
fi

export ANT_HOME=$CAPLIN_THIRDPARTY_DIR/common/ant/1.8.0
export ANT_OPTS=-XX:MaxPermSize=256m
export PATH=$ANT_HOME/bin:$PATH

ant -quiet trader

echo "The following environment variables were set:"
echo ANT_HOME=$ANT_HOME
echo ANT_OPTS=$ANT_OPTS
echo PATH=$PATH
echo "... you might consider them permanently in your environment"
