TO BASELINE FOR YOUR OWN TRADING APPLICATION:
=============================================

Objective: To create a new baseline from which to develop your trading application.

Prerequisites: You have already followed the README-first.txt instructions, which gives the following directory structure:

        X:/scm_root/CT2/2.0.0-nnnnnn/sdk/
                                    /caplintrader/
                       /thirdparty/

[Note: you can unzip the Caplin Trader ZIP files in any directory, but X:/scm_root has been used here to reinforce the need 
to check-in the entire structure to version control to provide a rollback point, and as a means of sharing with other team members]

To create a baseline of your trading application (e.g. "novotrader") at your version level (e.g. "1.0"), 
perform the following steps:

    1. Open a command prompt in the directory X:/scm_root/CT2/2.0.0-nnnnnn/caplintrader and execute the following command:

          ant baseline -DAPPLICATION=novotrader -DVERSION=1.0 -DNAMESPACE=novox -DDIR=X:/scm_root/NovoBank
          
       [Note: you can use any directory instead of X:/scm_root/NovoBank, but it will need to go in version control]

    2. Change directory to X:/scm_root/NovoBank/1.0/novotrader and then you can issue the following ant commands:	
		  
       * To launch the trading application:
       
          ant trader         launches the trading application in development mode

       * To build the trading application, perform the following steps:

          ant clean          deletes temporary build files
          ant compile        creates the maven artifact for installation
          ant build          compiles and tests JavaScript library and builds a war
          ant deploy         deploys the war
          ant reset          resets the server contexts, database layouts and Caplin Xaqua ports for the application
		  
       * Additionally, each time you baseline your trading application or make environment changes (including web
         server contexts, database layouts and Caplin Xaqua ports), run the following command:

          ant reset          resets the server contexts, database layouts and Caplin Xaqua ports for the application
          		  
          
     3. To view the new baseline, open any of the following URLs:
      
        * To run against the source (you can change JS/CSS etc. and refresh the browser):

          http://localhost.novobank.com:9090/1.0/novotrader/webapp/application.jsp?mode=dev
          https://localhost.novobank.com:9443/1.0/novotrader/webapp/application.jsp?mode=dev
          
        * To run against the WAR:

          http://localhost.novobank.com:9090/novotrader/application.jsp
          https://localhost.novobank.com:9443/novotrader/application.jsp   
		  
        Where 'novobank' is your network domain name.

     4. Check the entire directory structure into version control:
        
                X:/scm_root/CT2/2.0.0-nnnnnn/sdk/
                                            /caplintrader/
                               /thirdparty/
                           /Novobank/1.0/novotrader/
