Test = CaplinTestCase("StatusBarComponentTest");

Test.setUp = function()
{
	this.TEMPLATE_HTML = '<div><button name="trigger:chatButton">Chat</button></div><div><span name="render:CompactionNPV:text">123456</span></div>';
	
	this.m_oStatusBarListener, this.m_eDomHolder;
	this.m_eXmlModel = {
		getAttribute: function(n){return {
			src : false,
			extraClasses : "extra1 extra2"
		}[n];}
	};
	
	this.m_oStatusBarListener = mock(caplinx.component.form.StatusBarListener);
	this.m_eDomHolder = document.createElement("DIV");
	document.body.appendChild(this.m_eDomHolder);
	
	this.m_mEventToModule = {
	    "DOMFocusIn":"UIEvent", "DOMFocusOut":"UIEvent", "DOMActivate":"UIEvent",
	    
	    "mousedown":"MouseEvent","mouseup":"MouseEvent","mouseover":"MouseEvent",
	    "mousemove":"MouseEvent","mouseout":"MouseEvent", "click":"MouseEvent",
	    
	    "load":"Event", "unload":"Event", "resize":"Event", "scroll":"Event",
	    "abort":"Event", "error":"Event", "select":"Event",
	    "change":"Event", "submit":"Event",
	    "reset":"Event", "focus":"Event", "blur":"Event",
	 
	    "":"Events"
	}; 
};

Test.tearDown = function()
{
	document.body.removeChild(this.m_eDomHolder);
	this.m_eDomHolder = null;
};

Test.getSerializedStateWorks = function()
{
	var oStatusBar = new caplinx.component.form.StatusBarComponent("", this.m_eXmlModel);
	oStatusBar.getElement();
	assertEquals('<statusBar src="false" extraClasses="extra1 extra2"/>', oStatusBar.getSerializedState());
};

Test.onButtonWorks = function()
{
	var oMockStatusBarListener = this.m_oStatusBarListener.proxy();
	
	var oStatusBar = new caplinx.component.form.StatusBarComponent(this.TEMPLATE_HTML, this.m_eXmlModel);
	var eHolder = oStatusBar.getElement();
	oStatusBar.addListener(oMockStatusBarListener);
	
	//this.m_oStatusBarListener.expects(once()).onButton(NOT_NULL);
	assertNotEquals(0,oStatusBar.m_pButtons.length);
};

Test.ThatSpansMakesRenderers = function()
{
	var oMockStatusBarListener = this.m_oStatusBarListener.proxy();
	
	var oStatusBar = new caplinx.component.form.StatusBarComponent(this.TEMPLATE_HTML, this.m_eXmlModel);
	var eHolder = oStatusBar.getElement();
	oStatusBar.addListener(oMockStatusBarListener);

	var CompactionNPV = oStatusBar.getRenderers()['CompactionNPV'];
	assertTrue(CompactionNPV != null);
	assertTrue(this._hasEqivalentMembers(caplin.element.Renderer.prototype,CompactionNPV));
};

Test.ThatElementDoeNotThrowAnException = function()
{
	var sTemplate = this.TEMPLATE_HTML;
	
	var oComponent = new caplinx.component.form.StatusBarComponent(sTemplate, this.m_eXmlModel);
	try
	{
		this.m_eDomHolder.appendChild(oComponent.getElement());
	}
	catch(e)
	{
		fail("An exception should NOT have been thrown when creating a StatusBarComponent : " + e);
	}
};

Test._hasEqivalentMembers = function(map1,map2)
{
	for(n in map1) {
		if (!n in map2) return false;
	}
	for(n in map2) {
		if (!n in map1) return false;
	}
	return true;
};

Test.initialize();
