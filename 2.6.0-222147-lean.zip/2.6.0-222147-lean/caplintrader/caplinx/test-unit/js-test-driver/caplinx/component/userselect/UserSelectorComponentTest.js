Test = CaplinTestCase("UserSelectorComponentTest");

Test.setUp = function()
{
	this.protectApis("caplinx.tobo", "caplinx.tobo.TOBOUserManager");
	
	this.m_oUserDropDownStore = new Ext.data.SimpleStore({"fields": ["value", "label"]});
	this.m_oUserDropDownBox = new Ext.form.ComboBox({
		"displayField": "label",
		"width": 131,
		"listWidth": Ext.isIE6 ? 146 : 149,
		"triggerAction": 'all',
		"editable": true,
		"mode": 'local',
		"forceSelection": true,
		"store" : this.m_oUserDropDownStore
    });
	
	this.m_oAccountDropDownStore = new Ext.data.SimpleStore({"fields": ["value", "label"]});
	this.m_oAccountDropDownBox = new Ext.form.ComboBox({
		"displayField": "label",
		"width": 131,
		"listWidth": Ext.isIE6 ? 146 : 149,
		"triggerAction": 'all',
		"editable": true,
		"mode": 'local',
		"forceSelection": true,
		"store" : this.m_oAccountDropDownStore
    });
	
	this.m_sSelectedUser = "";
	this.m_sSelectedAccount = "";
	this.m_oRegisteredObserver = null;
	
	var oThis = this;
	caplinx.tobo.TOBOUserManager = new function(){
		
		this.initialise = function(){};
		this.addObserver = function(oObserver){
			oThis.m_oRegisteredObserver = oObserver;
		};
		this.updateUser = function(sUserName) {
			oThis.m_sSelectedUser = sUserName;
		};
		this.updateAccount = function(sAccount) {
			oThis.m_sSelectedAccount = sAccount;
		};
	};
};

Test.componentIsRegisteredAsAnObserverOfTOBOUserManager = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	assertEquals("The component should be registered as an observer of TOBOUserManager", oUserSelector, this.m_oRegisteredObserver);
	
};

Test.userDropdownBoxIsNotInitiallyVisible = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	var eRootElement = oUserSelector.getElement();
	assertEquals("There should be no input box before permissions have been received", 0, eRootElement.getElementsByTagName("input").length);
};

Test.dropdownBoxesBecomesVisibleIfUserHasATOBOUserTypeOfSALES = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	var eRootElement = oUserSelector.getElement();
	oUserSelector.onTOBOUserTypeChanged("SALES");
	assertEquals("The user input box should be added when the user has a TOBOUserType of SALES", this.m_oUserDropDownBox.getEl().dom, eRootElement.getElementsByTagName("input")[0]);
	assertEquals("The account input box should be added when the user has a TOBOUserType of SALES", this.m_oAccountDropDownBox.getEl().dom, eRootElement.getElementsByTagName("input")[1]);
};

Test.dropdownBoxesDoNotBecomeVisibleIfUserHasATOBOUserTypeOtherThanSALES = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	var eRootElement = oUserSelector.getElement();
	oUserSelector.onTOBOUserTypeChanged("USER");
	assertEquals("Only one input box should be added when the user has a TOBOUserType other than SALES", 1, eRootElement.getElementsByTagName("input").length);
	assertEquals("The single input box should be the account input box when the user has a TOBOUserType other than SALES", this.m_oAccountDropDownBox.getEl().dom, eRootElement.getElementsByTagName("input")[0]);
};

Test.userDropDownStoreIsPopulatedWithUsersWhenTOBOUserPermissionsAreReceived = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	oUserSelector.onTOBOUserListChanged(["Anna","Bob","Carl"]);
	assertTrue("User Anna should have been added to the store", this.m_oUserDropDownStore.find("value","Anna") >= 0);
	assertTrue("User Bob should have been added to the store", this.m_oUserDropDownStore.find("value","Bob") >= 0);
	assertTrue("User Carl should have been added to the store", this.m_oUserDropDownStore.find("value","Carl") >= 0);
};

Test.selectingAUserUpdatesTheTOBOUserManager = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	oUserSelector.onTOBOUserListChanged(["Anna","Bob","Carl"]);
	this.m_oUserDropDownBox.setValue("Bob");
	this.m_oUserDropDownBox.fireEvent("select");
	assertEquals("Selecting a user should update the TOBOUserManager","Bob",this.m_sSelectedUser);
};

Test.accountDropDownStoreIsPopulatedWithAccountsWhenTOBOAccountPermissionsAreReceived = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	oUserSelector.onTOBOAccountListChanged(["Account A","Account B","Account C"]);
	assertTrue("Account A should have been added to the store", this.m_oAccountDropDownStore.find("value","Account A") >= 0);
	assertTrue("Account B should have been added to the store", this.m_oAccountDropDownStore.find("value","Account B") >= 0);
	assertTrue("Account C should have been added to the store", this.m_oAccountDropDownStore.find("value","Account C") >= 0);
};

Test.selectingAnAccountUpdatesTheTOBOUserManager = function()
{
	var oUserSelector = new caplinx.component.userselect.UserSelectorComponent(this.m_oUserDropDownBox,this.m_oAccountDropDownBox);
	oUserSelector.onTOBOAccountListChanged(["Account A","Account B","Account C"]);
	this.m_oAccountDropDownBox.setValue("Account B");
	this.m_oAccountDropDownBox.fireEvent("select");
	assertEquals("Selecting an account should update the TOBOUserManager","Account B",this.m_sSelectedAccount);
};

Test.initialize();
