Test = CaplinTestCase("TileQuantityTextFormatterTest");

Test.setUp = function()
{
	g_oQuantityTextFormatter = new caplinx.widget.format.TileQuantityTextFormatter();
};

Test.valueZeroParameterOutputWithNoCommas = function()
{
	assertEquals("0", g_oQuantityTextFormatter.formatText("0"));
};

Test.valueOneAsParameterOutputWithNoCommas = function()
{
	assertEquals("1", g_oQuantityTextFormatter.formatText("1"));
};

Test.value999AsParameterOutputWithNoCommas = function()
{
	assertEquals("999", g_oQuantityTextFormatter.formatText("999"));
};

Test.negative1AsParameterOutputWithNoCommas = function()
{
	assertEquals("-1", g_oQuantityTextFormatter.formatText("-1"));
};

Test.negative999AsParameterOutputWithNoCommas = function()
{
	assertEquals("-999", g_oQuantityTextFormatter.formatText("-999"));
};

Test.notANumberAsParameter = function() 
{
	assertEquals("NaN", g_oQuantityTextFormatter.formatText("NaN"));
};

Test.nullAndUndefinedAsParameter = function () 
{
	assertEquals("1.1", "NaN", g_oQuantityTextFormatter.formatText("null"));
	assertEquals("1.2", "NaN", g_oQuantityTextFormatter.formatText(null));
	assertEquals("1.3", "NaN", g_oQuantityTextFormatter.formatText("undefined"));
	assertEquals("1.4", "NaN", g_oQuantityTextFormatter.formatText(undefined));
};

Test.emptyStringParameter = function ()
{
	assertEquals("NaN", g_oQuantityTextFormatter.formatText(""));
};

Test.valueOneThousandAsParameter = function ()
{
	assertEquals("1,000", g_oQuantityTextFormatter.formatText("1000"));	
};

Test.valueTenThousandAsParameter = function ()
{
	assertEquals("10,000", g_oQuantityTextFormatter.formatText("10000"));	
};

Test.valueOneMillionAsParameter = function ()
{
	assertEquals("1,000,000", g_oQuantityTextFormatter.formatText("1000000"));
};

Test.negativeOneMillionAsParameter = function ()
{
	assertEquals("-1,000,000", g_oQuantityTextFormatter.formatText("-1000000"));
};

Test.initialize();
