Test = CaplinTestCase("TileButtonElemenetRendererTest");

Test.setUp = function()
{
	this.protectApis("SL4B_Accessor", "caplinx.widget.element.renderer.TileButtonElementRenderer");
	
	window.SL4B_Accessor.getStatistics = function() {
		return {
			getResponseQueueStatistics: function() {
				return {"getTimeOldestBatchBeganExecution" : function(){return 128565445},"getTimeOldestBatchWasQueued" : function(){return 128755344}};
			}
		};
	};
	
	sInstrumentName = "GBPUSD";
	oRenderer = new caplinx.widget.element.renderer.TileButtonElementRenderer(sInstrumentName, [{}], ["ABC"], {getField: function() {return "";}});
	caplinx.widget.element.renderer.TileButtonElementRenderer.formatStore = {};
	this._verifyFormatDataIsClear();
};

// -------------------------------------------------------------------------- //

Test.getFormatStoreWhenEmpty = function()
{
	this._verifyFormatDataIsClear();
};

Test.getFormatStore = function()
{
	caplinx.widget.element.renderer.TileButtonElementRenderer.formatStore["EURJPY"] = {bShowSmallPip: true};
	caplinx.widget.element.renderer.TileButtonElementRenderer.formatStore[sInstrumentName] = {bShowSmallPip: false}; 
	this._verifyFormatData(false);
};

Test.setSmallPipToBeShown = function()
{
	oRenderer.setSmallPipToBeShown(true);
	this._verifyFormatData(true);
	oRenderer.setSmallPipToBeShown(false);
	this._verifyFormatData(false);
};

Test.getSmallPipToBeShown = function()
{
	oRenderer.setSmallPipToBeShown(true);
	assertEquals(true, oRenderer.getSmallPipToBeShown());
	oRenderer.setSmallPipToBeShown(false);
	assertEquals(false, oRenderer.getSmallPipToBeShown());
};

Test.getUpdateMetaData = function()
{
	this._verifyUpdateMetaData(undefined);
	oRenderer.setSmallPipToBeShown(true);
	this._verifyUpdateMetaData(true);
	oRenderer.setSmallPipToBeShown(false);
	this._verifyUpdateMetaData(false);
};

Test.TileButtonUpdate = function()
{
	var update = new caplinx.widget.element.renderer.TileButtonUpdate([], [], "1.00000", "1.00000", "", function(){}, {});
	assertEquals("1.00000",update.m_sCurrentValue);
	var update = new caplinx.widget.element.renderer.TileButtonUpdate([], [], "1.00000e-06", "1.00000", "", function(){}, {});
	assertEquals("0.00000",update.m_sCurrentValue);
	var update = new caplinx.widget.element.renderer.TileButtonUpdate([], [], "1.0e-99", "1.00000", "", function(){}, {});
	assertEquals("0.00000",update.m_sCurrentValue);
};


// -------------------------------------------------------------------------- //

Test._verifyFormatDataIsClear = function()
{
	this._verifyFormatData(undefined);
};

Test._verifyFormatData = function(bShowSmallPip)
{
	var oFormatStore = oRenderer.getFormatStore();
	assertNotNull(oFormatStore);
	assertEquals(bShowSmallPip, oFormatStore.bShowSmallPip);
};

Test._verifyUpdateMetaData = function(bShowSmallPip)
{
	var oUpdateMetaData = oRenderer.getUpdateMetaData();
	assertNotNull(oUpdateMetaData);
	assertEquals(bShowSmallPip, oUpdateMetaData.bShowSmallPip);
};

Test.initialize();
