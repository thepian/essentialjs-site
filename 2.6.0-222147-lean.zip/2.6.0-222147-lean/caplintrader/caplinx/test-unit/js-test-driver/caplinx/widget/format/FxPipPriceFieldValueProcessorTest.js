Test = CaplinTestCase("FxPipPriceFieldValueProcessorTest");

Test.setUp = function()
{
	pipProcessorPart1 = new caplinx.widget.format.FxPipPriceFieldValueProcessor(caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_ONE);
	pipProcessorPart2 = new caplinx.widget.format.FxPipPriceFieldValueProcessor(caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_TWO);
	pipProcessorPart3 = new caplinx.widget.format.FxPipPriceFieldValueProcessor(caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_THREE);

	metaDataNoSmallPip = {bShowSmallPip: false};
	metaDataSmallPip = {bShowSmallPip: true};

	price1 = "1.2345";
	price2 = "12345.6789";
	price3 = "1.234567";
};

// -------------------------------------------------------------------------- //

Test.processPart1WithNoSmallPip_Price1 = function()
{
	assertEquals("1.23", pipProcessorPart1.getValue(price1, metaDataNoSmallPip));
};

Test.processPart2WithNoSmallPip_Price1 = function()
{
	assertEquals("45", pipProcessorPart2.getValue(price1, metaDataNoSmallPip));
};

Test.processPart3WithNoSmallPip_Price1 = function()
{
	assertEquals("", pipProcessorPart3.getValue(price1, metaDataNoSmallPip));
};

Test.processPart1WithSmallPip_Price1 = function()
{
	assertEquals("1.2", pipProcessorPart1.getValue(price1, metaDataSmallPip));
};

Test.processPart2WithSmallPip_Price1 = function()
{
	assertEquals("34", pipProcessorPart2.getValue(price1, metaDataSmallPip));
};

Test.processPart3WithSmallPip_Price1 = function()
{
	assertEquals("5", pipProcessorPart3.getValue(price1, metaDataSmallPip));
};

// -------------------------------------------------------------------------- //

Test.processPart1WithNoSmallPip_Price2 = function()
{
	assertEquals("12345.67", pipProcessorPart1.getValue(price2, metaDataNoSmallPip));
};

Test.processPart2WithNoSmallPip_Price2 = function()
{
	assertEquals("89", pipProcessorPart2.getValue(price2, metaDataNoSmallPip));
};

Test.processPart3WithNoSmallPip_Price2 = function()
{
	assertEquals("", pipProcessorPart3.getValue(price2, metaDataNoSmallPip));
};

Test.processPart1WithSmallPip_Price2 = function()
{
	assertEquals("12345.6", pipProcessorPart1.getValue(price2, metaDataSmallPip));
};

Test.processPart2WithSmallPip_Price2 = function()
{
	assertEquals("78", pipProcessorPart2.getValue(price2, metaDataSmallPip));
};

Test.processPart3WithSmallPip_Price2 = function()
{
	assertEquals("9", pipProcessorPart3.getValue(price2, metaDataSmallPip));
};

// -------------------------------------------------------------------------- //

Test.processPart1WithNoSmallPip_Price3 = function()
{
	assertEquals("1.2345", pipProcessorPart1.getValue(price3, metaDataNoSmallPip));
};

Test.processPart2WithNoSmallPip_Price3 = function()
{
	assertEquals("67", pipProcessorPart2.getValue(price3, metaDataNoSmallPip));
};

Test.processPart3WithNoSmallPip_Price3 = function()
{
	assertEquals("", pipProcessorPart3.getValue(price3, metaDataNoSmallPip));
};

Test.processPart1WithSmallPip_Price3 = function()
{
	assertEquals("1.234", pipProcessorPart1.getValue(price3, metaDataSmallPip));
};

Test.processPart2WithSmallPip_Price3 = function()
{
	assertEquals("56", pipProcessorPart2.getValue(price3, metaDataSmallPip));
};

Test.processPart3WithSmallPip_Price3 = function()
{
	assertEquals("7", pipProcessorPart3.getValue(price3, metaDataSmallPip));
};

// -------------------------------------------------------------------------- //

Test.getPartOneValueWithSmallPip = function()
{
	pipProcessorPart1.m_bShowSmallPip = true;
	assertEquals("1.2", pipProcessorPart1._getPartOneValue("1.2345"));
};

Test.getPartOneValueWithNoSmallPip = function()
{
	pipProcessorPart1.m_bShowSmallPip = false;
	assertEquals("1.23", pipProcessorPart1._getPartOneValue("1.2345"));
};

Test.getPartTwoValueWithSmallPip = function()
{
	pipProcessorPart1.m_bShowSmallPip = true;
	assertEquals("34", pipProcessorPart1._getPartTwoValue("1.2345"));
};

Test.getPartTwoValueWithNoSmallPip = function()
{
	pipProcessorPart1.m_bShowSmallPip = false;
	assertEquals("45", pipProcessorPart1._getPartTwoValue("1.2345"));
};

Test.getPartThreeValueWithSmallPip = function()
{
	pipProcessorPart1.m_bShowSmallPip = true;
	assertEquals("5", pipProcessorPart1._getPartThreeValue("1.2345"));
};

Test.getPartThreeValueWithNoSmallPip = function()
{
	pipProcessorPart1.m_bShowSmallPip = false;
	assertEquals("", pipProcessorPart1._getPartThreeValue("1.2345"));
};

Test.initialize();
