Test = CaplinTestCase("BlotterRecordObjectTest");

Test.setUp = function()
{
	this.protectApis("caplinx.widget.objectset.BlotterRecordObject");
	
	var oThis = this;
	
	StubField = function(sName)
	{
		oThis.m_sName = sName;
	};
	StubField.prototype.getId = function() { return oThis.m_sName; }
	StubField.prototype.getName = function() { return oThis.m_sName; }
	
	this.m_oBlotterRecordObject = null;
	this.m_oMockRttpProvider = null;
	this.m_oFieldCollection = new caplin.widget.collection.Collection([new StubField("InstrumentDescription")], null);
	this.m_oModel = { getFields: function() { return oThis.m_oFieldCollection; } };
	
	this.m_fOriginalSl4bAccessor = SL4B_Accessor;
	SL4B_Accessor = {
		getRttpProvider: function() { return oThis.m_oMockRttpProvider.proxy(); }
	};
	
	caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener._$clear();
	
	this.m_oBlotterRecordObject = new caplinx.widget.objectset.BlotterRecordObject("/TRADE/HISTORY", "TradeId", 50);
	this.m_oBlotterRecordObject.setModel(this.m_oModel);
	
	this.m_oMockRttpProvider = mock(SL4B_RttpProvider);
};

Test.tearDown = function()
{
	SL4B_Accessor = this.m_fOriginalSl4bAccessor;
};

Test.initialSubscriptionIsOnlyMadeByOnceSl4BIsReadyAndBlotterIsActivated = function()
{
	this.m_oBlotterRecordObject.ready();
	
	this.m_oMockRttpProvider.expects(once()).getObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oBlotterRecordObject.activate();
};

Test.deactivationSendsDiscardToLiberatorIfBlotterWasActivated = function()
{
	this._initializeBlotter(this.m_oBlotterRecordObject);
	
	this.m_oMockRttpProvider.expects(once()).removeObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oBlotterRecordObject.deactivate();
};

Test.deactivationDoesNotSendDiscardToLiberatorIfBlotterWasNotActivated = function()
{
	this.m_oBlotterRecordObject.ready();
	this.m_oBlotterRecordObject.deactivate();
};

Test.objectNotFoundSetsUpBlotterForResubscription = function()
{
	this._verifyObjectErrorIsInvoked("objectNotFound");
};

Test.objectUnavailableSetsUpBlotterForResubscription = function()
{
	this._verifyObjectErrorIsInvoked("objectUnavailable");
};

Test.objectReadDeniedSetsUpBlotterForResubscription = function()
{
	this._verifyObjectErrorIsInvoked("objectReadDenied");
};

Test.objectWriteDeniedSetsUpBlotterForResubscription = function()
{
	this._verifyObjectErrorIsInvoked("objectWriteDenied");
};

Test.serviceUpDoesNotTriggerResubscriptionForBlotterWithSuccessfulSubscription = function()
{
	this._initializeBlotter(this.m_oBlotterRecordObject);
	
	// this call should do nothing
	this.m_oBlotterRecordObject.resubscribe();
};

Test.serviceUpTriggersResubscriptionForBlotterWithFailedSubscription = function()
{
	this._initializeBlotter(this.m_oBlotterRecordObject);
	
	// send objectError
	this.m_oBlotterRecordObject.objectError();
	
	// resubscription should now occur
	this.m_oMockRttpProvider.expects(once()).getObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oBlotterRecordObject.resubscribe();
};

Test.serviceUpDoesNotTriggerResubscriptionForDeactivatedBlotter = function()
{
	this._initializeBlotter(this.m_oBlotterRecordObject);
	
	// send objectError
	this.m_oBlotterRecordObject.objectError();
	
	// then deactivate the blotter
	this.m_oBlotterRecordObject.deactivate();
	
	// resubscription should do nothing
	this.m_oBlotterRecordObject.resubscribe();
};

Test.serviceUpMessageSendsResubscriptionToAllRegisteredBlotters = function()
{
	var oBlotterRecordObject1 = new caplinx.widget.objectset.BlotterRecordObject("/TRADE/HISTORY", "TradeId", 50);
	oBlotterRecordObject1.setModel(this.m_oModel);
	this._initializeBlotter(oBlotterRecordObject1);
	
	var oBlotterRecordObject2 = new caplinx.widget.objectset.BlotterRecordObject("/TRADE/HISTORY", "TradeId", 50);
	oBlotterRecordObject2.setModel(this.m_oModel);
	this._initializeBlotter(oBlotterRecordObject2);
	
	this.m_oBlotterRecordObject.objectError();
	oBlotterRecordObject1.objectError();
	oBlotterRecordObject2.objectError();
	
	this.m_oMockRttpProvider.expects(once()).getObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oMockRttpProvider.expects(once()).getObject(oBlotterRecordObject1, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oMockRttpProvider.expects(once()).getObject(oBlotterRecordObject2, "/TRADE/HISTORY", "InstrumentDescription");
	caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.serviceMessage(SL4B_RttpCodes.const_SERVICE_OK, "trading", "Trading", "Trading+is+OK");
};

Test.resubscriptionKeepsTryingUntilItIsSuccessful = function()
{
	this._initializeBlotter(this.m_oBlotterRecordObject);
	
	// send objectError
	this.m_oBlotterRecordObject.objectError();
	
	// resubscription should now occur
	this.m_oMockRttpProvider.expects(once()).getObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oBlotterRecordObject.resubscribe();
	
	// send another objectError
	this.m_oBlotterRecordObject.objectError();
	
	// resubscription should now occur
	this.m_oMockRttpProvider.expects(once()).getObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oBlotterRecordObject.resubscribe();
	
	// send another objectError
	this.m_oBlotterRecordObject.objectError();
	
	// resubscription should now occur
	this.m_oMockRttpProvider.expects(once()).getObject(this.m_oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	this.m_oBlotterRecordObject.resubscribe();
	
	// final resubscribe should do nothing
	this.m_oBlotterRecordObject.resubscribe();
};

// utility methods
Test._initializeBlotter = function(oBlotterRecordObject)
{
	oBlotterRecordObject.ready();
	
	this.m_oMockRttpProvider.expects(once()).getObject(oBlotterRecordObject, "/TRADE/HISTORY", "InstrumentDescription");
	oBlotterRecordObject.activate();
};

Test._verifyObjectErrorIsInvoked = function(sMethodName)
{
	this._initializeBlotter(this.m_oBlotterRecordObject);
	
	var bObjectErrorInvoked = false;
	this.m_oBlotterRecordObject.objectError = function () {
		bObjectErrorInvoked = true;
	};
	
	this.m_oBlotterRecordObject["objectNotFound"]("/TRADE/HISTORY");
	assertTrue("objectError() was not invoked", bObjectErrorInvoked);
};

Test.initialize();
