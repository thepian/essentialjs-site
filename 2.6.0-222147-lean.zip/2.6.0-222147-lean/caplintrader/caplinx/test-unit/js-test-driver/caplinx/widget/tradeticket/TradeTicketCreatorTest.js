Test = CaplinTestCase("TradeTicketCreatorTest");

Test.setUp = function()
{
	this.protectApis("caplin.widget.message", "caplin.security.permissioning");
	this.m_oWebcentric = window.webcentric;
};

Test.tearDown = function()
{
	window.webcentric = this.m_oWebcentric;
};

Test.correctTicketIsOpened = function(){
	var tradeTicketCreator = caplinx.widget.tradeticket.TradeTicketCreator.getInstance();
	
	var testData = [{
		objectName: "/FI/AT0000383864=R",
		buyOrSell: "Ask",
		tradeProtocol: "RFS",
		amount: undefined,
		dealtCurrency: undefined,
		account: undefined
	}, {
		objectName: "/FX/EURUSD",
		buyOrSell: "Bid",
		tradeProtocol: "RFS",
		amount: undefined,
		dealtCurrency: undefined,
		account: undefined
	}, {
		objectName: "",
		buyOrSell: "",
		tradeProtocol: "",
		amount: undefined,
		dealtCurrency: undefined,
		account: undefined
	} ];

	var sDialogTemplate;
	var oPropertyValues;
	webcentric = { 
		showDialog: function(l_sDialogTemplate, l_oPropertyValues)
		{
			bRefusedPermission = false;
			sDialogTemplate = l_sDialogTemplate;
			oPropertyValues = l_oPropertyValues;
		}
	};
	
	var bRefusedPermission;
	caplin.widget.message.MessageManager = {
		getInstance: function() {
			return {
				alert: function(){
					bRefusedPermission = true;
				}
			}
		}
	};
	
	var bHasPermission = false;
	caplin.security.permissioning.PermissionService = {
		canUserPerformAction: function() {
			return bHasPermission;
		},
		
		getAllowPermissions: function() {
			return {
				length: 1
			};
		}
	};
	
	// Check that we get kicked out when we pass in undefined parameters
	tradeTicketCreator.openTicket(undefined, undefined, undefined, undefined, undefined, undefined);
	assertUndefined(bRefusedPermission);
	assertUndefined(sDialogTemplate);
	assertUndefined(oPropertyValues);	
	
	// Check that we get the permission refused message when we're not permissioned...
	tradeTicketCreator.openTicket(testData[0]["objectName"], testData[0]["buyOrSell"], testData[0]["tradeProtocol"], testData[0]["amount"], testData[0]["dealtCurrency"], testData[0]["account"]);
	assertTrue(bRefusedPermission);
	
	bHasPermission = true;
	
	// Check that we get past the permission check now
	// Assert the FI route was okay.
	tradeTicketCreator.openTicket(testData[0]["objectName"], testData[0]["buyOrSell"], testData[0]["tradeProtocol"], testData[0]["amount"], testData[0]["dealtCurrency"], testData[0]["account"]);
	assertFalse(bRefusedPermission);
	assertEquals("FI data should open bond ticket.", "bonds-trade-ticket", sDialogTemplate);
	assertEquals("Structure type property should match that passed in.", testData[0]["objectName"], oPropertyValues.properties.setStructureType);
	assertEquals("Side property should match that passed in.", "Ask", oPropertyValues.properties.setSide);
	
	// Assert the FX route was okay.
	tradeTicketCreator.openTicket(testData[1]["objectName"], testData[1]["buyOrSell"], testData[1]["tradeProtocol"], testData[1]["amount"], testData[1]["dealtCurrency"], testData[1]["account"]);
	assertFalse(bRefusedPermission);
	assertEquals("FX data should open fx trade ticket.", "fx-trade-ticket", sDialogTemplate);
	assertEquals("Object name property should match that passed in.", testData[1]["objectName"], oPropertyValues.properties.setObjectName);
	var sFxBuyOrSell = (testData[1]["buyOrSell"] == "Bid") ? "Sell" : "Buy";
	assertEquals("Buy/sell property should match that passed in.", sFxBuyOrSell, oPropertyValues.properties.setBuySell);
	assertEquals("Trade protocol property should match that passed in.", testData[1]["tradeProtocol"], oPropertyValues.properties.setProtocol);
	assertEquals("Amount property should match that passed in.", testData[1]["amount"], oPropertyValues.properties.setAmount);
	assertEquals("Dealt currency property should match that passed in.", testData[1]["dealtCurrency"], oPropertyValues.properties.setInitialDealtCurrency);
	assertEquals("Account property should match that passed in.", testData[1]["account"], oPropertyValues.properties.setAccount);
};

Test.initialize();
