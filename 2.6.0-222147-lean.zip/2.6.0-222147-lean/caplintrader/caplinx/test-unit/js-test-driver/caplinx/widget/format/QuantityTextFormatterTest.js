Test = CaplinTestCase("QuantityTextFormatterTest");

Test.setUp = function()
{
	g_oQuantityTextFormatter = new caplinx.widget.format.QuantityTextFormatter();
};

Test._parseUserInput_basics = function()
{
	assertEquals(10, g_oQuantityTextFormatter.parseUserInput(10));
	assertEquals(10, g_oQuantityTextFormatter.parseUserInput('10.000'));
};

Test._parseUserInput_shortCutsWork = function()
{
	assertEquals(1000, g_oQuantityTextFormatter.parseUserInput('1k'));
	assertEquals(1000000, g_oQuantityTextFormatter.parseUserInput('1mil'));
	assertEquals(1000000000, g_oQuantityTextFormatter.parseUserInput('1bil'));
	assertEquals(1000, g_oQuantityTextFormatter.parseUserInput('1K'));
	assertEquals(1000000, g_oQuantityTextFormatter.parseUserInput('1MIL'));
	assertEquals(1000000000, g_oQuantityTextFormatter.parseUserInput('1BIL'));
};

Test._parseUserInput_commasAreOk = function()
{
	assertEquals(1000, g_oQuantityTextFormatter.parseUserInput('1,000'));
	assertEquals(1000, g_oQuantityTextFormatter.parseUserInput('1,0,0,0'));
};

Test._parseUserInput_ignoresLeadingSpaces = function()
{
	assertEquals("1.1", 1000, g_oQuantityTextFormatter.parseUserInput(' 1000'));
	assertEquals("1.2", 2000, g_oQuantityTextFormatter.parseUserInput('   2000'));
	assertEquals("1.3", 3000, g_oQuantityTextFormatter.parseUserInput(' 3,000'));
	assertEquals("1.4", 4000, g_oQuantityTextFormatter.parseUserInput('   4,000'));
	assertEquals("1.5", 5000, g_oQuantityTextFormatter.parseUserInput('\t5,000'));
};

Test._parseUserInput_ignoresTrailingSpaces = function()
{
	assertEquals("1.1", 1000, g_oQuantityTextFormatter.parseUserInput('1000 '));
	assertEquals("1.2", 2000, g_oQuantityTextFormatter.parseUserInput('2000   '));
	assertEquals("1.3", 3000, g_oQuantityTextFormatter.parseUserInput('3,000 '));
	assertEquals("1.4", 4000, g_oQuantityTextFormatter.parseUserInput('4,000   '));
	assertEquals("1.5", 5000, g_oQuantityTextFormatter.parseUserInput('5,000\t'));
};

Test._parseUserInput_ignoresSpacesBetweenNumbers = function()
{
	assertEquals("1.1", 1000, g_oQuantityTextFormatter.parseUserInput('1 000'));
	assertEquals("1.2", 2000000, g_oQuantityTextFormatter.parseUserInput('2 000 000'));
};

Test._parseUserInput_ignoresSpacesBetweenShortCuts = function()
{
	assertEquals("1.1", 1000, g_oQuantityTextFormatter.parseUserInput('1 K'));
	assertEquals("1.2", 2000000, g_oQuantityTextFormatter.parseUserInput('2 MIL'));
	assertEquals("1.3", 3500000, g_oQuantityTextFormatter.parseUserInput('3.5 MIL'));
	assertEquals("1.4", 4200, g_oQuantityTextFormatter.parseUserInput('4.2 K'));
};

Test._parseUserInput_zero_isInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, 0);
};

Test._parseUserInput_fractions_isInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, 10.5);
	assertThrows(g_oQuantityTextFormatter.parseUserInput, '10.5');
};

Test._parseUserInput_exponents_areInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, '1e6');
	assertThrows(g_oQuantityTextFormatter.parseUserInput, '1E6');
};

Test._parseUserInput_text_isInvalid= function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, 'fail');
};

Test._parseUserInput_nan_isInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, NaN);
};

Test._parseUserInput_null_isInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, null);
};

Test._parseUserInput_undefined_isInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, undefined);
};

Test._parseUserInput_Infinity_isInvalid = function()
{
	assertThrows(g_oQuantityTextFormatter.parseUserInput, 'Infinity');
};

Test._formatText_basics = function()
{
	assertEquals('0', g_oQuantityTextFormatter.formatText('0'));
	assertEquals('10', g_oQuantityTextFormatter.formatText('10'));
};

Test._formatText_shortCutsWork = function()
{
	assertEquals('1??? cx.widget.format.quantity.formatter.thousand ???', g_oQuantityTextFormatter.formatText('1000'));
	assertEquals('1??? cx.widget.format.quantity.formatter.million ???', g_oQuantityTextFormatter.formatText('1000000'));
	assertEquals('1??? cx.widget.format.quantity.formatter.billion ???', g_oQuantityTextFormatter.formatText('1000000000'));
};

Test._formatText_text = function()
{
	assertEquals('Infinity', g_oQuantityTextFormatter.formatText('Infinity'));
	assertTrue(isNaN(g_oQuantityTextFormatter.formatText('fail')));
};

Test._formatText_fractionsNotTruncated= function()
{
	assertEquals('10.555555', g_oQuantityTextFormatter.formatText('10.555555'));
};

Test._formatText_numberOfSignificantFigures = function()
{
	var oQuantityTextFormatter = new caplinx.widget.format.QuantityTextFormatter(false, 4);
	assertEquals('10.56', oQuantityTextFormatter.formatText('10.555555'));
};

// Is has been broken so fixing it may break stuff
Test._formatText_zeroAsBlank_doesNotWork = function()
{
	var oQuantityTextFormatter = new caplinx.widget.format.QuantityTextFormatter(true);
	assertEquals('0', oQuantityTextFormatter.formatText('0'));
};

Test._insertCommas = function()
{
	assertEquals('1,000', g_oQuantityTextFormatter.insertCommas ('1000'));
	assertEquals('1,000', g_oQuantityTextFormatter.insertCommas (1000));
};

assertThrows = function(fFunction)
{
	try
	{
		var pArguments =  Array.prototype.slice.call(arguments);
		pArguments.shift();
		fFunction.apply(g_oQuantityTextFormatter, pArguments);
	}
	catch(success)
	{
		return;
	}
	fail('Did not throw!');
};

Test.initialize();
