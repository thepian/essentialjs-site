Test = CaplinTestCase("TradableElementRendererTest");

Test.setUp = function()
{
	this.protectApis("caplin.security.permissioning.PermissionService");
	
	caplin.security.permissioning.PermissionService.addPermissionListener = function(sProduct, sNamespace, sAction, oListener)
	{
		this.m_sProduct = sProduct;
		this.m_sNamespace = sNamespace;
		this.m_sAction = sAction;
		this.m_oListener = oListener;
		this._sendPermission(this.m_bIsPermitted);
	};

	caplin.security.permissioning.PermissionService._sendPermission = function(bIsPermitted)
	{
		this.m_oListener.onSinglePermissionChanged(bIsPermitted, this.m_sProduct, this.m_sNamespace, this.m_sAction);
	};

	caplin.security.permissioning.PermissionService.removeListener = function()
	{
		// do nothing
	};
	
	caplin.security.permissioning.PermissionService.m_bIsPermitted = false;
	
	window.RTSL_AddElementToCache = function(s,ss){};
	window.RTSL_DisplayUpdate = function(obj){};
	window.RTSL_CreateUpdate = function(one, two, three){
		assertEquals('2.0',three);
	};
};

Test.TradableElementRendererFailsWithUndefinedField = function()
{
	assertFails("Expected failure on undefined arguments", function(){
		new caplinx.renderer.TradableElementRenderer();
	});	
};

Test.TradableElementRendererFailsWithDefinedFieldNonArray = function()
{
	assertFails("Expected failure on lack of array as constructor argument", function(){
		new caplinx.renderer.TradableElementRenderer('v');
	});	
};

//Test.TradableElementRendererCreatesCorrectHtmlWhenPermissionInitiallyGranted = function()
//{
//	var mRecord = {'BestBid':'2.0','BestAsk':'2.0','InstrumentId':'GBPUSD','SID':'fx-data'};
//	var sSubject = '/FX/GBPUSD';
//	var eElement = document.createElement('div');
//	var oTradableER = new caplinx.renderer.TradableElementRenderer(['BestAsk']);
//	
//	caplin.security.permissioning.PermissionService.m_bIsPermitted = true;
//	oTradableER.setSubject(sSubject);
//	var sHtml = oTradableER.createElementHtml(mRecord);
//	assertEquals('<span class="tradablePrices">2.0</span>', sHtml);
//};

Test.TradableElementRendererCreatesCorrectHtmlWhenPermissionInitiallyRevoked = function()
{
	var mRecord = {'BestBid':'2.0','BestAsk':'2.0','InstrumentId':'GBPUSD','SID':'fx-data'};
	var sSubject = '/FX/GBPUSD';
	var eElement = document.createElement('div');
	var oTradableER = new caplinx.renderer.TradableElementRenderer(['BestAsk']);
	
	caplin.security.permissioning.PermissionService.m_bIsPermitted = false;
	oTradableER.setSubject(sSubject);
	var sHtml = oTradableER.createElementHtml(mRecord, sSubject);
	assertEquals('<span>2.0</span>', sHtml);
};

//Test.TradableElementRendererChangesClassOnPermissionChanges = function()
//{
//	var mRecord = {
//		'BestBid': '2.0',
//		'BestAsk': '2.0',
//		'InstrumentId': 'GBPUSD',
//		'SID': 'fx-data'
//	};
//	var sSubject = '/FX/GBPUSD';
//	var eElement = document.createElement('div');
//	var oTradableER = new caplinx.renderer.TradableElementRenderer(['BestAsk']);
//	
//	// tradable element is added to the dom
//	caplin.security.permissioning.PermissionService.m_bIsPermitted = true;
//	oTradableER.setSubject(sSubject);
//	eElement.innerHTML = oTradableER.createElementHtml(mRecord);
//	oTradableER.setDomElement(eElement);
//	
//	// if the permission is revoked the class disappears
//	caplin.security.permissioning.PermissionService._sendPermission(false);
//	assertEquals("1a", "", eElement.firstChild.className);
//	
//	// but if the permission is revoked the class becomes disappears
//	caplin.security.permissioning.PermissionService._sendPermission(true);
//	assertEquals("2a", "tradablePrices", eElement.firstChild.className);
//};

Test.TradableElementRendererCorrectlyAddsListernerToModel = function(){
	var m_pFields = ['BestAsk'];
	var oTradableER = new caplinx.renderer.TradableElementRenderer(m_pFields);
	
	assertEquals(m_pFields, oTradableER.getFieldNames());	
};

Test.TradableElementRendererPassesTheCorrectDataToSL4B = function(){
	var mRecord = {'BestBid':'2.0','BestAsk':'2.0','InstrumentId':'GBPUSD','SID':'fx-data'};
	var m_pFields = ['BestAsk'];
	var oTradableER = new caplinx.renderer.TradableElementRenderer(m_pFields);
	
	var domNode = document.createElement('span');
	var domNode2 = document.createElement('span');
	var domNode3 = document.createElement('span');
	domNode.appendChild(domNode2);
	domNode2.appendChild(domNode3);
	document.body.appendChild(domNode);
	oTradableER.setDomElement(domNode);
	
	oTradableER.renderDataUpdate(mRecord);
	assertEquals(m_pFields, oTradableER.getFieldNames());	
};

Test.initialize();
