Test = CaplinTestCase("RangeFilterHandlerTest");

Test.setUp = function()
{
	this.m_oMockControlRenderer = mock(caplin.renderer.control.ControlRenderer);
	this.m_oMockColumn = mock(caplin.grid.GridColumn);
	this.m_oMockColumnModel = mock(caplin.grid.GridColumnModel);
};

Test.verifyPositiveRange = function()
{
	this._verifyRangeAddFilterEvent("100 - 200", '100', '200');
};

Test.verifyNegativeRange = function()
{
	this._verifyRangeAddFilterEvent("-200 - -100", '-200', '-100');
};
Test.verifyFloatRange = function()
{
	this._verifyRangeAddFilterEvent("1.10 - 2.30", '1.1', '2.3');
};
Test.verifyNegativeFloatRange = function()
{
	this._verifyRangeAddFilterEvent("-2.30 - -1.10", '-2.3', '-1.1');
};

Test.verifyRangeWithWhiteSpace = function()
{
	this._verifyRangeAddFilterEvent("  - 100  - 200 ", '-100', '200');
};

Test.verifyRangeWithLowZero = function()
{
	this._verifyRangeAddFilterEvent("0 - 1", '0', '1');
};

Test.verifyRangeWithHighZero = function()
{
	this._verifyRangeAddFilterEvent("-1 - 0", '-1', '0');
};
//Test.
verifyIdenticalRangeChangesToEqualsTo = function()
{
	this._setupStandardExpectations();
	this.m_oMockColumn.expects(once()).addFilter(caplin.grid.GridColumnFilter.EXACT_MATCH, '1');
	caplinx.renderer.handler.RangeFilterHandler.onChange('1-1', this.m_oMockControlRenderer.proxy());
};

// Less than
Test.verifyPositiveHigh = function()
{
	this._verifySingleAddFilterEvent('< 100', caplin.grid.GridColumnFilter.LESS_THAN, '100');
};

Test.verifyNegativeHigh = function()
{
	this._verifySingleAddFilterEvent('< -100', caplin.grid.GridColumnFilter.LESS_THAN, '-100');
};

Test.verifyFloatHigh= function()
{
	this._verifySingleAddFilterEvent('< 1.88',caplin.grid.GridColumnFilter.LESS_THAN, '1.88');
};

Test.verifyNegativeFloatHigh = function()
{
	this._verifySingleAddFilterEvent('< -1.88', caplin.grid.GridColumnFilter.LESS_THAN, '-1.88');
};


// Greater than
Test.verifyPositiveLow = function()
{
	this._verifySingleAddFilterEvent('> 100', caplin.grid.GridColumnFilter.GREATER_THAN, '100');
};

Test.verifyNegativeLow = function()
{
	this._verifySingleAddFilterEvent('> -100', caplin.grid.GridColumnFilter.GREATER_THAN, '-100');
};

Test.verifyFloatLow= function()
{
	this._verifySingleAddFilterEvent('> 1.88',caplin.grid.GridColumnFilter.GREATER_THAN, '1.88');
};

Test.verifyNegativeFloatLow = function()
{
	this._verifySingleAddFilterEvent('> -1.88', caplin.grid.GridColumnFilter.GREATER_THAN, '-1.88');
};


// equals to
Test.verifyPositiveEqualsTo = function()
{
	this._verifySingleAddFilterEvent('100', caplin.grid.GridColumnFilter.NUMERIC_MATCH, '100');
};

Test.verifyNegativeEqualsTo = function()
{
	this._verifySingleAddFilterEvent('-100', caplin.grid.GridColumnFilter.NUMERIC_MATCH, '-100');
};

Test.verifyFloatEqualsTo = function()
{
	this._verifySingleAddFilterEvent('1.02', caplin.grid.GridColumnFilter.NUMERIC_MATCH,  '1.02');
};

Test.verifyNegativeFloatEqualsTo = function()
{
	this._verifySingleAddFilterEvent('-1.88', caplin.grid.GridColumnFilter.NUMERIC_MATCH, '-1.88');
};

Test.verifyEmptyValueDoesNotAddAnyFilter = function()
{
	this._setupStandardExpectations();
	this.m_oMockColumn.expects(never()).addFilter(ANYTHING, ANYTHING);

	caplinx.renderer.handler.RangeFilterHandler.onChange('', this.m_oMockControlRenderer.proxy());
};

Test.verifyInvalidStringRangeThrowsError = function()
{
	this.m_oMockColumn.expects(once()).clearFilters();
	this.m_oMockControlRenderer.expects(once()).getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockControlRenderer.expects(once()).onError("caplinx.renderer.handler.RangeFilterHandler", ANYTHING);
	caplinx.renderer.handler.RangeFilterHandler.onChange('1000 - 900', this.m_oMockControlRenderer.proxy());
};

Test.verifyInvalidRangeThrowsError = function()
{
	this.m_oMockColumn.expects(once()).clearFilters();
	this.m_oMockControlRenderer.expects(once()).getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockControlRenderer.expects(once()).onError("caplinx.renderer.handler.RangeFilterHandler", ANYTHING);
	this.m_oMockControlRenderer.expects(once()).onInvalidChange();
	caplinx.renderer.handler.RangeFilterHandler.onChange('10<>12', this.m_oMockControlRenderer.proxy());
};

Test.verifyInvalidPreRangeThrowsError = function()
{
	this.m_oMockColumn.expects(once()).clearFilters();
	this.m_oMockControlRenderer.expects(once()).getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockControlRenderer.expects(once()).onError("caplinx.renderer.handler.RangeFilterHandler", ANYTHING);
	this.m_oMockControlRenderer.expects(once()).onInvalidChange();
	caplinx.renderer.handler.RangeFilterHandler.onChange('<<10-12', this.m_oMockControlRenderer.proxy());
};

Test.verifyInvalidPostRangeThrowsError = function()
{
	this.m_oMockColumn.expects(once()).clearFilters();
	this.m_oMockControlRenderer.expects(once()).getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockControlRenderer.expects(once()).onError("caplinx.renderer.handler.RangeFilterHandler", ANYTHING);
	this.m_oMockControlRenderer.expects(once()).onInvalidChange();
	caplinx.renderer.handler.RangeFilterHandler.onChange('10-12>>', this.m_oMockControlRenderer.proxy());
};

Test.verifyInvalidInputThrowsError = function()
{
	this.m_oMockColumn.expects(once()).clearFilters();
	this.m_oMockControlRenderer.expects(once()).getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockControlRenderer.expects(once()).onError("caplinx.renderer.handler.RangeFilterHandler", ANYTHING);
	this.m_oMockControlRenderer.expects(once()).onInvalidChange();
	caplinx.renderer.handler.RangeFilterHandler.onChange('test', this.m_oMockControlRenderer.proxy());
};

Test.verifyInvalidRangeThrowsErrorWithSpaces = function()
{
	this.m_oMockColumn.expects(once()).clearFilters();
	this.m_oMockControlRenderer.expects(once()).getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockControlRenderer.expects(once()).onError("caplinx.renderer.handler.RangeFilterHandler", ANYTHING);
	this.m_oMockControlRenderer.expects(once()).onInvalidChange();
	caplinx.renderer.handler.RangeFilterHandler.onChange('10 <> 20', this.m_oMockControlRenderer.proxy());
};

// Helper Methods
Test._setupStandardExpectations = function(xxx)
{
	this.m_oMockControlRenderer.stubs().getFieldModel().will(returnValue(this.m_oMockColumn.proxy()));
	this.m_oMockColumn.expects(once()).clearFilters();
};

Test._verifySingleAddFilterEvent = function(sNewValue, nExpectedFilter, sExpectedValue )
{
	this._setupStandardExpectations();
	this.m_oMockColumn.expects(once()).addFilter(nExpectedFilter, sExpectedValue);
	
	caplinx.renderer.handler.RangeFilterHandler.onChange(sNewValue, this.m_oMockControlRenderer.proxy());	
};

Test._verifyRangeAddFilterEvent = function(sNewValue, sExpectedgreaterThan, sExpectedHigh)
{
	this._setupStandardExpectations();
	// two filters will be added for a range, a lessThanFilter and a LowFilter
	this.m_oMockColumn.expects(once()).getFieldNames().will(returnValue(['string']));
	this.m_oMockColumn.expects(once()).setFilters(ANYTHING, ANYTHING);
	
//	var sNewValue = "100 - 200";
	caplinx.renderer.handler.RangeFilterHandler.onChange(sNewValue, this.m_oMockControlRenderer.proxy());
};

Test.initialize();
