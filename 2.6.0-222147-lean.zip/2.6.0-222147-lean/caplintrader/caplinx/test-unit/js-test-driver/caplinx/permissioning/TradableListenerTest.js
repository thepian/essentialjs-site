Test = CaplinTestCase("TradableListenerTest");

Test.setUp = function()
{
	this.m_oPermissionService = caplin.security.permissioning.PermissionService;
};

Test.tearDown = function()
{
	caplin.security.permissioning.PermissionService = this.m_oPermissionService;
};

Test._stubPermissionService = function()
{
	caplin.security.permissioning.PermissionService = {
		addPermissionSetListener : function() {},
		addPermissionListener : function() {}
	};
};

// constructor tests
Test.InstatiatingWithProtocolAndTradeTypeAddsCorrectSingleListeners = function()
{
	var oMockPermissionService = mock(this.m_oPermissionService.constructor);
	
	oMockPermissionService.expects(once()).addPermissionSetListener("/FX/test", "TradeType", this.m_oPermissionService.ALLOW, ANYTHING);
	oMockPermissionService.expects(once()).addPermissionListener("/FX/test", "TradeProtocol", "RFS", ANYTHING);

	caplin.security.permissioning.PermissionService = oMockPermissionService.proxy();
	caplin.security.permissioning.PermissionService.ALLOW = this.m_oPermissionService.ALLOW;
	
	new caplinx.permissioning.TradableListener("/FX/test", null, "RFS");
};

Test.InstatiatingWithProtocolOnlyAddsSingleListenersForProtocolAndSetForTradeType = function()
{
	var oMockPermissionService = mock(this.m_oPermissionService.constructor);
	
	oMockPermissionService.expects(once()).addPermissionListener("/FX/test", "TradeProtocol", "ESP", ANYTHING);
	oMockPermissionService.expects(once()).addPermissionListener("/FX/test", "TradeType", "SPOT", ANYTHING);

	caplin.security.permissioning.PermissionService = oMockPermissionService.proxy();
	caplin.security.permissioning.PermissionService.ALLOW = this.m_oPermissionService.ALLOW;
	
	new caplinx.permissioning.TradableListener("/FX/test", null, "ESP", "SPOT");
};

// removal tests
Test.SingleListenersRemovedWhenCanceled = function()
{
	var oMockPermissionService =  mock(this.m_oPermissionService.constructor);
	
	oMockPermissionService.expects(once()).addPermissionListener(ANYTHING, "TradeProtocol", ANYTHING, ANYTHING).will(returnValue(1));
	oMockPermissionService.expects(once()).addPermissionListener(ANYTHING, "TradeType", ANYTHING, ANYTHING).will(returnValue(2));
	oMockPermissionService.expects(once()).removeListener(1);
	oMockPermissionService.expects(once()).removeListener(2);

	caplin.security.permissioning.PermissionService = oMockPermissionService.proxy();

	new caplinx.permissioning.TradableListener("/FX/test", null, "ESP", "SPOT")._$cancelSubscription();
};

Test.SingleAndSetListenerRemovedWhenCanceled = function()
{
	var oMockPermissionService =  mock(this.m_oPermissionService.constructor);
	
	oMockPermissionService.expects(once()).addPermissionSetListener(ANYTHING, ANYTHING, ANYTHING, ANYTHING).will(returnValue(1));
	oMockPermissionService.expects(once()).addPermissionListener(ANYTHING, ANYTHING, ANYTHING, ANYTHING).will(returnValue(2));
	oMockPermissionService.expects(once()).removeListener(1);
	oMockPermissionService.expects(once()).removeListener(2);
	
	caplin.security.permissioning.PermissionService = oMockPermissionService.proxy();
	
	new caplinx.permissioning.TradableListener("/FX/test", null, "RFS")._$cancelSubscription();
};

// callback tests - ESP/SPOT
Test.UserPermissionedEventIsNotPropagatedUntilBothSinglePermissionsReturnTrue = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "ESP", "SPOT");
	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeType", "SPOT");
	
	oMockCallBack.expects(once()).onTilePermissionsChanged(true);	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeProtocol", "ESP");
};

Test.UserNotPermissionedEventIsPropagatedWhenBothSinglePermissionsReturnFalse = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "ESP", "SPOT");
	
	oTradableListener.onSinglePermissionChanged(false, "/FX/TEST", "TradeType", "SPOT");
	
	oMockCallBack.expects(once()).onTilePermissionsChanged(false);
	oTradableListener.onSinglePermissionChanged(false, "/FX/TEST", "TradeProtocol", "ESP");
};

Test.UserNotPermissionedEventPropagatedWhenOneSinglePermissionReturnsFalse = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "ESP", "SPOT");
	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeType", "SPOT");
	
	oMockCallBack.expects(once()).onTilePermissionsChanged(false);	
	oTradableListener.onPermissionsChanged(false, "/FX/TEST", "TradeProtocol", "ESP");
};

Test.UserNotPermissionedEventPropagatedWhenOneSinglePermissionReturnsFalse = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "RFS");
	
	oTradableListener.onPermissionsChanged(["SPOT"], "/FX/TEST", "TradeType");
	
	oMockCallBack.expects(once()).onTicketPermissionsChanged(true);	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeProtocol", "RFS");
};

// callback tests - RFS/[any trade type]
Test.UserPermissionedEventIsPropagatedWhenBothSetAndSinglePermissionsReturnTrue = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "RFS");
	
	oTradableListener.onPermissionsChanged(["SPOT"], "/FX/TEST", "TradeType");
	
	oMockCallBack.expects(once()).onTicketPermissionsChanged(true);	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeProtocol", "RFS");
};

Test.UserNotPermissionedEventIsPropagatedWhenNoTradeTypesArePermissioned = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "RFS");
	
	oTradableListener.onPermissionsChanged([], "/FX/TEST", "TradeType");
	
	oMockCallBack.expects(once()).onTicketPermissionsChanged(false);	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeProtocol", "RFS");
};

Test.UserNotPermissionedEventIsPropagatedWhenTradeTypesArePermissionedButProtocolIsnt = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "RFS");
	
	oTradableListener.onSinglePermissionChanged(false, "/FX/TEST", "TradeProtocol", "RFS");
	
	oMockCallBack.expects(once()).onTicketPermissionsChanged(false);	
	oTradableListener.onPermissionsChanged(["SPOT","SWAP"], "/FX/TEST", "TradeType");
};

// callback tests - only prop
Test.CallBacksAreOnlyCalledWhenTheResultOfAndingBothPermissionsChange = function()
{
	this._stubPermissionService();
	var oMockCallBack =  mock(caplinx.trading.presentation.tile.PermissionModel);
	var oTradableListener = new caplinx.permissioning.TradableListener("/FX/TEST", oMockCallBack.proxy(), "ESP", "SPOT");

	oTradableListener.onSinglePermissionChanged(false, "/FX/TEST", "TradeType", "SPOT");
	oMockCallBack.expects(once()).onTilePermissionsChanged(false);	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeProtocol", "ESP");

	//setting ESP to false does not change the result, so no callback should be received	
	oTradableListener.onSinglePermissionChanged(false, "/FX/TEST", "TradeProtocol", "ESP");
	
	//setting it back to true still doesnt have an effect
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeProtocol", "ESP");
	
	oMockCallBack.expects(once()).onTilePermissionsChanged(true);	
	oTradableListener.onSinglePermissionChanged(true, "/FX/TEST", "TradeType", "SPOT");
};

Test.initialize();
