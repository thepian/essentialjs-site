Test = CaplinTestCase("CaplinPermissionServiceTest");

Test.setUp = function()
{
	this.protectApis("caplinx.permissioning.CaplinPermissionService");
	
	oMockPermissionService = function(){};
	oMockPermissionService.prototype.canUserPerformAction = function(){};
	
	this.m_oMockPermissionService = mock(oMockPermissionService);
	caplinx.permissioning.CaplinPermissionService.m_oPermissionService = this.m_oMockPermissionService.proxy();
};

Test.simplefilterOutNonViewPermissionedCurrencyPairsTest = function()
{
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/EU", null , "VIEW").will(returnValue(true));
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/UG", null , "VIEW").will(returnValue(true));
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/JC", null , "VIEW").will(returnValue(false));
	
	var pPermittedCurrencies = caplinx.permissioning.CaplinPermissionService.filterOutNonViewPermissionedCurrencyPairs(["EU", "UG", "JC"]);
	assertArrayEquals(["EU", "UG"], pPermittedCurrencies);
};

Test.simplefilterOutNonViewPermissionedBaseCurrenciesTest = function()
{
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/EUGB", null , "VIEW").will(returnValue(false));
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/EUUS", null , "VIEW").will(returnValue(false));
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/EGGB", null , "VIEW").will(returnValue(true));
	this.m_oMockPermissionService.expects(once()).canUserPerformAction("/FX/EKGB", null , "VIEW").will(returnValue(true));
	
	var pPermittedCurrencies = caplinx.permissioning.CaplinPermissionService.filterOutNonViewPermissionedBaseCurrencies(["EU", "EG", "EK"], 
			["GB", "US"]);
	assertArrayEquals(["EG", "EK"], pPermittedCurrencies);
};

Test.initialize();
