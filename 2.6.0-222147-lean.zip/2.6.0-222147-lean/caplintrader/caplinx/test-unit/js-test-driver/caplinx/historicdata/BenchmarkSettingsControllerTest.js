Test = CaplinTestCase("BenchmarkSettingsControllerTest");

Test.setUp = function()
{
	this.m_fOldConst = null;
	this.m_pInstances = [];
	this.m_nFinalizeCount = 0;
	
	this._mockOpenAjaxChannelSubscriptionHelper = function()
	{
		this.m_fOldConst = caplin.component.comms.OpenAjaxChannelSubscriptionHelper;
		var oThis = this;
		caplin.component.comms.OpenAjaxChannelSubscriptionHelper = function()
		{
			this.arguments = arguments;
			oThis.m_pInstances.push( this );
			
			this.finalize = function()
			{
				oThis.m_nFinalizeCount++;
			};
		};
		
	};
	
	this._restoreOpenAjaxChannelSubscriptionHelper = function()
	{
		if(this.m_fOldConst !== null)
		{
			caplin.component.comms.OpenAjaxChannelSubscriptionHelper = this.m_fOldConst;
			this.m_fOldConst = null;
		}
	};
	
	this.m_pInstances = [];
	this.m_nFinalizeCount = 0;
	this._restoreOpenAjaxChannelSubscriptionHelper();
};

Test.tearDown = function()
{
	this._restoreOpenAjaxChannelSubscriptionHelper();
};

Test.channelsAreSetUpAsConstructed = function()
{
	this._mockOpenAjaxChannelSubscriptionHelper();
	
	var oComponent = mock( caplin.component.form.SimpleFormComponent );
	var oComponentMock = oComponent.proxy();
	oComponent.expects(once()).addListener(NOT_NULL);
	oComponent.stubs().formComponentsHaveBeenParsed().will( returnValue(false));
	
	var oController = new caplinx.historicdata.BenchmarkSettingsController(oComponentMock);
	assertEquals("Three helpers should have been created", 4, this.m_pInstances.length);
	assertEquals("selected", "subjectSelected", this.m_pInstances[0].arguments[2]);
	assertEquals("selected", "subjectAdded", this.m_pInstances[2].arguments[2]);
	assertEquals("selected", "subjectRemoved", this.m_pInstances[3].arguments[2]);
	
	this._restoreOpenAjaxChannelSubscriptionHelper();
};

Test.constructionComponentSetupAndFinalizeLifeCycle = function()
{
	this._mockOpenAjaxChannelSubscriptionHelper();
	
	var oComponent = mock( caplin.component.form.SimpleFormComponent );
	var oComponentMock = oComponent.proxy();
	oComponent.expects(once()).addListener(NOT_NULL);
	oComponent.stubs().formComponentsHaveBeenParsed().will( returnValue(true));
	
	var mControls = {};
	
	// Buttons
	var oButton = mock( caplin.dom.controls.form.FlexibleButton );
	oButton.expects(exactly(4)).addOnClickListener( NOT_NULL );
	oButton.stubs().setEnabled( NOT_NULL );
	
	var oButtonMock = oButton.proxy();
	mControls.Add = oButtonMock;
	mControls.Hide = oButtonMock;
	mControls.Update = oButtonMock;
	mControls.Remove = oButtonMock;
	
	// Date Picker
	var oDatePicker = mock( Ext.form.DateField );
	oDatePicker.stubs().on(NOT_NULL, NOT_NULL, NOT_NULL);
	oDatePicker.stubs().disable();
	oDatePicker.stubs().setMaxValue(NOT_NULL);
	oDatePicker.stubs().getValue();
	
	var oDatePickerMock = oDatePicker.proxy();
	mControls.DatePicker = oDatePickerMock;
	
	// Combobox
	var oComboBox = mock( Ext.form.ComboBox );
	oComboBox.stubs().on(NOT_NULL, NOT_NULL, NOT_NULL);
	oComboBox.stubs().disable();
	oComboBox.stubs().getValue();
	
	var oComboBoxMock = oComboBox.proxy();
	
	mControls.ComboBox = oComboBoxMock;
	
	// finalize
	oComponent.expects(once()).getFormComponents().will( returnValue( mControls ) );
	oButton.expects(exactly(4)).removeOnClickListener( NOT_NULL );
	
	var oController = new caplinx.historicdata.BenchmarkSettingsController(oComponentMock);	
	oController.finalize();
		
	assertEquals("OpenAjaxChannelSubscriptionHelper objects should have been finalized", 4, this.m_nFinalizeCount);
		
	this._restoreOpenAjaxChannelSubscriptionHelper();
};

Test.initialize();
