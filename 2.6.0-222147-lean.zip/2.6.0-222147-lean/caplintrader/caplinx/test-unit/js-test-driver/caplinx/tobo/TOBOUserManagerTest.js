Test = CaplinTestCase("TOBOUserManagerTest");

Test.setUp = function()
{
	this.protectApis("caplin.trading.trademodel", "caplin.trading.trademodel.TradeOnBehalfOf",
		"caplin.widget.message.MessageManager", "caplinx.tobo.TOBOUserManager");
	
	this.m_bCalledSetTradeOnBehalfOfPermissionable = false;
	this.m_bCalledClearTradeOnBehalfOfPermissionable = false;
	
	var oThis = this;
	caplin.trading.trademodel.TradeOnBehalfOf = function() {};
	caplin.trading.trademodel.TradeOnBehalfOf.addListener = function() {};
	caplin.trading.trademodel.TradeOnBehalfOf.setTradeOnBehalfOfPermissionable = function() {
		oThis.m_bCalledSetTradeOnBehalfOfPermissionable = true;
	};
	caplin.trading.trademodel.TradeOnBehalfOf.clearTradeOnBehalfOfPermissionable = function() {
		oThis.m_bCalledClearTradeOnBehalfOfPermissionable = true;
	};
	
	caplin.widget.message.MessageManager.prototype.alert = function() {	};
	
	this.m_oToboUserManager = caplinx.tobo.TOBOUserManager;
};

Test.tearDown = function()
{
	this.m_bCalledSetTradeOnBehalfOfPermissionable = false;
	this.m_bCalledClearTradeOnBehalfOfPermissionable = false;
	
	this.m_oToboUserManager.m_mValues["Locked"] = false;
	this.m_oToboUserManager.m_nActiveTradeCount = 0;
	this.m_oToboUserManager.m_mValues = {};
};

Test.onTOBOUserChangedToAUserSetsTOBOPermissionable = function()
{
	this.m_oToboUserManager.changeUser("Anna");
	
	assertTrue(this.m_bCalledSetTradeOnBehalfOfPermissionable);
	assertFalse(this.m_bCalledClearTradeOnBehalfOfPermissionable);
};

Test.onTOBOUserChangedToBaseRatesClearsTOBOPermissionable = function()
{
	this.m_oToboUserManager.changeUser(caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT);
	
	assertTrue(this.m_bCalledClearTradeOnBehalfOfPermissionable);
	assertFalse(this.m_bCalledSetTradeOnBehalfOfPermissionable);
};

Test.tradeStartedIncrementsActiveTradeCount = function()
{
	this.m_oToboUserManager.m_nActiveTradeCount = 0;
	
	this.m_oToboUserManager.tradeStarted();
	
	assertEquals(1, this.m_oToboUserManager.m_nActiveTradeCount);
};

Test.tradeStartedSetsLockedAttributeTrue = function()
{
	this.m_oToboUserManager.m_mValues["Locked"] = false;
	
	this.m_oToboUserManager.tradeStarted();
	
	assertEquals(true, this.m_oToboUserManager.m_mValues["Locked"]);
};

Test.tradeFinishedDecrementsActiveTradeCount = function()
{
	this.m_oToboUserManager.m_nActiveTradeCount = 5;
	
	this.m_oToboUserManager.tradeFinished();
	
	assertEquals(4, this.m_oToboUserManager.m_nActiveTradeCount);
};

Test.tradeFinishedCannotDecrementActiveTradeCountBelowZero = function()
{
	this.m_oToboUserManager.m_nActiveTradeCount = 1;
	
	this.m_oToboUserManager.tradeFinished();
	
	assertEquals(0, this.m_oToboUserManager.m_nActiveTradeCount);
	
	assertFails("Unexpected success involving decrementing counter below zero.", function() {this.m_oToboUserManager.tradeFinished()});
	
	assertEquals(0, this.m_oToboUserManager.m_nActiveTradeCount);
};

Test.tradeFinishedAtCountOneSetsLockedAttributeFalse = function()
{
	this.m_oToboUserManager.m_nActiveTradeCount = 1;
	
	this.m_oToboUserManager.m_mValues["Locked"] = true;
	
	this.m_oToboUserManager.tradeFinished();
	
	assertEquals(false, this.m_oToboUserManager.m_mValues["Locked"]);
};

Test.tradeFinishedAtCountAboveOneSetsLockedAttributeFalse = function()
{
	this.m_oToboUserManager.m_nActiveTradeCount = 2;
	
	this.m_oToboUserManager.m_mValues["Locked"] = true;
	
	this.m_oToboUserManager.tradeFinished();
	
	assertEquals(true, this.m_oToboUserManager.m_mValues["Locked"]);
};

Test.updateUpdatesValueWhenItDoesntAlreadyMatch = function()
{
	this.m_oToboUserManager.m_mValues["User"] = "Bob";
	
	this.m_oToboUserManager.update("User", "Anna");
	
	assertEquals("User should have changed to Anna when update called.", "Anna", this.m_oToboUserManager.m_mValues["User"]);
};

Test.updateDoesntNotifyObserversWhenItAlreadyMatches = function()
{
	this.m_oToboUserManager.m_mValues["User"] = "Anna";
	
	this.m_oToboUserManager.update("User", "Anna");
	
	assertEquals("User should not be changed when it already matches.", "Anna", this.m_oToboUserManager.m_mValues["User"]);
};

Test.canPerformTradeWhenNotPermissionedToTradeOnBehalfOf = function()
{
	this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf = false;
	
	var canPerformTrade = this.m_oToboUserManager.canPerformTrade();
	
	assertTrue("canPerformTrade should be true when not a TOBO user.", canPerformTrade);
};

Test.canPerformTradeWhenPermissionedToTradeOnBehalfOfAndValidUserSelected = function()
{
	this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf = true;
	this.m_oToboUserManager.m_mValues["User"] = "Anna";
	var canPerformTrade = this.m_oToboUserManager.canPerformTrade();
	assertTrue("canPerformTrade should be true when a TOBO user tries to trade on a valid user.", canPerformTrade);
};

Test.cantPerformTradeWhenPermissionedToTradeOnBehalfOfAndBlankUserSelected = function()
{
	this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf = true;
	this.m_oToboUserManager.m_mValues["User"] = "";
	var canPerformTrade = this.m_oToboUserManager.canPerformTrade();
	assertFalse("canPerformTrade should be false when a TOBO user tries to trade on a blank user.", canPerformTrade);
	
	this.m_oToboUserManager.m_mValues["User"] = undefined;
	var canPerformTrade = this.m_oToboUserManager.canPerformTrade();
	assertFalse("canPerformTrade should be false when a TOBO user tries to trade on an undefined user.", canPerformTrade);
	
	this.m_oToboUserManager.m_mValues["User"] = null;
	var canPerformTrade = this.m_oToboUserManager.canPerformTrade();
	assertFalse("canPerformTrade should be false when a TOBO user tries to trade on a null user.", canPerformTrade);
};

Test.cantPerformTradeWhenPermissionedToTradeOnBehalfOfAndBaseRatesSelected = function()
{
	this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf = true;
	this.m_oToboUserManager.m_mValues["User"] = caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT;
	var canPerformTrade = this.m_oToboUserManager.canPerformTrade();
	assertFalse("canPerformTrade should be false when a TOBO user tries to trade on the < Base rates > user.", canPerformTrade);
};

Test.updateUserTypeSetsUserType = function()
{
	this.m_oToboUserManager.m_mValues["UserType"] = "SALES";
	this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf = false;
	
	this.m_oToboUserManager._updateUserType(["TOBO"]);
	
	assertEquals("UserType should be changed to TOBO when _updateUserType called.", "TOBO", this.m_oToboUserManager.m_mValues["UserType"]);
	assertTrue("isAllowedToTradeOnBehalfOf should have been set to true", this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf);
};

Test.updateUserTypeSetsUserTypeAndAddsListenerIfNewTypeIsTRADER = function()
{
	var bCalled = false;
	
	caplinx.permissioning.CaplinPermissionService.addAccountsListener = function(sInstrument, oListener)
	{
		bCalled = true;
	};
	
	this.m_oToboUserManager.m_mValues["UserType"] = "SALES";
	this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf = true;
	
	this.m_oToboUserManager._updateUserType(["TRADER"]);
	
	assertEquals("UserType should be changed to TRADER when _updateUserType called.", "TRADER", this.m_oToboUserManager.m_mValues["UserType"]);
	assertTrue("caplinx.permission.CaplinPermissionService.addAccountsListener() should be called when _updateUserType is called with TRADER.", bCalled);
	assertFalse("isAllowedToTradeOnBehalfOf should have been set to false", this.m_oToboUserManager.m_bIsAllowedToTradeOnBehalfOf);
};
//
//Test.setPermissionListenerForUserAccountsWithBlankUserClearsListeners = function()
//{
//	var bRemoveCalled = false;
//	var bAddCalled = false;
//	
//	this.m_oToboUserManager.m_oPermissionListener.removeListener = function()
//	{
//		bRemoveCalled = true;
//	};
//	this.m_oToboUserManager.m_oPermissionListener.addListener = function()
//	{
//		bAddCalled = true;
//	};
//	
//	this.m_oToboUserManager.m_sUserAccountPermission = "ACCOUNT-TOBO:BOB";
//	
//	
//	this.m_oToboUserManager._setPermissionListenerForUserAccounts("");
//	
//	
//};

Test.initialize();
