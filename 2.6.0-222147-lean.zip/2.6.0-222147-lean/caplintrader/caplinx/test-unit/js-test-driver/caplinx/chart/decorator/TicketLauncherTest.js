Test = CaplinTestCase("TicketLauncherTest");

Test.setUp = function()
{
	this.protectApis("caplin.framework", "caplin.framework.ApplicationFactory");
	
	caplin.framework.ApplicationFactory = function(){};
	caplin.framework.ApplicationFactory.getInstance = function() {return caplin.framework.ApplicationFactory;};
	
	this.m_oMockChartView = mock(caplin.chart.ChartView);
	this.m_oTicketLauncher = new caplinx.chart.decorator.TicketLauncher({});
};

Test.setChartViewWorks = function()
{
	this.m_oMockChartView.expects(once()).addChartViewListener(NOT_NULL);
	var oChartView = this.m_oMockChartView.proxy();
	this.m_oTicketLauncher.setChartView(oChartView);
};

Test.onPointDoubleClickedWorks = function()
{
	var bLaunchFxTradeTicketCalled = false;
	var fOld = caplin.framework.ApplicationFactory.launchFxTradeTicket;
	caplin.framework.ApplicationFactory.launchFxTradeTicket = function(sSubject, sSide, sPrototcol)
	{
		bLaunchFxTradeTicketCalled = true;
		assertEquals("/FI/BNK", sSubject);
		assertEquals("Bid", sSide);
		assertEquals("RFS", sPrototcol);
	};
	// sId, sTitle, sSeriesType, sDataFormat, oSeriesData, oSeriesConfig, oMetaData
	var oChartSeries = new caplin.chart.ChartSeries("/FI/BNK", "/FI/BNK", "Big Bank", "LineSeries", "base", [[0,1.221]], {"config":"config"});
	this.m_oTicketLauncher.onPointDoubleClicked(oChartSeries);
	assertTrue(bLaunchFxTradeTicketCalled);
	
	caplin.framework.ApplicationFactory.launchFxTradeTicket = fOld;
};

Test.initialize();
