Test = CaplinTestCase("BenchmarkChartDataProviderTest");

Test.setUp = function()
{
	this.m_oConfig = {
		instrumentSubjectMatcher: "/FI/",
		subjectMappers: {
			subjectMapper: {
				className: "caplin.chart.util.WebServiceBenchmarkProvider",
				config: {
					url: "source/services/static-data/relatedBenchmarks.jsp"	
				}
			}	
		},
		internalDataProviders: {
			rttpDataProvider: {
				fields: {
					field : [{
						id: "description",
						fieldName: "Description"
					},
					{
						id: "xAxisField",
						fieldName: "MaturityDate"
					},
					{
						id: "yAxisField",
						fieldName: "BidYield"
					}]
				}
			},
			webServiceDataProvider: {
				url: "test.jsp"
			}
		}	
	};

	this.m_oBenchmarkDataProvider =  null;
	this.m_oMockWebServiceDataProvider = null;
	this.m_oMockRttpDataProvider = null;

	this.m_oMockSubjectMapper = function(){};
	this.m_oMockSubjectMapper.mapSubject = function(sSubject, fCallback) {
		fCallback("mappedSubject");
	};

	this.m_sSubject = "/FI/Test";
	this.m_oRequest = null;

	this.m_mBenchmarkToSubjectsMap = {
		bench1 : {
			subject1 : true,
			subject2 : true
		},
		bench2 : {
			subject3 : true,
			subject4 : true
		}
	};
	
	// Create out mock objects
	this.m_oBenchmarkDataProvider = new caplinx.chart.BenchmarkChartDataProvider(this.m_oConfig);
	this.m_oMockWebServiceDataProvider = mock(caplin.chart.WebServiceChartDataProvider);
	this.m_oMockRttpDataProvider	= mock(caplin.chart.RttpChartDataProvider);
	
	// Set the webservice data provider and rttp provider to be our mocks
	this.m_oMockWebServiceDataProvider.expects(once()).addChartDataProviderListener(ANYTHING);
	this.m_oMockRttpDataProvider.expects(once()).addChartDataProviderListener(ANYTHING);

	this.m_oBenchmarkDataProvider.$_setWebServiceDataProvider(this.m_oMockWebServiceDataProvider.proxy());
	this.m_oBenchmarkDataProvider.$_setRttpDataProvider(this.m_oMockRttpDataProvider.proxy());
	
	// Add a mock chart model
	this.m_oMockChartModel = mock(caplin.chart.ChartModel);
	this.m_oBenchmarkDataProvider.addChartDataProviderListener(this.m_oMockChartModel.proxy());
	
	// Set subject mapper to our mock subject mapper
	this.m_oBenchmarkDataProvider.$_setSubjectMapper(this.m_oMockSubjectMapper);
	
	// Set the benchmark to related subjects map
	this.m_oBenchmarkDataProvider.$_setBenchmarkToRelatedSubjectsMap(this.m_mBenchmarkToSubjectsMap);
	
	var oQuery = new caplin.component.filter.QueryFilterExpression();
	this.m_oRequest = new caplin.chart.ChartSeriesRequest(this.m_sSubject, oQuery);
};

Test.tearDown = function()
{
	
};

Test.dataProvidersAreCreatedCorrectly = function()
{
	var oBenchmarkDataProvider = new caplinx.chart.BenchmarkChartDataProvider(this.m_oConfig);
	
	var oWebServiceDataProvider = oBenchmarkDataProvider.$_getWebServiceDataProvider();
	var oRttpDataProvider = oBenchmarkDataProvider.$_getRttpDataProvider();
	
	assertTrue("oWebServiceDataProvider should be an instance of caplin.chart.WebServiceChartDataProvider"
		,oWebServiceDataProvider instanceof caplin.chart.WebServiceChartDataProvider);
		
	assertTrue("oRttpDataProvider should be an instance of caplin.chart.RttpChartDataProvider"
		,oRttpDataProvider instanceof caplin.chart.RttpChartDataProvider);
};

Test.seriesRequestIsSentToBothDataProviders = function()
{
	// Both data providers should receive a request
	this.m_oMockWebServiceDataProvider.expects(once()).requestSeries(NOT_NULL);
	this.m_oMockRttpDataProvider.expects(once()).requestSeries(NOT_NULL);
	
	// Request the series
	this.m_oBenchmarkDataProvider.requestSeries(this.m_oRequest);
};

Test.seriesRequestSentToWebServiceHasTheCorrectIdAndMappedSubject = function()
{
	// Create a mock webservice data provider so we can validate the request object
	// we receive
	var oMockWebServiceDataProvider = function(){};
	oMockWebServiceDataProvider.addChartDataProviderListener = function(){};
	oMockWebServiceDataProvider.requestSeries = function(oRequest) {
		assertEquals("The data provider id should be set to 'webservice'", "webservice", oRequest.getDataProviderId());
		assertEquals("The subject should be set to 'mappedSubject'", "mappedSubject", oRequest.getSubject());
	};
	this.m_oBenchmarkDataProvider.$_setWebServiceDataProvider(oMockWebServiceDataProvider);
	
	// The rttp data provider also expects this request
	this.m_oMockRttpDataProvider.expects(once()).requestSeries(NOT_NULL);
	
	// Request the series
	this.m_oBenchmarkDataProvider.requestSeries(this.m_oRequest);
};

Test.seriesRequestSentToRttpDataProviderHasTheCorrectIdAndMappedSubject = function()
{
	// Create a mock rttp data provider so we can validate the request object
	// we receive
	var oMockRttpDataProvider = function(){};
	oMockRttpDataProvider.addChartDataProviderListener = function(){};
	oMockRttpDataProvider.requestSeries = function(oRequest) {
		assertEquals("The data provider id should be set to 'rttp'", "rttp", oRequest.getDataProviderId());
		assertEquals("The subject should be set to '/FI/Test'", "/FI/Test", oRequest.getSubject());
	};
	this.m_oBenchmarkDataProvider.$_setRttpDataProvider(oMockRttpDataProvider);
	
	// The web service data provider also expects this request
	this.m_oMockWebServiceDataProvider.expects(once()).requestSeries(NOT_NULL);
	
	// Request the series
	this.m_oBenchmarkDataProvider.requestSeries(this.m_oRequest);
};

Test.seriesRequestWithWebServiceDataProviderIdIsOnlySentToWebServiceAndSubjectIsNotMapped = function()
{	
	// Set the data provider id so this request only gets sent to the webservice
	this.m_oRequest.setDataProviderId("webservice");
	
	var bCallback = false;
	
	// Create a mock webservice data provider so we can validate the request object
	// we receive
	var oMockWebServiceDataProvider = function(){};
	oMockWebServiceDataProvider.addChartDataProviderListener = function(){};
	oMockWebServiceDataProvider.requestSeries = function(oRequest) {
		assertEquals("The data provider id should be set to 'webservice'", "webservice", oRequest.getDataProviderId());
		assertEquals("The subject should be set to '/FI/Test'", "/FI/Test", oRequest.getSubject());
		bCallback = true;
	};
	this.m_oBenchmarkDataProvider.$_setWebServiceDataProvider(oMockWebServiceDataProvider);
	
	// The rttp data provider should not receive this request
	this.m_oMockRttpDataProvider.expects(never()).requestSeries(NOT_NULL);
	
	// Request the series
	this.m_oBenchmarkDataProvider.requestSeries(this.m_oRequest);
	
	assertTrue("The web service data provider should have had requestSeries called", bCallback);
};

Test.seriesRequestWithRttpDataProviderIdIsOnlySentToRttpDataProvider = function()
{	
	// Set the data provider id so this request only gets sent to the webservice
	this.m_oRequest.setDataProviderId("rttp");
	
	// The rttp data provider expects this request
	this.m_oMockRttpDataProvider.expects(once()).requestSeries(NOT_NULL);
	// The web service provider should not receive this request
	this.m_oMockWebServiceDataProvider.expects(never()).requestSeries(NOT_NULL);
	
	// Request the series
	this.m_oBenchmarkDataProvider.requestSeries(this.m_oRequest);
};

Test.setBenchmarkToRelatedSubjectsMapSetsSubjectToBenchmarkMapCorrectly = function()
{	
	// Get the subject to benchmark map that would have been created by calling
	// $_setBenchmarkToRelatedSubjectsMap in setup
	var mBenchmarkMap = this.m_oBenchmarkDataProvider.$_getSubjectToBenchmarkMap();
	
	assertEquals("subject1 should be associated with bench1", "bench1", mBenchmarkMap["subject1"]);
	assertEquals("subject2 should be associated with bench1", "bench1", mBenchmarkMap["subject2"]);
	assertEquals("subject3 should be associated with bench2", "bench2", mBenchmarkMap["subject3"]);
	assertEquals("subject4 should be associated with bench2", "bench2", mBenchmarkMap["subject4"]);
};

Test.seriesReceivedNotifiesDataProviderListenersWhenBenchmarkReceived = function()
{	
	var oBenchmark1 = this._createSeries("bench1");
	var oBenchmark2 = this._createSeries("bench2");

	// The chart model should be notified as soon as a benchmark series is received
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark1]);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark1]);
	
	// The chart model should be notified as soon as a benchmark series is received
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark2]);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark2]);
};

Test.multipleSeriesReceivedNotifiesDataProviderListenersThatBenchmarksAreReceived = function()
{	
	var oBenchmark1 = this._createSeries("bench1");
	var oBenchmark2 = this._createSeries("bench2");
	
	// The chart model should be notified of both series being received
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark1]);
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark2]);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark1, oBenchmark2]);
};

Test.pointsReceivedBeforeBenchmarksAreQueuedUpAndTheModelIsNotifiedWhenTheBenchmarkIsReceived = function()
{	
	var oBenchmark1 = this._createSeries("bench1");
	var oSubject1 = this._createSeries("subject1");
	var oSubject2 = this._createSeries("subject2");
		
	// The chart model should not be notified of these series until their related benchmark has been retrieved
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oSubject1]);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oSubject2]);
	
	// Retrieve the benchmark. The chart model should be informed about the benchmark and
	// all related points
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark1]);
	this.m_oMockChartModel.expects(once()).onRelatedSeriesAdded(oSubject1);
	this.m_oMockChartModel.expects(once()).onRelatedSeriesAdded(oSubject2);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark1]);
	
	// Ensure this all works a second time
	var oBenchmark2 = this._createSeries("bench2");
	var oSubject3 = this._createSeries("subject3");
	
	// The chart model should not be informed here
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oSubject3]);
	
	// The chart model should be informed of the benchmark and related point here
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark2]);
	this.m_oMockChartModel.expects(once()).onRelatedSeriesAdded(oSubject3);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark2]);
};

Test.theCorrectDataProvidersAreNotifiedOfSeriesRemovals = function()
{	
	var oBenchmark1 = this._createSeries("bench1", "webservice");
	var oSubject1 = this._createSeries("subject1", "rttp");
	var oSubject2 = this._createSeries("subject2", "rttp");
		
	// Populate the data provider with series objects
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark1]);
	this.m_oMockChartModel.expects(once()).onRelatedSeriesAdded(oSubject1);
	this.m_oMockChartModel.expects(once()).onRelatedSeriesAdded(oSubject2);
	
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark1]);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oSubject1]);
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oSubject2]);
	
	// Remove subject1 and subjec2. The rttp data provider should be informed
	this.m_oMockRttpDataProvider.expects(once()).removeSeries(oSubject1);
	this.m_oMockRttpDataProvider.expects(once()).removeSeries(oSubject2);
	this.m_oBenchmarkDataProvider.removeSeries(oSubject1);
	this.m_oBenchmarkDataProvider.removeSeries(oSubject2);
	
	// Remove benchmark 1. The webservice data provider should be informed.
	this.m_oMockWebServiceDataProvider.expects(once()).removeSeries(oBenchmark1);
	this.m_oBenchmarkDataProvider.removeSeries(oBenchmark1);
};

Test.thatAllDataProvidersAreNotifiedWhenASeriesIsRemovedThatDoesNotHaveADataProviderId = function()
{		
	// Create a series but do not give it a data provider id
	var oBenchmark1 = this._createSeries("bench1");
	this.m_oMockChartModel.expects(once()).onSeriesDataReceived([oBenchmark1]);	
	this.m_oBenchmarkDataProvider.onSeriesDataReceived([oBenchmark1]);
	
	// Both data providers should be informed if this series is removed
	this.m_oMockWebServiceDataProvider.expects(once()).removeSeries(oBenchmark1);
	this.m_oMockRttpDataProvider.expects(once()).removeSeries(oBenchmark1);
	this.m_oBenchmarkDataProvider.removeSeries(oBenchmark1);
};

Test._createSeries = function(sSubject, sDataProviderId)
{
	var oQuery = new caplin.component.filter.QueryFilterExpression();
	var oRequest = new caplin.chart.ChartSeriesRequest(sSubject, oQuery);
	
	if (sDataProviderId) {
		oRequest.setDataProviderId(sDataProviderId);		
	}
		
	var oBenchmark = new caplin.chart.ChartSeries(sSubject, sSubject, sSubject, null, null, null, null, null, oRequest);
	oBenchmark.addSeriesListener(this.m_oMockChartModel.proxy());
	return oBenchmark;
};

Test.initialize();
