Test = CaplinTestCase("EventDistributionDecoratorTest");

Test.setUp = function()
{
	this.m_fOldOpenAjaxHub = null;
	this.m_oOpenAjaxHub;
	this.m_oOpenAjaxHubProxy;

	this.m_oOldComms = null;
	this.m_oMockComms = null;
	this.m_oMockCommsProxy = null;

	this.m_oDecorator = null;
	this.m_oChartView = null;
	this.m_oChartViewProxy = null;
	
	this.m_oSeries = null;
	this.m_sSubject = "/FI/BANK";
	this.m_sSeriesId = "seriesId1";
	this.m_pRelatedSubjects = [this.m_sSeriesId];
	this.m_sTitle = "US Treasuries";
	this.m_pSeriesData = [];
	this.m_oMetaData = {};
	this.m_bIsRelatedSeries = false;
	
	this._restoreOpenAjax();
	this._restoreComms();
	
	this._mockOpenAjax();
	this._mockComms();
	
	var oSeriesMock = mock(caplin.chart.ChartSeries);
	oSeriesMock.stubs().getId().will(returnValue(this.m_sSeriesId));
	oSeriesMock.stubs().getSubject().will(returnValue(this.m_sSubject));
	oSeriesMock.stubs().getTitle().will(returnValue(this.m_sTitle));
	oSeriesMock.stubs().getSeriesData().will(returnValue(this.m_pSeriesData));
	oSeriesMock.stubs().getMetaData().will(returnValue(this.m_oMetaData));
	oSeriesMock.stubs().hasRelatedSeries().will(returnValue(this.m_bIsRelatedSeries));
	this.m_oSeries = oSeriesMock.proxy();
};

Test.tearDown = function()
{
	this._restoreOpenAjax();
	
	this._restoreComms();
	
	this.m_oChartView = null;
	this.m_oDecorator = null;
};

Test._mockOpenAjax = function()
{
	this.m_oOpenAjaxHub = Mock4JS.mockObject( OpenAjax.hub );
	this.m_oOpenAjaxHubProxy = this.m_oOpenAjaxHub.proxy();
	
	this.m_fOldOpenAjaxHub = OpenAjax.hub;
	OpenAjax.hub = this.m_oOpenAjaxHubProxy;
};

Test._restoreOpenAjax = function()
{	
	if (this.m_fOldOpenAjaxHub != null) 
	{
		OpenAjax.hub = this.m_fOldOpenAjaxHub;
		this.m_fOldOpenAjaxHub = null;
		this.m_oMockComms = null;
		this.m_oMockCommsProxy = null;
	}
};

Test._mockComms = function()
{
	this.m_oOldComms = caplin.component.comms.InterComponentComms;
	this.m_oMockComms = Mock4JS.mockObject( caplin.component.comms.InterComponentComms );
	caplin.component.comms.InterComponentComms = this.m_oMockComms.proxy();
	this.m_oMockCommsProxy = caplin.component.comms.InterComponentComms;
};

Test._restoreComms = function()
{
	if( this.m_oOldComms != null )
	{
		caplin.component.comms.InterComponentComms = this.m_oOldComms;
	}
};

Test._setupDecorator = function()
{
	// asset chart view is set and registers as a listener
	this.m_oDecorator = new caplinx.chart.decorator.EventDistributionDecorator({});
	this.m_oChartView = mock( caplin.chart.ChartView );
	this.m_oChartModel = mock(caplin.chart.ChartModel);
	this.m_oChartModel.expects( once() ).addChartModelListener( this.m_oDecorator );
	
	this.m_oChartViewProxy = this.m_oChartView.proxy();
	
	this.m_oChartView.expects( once() ).addChartViewListener( this.m_oDecorator );
	this.m_oChartView.expects(once()).getChartModel().will(returnValue(this.m_oChartModel.proxy()));
	
	this.m_oDecorator.setChartView(this.m_oChartViewProxy);
}

Test.constructorTest = function()
{
	var oDecorator = new caplinx.chart.decorator.EventDistributionDecorator({});
};

Test.setChartView = function()
{	
	this._setupDecorator();
};

/*Test.setChartModel = function()
{
	// asset that the model is set?	
};*/

Test.onPointDoubleClicked = function()
{
	this._setupDecorator();
	
	// Assert the channel is requested
	var sChannelId = "1000";
	var sNamespace = "chart." + sChannelId + ".pointDoubleClicked";
	
	var oEventObj = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries(this.m_oSeries);
	
	this.m_oMockComms.expects( once() ).getComponentChannel( this.m_oChartViewProxy ).will( returnValue( sChannelId ) );
	
	// Assert the event is published
	this.m_oOpenAjaxHub.expects( once() ).publish( sNamespace, oEventObj );
	this.m_oOpenAjaxHub.expects( once() ).publish( "chart." + sChannelId + ".subjectSelected", oEventObj );
	this.m_oDecorator.onPointDoubleClicked( this.m_oSeries );
};

Test.onSeriesAddedToView = function()
{
	this._setupDecorator();
	
	// Assert the channel is requested
	var sChannelId = "1000";
	var sNamespace = "chart." + sChannelId + ".subjectAdded";
	var oEventObj = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries(this.m_oSeries);
	
	this.m_oMockComms.expects( once() ).getComponentChannel( this.m_oChartViewProxy ).will( returnValue( sChannelId ) );
	
	// Assert the event is published
	this.m_oOpenAjaxHub.expects( once() ).publish( sNamespace, oEventObj );
	this.m_oDecorator.onSeriesAdded( this.m_oSeries );	
};

Test.onSeriesRemovedFromView = function()
{
	this._setupDecorator();
	
	// Assert the channel is requested
	var sChannelId = "1000";
	var sNamespace = "chart." + sChannelId + ".subjectRemoved";
	var oEventObj = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries(this.m_oSeries);
	oEventObj.additionalSeriesWillBeRemoved = false;
	
	this.m_oMockComms.expects( once() ).getComponentChannel( this.m_oChartViewProxy ).will( returnValue( sChannelId ) );
	
	// Assert the event is published
	this.m_oOpenAjaxHub.expects( once() ).publish( sNamespace, oEventObj );
	this.m_oDecorator.onSeriesRemoved( this.m_oSeries, false );	
};

Test.onChartViewClose = function()
{
	this._setupDecorator();
	
	// Assert the channel is requested
	var sChannelId = "1000";
	var sNamespace = "chart." + sChannelId + ".closed";
	
	this.m_oMockComms.expects( once() ).getComponentChannel( this.m_oChartViewProxy ).will( returnValue( sChannelId ) );
	
	// Assert the event is published
	this.m_oOpenAjaxHub.expects( once() ).publish( sNamespace );
	this.m_oDecorator.onChartViewClose();	
};

Test.onSeriesUpdatedInView = function(oSeries)
{
	this._setupDecorator();
	
	// Assert the channel is requested
	var sChannelId = "1000";
	var sNamespace = "chart." + sChannelId + ".subjectUpdated";
	var oEventObj = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries(this.m_oSeries);
	
	this.m_oMockComms.expects( once() ).getComponentChannel( this.m_oChartViewProxy ).will( returnValue( sChannelId ) );
	
	// Assert the event is published
	this.m_oOpenAjaxHub.expects( once() ).publish( sNamespace, oEventObj );
	this.m_oDecorator.onSeriesUpdated( this.m_oSeries );		
};

Test.initialize();
