Test = CaplinTestCase("BrowserValidatorTest");

Test.setUp = function()
{
	this.m_oCases = {
	   "cases":{
	      "default_message_id":"defaultNotAllowedMessage",
	      "browser":[
	         {
	            "max_version":"3.5",
	            "min_version":"3",
	            "allow":"yes",
	            "name":"Firefox"
	         },
	         {
	            "max_version":"8",
	            "min_version":"6",
	            "allow":"yes",
	            "name":"MSIE",
	            "message_id":"ieUpgradeMessage"
	         },
	         {
	            "min_version":"2",
	            "allow":"warn",
	            "name":"Firefox",
	            "message_id":"warningMessage"
	         },
	         {
	            "min_version":"1",
	            "allow":"warn",
	            "name":"Chrome",
	            "message_id":"warningMessage"
	         },
	         {
	            "allow":"no",
	            "name":"Safari",
	            "message_id":"specialSafariMessage"
	         }
	      ],
	      "default_allow":"no"
	   }
	}.cases;
	
	BrowserValidator.init(this.m_oCases);
};

Test.getValidationDefinitionWorks = function()
{
	var oNonExistantBrowserResults = BrowserValidator.getValidationDefinition("NonExistant", "1");
	assertEquals("Default result should be returned for browsers not in the list.", this.m_oCases.default_allow, oNonExistantBrowserResults.sAllow);
	assertEquals("Default result should be returned for browsers not in the list.", this.m_oCases.default_message_id, oNonExistantBrowserResults.sMessageId);
	
	var oFirefox1Result = BrowserValidator.getValidationDefinition("Firefox", "1");
	assertEquals("Default result should be returned for browsers in the list but not within the version range.", this.m_oCases.default_allow, oFirefox1Result.sAllow);
	assertEquals("Default result should be returned for browsers in the list but not within the version range.", this.m_oCases.default_message_id, oFirefox1Result.sMessageId);
	
	var oFirefox3Result = BrowserValidator.getValidationDefinition("Firefox", "3");
	assertEquals("Only results with the correct browser version should be used.", "yes", oFirefox3Result.sAllow);
	assertEquals("If neither the browser entry nor list have a message specified the message id should be undefined", undefined, oFirefox3Result.sMessageId);
	
	var oFirefox2Result = BrowserValidator.getValidationDefinition("Firefox", "2");
	assertEquals("Only results with the correct browser version should be used.", "warn", oFirefox2Result.sAllow);
	assertEquals("Browsers defined message should be used if it exists", "warningMessage", oFirefox2Result.sMessageId);
	
	var oSafariResult = BrowserValidator.getValidationDefinition("Safari", "2");
	assertEquals("The default message for the list should be used if there is no message defined for the browser.", "specialSafariMessage", oSafariResult.sMessageId);
	assertEquals("The default message for the list should be used if there is no message defined for the browser.", "no", oSafariResult.sAllow);
};
	
Test.isVersionMatchWorks = function()
{
	assertTrue("isVersionMatch should return true when no min or max version is specified", BrowserValidator.isVersionMatch("1", {}));

	assertTrue("isVersionMatch should return true when version is '1' and min version is '1'", BrowserValidator.isVersionMatch("1", {min_version: "1"}));
	assertFalse("isVersionMatch should return false when version is '1' and min version is '2'", BrowserValidator.isVersionMatch("1", {min_version: "2"}));
	assertTrue("isVersionMatch should return true when version is '3' and min version is '2'", BrowserValidator.isVersionMatch("3", {min_version: "2"}));

	assertTrue("isVersionMatch should return true when version is '1' and max version is '1'", BrowserValidator.isVersionMatch("1", {max_version: "1"}));
	assertTrue("isVersionMatch should return true when version is '1' and max version is '2'", BrowserValidator.isVersionMatch("1", {max_version: "2"}));
	assertFalse("isVersionMatch should return false when version is '3' and max version is '2'", BrowserValidator.isVersionMatch("3", {max_version: "2"}));
	
	assertTrue("isVersionMatch should return true when version, min_version and max_version are all equal", BrowserValidator.isVersionMatch("1", {min_version: "1", max_version: "1"}));
	assertTrue("isVersionMatch should return true when version is within the min_version and max_version range", BrowserValidator.isVersionMatch("2", {min_version: "1", max_version: "3"}));

	assertFalse("isVersionMatch should return false when version is below the min_version and max_version range", BrowserValidator.isVersionMatch("1", {min_version: "2", max_version: "3"}));
	assertFalse("isVersionMatch should return false when version is above the min_version and max_version range", BrowserValidator.isVersionMatch("3", {min_version: "1", max_version: "2"}));

	assertTrue("isVersionMatch should return true when version is at the bottom end of the min_version and max_version range", BrowserValidator.isVersionMatch("1", {min_version: "1", max_version: "2"}));
	assertTrue("isVersionMatch should return true when version is at the top end of the min_version and max_version range", BrowserValidator.isVersionMatch("2", {min_version: "1", max_version: "2"}));
	
	assertTrue("isVersionMatch should return true if the version matches as many details as supplied in max_version", BrowserValidator.isVersionMatch("2.1", {max_version: "2"}));
};

Test.isVersionGreaterOrEqualWorks = function()
{
	assertFalse("isVersionGreaterOrEqual should return false for '1' vs '2'", BrowserValidator.isVersionGreaterOrEqual("1", "2"));
	assertTrue("isVersionGreaterOrEqual should return true for '2' vs '1'", BrowserValidator.isVersionGreaterOrEqual("2", "1"));
	assertTrue("isVersionGreaterOrEqual should return true for '1' vs '1'", BrowserValidator.isVersionGreaterOrEqual("1", "1"));
	
	assertFalse("isVersionGreaterOrEqual should return false for '1.1.1' vs '1.1.2'", BrowserValidator.isVersionGreaterOrEqual("1.1.1", "1.1.2"));
	assertTrue("isVersionGreaterOrEqual should return true for '1.1.2' vs '1.1.1'", BrowserValidator.isVersionGreaterOrEqual("1.1.2", "1.1.1"));
	assertTrue("isVersionGreaterOrEqual should return true for '1.1.1' vs '1.1.1'", BrowserValidator.isVersionGreaterOrEqual("1.1.1", "1.1.1"));
	
	assertFalse("isVersionGreaterOrEqual should return false for '1.1.1' vs '1.2.1'", BrowserValidator.isVersionGreaterOrEqual("1.1.1", "1.2.1"));
	assertTrue("isVersionGreaterOrEqual should return true for '1.2.1' vs '1.1.1'", BrowserValidator.isVersionGreaterOrEqual("1.2.1", "1.1.1"));

	assertFalse("isVersionGreaterOrEqual should return false for '1.1.1' vs '1.2'", BrowserValidator.isVersionGreaterOrEqual("1.1.1", "1.2"));
	assertTrue("isVersionGreaterOrEqual should return true for '1.2' vs '1.1.1'", BrowserValidator.isVersionGreaterOrEqual("1.2", "1.1.1"));
	assertFalse("isVersionGreaterOrEqual should return false for '1.1' vs '1.2.1'", BrowserValidator.isVersionGreaterOrEqual("1.1", "1.2.1"));
	assertTrue("isVersionGreaterOrEqual should return true for '1.2.1' vs '1.1'", BrowserValidator.isVersionGreaterOrEqual("1.2.1", "1.1"));		
	
	assertTrue("isVersionGreaterOrEqual should return true for '1.2' vs '1.2.1' when the bIgnoreUndefinedVersionLevels flag is true", BrowserValidator.isVersionGreaterOrEqual("1.2", "1.2.1", true));
	assertFalse("isVersionGreaterOrEqual should return false for '1.2' vs '1.2.1' when the bIgnoreUndefinedVersionLevels flag is not set", BrowserValidator.isVersionGreaterOrEqual("1.2", "1.2.1"));	
};

Test.initialize();
