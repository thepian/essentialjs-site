caplin.namespace("caplinx.composite");

caplin.include("caplinx.composite.RangeFilter");
caplin.include("caplinx.composite.EqualToFilter");
caplin.include("caplin.core.MapFactory");
caplin.include("caplin.core.MapUtility");
caplin.include("caplinx.composite.CaseInsensitiveReqularExpressionFilter");
caplin.include("caplin.component.filter.LogicalFilterExpression");

caplinx.composite.ActiveFieldFilters = function(sFieldName)
{
	this.m_sFieldName = sFieldName;
	this.m_mFilterValues = caplin.core.MapFactory.createMap();
};

caplinx.composite.ActiveFieldFilters.prototype.addFilter = function(sNodeValue)
{
	var oRangeMatch = sNodeValue.match(/^(\d+)(\.)?(\d*)?([+-])(\d*)(\.)?(\d*)$/);
	var oNumericEqualToMatch = sNodeValue.match(/^(\d+)(\.)?(\d)*$/);
	
	if(oRangeMatch !== null) 
	{
		var sFirstValue = oRangeMatch[1];
		
		if (oRangeMatch[2] && oRangeMatch[3]){
			sFirstValue = sFirstValue + oRangeMatch[2] + oRangeMatch[3];
		}
		
		var sOperator = oRangeMatch[4];
		
		var sSecondValue = oRangeMatch[5];
		
		if (sOperator === "-" && oRangeMatch[6] && oRangeMatch[7]){
			sSecondValue = sSecondValue + oRangeMatch[6] + oRangeMatch[7];
		}		

		this.m_mFilterValues[sNodeValue] = new caplinx.composite.RangeFilter(this.m_sFieldName, sFirstValue, sOperator, sSecondValue);
	}
	else if(oNumericEqualToMatch !== null)
	{
		this.m_mFilterValues[sNodeValue] = new caplinx.composite.EqualToFilter(this.m_sFieldName, sNodeValue);
	}
	else
	{
		this.m_mFilterValues[sNodeValue] = new caplinx.composite.CaseInsensitiveReqularExpressionFilter(this.m_sFieldName, sNodeValue);
	}
};

caplinx.composite.ActiveFieldFilters.prototype.removeAllFilters = function()
{
	for (var sNodeValue in this.m_mFilterValues)
	{
		if(this.m_mFilterValues[sNodeValue] !== undefined)
		{
			this.m_mFilterValues = caplin.core.MapFactory.removeItem(this.m_mFilterValues, sNodeValue);
		}	
	}
};

caplinx.composite.ActiveFieldFilters.prototype.removeFilter = function(sNodeValue)
{
	if(this.m_mFilterValues[sNodeValue] !== undefined)
	{
		this.m_mFilterValues = caplin.core.MapFactory.removeItem(this.m_mFilterValues, sNodeValue);
		return true;
	}
	return false;
};

caplinx.composite.ActiveFieldFilters.prototype.isEmpty = function()
{
	for(var sNodeValue in this.m_mFilterValues)
	{
		return false;
	}
	return true;
};

caplinx.composite.ActiveFieldFilters.prototype.getFilterExpression = function()
{
	if(caplin.core.MapUtility.size(this.m_mFilterValues) == 1)
	{
		for(var sNodeValue in this.m_mFilterValues)
		{
			return this.m_mFilterValues[sNodeValue].getFilterExpression();
		}		
	}
	else
	{
		var oORFilterExpression = new caplin.component.filter.LogicalFilterExpression(caplin.component.filter.LogicalFilterExpression.Operator.OR);
	
		for(var sNodeValue in this.m_mFilterValues)
		{
			oORFilterExpression.addFilterExpression(this.m_mFilterValues[sNodeValue].getFilterExpression());
		}
	
		return oORFilterExpression;		
	}
};