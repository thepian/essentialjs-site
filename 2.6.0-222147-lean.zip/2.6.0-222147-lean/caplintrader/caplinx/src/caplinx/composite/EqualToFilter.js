caplin.namespace("caplinx.composite");

caplin.include("caplin.component.filter.FieldFilterExpression");

caplinx.composite.EqualToFilter = function(sFieldName, sValue)
{
	this.m_oFilterExpression = new caplin.component.filter.FieldFilterExpression(sFieldName, caplin.component.filter.FieldFilterExpression.Operator.EQUAL, sValue);
};

caplinx.composite.EqualToFilter.prototype.getFilterExpression = function()
{
	return this.m_oFilterExpression;
};