caplin.namespace("caplinx.composite");

caplin.include("caplin.component.filter.FieldFilterExpression");

caplinx.composite.CaseInsensitiveReqularExpressionFilter = function(sFieldName, sRegularExpression)
{
	this.m_oFilterExpression = new caplin.component.filter.FieldFilterExpression(sFieldName, caplin.component.filter.FieldFilterExpression.Operator.CASE_INSENSITIVE_REGULAR_EXPRESSION, sRegularExpression);
};

caplinx.composite.CaseInsensitiveReqularExpressionFilter.prototype.getFilterExpression = function()
{
	return this.m_oFilterExpression;
};