caplin.namespace("caplinx.fields");


/**
 * This constructor is <code>private</code> and must never be used.
 * 
 * @class Singleton that provides the names of all the fields that are used by the trade messages.
 */
caplinx.fields.FieldNames = function()
{
	this.TRADING = new Object();
	this.TRADING.ACCOUNT = "Account";
	this.TRADING.ADDITIONAL_INFO = "AdditionalInfo";

	this.TRADING.BUY_OR_SELL = "BuySell";
   
	this.TRADING.ERROR_DESCRIPTION = "ErrorDescription";
	this.TRADING.EXECUTE_TIME_OUT = "ExecuteTimeOut";
	this.TRADING.LEGAL_ENTITY = "LegalEntity";
	this.TRADING.MESSAGE_TYPE = "MsgType";
	this.TRADING.MESSAGE_VERSION = "MsgVersion";
	this.TRADING.ON_THE_WIRE_TIME = "OTWTime";
	this.TRADING.OVERALL_TIME_OUT = "OverallTimeOut";
	this.TRADING.PRICE_TYPE = "PriceType";
	this.TRADING.PRICE_VERSION = "PriceVersion";
	this.TRADING.REQUEST_ID = "RequestID";
	this.TRADING.STATUS = "Status";
	this.TRADING.STATUS_CODE = "StatusCode";
	this.TRADING.STATUS_REASON = "StatusReason";
	
	this.TRADING.TRADE_DATE = "TradeDate";
	this.TRADING.TIMESTAMP = "TimeStamp";
	this.TRADING.TRADE_ID = "TradeID";
	this.TRADING.TRADING_PROTOCOL = "TradingProtocol";
	this.TRADING.TRADING_TYPE = "TradingType";
	this.TRADING.USER_NAME = "UserName";
	this.TRADING.USER_ROLE = "UserRole";
	
	this.TRADING.FX = this.TRADING;
	FxFields(this.TRADING.FX);
	
	
	this.LEG = new Array();
	
	/**
	 * Defines the fields that are available for the first leg of a trade.
	 * 
	 * @type LegFields
	 */
	this.LEG1 = new LegFields("L1_");
	this.LEG[1] = this.LEG1;
	this.TRADING.FX.LEG = new LegFields("");

	/**
	 * Defines the fields that are available for the second leg of a trade. These are only required
	 * for swap, switch and butterfly trade types.
	 * 
	 * @type LegFields
	 */
	this.LEG2 = new LegFields("L2_");
	this.LEG[2] = this.LEG2;

	/**
	 * Defines the fields that are available for the third leg of a trade. These are only required
	 * for the butterfly trade type.
	 * 
	 * @type LegFields
	 */
	this.LEG3 = new LegFields("L3_");
	this.LEG[3] = this.LEG3;
};

/**
 * Adds fx filed to the root object passed
 */
function FxFields(l_oRootObject)
{
	l_oRootObject.AMOUNT =  "Amount";
	l_oRootObject.ASK_PRICE =  "AskPrice";
	l_oRootObject.BID_PRICE =  "BidPrice";
	l_oRootObject.RATE_PRECISION =  "RatePrecision";
	l_oRootObject.POINTS_PRECISION =  "PointsPrecision";
	l_oRootObject.POINTS_SCALE_FACTOR =  "PointsScaleFactor";
	l_oRootObject.TIER_LIMIT =  "TierLimit";
	l_oRootObject.BUY_OR_SELL =  "BuySell";
	l_oRootObject.INSTRUMENT =  "Instrument";
	l_oRootObject.INSTRUMENT_TYPE =  "InstrumentType";


	l_oRootObject.BID_SPOT_PRICE =  "BidSpotPrice";
    l_oRootObject.ASK_SPOT_PRICE =  "AskSpotPrice";
    l_oRootObject.BID_FWD_PRICE =  "BidFwdPrice";
    l_oRootObject.ASK_FWD_PRICE =  "AskFwdPrice";
    //Points is difference between spot and forward price
    l_oRootObject.BID_POINTS =  "BidPoints";
    l_oRootObject.ASK_POINTS =  "AskPoints";
    

    l_oRootObject.PRICE =  "Price";
	l_oRootObject.YIELD =  "Yield";
	l_oRootObject.YIELD_CHANGE_ON_DAY =  "YieldChangeOnDay";
	l_oRootObject.PRICING_TYPE =  "PricingType";
	l_oRootObject.SETTLEMENT_DATE =  "SettlementDate";
	l_oRootObject.TENOR =  "Tenor";
	
	l_oRootObject.BASE_CURRENCY = "BaseCurrency";
	l_oRootObject.DEALT_CURRENCY = "DealtCurrency";
	l_oRootObject.TERM_CURRENCY = "TermCurrency";
}	    


/**
 * Creates a new <code>LegFields</code> object with the specified prefix.
 * 
 * @param {String} l_sPrefix The prefix that should be applied to each of the field names.
 * 
 * @class Represents the fields used for trading for a particular leg of a trade.
 */
function LegFields(l_sPrefix)
{
	this.AMOUNT = l_sPrefix + "Amount";
	this.SIDE = l_sPrefix + "Side";
	this.ASK_PRICE = l_sPrefix + "AskPrice";
	this.BID_PRICE = l_sPrefix + "BidPrice";
	this.ASK_YIELD = l_sPrefix + "AskYield";
	this.BID_YIELD = l_sPrefix + "BidYield";
	this.RATE_PRECISION = l_sPrefix + "RatePrecision";
	this.POINTS_PRECISION = l_sPrefix + "PointsPrecision";
	this.POINTS_SCALE_FACTOR = l_sPrefix + "PointsScaleFactor";
	this.TIER_LIMIT = l_sPrefix + "TierLimit";
	this.BUY_OR_SELL = l_sPrefix + "BuySell";
	this.INSTRUMENT = l_sPrefix + "Instrument";
	this.INSTRUMENT_TYPE = l_sPrefix + "InstrumentType";
    // Eddy hack
    this.BID_POINTS = l_sPrefix + "BidPoints";
    this.ASK_POINTS = l_sPrefix + "AskPoints";
    this.BID_SPOT_PRICE = l_sPrefix + "BidSpotPrice";
    this.ASK_SPOT_PRICE = l_sPrefix + "AskSpotPrice";

    this.PRICE = l_sPrefix + "Price";
	this.YIELD = l_sPrefix + "Yield";
	this.YIELD_CHANGE_ON_DAY = l_sPrefix + "YieldChangeOnDay";
	this.PRICING_TYPE = l_sPrefix + "PricingType";
	this.SETTLEMENT_DATE = l_sPrefix + "SettlementDate";
	this.TENOR = l_sPrefix + "Tenor";
	
	this.BENCHMARK_YIELD 		= l_sPrefix + "BenchmarkYield";
	this.BENCHMARK_INSTRUMENT 	= l_sPrefix + "BenchmarkInstrument";
	this.BENCHMARK_PRICE 		= l_sPrefix + "BenchmarkPrice";

	this.BENCHMARK_ASK_YIELD	= l_sPrefix + "BenchmarkAskYield";
	this.BENCHMARK_BID_YIELD	= l_sPrefix + "BenchmarkBidYield";
	this.BENCHMARK_ASK_PRICE	= l_sPrefix + "BenchmarkAskPrice";
	this.BENCHMARK_BID_PRICE	= l_sPrefix + "BenchmarkBidPrice";
	
	this.CURRENCY				= l_sPrefix + "IssueCurrency";
	
	this.SWAP_DIFF				= "SwapPriceDifferential" + l_sPrefix.replace( /[\D_]/g, '' );

    // ******** FIELDS for IRS ***************************
    this.MATURITY           = "MatD";
    this.EFFECTIVE          = "StlmD";
    this.RESETFREQ          = "CpnFrq";
    this.DAYCOUNT           = "DaysTyp";
    
    
    	
	this.DISPLAY_NAME = l_sPrefix + "DisplayName";
    
}






	
