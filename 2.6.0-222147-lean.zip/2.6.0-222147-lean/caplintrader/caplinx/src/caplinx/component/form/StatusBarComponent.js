caplin.namespace("caplinx.component.form");

caplin.include("caplin.core.Logger");
caplin.include("caplin.core.LogLevel");
caplin.include("caplin.core.Observable");
caplin.include("caplin.core.Exception");
caplin.include("caplin.dom.Utility");
caplin.include("caplin.core.ArrayUtility");
caplin.include("caplin.dom.controls.form.FlexibleButton");
caplin.include("caplin.dom.ElementFactory");
caplin.include("caplin.component.Component", true);
caplin.include("caplin.element.ElementFactory");

caplinx.component.form.StatusBarComponent = function(sTemplate, eXmlModel)
{
	/** @private **/
	this.m_eXmlModel = eXmlModel;
	
	/** @private **/
	this.m_sTemplate = sTemplate;
	/** @private **/
	this.m_oObservable = new caplin.core.Observable();
	/**
	 * [[button,listener],..]
	 * @private
	 */
	this.m_pButtonListeners = [];
	/** @private **/
	this.m_eHolderElem = null;
	
	/**
	 * Map of Renderer objects for data spans
	 * @private
	 */
	this.m_mRenderers = {};

	/** 
	 * INPUT/SPAN elements
	 * @private **/
	this.m_pElements = [];
	/**
	 * @private
	 */
	this.m_pButtons = [];
	
	/**
	 * @private
	 * Instance  unique ID used to uniquely identify that this component has published an event to the OpenAjax hub.
	 */
	this.m_nUniqueID = this.m_nClassUniqueID++;
	
	/** @private */
	this.m_sOpenAjaxOnSubmitEventName = (this.m_eXmlModel.getAttribute("onSubmitEventName") || "caplinx.component.form.StatusBarComponent.onSubmit") + "." + this.m_nUniqueID;
	
	/** @private */
	this.m_mSerializedInputData = {};
};
caplin.implement(caplinx.component.form.StatusBarComponent, caplin.component.Component);

/**
 * @private
 * Global unique ID used to uniquely identify that this component has published an event to the OpenAjax hub.
 */
caplinx.component.form.StatusBarComponent.prototype.m_nClassUniqueID = 0;


/****************************************************
 *                 PUBLIC METHODS 
 ****************************************************/

caplinx.component.form.StatusBarComponent.prototype.addListener = function(oListener)
{
	this.m_oObservable.addObserver(oListener);
};

caplinx.component.form.StatusBarComponent.prototype.removeListener = function(oListener)
{
	this.m_oObservable.removeObserver(oListener);
};

caplinx.component.form.StatusBarComponent.prototype.getRenderers = function()
{
	return this.m_mRenderers;
};
/****************************************************
 *      caplin.component.Component Interface 
 ****************************************************/

/**
 * @see caplin.component.Component#getElement
 */
caplinx.component.form.StatusBarComponent.prototype.getElement = function()
{
	if(this.m_eHolderElem === null)
	{
		this.m_eHolderElem = document.createElement("DIV");
		var sExtraClasses = this.m_eXmlModel.getAttribute("extraClasses") || "";

		this.m_eHolderElem.className = "StatusBarHolder " + sExtraClasses;
		this.m_eHolderElem = caplin.dom.Utility.setInnerHtml(this.m_eHolderElem, this.m_sTemplate);
		
		this._processElements();
	}
	
	return this.m_eHolderElem;
};

/**
 * @see caplin.component.Component#getSerializedState
 */
caplinx.component.form.StatusBarComponent.prototype.getSerializedState = function()
{
	var sTemplateFile = this.m_eXmlModel.getAttribute("src");
	var sExtraClasses = this.m_eXmlModel.getAttribute("extraClasses") || "";
	return '<statusBar src="' + sTemplateFile + '"' + ' extraClasses="' + sExtraClasses + '"/>';
};

/**
 * @see caplin.component.Component#onClose
 */
caplinx.component.form.StatusBarComponent.prototype.onClose = function()
{
	for(var i=this.m_pButtonListeners-1;i>=0;i--) {
		var pPair = this.m_pButtonListeners[i];
		pPair[0].removeOnClickListener(pPair[1]);
	}

	this.m_eHolderElem = null;
	this.m_pElements = [];
	this.m_pButtons = [];
};


/****************************************************
 *                 PRIVATE METHODS 
 ****************************************************/

/**
 * @private
 */
caplinx.component.form.StatusBarComponent.prototype._processButton = function(eButton) 
{
	var sName = eButton? eButton.getAttribute("name") : "";
	if (sName.indexOf("trigger:")==0) {
		var sBits = sName.split(":");
		var sSymbolicName = sBits[1];
		var oNewButton = new caplin.dom.controls.form.FlexibleButton(eButton.innerHTML.toString(), null, null, [], eButton.parentNode);
		oNewButton.create();
		oNewButton.setEnabled(true);
		oNewButton.m_sSymbolicName = sSymbolicName;
		
		var nListenerId = oNewButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onButton", []));
		this.m_pButtonListeners.push(oNewButton,nListenerId);
		
		eButton.parentNode.removeChild(eButton);
		this.m_pButtons.push(oNewButton.getElement());
	}
};
 
/**
 * @private
 */
caplinx.component.form.StatusBarComponent.prototype._processSpan = function(eSpan) 
{
	var sName = eSpan? eSpan.getAttribute("name") : "";
	if (sName.indexOf("render:")==0) {
		var sBits = sName.split(":");
		var sRendererTemplate = sBits[2] || "text";
		var sFieldName = sBits[1];
		var oRendererFactory = caplin.element.ElementFactory.getRendererFactory();
		
		var oRenderer = oRendererFactory.createRenderer(sRendererTemplate, [sFieldName]);
		eSpan.innerHTML = oRenderer.createHtml();
		oRenderer.bind(eSpan.firstChild);
		this.m_mRenderers[sFieldName] = oRenderer;
		
		this.m_pElements.push(eSpan)
	}
};
 
/**
 * Process the input, select, button, label, span
 * 
 * @private
 */
caplinx.component.form.StatusBarComponent.prototype._processElements = function()
{
	var a = this.m_eHolderElem.getElementsByTagName("BUTTON");
	caplin.core.ArrayUtility.forEachReverse(this.m_eHolderElem.getElementsByTagName("BUTTON"),this._processButton,this);
	//caplin.core.ArrayUtility.forEachReverse(this.m_eHolderElem.getElementsByTagName("INPUT"),this._processInput,this);
	//caplin.core.ArrayUtility.forEachReverse(this.m_eHolderElem.getElementsByTagName("SELECT"),this._processSelect,this);
	//caplin.core.ArrayUtility.forEachReverse(this.m_eHolderElem.getElementsByTagName("LABEL"),this._processLabel,this);
	caplin.core.ArrayUtility.forEachReverse(this.m_eHolderElem.getElementsByTagName("SPAN"),this._processSpan,this);
};

/**
 * Notify observers
 * function onButton(sSymbolicName,oButton)
 * @private
 */
caplinx.component.form.StatusBarComponent.prototype._onButton = function(oEvent)
{
	this.m_oObservable.notify("onButton", oEvent.Source.m_sSymbolicName,oEvent.Source);
};

