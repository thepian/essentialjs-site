caplin.namespace("caplinx.tobo");

caplin.include("caplin.core.Observable",true);
caplin.include("caplin.i18n.Translator", true);
caplin.include("caplinx.tobo.TOBOUserPermissionServiceListener", true);
caplin.include("caplin.framework.connection.ConnectionStatusFieldModel", true);
caplin.include("caplinx.component.userselect.UserSelectorComponent");
caplin.include("caplin.widget.message.MessageManager");
caplin.include("caplinx.permissioning.CaplinPermissionService");

caplin.include("caplin.trading.trademodel.TradeOnBehalfOfListener", true);
caplin.include("caplin.trading.trademodel.TradeOnBehalfOf", true);


caplinx.tobo.TOBOUserManager = function()
{
	caplin.notifyAfterClassLoad(this);
};

caplin.extend(caplinx.tobo.TOBOUserManager, caplin.core.Observable);
caplin.implement(caplinx.tobo.TOBOUserManager, caplin.trading.trademodel.TradeOnBehalfOfListener);

caplinx.tobo.TOBOUserManager.prototype.onAfterClassLoad = function()
{
	caplin.core.Observable.apply(this,arguments);

	this.m_mValues = {};
	this.m_mFieldUpdateMethodNames = {
		"User" : 	"onTOBOUserChanged",
		"Account" : "onTOBOAccountChanged",
		"UserList" : "onTOBOUserListChanged",
		"AccountList" : "onTOBOAccountListChanged",
		"UserType" : "onTOBOUserTypeChanged",
		"Locked" : "onLockChanged"
	};
	
	this.m_oPermissionListener = new caplinx.tobo.TOBOUserPermissionServiceListener();
	this.m_nAccountListenerId = null;
	this.m_sUserAccountPermission;
	this.m_bIsAllowedToTradeOnBehalfOf = false;
	this.m_nActiveTradeCount = 0;
	
	caplin.trading.trademodel.TradeOnBehalfOf.addListener(this);
};

// TODO - This should not be needed. A problem with the permission service means we can't do this straight away
caplinx.tobo.TOBOUserManager.prototype.initialise = function()
{
	this.m_oPermissionListener.addListener("TOBOUser",this,"_updateUserList");
	this.m_oPermissionListener.addListener("TOBOUserType",this,"_updateUserType");
	this.m_oConnectionStausModel = caplin.framework.connection.ConnectionStatusFieldModel.getInstance();
	var self = this;
	
	var receiver = {};
	var fields = [];
	fields.push(caplin.framework.connection.ConnectionStatusFieldModel.FIELD_CONNECTION_STATUS);
	receiver.onFieldUpdate = function(oFields, mChanged){
		var sStatus = oFields.FIELD_CONNECTION_STATUS;
		if(sStatus == caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_ERROR){
			self.update("Locked", true);
		}else{
			self.update("Locked", false);
		}
	}
	this.m_oConnectionStausModel.addListener(fields,receiver);
	
};

caplinx.tobo.TOBOUserManager.prototype.tradeStarted = function(){
	this.update("Locked", true);
	this.m_nActiveTradeCount++; 
};

caplinx.tobo.TOBOUserManager.prototype.tradeFinished = function(){
	if(this.m_nActiveTradeCount == 0){
		throw "Cant reduce active trade count below zero";
	}
	
	if (this.m_nActiveTradeCount == 1){
		this.update("Locked", false);
	}
	
	this.m_nActiveTradeCount--;
}

caplinx.tobo.TOBOUserManager.prototype.getField = function(sField)
{
	return this.m_mValues[sField];
};

caplinx.tobo.TOBOUserManager.prototype.getAccount = function()
{
	return this.getField("Account");
};

caplinx.tobo.TOBOUserManager.prototype.getUser = function()
{
	return this.getField("User");
};

caplinx.tobo.TOBOUserManager.prototype.getUserType = function()
{
	return this.getField("UserType");
};

caplinx.tobo.TOBOUserManager.prototype.isAllowedToTradeOnBehalfOf = function()
{
	return this.m_bIsAllowedToTradeOnBehalfOf;
};

caplinx.tobo.TOBOUserManager.prototype.canPerformTrade = function()
{
	if(caplinx.tobo.TOBOUserManager.isAllowedToTradeOnBehalfOf() && 
	   (!caplinx.tobo.TOBOUserManager.getUser() || 
	     caplinx.tobo.TOBOUserManager.getUser() === caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT
		))
	{
		var sMsg = ct.i18n("cx.tobo.user.manager.message");
		caplin.widget.message.MessageManager.prototype.alert(sMsg);
		return false;
	}
	
	return true;
}

caplinx.tobo.TOBOUserManager.prototype.update = function(sField,vValue)
{
	if(this.m_mValues[sField] !== vValue)
	{
		this.m_mValues[sField] = vValue;
		var sUpdateMethodName = this.m_mFieldUpdateMethodNames[sField];
		this.notifyObservers(sUpdateMethodName,[vValue]);
	}
};

caplinx.tobo.TOBOUserManager.prototype.updateUser = function(sUser)
{
	if(this.m_mValues["User"] !== sUser)
	{
		this.update("AccountList",[]);
		this.update("Account","");
		this.update("User",sUser);
		this.changeUser(sUser);
		this._setPermissionListenerForUserAccounts(sUser);
	}
};

caplinx.tobo.TOBOUserManager.prototype.updateAccount = function(sAccount)
{
	this.update("Account",sAccount);
};

caplinx.tobo.TOBOUserManager.prototype._updateUserList = function(pUserList)
{
	this.update("UserList",pUserList);
};

caplinx.tobo.TOBOUserManager.prototype._updateAccountList = function(pAccountList)
{
	this.update("AccountList",pAccountList);
};

caplinx.tobo.TOBOUserManager.prototype._updateUserType = function(pPermissions)
{
	if(pPermissions.length < 1)
	{
		//throw "User does not have any associated permissions. PermissioningDataSource appears to be misconfigured.";
		pPermissions[0] = "TRADER";
	}
	
	var sUserType = pPermissions[0];
	this.update("UserType",sUserType);
	this.m_bIsAllowedToTradeOnBehalfOf = true;
	
	if(sUserType === "TRADER"){
		this.m_bIsAllowedToTradeOnBehalfOf = false;
		caplinx.permissioning.CaplinPermissionService.addAccountsListener("/FX", this);
	}
};

caplinx.tobo.TOBOUserManager.prototype.changeUser = function(sUser)
{
	if (sUser === caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT) 
	{
		caplin.trading.trademodel.TradeOnBehalfOf.clearTradeOnBehalfOfPermissionable("UserName");
	}
	else 
	{
		caplin.trading.trademodel.TradeOnBehalfOf.setTradeOnBehalfOfPermissionable("UserName", sUser);
	}
};

caplinx.tobo.TOBOUserManager.prototype.onAccountsPermissionsChanged = function(bAllowed,pAccounts){
	this._updateAccountList(pAccounts);
};

caplinx.tobo.TOBOUserManager.prototype._setPermissionListenerForUserAccounts = function(sUser)
{
	this.m_sUserAccountPermission;
	
	if(this.m_sUserAccountPermission !== undefined)
	{
		this.m_oPermissionListener.removeListener(this.m_sUserAccountPermission);
		delete this.m_sUserAccountPermission;
	}

	if(sUser !== "")
	{
		this.m_sUserAccountPermission = "ACCOUNT-TOBO:" + sUser;
		this.m_oPermissionListener.addListener(this.m_sUserAccountPermission,this,"_updateAccountList");
	}
};

/**
 * A "trade on behalf of" change has been initiated, and we are currently awaiting prices for the new tier.
 * Any existing prices should be considered stale.
 * @param sPermissionable {String} A string representing the permissionable item that we are going to 
 * "trade on behalf of".
 */
caplinx.tobo.TOBOUserManager.prototype.tradeOnBehalfOfChangeInitiated = function(sPermissionable) {
	caplin.framework.ApplicationFactory.INSTANCE.m_oFxSl4bTradeSubscriber.stopTrading();
	caplin.framework.ApplicationFactory.INSTANCE.m_oFiSl4bTradeSubscriber.stopTrading();
};

/**
 * A "trade on behalf of" change has been completed, and any subsequent prices are from the new tier.
 * @param sPermissionable {String} A string representing the permissionable item that we are now 
 * "trading on behalf of".
 */
caplinx.tobo.TOBOUserManager.prototype.tradeOnBehalfOfChangeCompleted = function(sPermissionable) {
	caplin.framework.ApplicationFactory.INSTANCE.m_oFxSl4bTradeSubscriber.startTrading();
	caplin.framework.ApplicationFactory.INSTANCE.m_oFiSl4bTradeSubscriber.startTrading();
};

/**
 * A pending "trade on behalf of" change has failed, and any subsequent prices are from the old tier.
 * @param sReason {String} A string description of the reason for failure.
 */
caplinx.tobo.TOBOUserManager.prototype.tradeOnBehalfOfChangeFailed = function(sReason) {
	caplin.framework.ApplicationFactory.INSTANCE.m_oFxSl4bTradeSubscriber.startTrading();
	caplin.framework.ApplicationFactory.INSTANCE.m_oFiSl4bTradeSubscriber.startTrading();
};

caplinx.tobo.TOBOUserManager.prototype.addObserver = function(oObserver)
{
	caplin.core.Observable.prototype.addObserver.apply(this,arguments);
	for(var sField in this.m_mValues)
	{
		var sUpdateMethodName = this.m_mFieldUpdateMethodNames[sField];
		var vValue = this.m_mValues[sField];
		oObserver[sUpdateMethodName](vValue);
	}
};

caplin.singleton('caplinx.tobo.TOBOUserManager');