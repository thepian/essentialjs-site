caplin.namespace("caplinx.renderer");

caplin.include("caplinx.renderer.SpreadElementRenderer", true);
caplin.include("caplinx.renderer.TradableElementRenderer");

caplinx.renderer.Notation32SpreadElementRenderer = function(pFields)
{
	var oBidElementRenderer = new caplinx.renderer.Notation32PriceElementRenderer([ pFields[0] ], 2);
	var oAskElementRenderer = new caplinx.renderer.Notation32PriceElementRenderer([ pFields[1] ], 2);
	
	caplinx.renderer.SpreadElementRenderer.call(this, pFields, oBidElementRenderer, oAskElementRenderer);
};
caplin.implement(caplinx.renderer.Notation32SpreadElementRenderer, caplinx.renderer.SpreadElementRenderer);