caplin.namespace("caplinx.renderer");

caplin.include("caplin.dom.Utility", true);
caplin.include("caplin.dom.renderer.ElementRenderer", true);
caplin.include("caplinx.renderer.TradableElementRenderer");
caplin.include("caplinx.permissioning.CaplinPermissionService");

caplinx.renderer.SpreadElementRenderer = function(pFields, oBidElementRenderer, oAskElementRenderer)
{
	this.m_pFields = pFields;

	this.m_oBidElementRenderer = oBidElementRenderer || new caplinx.renderer.TradableElementRenderer([pFields[0]]);
	this.m_oAskElementRenderer = oAskElementRenderer || new caplinx.renderer.TradableElementRenderer([pFields[1]]);

	this.m_sSeparator = "/";
	this.m_oCaplinPermissionService = caplinx.permissioning.CaplinPermissionService;
};
caplin.implement(caplinx.renderer.SpreadElementRenderer, caplin.dom.renderer.ElementRenderer);

caplinx.renderer.SpreadElementRenderer.NO_FIELDS = [];

caplinx.renderer.SpreadElementRenderer.prototype.setFieldModel = function(oFieldModel)
{
	this.m_oBidElementRenderer.setFieldModel(oFieldModel);
	this.m_oAskElementRenderer.setFieldModel(oFieldModel);
};

caplinx.renderer.SpreadElementRenderer.prototype.getFieldNames = function(mRecord)
{
	return this.m_pFields;
};

caplinx.renderer.SpreadElementRenderer.prototype.setSubject = function(sSubject)
{
	if (sSubject !== this.m_sSubject)
	{
		this.m_sSubject = sSubject;
		this.m_oBidElementRenderer.setSubject(sSubject);
		this.m_oAskElementRenderer.setSubject(sSubject);
	}
};

caplinx.renderer.SpreadElementRenderer.prototype.createElementHtml = function(mRecord, sSubject)
{
	return [
		"<span>", this.m_oBidElementRenderer.createElementHtml(mRecord, sSubject), "</span>", 
		this.m_sSeparator, 
		"<span>", this.m_oAskElementRenderer.createElementHtml(mRecord, sSubject), "</span>"
	].join('');
};

caplinx.renderer.SpreadElementRenderer.prototype.setDomElement = function(eElement)
{
	caplin.dom.Utility.addClassName(eElement, "price");

	this.m_oBidElementRenderer.setDomElement(eElement.childNodes[0]);
	this.m_oAskElementRenderer.setDomElement(eElement.childNodes[2]);
};

caplinx.renderer.SpreadElementRenderer.prototype.renderDataUpdate = function(mRecord, sSubject)
{
	// proxy the call onto the contained ElementRenderers
	this.m_oBidElementRenderer.renderDataUpdate(mRecord, sSubject);
	this.m_oAskElementRenderer.renderDataUpdate(mRecord, sSubject);
};

caplinx.renderer.SpreadElementRenderer.prototype.renderGeneralUpdate = function(nType, vUpdate)
{
	// proxy the call onto the contained ElementRenderers
	this.m_oBidElementRenderer.renderDataUpdate(nType, vUpdate);
	this.m_oAskElementRenderer.renderDataUpdate(nType, vUpdate);
};

caplinx.renderer.SpreadElementRenderer.prototype.forceDraw = function(mRecord)
{
	this.m_oBidElementRenderer.forceDraw(mRecord);
	this.m_oAskElementRenderer.forceDraw(mRecord);
};

caplinx.renderer.SpreadElementRenderer.prototype.clear = function(mRecord)
{
	this.m_oBidElementRenderer.clear(mRecord);
	this.m_oAskElementRenderer.clear(mRecord);
};

caplinx.renderer.SpreadElementRenderer.prototype.destruct = function()
{
	this._removePermissionListener();
	this.m_oBidElementRenderer.destruct();
	this.m_oAskElementRenderer.destruct();
};

caplinx.renderer.SpreadElementRenderer.prototype.registerAsPermissionListener = function()
{
	if (this.m_sSubject)
	{
		// de-register the previous listeners if any exist
		this._removePermissionListener();
		// register permission listener
		this.m_nPermissionListenerId = this.m_oCaplinPermissionService.addTicketTradableListener(this.m_sSubject, this);
	}
};

// *********************** Permissioning Listener ***********************
caplinx.renderer.SpreadElementRenderer.prototype.onTicketPermissionsChanged = function(bIsPermitted)
{
	this.m_oBidElementRenderer.onTicketPermissionsChanged(bIsPermitted);
	this.m_oAskElementRenderer.onTicketPermissionsChanged(bIsPermitted);
};

// *********************** private methods ***********************

/**
 * @private
 */
caplinx.renderer.SpreadElementRenderer.prototype._removePermissionListener = function()
{
	if(this.m_nPermissionListenerId !== null)
	{
		this.m_oCaplinPermissionService.removeListener(this.m_nPermissionListenerId);
	}
	this.m_nPermissionListenerId = null;
};
