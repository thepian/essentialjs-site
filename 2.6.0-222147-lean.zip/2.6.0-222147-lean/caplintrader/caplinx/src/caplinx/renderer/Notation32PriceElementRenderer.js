caplin.namespace("caplinx.renderer");

caplin.include("caplinx.renderer.TradableElementRenderer", true);
caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplinx.widget.format.Notation32Formatter");

caplinx.renderer.Notation32PriceElementRenderer = function(pFields)
{
	var oTextFormatterFactory = caplin.framework.ApplicationFactory.INSTANCE.getTextFormatterFactory();
	this.oFormatter = oTextFormatterFactory.getTextFormatter("caplinx.widget.format.Notation32Formatter");
	caplinx.renderer.TradableElementRenderer.call(this, pFields, 3);
	this.m_bIsTradable = true;
};

caplin.implement(caplinx.renderer.Notation32PriceElementRenderer, caplinx.renderer.TradableElementRenderer);

caplinx.renderer.Notation32PriceElementRenderer.prototype._formatValue = function(sValue)
{
      if (this.m_nDecimalPlaces!==undefined &&!isNaN(sValue))
      {
            sValue = parseFloat(sValue);
            sValue = sValue.toFixed(this.m_nDecimalPlaces);

            if (sValue <= 0)
            {
                  this.m_bIsTradable = false;
            }
            else
            {

                  this.m_bIsTradable = true;
            }
      }
      return this.oFormatter.formatText(sValue);
};

caplinx.renderer.Notation32PriceElementRenderer.prototype.checkIfTradeable = function(permManager)
{
	return (caplinx.renderer.TradableElementRenderer.prototype.checkIfTradeable.call(this,permManager) && this.m_bIsTradable);
};