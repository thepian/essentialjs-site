caplin.namespace("caplinx.renderer");

caplin.include("caplin.dom.renderer.TextElementRenderer", true);

caplinx.renderer.YieldElementRenderer = function(pFields)
{
	caplin.dom.renderer.TextElementRenderer.call(this, pFields);
};
caplin.implement(caplinx.renderer.YieldElementRenderer, caplin.dom.renderer.TextElementRenderer);

caplinx.renderer.YieldElementRenderer.prototype.formatValue = function(sValue)
{
	if (!isNaN(sValue))
	{
		sValue = parseFloat(sValue);
		sValue = sValue.toFixed(3);
	}
	return sValue;
};