caplin.namespace("caplinx.utilities");
/*
 *
 */
caplinx.utilities.HTMLTemplate = function(sSrc){
	var nSequenceNumber = ++arguments.callee.sequenceNumber;
	var sHtml = caplin.getFileContents(sSrc);

	// regexp * replace string for the attributes "id" in the html template
	var l_oIdRegex = /\s*id=[\"']([^\"']*)[\"']/gm;
	var l_sIdReplace = " id=\"$1_" + nSequenceNumber + "\"";

	// regexp * replace string for the attributes "for" in the html template
	var l_oForRegex = /\s*for=[\"']([^\"']*)[\"']/gm;
	var l_sForReplace = " for=\"$1_" + nSequenceNumber + "\"";

	var l_aMatch = sHtml.match(l_oIdRegex)||[];
	var l_oMap = {};var sId;

	for(var i=0, l=l_aMatch.length; i<l; ++i){
		sId = l_aMatch[i].replace(/\s*id=|[\"']*/g, '');
		// call a self executing function in the loop to assign a function to the item in the map
		l_oMap[sId] = (function(sId){
			return function(){ // when the function is called it will get the dom reference of the element
				// this will be done only first time this function is called
				var eElement = document.getElementById(sId + '_' + nSequenceNumber);
				// once we have the reference we overide ourselve by returning a reference to the dom element we just catched
				arguments.callee = (function(eElement){
					return function(){
						return eElement;
					}
				})(eElement);
				// finally we return the element found
				return eElement;
			}
		})(sId);
	}
	this.html = sHtml.replace(l_oIdRegex, l_sIdReplace).replace(l_oForRegex, l_sForReplace);
	this.map = l_oMap;
};
caplinx.utilities.HTMLTemplate.sequenceNumber = 0;

caplinx.utilities.HTMLTemplate.prototype.getElementById = function(sId){
	if(this.map[sId]){
		return this.map[sId]();
	}
}
