caplin.namespace("caplinx.utilities");

caplin.include("caplin.core.StringUtility", true);

caplinx.utilities.NumericRangeMatcher = function()
{
	this.m_sNumericRegex = "\\-?(\\d*\\.\\d+|\\d+)";
	
	this.m_oRangeRegEx = new RegExp("^(" + this.m_sNumericRegex + ")-(" + this.m_sNumericRegex + ")$");
	this.m_oLessThanRegEx = new RegExp("^<(" + this.m_sNumericRegex + ")$");
	this.m_oLessThanOrEqualRegEx = new RegExp("^<=(" + this.m_sNumericRegex + ")$");
	this.m_oGreaterThanRegEx = new RegExp("^>(" + this.m_sNumericRegex + ")$");
	this.m_oGreaterThanOrEqualRegEx = new RegExp("^>=(" + this.m_sNumericRegex + ")$");
	this.m_oEqualToRegEx = new RegExp('^('+this.m_sNumericRegex+')$');
};

caplinx.utilities.NumericRangeMatcher.prototype.getEqualToMatch = function(sValue)
{
	var sCleanValue = caplin.core.StringUtility.stripWhitespace(sValue);
	var pMatches = sCleanValue.match(this.m_oEqualToRegEx);
	if(pMatches)
	{
		return pMatches[1];
	}
	
	return null;
};

caplinx.utilities.NumericRangeMatcher.prototype.getGreaterThanMatch = function(sValue)
{
	var sCleanValue = caplin.core.StringUtility.stripWhitespace(sValue);
	var pMatches = sCleanValue.match(this.m_oGreaterThanRegEx);
	if(pMatches)
	{
		return pMatches[1];
	}
	
	return null;
};

caplinx.utilities.NumericRangeMatcher.prototype.getGreaterThanOrEqualMatch = function(sValue)
{
	var sCleanValue = caplin.core.StringUtility.stripWhitespace(sValue);
	var pMatches = sCleanValue.match(this.m_oGreaterThanOrEqualRegEx);
	if(pMatches)
	{
		return pMatches[1];
	}
	
	return null;
};

caplinx.utilities.NumericRangeMatcher.prototype.getLessThanMatch = function(sValue)
{
	var sCleanValue = caplin.core.StringUtility.stripWhitespace(sValue);
	var pMatches = sCleanValue.match(this.m_oLessThanRegEx);
	if(pMatches)
	{
		return pMatches[1];
	}
	
	return null;
};
caplinx.utilities.NumericRangeMatcher.prototype.getLessThanOrEqualMatch = function(sValue)
{
	var sCleanValue = caplin.core.StringUtility.stripWhitespace(sValue);
	var pMatches = sCleanValue.match(this.m_oLessThanOrEqualRegEx);
	if(pMatches)
	{
		return pMatches[1];
	}
	
	return null;
};

caplinx.utilities.NumericRangeMatcher.prototype.getRangeMatch = function(sValue)
{
	var sCleanValue = caplin.core.StringUtility.stripWhitespace(sValue);
	var pMatches = sCleanValue.match(this.m_oRangeRegEx);
	if(pMatches)
	{
		return [pMatches[1], pMatches[3]];
	}
	
	return null;
};
