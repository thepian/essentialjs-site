/**
 * @fileoverview
 * Defines the caplinx.chart.decorator.EventListeningDecorator class.
 */
caplin.namespace("caplinx.chart.decorator");

caplin.include("caplin.chart.decorator.ChartDecorator", true);

caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.filter.QueryFilterExpression");
caplin.include("caplin.chart.ChartSeriesRequest");
caplin.include("caplin.core.Exception");

/**
 * Constructs a new <code>EventListeningDecorator</code> with the specified arguments. End-users will never need to do
 * this themselves since charts are fully constructed based on their XML definition files by the
 * {@link caplin.chart.ChartGenerator ChartGenerator} class.
 * 
 * @class
 * The <code>caplinx.chart.decorator.EventListeningDecorator</code> is used to listen to
 * events from the OpenAjax hub that may affect the contents of the chart
 * such as subjectAdded or subjectRemoved events.
 * When it receiveds these events it will manipulate the chart accordingly. For example,
 * if a subjectAdded event is received it will attempt to add this subject to the chart.
 * 
 * <p>For more information on the OpenAjax hub see
 * the <a href="http://www.openajax.org/member/wiki/OpenAjax_Hub_1.0_Specification">OpenAjax hub 1.0 specification</a>.
 * </p>
 * 
 * @constructor
 * @implements caplin.chart.decorator.ChartDecorator
 */
caplinx.chart.decorator.EventListeningDecorator = function(oConfig)
{
	/** @private */
	this.m_oConfig = oConfig || {};
	
	/** @private */
	this.m_oChartView = null;
	
	/** @private */
	this.m_oChartModel = null;

	/** @private */	
	this.m_oAddedHelper = null;
	
	/** @private */	
	this.m_oRemovedHelper = null;
	
	/** @private */	
	this.m_oUpdatedHelper = null;
	
	/** @private */
	this.m_sSubjectField = this.m_oConfig.subjectField || "subject";
};
caplin.implement(caplinx.chart.decorator.EventListeningDecorator, caplin.chart.decorator.ChartDecorator);

/** --------------------------------------------------------------------------------------------------------
 *                      caplin.chart.decorator.ChartDecorator Interface
 ---------------------------------------------------------------------------------------------------------- */

/**
 * @private
 * @see caplin.chart.decorator.ChartDecorator#setChartView
 */
caplinx.chart.decorator.EventListeningDecorator.prototype.setChartView = function(oChartView)
{	
	this.m_oChartView = oChartView;
	
	// oComponent, sNameSpace, sEventName, oCallbackScope, fCallbackMethod
	this.m_oAddedHelper =
		new caplin.component.comms.OpenAjaxChannelSubscriptionHelper( this.m_oChartView,
			"*", "addSubject", this, this._addSubject);
			
	this.m_oRemovedHelper =
		new caplin.component.comms.OpenAjaxChannelSubscriptionHelper( this.m_oChartView,
			"*", "removeSubject", this, this._removeSubject);
			
	this.m_oUpdatedHelper =
		new caplin.component.comms.OpenAjaxChannelSubscriptionHelper( this.m_oChartView,
			"*", "updateSubject", this, this._updateSubject);	
			
	this.m_oChartModel = this.m_oChartView.getChartModel();					
};


/** --------------------------------------------------------------------------------------------------------
 *                      Private OpenAjax handling methods
 ---------------------------------------------------------------------------------------------------------- */

/** @private */
caplinx.chart.decorator.EventListeningDecorator.prototype._addSubject = function(sName, oEvent)
{
	if (oEvent.id === null || oEvent.id === "" || oEvent.id === undefined) 
	{
		var sMsg = "An \"id\" must be supplied for event \"" + sName + "\"";
		throw new caplin.core.Exception( sMsg,
				"caplinx.chart.decorator.EventListeningDecorator._addSubject");
	}
	
	this._requestSubject(oEvent);
};

/** @private */
caplinx.chart.decorator.EventListeningDecorator.prototype._removeSubject = function(sName, oEvent)
{
	if (oEvent.id === null || oEvent.id === "" || oEvent.id === undefined) 
	{
		var sMsg = "An \"id\" must be supplied for event \"" + sName + "\"";
		throw new caplin.core.Exception( sMsg,
				"caplinx.chart.decorator.EventListeningDecorator._removeSubject");
	}
	
	this.m_oChartModel.removeSeries( oEvent.id );
};

/** @private */
caplinx.chart.decorator.EventListeningDecorator.prototype._updateSubject = function(sName, oEvent)
{
	if (oEvent.id === null || oEvent.id === "" || oEvent.id === undefined) 
	{
		var sMsg = "An \"id\" must be supplied for event \"" + sName + "\"";
		throw new caplin.core.Exception( sMsg,
				"caplinx.chart.decorator.EventListeningDecorator._updateSubject");
	}
	
	this._requestSubject(oEvent);
};

/** @private */
caplinx.chart.decorator.EventListeningDecorator.prototype._requestSubject = function(oEvent)
{
	var oFilter = new caplin.component.filter.QueryFilterExpression();

	oFilter.addFilter("subject", oEvent[this.m_sSubjectField]);
	if (oEvent.snapshotDate)
	{
		oFilter.addFilter("snapshotDate", oEvent.snapshotDate);		
	}

	var oRequest = new caplin.chart.ChartSeriesRequest( oEvent[this.m_sSubjectField], oFilter );
	this.m_oChartModel.requestSeries( oRequest );
};