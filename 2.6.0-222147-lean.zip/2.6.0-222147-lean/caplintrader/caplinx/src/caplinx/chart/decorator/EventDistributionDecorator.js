/**
 * @fileoverview
 * Defines the caplinx.chart.decorator.EventDistributionDecorator class.
 */
caplin.namespace("caplinx.chart.decorator");

caplin.include("caplin.chart.decorator.ChartDecorator", true);
caplin.include("caplin.chart.ChartViewListener", true);
caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplin.chart.ChartModelListener", true);

/**
 * Constructs a new <code>EventDistributionDecorator</code> with the specified arguments. End-users will never need to do
 * this themselves since charts are fully constructed based on their XML definition files by the
 * {@link caplin.chart.ChartGenerator ChartGenerator} class.
 * 
 * @class
 * <p>The <code>caplinx.chart.decorator.EventDistributionDecorator</code> Is used to distribute
 * events over the OpenAjax hub so that objects do not have to be tightly coupled</p>
 *
 * <p>For more information on the OpenAjax hub see
 * the <a href="http://www.openajax.org/member/wiki/OpenAjax_Hub_1.0_Specification">OpenAjax hub 1.0 specification</a>.
 * </p>
 * 
 * @constructor
 * @implements caplin.chart.decorator.ChartDecorator
 * @implements caplin.chart.ChartViewListener
 */
caplinx.chart.decorator.EventDistributionDecorator = function(oConfig)
{
	/** @private */
	this.m_oConfig = oConfig;
	
	/** @private */
	this.m_oChartView = null;
	
	/** @private */
	this.m_oChartModel = null;
};
caplin.implement(caplinx.chart.decorator.EventDistributionDecorator, caplin.chart.decorator.ChartDecorator);
caplin.implement(caplinx.chart.decorator.EventDistributionDecorator, caplin.chart.ChartViewListener);
caplin.implement(caplinx.chart.decorator.EventDistributionDecorator, caplin.chart.ChartModelListener);

/** --------------------------------------------------------------------------------------------------------
 *                      caplin.chart.decorator.ChartDecorator Interface
 ---------------------------------------------------------------------------------------------------------- */

/**
 * @private
 * @see caplin.chart.decorator.ChartDecorator#setChartView
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.setChartView = function(oChartView)
{	
	this.m_oChartView = oChartView;
	this.m_oChartView.addChartViewListener(this);
	this.m_oChartModel = this.m_oChartView.getChartModel();
	this.m_oChartModel.addChartModelListener(this);
};


/** --------------------------------------------------------------------------------------------------------
 *                            caplin.chart.ChartViewListener Interface
 ---------------------------------------------------------------------------------------------------------- */

/** 
 * @private
 * @see caplin.chart.ChartViewListener#onPointDoubleClicked
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onPointDoubleClicked = function(oSeries)
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	var oEvent = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries( oSeries );
	OpenAjax.hub.publish("chart." + sChannel + ".pointDoubleClicked", oEvent );
	OpenAjax.hub.publish("chart." + sChannel + ".subjectSelected", oEvent );
};



/** 
 * @private
 * @see caplin.chart.ChartViewListener#onChartViewClose
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onChartViewClose = function()
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	OpenAjax.hub.publish("chart." + sChannel + ".closed");
};

/** 
 * @private
 * @see caplin.chart.ChartViewListener#onSeriesSelected
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onSeriesSelected = function(oSeries)
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	var oEvent = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries( oSeries );
	OpenAjax.hub.publish("chart." + sChannel + ".subjectSelected", oEvent);
};

/** 
 * @private
 * @see caplin.chart.ChartViewListener#onSeriesDeselected
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onSeriesDeselected = function(oSeries)
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	var oEvent = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries( oSeries );
	OpenAjax.hub.publish("chart." + sChannel + ".subjectDeselected", oEvent);
};

/** --------------------------------------------------------------------------------------------------------
 *                            caplin.chart.ChartModelListener Interface
 ---------------------------------------------------------------------------------------------------------- */

/** 
 * @private
 * @see caplin.chart.ChartModelListener#onSeriesAddedToView
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onSeriesAdded = function(oSeries, bAddtionalSeriesWillBeUpdated)
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	var oEvent = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries( oSeries );
	
	OpenAjax.hub.publish("chart." + sChannel + ".subjectAdded", oEvent);
};

/** 
 * @private
 * @see caplin.chart.ChartModelListener#onSeriesRemovedFromView
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onSeriesRemoved = function(oSeries, bAdditionalSeriesWillBeRemoved)
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	
	var oEvent = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries( oSeries );
	oEvent.additionalSeriesWillBeRemoved = bAdditionalSeriesWillBeRemoved;
	
	OpenAjax.hub.publish("chart." + sChannel + ".subjectRemoved", oEvent);
};

/** 
 * @private
 * @see caplin.chart.ChartModelListener#onSeriesUpdatedInView
 */
caplinx.chart.decorator.EventDistributionDecorator.prototype.onSeriesUpdated = function(oSeries, bAddtionalSeriesWillBeUpdated)
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oChartView );
	var oEvent = caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries( oSeries );
	OpenAjax.hub.publish("chart." + sChannel + ".subjectUpdated", oEvent);
};

/** --------------------------------------------------------------------------------------------------------
 *                            Private Methods
 ---------------------------------------------------------------------------------------------------------- */

/**
 * @private
 * @param {Object} oSeries
 */
caplinx.chart.decorator.EventDistributionDecorator._$createEventObjectForSeries = function( oSeries )
{
	var oEvent = {	"id": oSeries.getId(),
					"title": oSeries.getTitle(),
					"subject": oSeries.getSubject(),
					"data":oSeries.getSeriesData(),
					"isKeySeries":oSeries.hasRelatedSeries(),
					"metaData":oSeries.getMetaData()};			
	return oEvent;
};