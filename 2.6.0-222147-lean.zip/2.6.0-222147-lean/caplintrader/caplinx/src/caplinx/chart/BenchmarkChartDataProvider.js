/**
 * @fileoverview
 * Defines caplinx.chart.BenchmarkChartDataProvider class.
*/

caplin.namespace("caplinx.chart");

caplin.include("caplin.chart.ChartDataProvider", true);
caplin.include("caplin.core.Observable");
caplin.include("caplin.core.Exception");
caplin.include("caplin.chart.ChartSeriesRequest");
caplin.include("caplin.chart.ChartSeries");
caplin.include("caplin.chart.WebServiceChartDataProvider");
caplin.include("caplin.chart.util.WebServiceBenchmarkProvider", true);
caplin.include("caplin.chart.RttpChartDataProvider");
caplin.include("caplin.core.XmlParser");
caplin.include("caplin.core.StringBuilder");

/**
 * Constructs a new <code>BenchmarkChartDataProvider</code> with the specified configuration
 * object.
 * 
 * @class
 * This class implements the {@link caplin.chart.ChartDataProvider} interface.
 * It is used by the {@link caplin.chart.ChartModel} class to request raw data
 * for a given instrument.
 * 
 * <p>After receiving a request for some data, this class then makes an AJAX request from
 * a web service specified by the sWebServiceUrl argument of its constructor.</p>
 * 
 * <p>Upon receiving the raw data after a request, this class then notifies all its observers,
 * passing on the raw data set.</p>
 * 
 * @param {Map} oConfig Web service configuration such as URL to the web service.
 *
 * @class
 * @constructor
 * @implements caplin.chart.ChartDataProvider
 */
caplinx.chart.BenchmarkChartDataProvider = function(oConfig, pInitialRequests)
{
	/** @private */
	this.m_oObservable = new caplin.core.Observable();
	
	/** @private */
	this.m_mBenchmarkToRelatedSubjects = {};
	
	/** @private */
	this.m_mSubjectToBenchmark = {};
	
	/** @private */
	this.m_oSubjectMapper = null;
	
	/** @private */
	this.m_sInstrumentSubjectMatcher = oConfig.instrumentSubjectMatcher;
	
	this._setupBenchmarkRelationShips(oConfig);
	
	/** @private */
	this.m_mBenchmarkToSeries = {};
	
	/** @private */
	this.m_mPendingRelatedSeries = {};
	
	/** @private */
	this.m_pRequests = [];
	
	/** @private */
	this.m_pInitialRequests = (pInitialRequests) || [];
	
	var oMappersConfig = oConfig.subjectMappers;
	this._setupSubjectMappers(oMappersConfig);
	
	var oDataProvidersConfig = oConfig.internalDataProviders;
	this._setupDataProviders(oDataProvidersConfig);	
};
caplin.implement(caplinx.chart.BenchmarkChartDataProvider, caplin.chart.ChartDataProvider);

/** --------------------------------------------------------------------------------------------------------
 *             caplin.chart.ChartDataProvider Interface Methods
 ---------------------------------------------------------------------------------------------------------- */

/**
 * Called when the model is ready to receive data
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.initialize = function()
{
	for (var i = 0, l = this.m_pInitialRequests.length; i < l; i++) {
		oRequest = this.m_pInitialRequests[i];
		this.requestSeries(oRequest);
	}
}

/** 
 * Use this method to request a new series from the underlying {@link caplin.chart.WebServiceChartDataProvider}
 * and {@link caplin.chart.RttpChartDataProvider}
 * 
 * @param {caplin.chart.ChartSeriesRequest} oRequest Defines query to be made by the this data provider
 * to the underlying dataproviders. The filter defines various name value pairs that the data provider will interpret, request
 * data for the series and push the data back into the chart model and then the view to be plotted.
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.requestSeries = function(oRequest)
{
	if ((oRequest instanceof caplin.chart.ChartSeriesRequest) === false) 
	{
		throw new caplin.core.Exception("BenchmarkChartDataProvider expected a caplin.chart.ChartSeriesRequest parameter", "caplinx.chart.BenchmarkChartDataProvider.requestSeries");
	}
	
	// If we have a data provider id, this request should only go to one data provider
	var sDataProviderId = oRequest.getDataProviderId()
	var sSubject = oRequest.getSubject();
	
	// If we are not requesting an FI instrument, this must be a new benchmark (webservice) request
	// e.g. The user may be requesting a benchmark that is already displayed, but for a different date.
	if (!sDataProviderId && sSubject.match(this.m_sInstrumentSubjectMatcher) === null) {
		sDataProviderId = "webservice";
		oRequest.setDataProviderId(sDataProviderId);
	}
	
	if (sDataProviderId) {
		// Note. We do not use subject mappers, and we do not clone the request if we know which 
		// data provider to use. We are assuming that as we know this the request has been serialised, 
		// and we have already mapped the subject.
		this._sendRequestDirectlyToDataProvider(oRequest, sDataProviderId);
	} else {
		this._distributeRequestToAllDataProviders(oRequest);	
	}	
};

/**
 * The {@link caplin.chart.ChartModel} notfied this dataprovider when a series is removed by calling
 * this method. When this happens, any references to the removed series need to be cleaned up.
 * 
 * @param {caplin.chart.ChartSeries} oSeries
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.removeSeries = function(oSeries)
{
	var oRequest = oSeries.$_getRequest();
	
	// Remove the request for this series from out list of requests
	for (var i = 0, l = this.m_pRequests.length; i < l; i++) {
		if (oRequest === this.m_pRequests[i]) {
			this.m_pRequests.splice(i, 1);
			break;
		}
	}
		
	// Remove our reference to the series object. Note we have to loop through the benchmark to series map
	// As we may have multiple series objects that have the same subject
	for (var sSubject in this.m_mBenchmarkToSeries) {
		var oSeriesToRemove = this.m_mBenchmarkToSeries[sSubject];
		if (oSeries === oSeriesToRemove) {
			delete this.m_mBenchmarkToSeries[sSubject];
			break;
		}
	}
	
	// Notfify the data providers that these series have been removed, in case they need to clean
	// up any caches they may have created.
	var sDataProviderId = oRequest.getDataProviderId()
	
	if (sDataProviderId) {
		// If this series request has a specific data provider id, only notify that data provider
		if (sDataProviderId === "rttp") {
			this.m_oRttpDataProvider.removeSeries(oSeries);
		} else if (sDataProviderId === "webservice") {
			this.m_oWebServiceDataProvider.removeSeries(oSeries);
		}
	} else {
		this.m_oWebServiceDataProvider.removeSeries(oSeries);
		this.m_oRttpDataProvider.removeSeries(oSeries);	
	}		
};

/**
 * Interface method
 * @see caplin.chart.ChartDataProvider.prototype#addChartDataProviderListener
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.addChartDataProviderListener = function(oListener)
{
	this.m_oObservable.addObserver(oListener);
};

/**
 * Interface method
 * @see caplin.chart.ChartDataProvider.prototype#removeChartDataProviderListener
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.removeChartDataProviderListener = function(oListener)
{
	this.m_oObservable.removeObserver(oListener);
};

/** --------------------------------------------------------------------------------------------------------
 *                            caplin.chart.ChartDataProviderListener Interface
 ---------------------------------------------------------------------------------------------------------- */

/** 
 * Called by a data provider when data has arrived.
 * @param {Array} pChartSeries An array of {@see caplin.chart.ChartSeries}
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.onSeriesDataReceived = function(pChartSeries)
{
	for (var i = 0, l = pChartSeries.length; i < l; i++) {
		var oSeries = pChartSeries[i];
		var sSubject = oSeries.getSubject();
		
		if (this.m_mBenchmarkToRelatedSubjects[sSubject]) {
		
			if (this.m_mBenchmarkToSeries[sSubject]) {
				//If this is a bechmark, and we already have a benchmark for this subject, add it as related
				this.m_mBenchmarkToSeries[sSubject].addRelatedSeries(oSeries);
			} else {
				this.m_mBenchmarkToSeries[sSubject] = oSeries;			
				// if this is a benchmark series then simply inform the model
				this.m_oObservable.notifyObservers("onSeriesDataReceived", [[oSeries]]);
				
				// add any pending related series
				if (this.m_mPendingRelatedSeries[sSubject]) {
					var pRelated = this.m_mPendingRelatedSeries[sSubject];
					for (var j = 0, k = pRelated.length; j < k; j++) {
						var oRelatedSeries = pRelated[j];
						oSeries.addRelatedSeries(oRelatedSeries);
					}
					delete this.m_mPendingRelatedSeries[sSubject];
				}	
			}
				
						
		} else {
			
			// this is a point. see whether we have received the benchmark. if we have, add it as a related series
			// otherwise add it to a pending list			
			var sBenchmark = this.m_mSubjectToBenchmark[sSubject];
			if (this.m_mBenchmarkToSeries[sBenchmark]) {
				var oBenchmark = this.m_mBenchmarkToSeries[sBenchmark];
				oBenchmark.addRelatedSeries(oSeries);
			} else {
				if (this.m_mPendingRelatedSeries[sBenchmark]) {
					this.m_mPendingRelatedSeries[sBenchmark].push(oSeries);
				} else {
					this.m_mPendingRelatedSeries[sBenchmark] = [oSeries];
				}
			}
			
		}
	}
	
};

/** 
 * Called by a data provider when data has arrived.
 * @param {Array} pChartSeries An array of {@see caplin.chart.ChartSeries}
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.onError = function(oError)
{
	// might need to cleanup state
	this.m_oObservable.notifyObservers("onError", [oError]);
};

/**
 * Interface method
 * @see caplin.chart.ChartDataProvider.prototype#addChartDataProviderListener
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.terminateUpdates = function()
{
	this.m_oSubjectMapper.terminateUpdates();
	this.m_oWebServiceDataProvider.terminateUpdates();
};


/** --------------------------------------------------------------------------------------------------------
 *             Private Methods
 ---------------------------------------------------------------------------------------------------------- */
	
/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._distributeRequestToAllDataProviders = function(oRequest)
{	
	// Map the subject and send the request to the webservice data provider
	var sSubject = oRequest.getSubject();
	
	var self = this;
	
	var successCallback = function(sMappedSubject)
	{
		if (self.m_mBenchmarkToRelatedSubjects[sMappedSubject]) {
			self.m_mBenchmarkToRelatedSubjects[sMappedSubject][sSubject] = true;
		} else {
			self.m_mBenchmarkToRelatedSubjects[sMappedSubject] = {};
			self.m_mBenchmarkToRelatedSubjects[sMappedSubject][sSubject] = true;
		}
		
		self.m_mSubjectToBenchmark[sSubject] = sMappedSubject;
		self._mappedSubjectReceived(sMappedSubject, oRequest);
	};
	
	var failureCallback = function(sMessage, sMethod) 
	{
		var oError = new caplin.core.Exception(sMessage, sMethod);
		self.m_oObservable.notifyObservers("onError", [oError]);
	};
	
	// Map the subject, so we request the benchmark subject, rather than the rttp subject
	this.m_oSubjectMapper.mapSubject(sSubject, successCallback, failureCallback);
}	

caplinx.chart.BenchmarkChartDataProvider.prototype._mappedSubjectReceived = function(sMappedSubject, oRequest)
{
	// Now that we have received the mapped subject, m_mSubjectToBenchmark will have been populated
	// and we can request the related point
	this._distributeRequestToRttpDataProvider(oRequest);
	
	// Request the benchmark series
	var oWebServiceRequest = oRequest.clone();
	oWebServiceRequest.setDataProviderId("webservice");
	oWebServiceRequest.setSubject(sMappedSubject);
	
	// If we have already requested this benchmark, dont do it again
	var oRequest = this._getMatchingRequest(oWebServiceRequest);
	if (!oRequest) {
		oRequest = oWebServiceRequest;
		// Request the series
		this.m_oWebServiceDataProvider.requestSeries(oRequest);
		this.m_pRequests.push(oRequest);
	}	
}	

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._distributeRequestToRttpDataProvider = function(oRequest)
{	
	var oRttpRequest = oRequest.clone();
	oRttpRequest.setDataProviderId("rttp");
	
	if (!this._isDuplicateRequest(oRttpRequest)) {
		this.m_oRttpDataProvider.requestSeries(oRttpRequest);	
		this.m_pRequests.push(oRttpRequest);
	}	
}		

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._sendRequestDirectlyToDataProvider = function(oRequest, sDataProviderId)
{
	if (!this._isDuplicateRequest(oRequest)) {
		if (sDataProviderId === "rttp") {
			this.m_oRttpDataProvider.requestSeries(oRequest);
		} else if (sDataProviderId === "webservice") {
			this.m_oWebServiceDataProvider.requestSeries(oRequest);
		}
		this.m_pRequests.push(oRequest);			
	}	
}

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._getMatchingRequest = function(oRequest)
{
	for (var i = 0, l = this.m_pRequests.length; i < l; i++) {
		if (oRequest.equals(this.m_pRequests[i])) {
			return this.m_pRequests[i];
		}
	}
	return null;
}

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._isDuplicateRequest = function(oRequest)
{
	for (var i = 0, l = this.m_pRequests.length; i < l; i++) {
		if (oRequest.equals(this.m_pRequests[i])) {
			return true;
		}
	}
	return false;
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._setupSubjectMappers = function(oConfig)
{
	if (!oConfig || !oConfig.subjectMapper) {
		throw new caplin.core.Exception("BenchmarkChartDataProvider expects configuration for the underlying subject mapper", "caplinx.chart.BenchmarkChartDataProvider._setupSubjectMappers");
	}
	
	var oMapperConfig = oConfig.subjectMapper;
	
	if (!oMapperConfig.className) {
		throw new caplin.core.Exception("BenchmarkChartDataProvider expects a className property to be set in the subject mapper configuration", "caplinx.chart.BenchmarkChartDataProvider._setupSubjectMappers");
	}
	
	var sMapperClass = oMapperConfig.className;
	var fClass = caplin.getClass(sMapperClass, {
		context:"BenchmarkChartDataProvider",
		load:true
	});
	var oSubjectMapper = new fClass(oMapperConfig.config);
	this.$_setSubjectMapper(oSubjectMapper);
}

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._setupDataProviders = function(oConfig)
{
	if (!oConfig) {
		throw new caplin.core.Exception("BenchmarkChartDataProvider expectes configuration for the underlying dataproviders", "caplinx.chart.BenchmarkChartDataProvider._setupDataProviders");
	}
	
	if (!oConfig.webServiceDataProvider) {
		throw new caplin.core.Exception("BenchmarkChartDataProvider expectes configuration for the underlying caplin.chart.WebServiceChartDataProvider", "caplinx.chart.BenchmarkChartDataProvider._setupDataProviders");		
	}
	
	if (!oConfig.rttpDataProvider) {
		throw new caplin.core.Exception("BenchmarkChartDataProvider expectes configuration for the underlying caplin.chart.RttpChartDataProvider", "caplinx.chart.BenchmarkChartDataProvider._setupDataProviders");		
	}
	
	var oWebServiceDataProvider = new caplin.chart.WebServiceChartDataProvider(oConfig.webServiceDataProvider);
	this.$_setWebServiceDataProvider(oWebServiceDataProvider);
	
	var oRttpDataProvider = new caplin.chart.RttpChartDataProvider(oConfig.rttpDataProvider);
	this.$_setRttpDataProvider(oRttpDataProvider);
}

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._setupBenchmarkRelationShips = function(oConfig)
{
	if (oConfig && oConfig.relationships 
		&& oConfig.relationships.benchmarkToRelatedSubjects 
		&& oConfig.relationships.benchmarkToRelatedSubjects.benchmark) {
			
			var pBenchmarks = oConfig.relationships.benchmarkToRelatedSubjects.benchmark;
			
			if (pBenchmarks.length) {
				// if there are more than one, it will be an array	
				for (var i = 0, l = pBenchmarks.length; i < l; i++) {
					var oBenchmark = pBenchmarks[i];
					var pRelations = oBenchmark.relation;					
					this._addRelations(oBenchmark.subject, pRelations);					
				}
			} else {
				// otherwise it will be an object				
				var pRelations = pBenchmarks.relation;				
				this._addRelations(pBenchmarks.subject, pRelations);							
			}
			
		}	

};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._addRelations = function(sBenchmark, pRelations)
{
	this.m_mBenchmarkToRelatedSubjects[sBenchmark] = {}; 

	if (pRelations.length) {
		for (var j = 0, k = pRelations.length; j < k; j++) {
			this.m_mBenchmarkToRelatedSubjects[sBenchmark][pRelations[j].subject] = true;
			this.m_mSubjectToBenchmark[pRelations[j].subject] = sBenchmark;
		}
	} else {
		this.m_mBenchmarkToRelatedSubjects[sBenchmark][pRelations.subject] = true;
		this.m_mSubjectToBenchmark[pRelations.subject] = sBenchmark;
	}
}

/** --------------------------------------------------------------------------------------------------------
 *             Package Private Methods
 ---------------------------------------------------------------------------------------------------------- */

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_setWebServiceDataProvider = function(oDataProvider)
{
	this.m_oWebServiceDataProvider = oDataProvider;
	this.m_oWebServiceDataProvider.addChartDataProviderListener(this);
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_setRttpDataProvider = function(oDataProvider)
{
	this.m_oRttpDataProvider = oDataProvider;
	this.m_oRttpDataProvider.addChartDataProviderListener(this);
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_getWebServiceDataProvider = function()
{
	return this.m_oWebServiceDataProvider;
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_getRttpDataProvider = function()
{
	return this.m_oRttpDataProvider;
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_setSubjectMapper = function(oSubjectMapper)
{
	this.m_oSubjectMapper = oSubjectMapper;
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_setBenchmarkToRelatedSubjectsMap = function(mBenchmarkToRelatedSubjects)
{
	this.m_mBenchmarkToRelatedSubjects = mBenchmarkToRelatedSubjects;	
	this.m_mSubjectToBenchmark = {};
	
	for (var sBenchmark in this.m_mBenchmarkToRelatedSubjects) {
		var mRelatedSubjects = this.m_mBenchmarkToRelatedSubjects[sBenchmark];
		for (var sSubject in mRelatedSubjects) {
			this.m_mSubjectToBenchmark[sSubject] = sBenchmark;
		}
	}
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_getBenchmarkToRelatedSubjectsMap = function()
{
	return this.m_mBenchmarkToRelatedSubjects;	
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.$_getSubjectToBenchmarkMap = function()
{
	return this.m_mSubjectToBenchmark;
};

/** --------------------------------------------------------------------------------------------------------
 *             Serialization Support
 ---------------------------------------------------------------------------------------------------------- */

/**
 * Gets the serialized state of the model. This includes any series or points plotted on the
 * chart.
 * 
 * @return {String} and XML representation of the state of the ChartModel 
 */
caplinx.chart.BenchmarkChartDataProvider.prototype.getSerializedState = function()
{
	var oSerializationBuilder = new caplin.core.StringBuilder();
	
	oSerializationBuilder.append('<benchmarkDataProvider>\n');
	
	this._serializeRelationships(oSerializationBuilder);
	
	oSerializationBuilder.append('</benchmarkDataProvider>\n');
		
	return oSerializationBuilder.toString();
};

/**
 * @private
 */
caplinx.chart.BenchmarkChartDataProvider.prototype._serializeRelationships = function(oSerializationBuilder)
{
	oSerializationBuilder.append('\t<relationships>\n');
	oSerializationBuilder.append('\t\t<benchmarkToRelatedSubjects>\n');
		
	for (var sBenchmark in this.m_mBenchmarkToRelatedSubjects) {
		
		oSerializationBuilder.append('\t\t<benchmark subject="' + sBenchmark + '">\n');
		
		var pRelatedSubjects = this.m_mBenchmarkToRelatedSubjects[sBenchmark];
		
		for (var sSubject in pRelatedSubjects) {
			oSerializationBuilder.append('\t\t\t<relation subject="' + sSubject + '"/>\n');
		}
		
		oSerializationBuilder.append('\t\t</benchmark>\n');
		
	}
		
	oSerializationBuilder.append('\t\t</benchmarkToRelatedSubjects>\n');
	oSerializationBuilder.append('\t</relationships>\n');
}
