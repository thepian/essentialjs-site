/**
 * @fileoverview
 * Creates a Chat Widget.
 * <p> Public Chat Rooms
 * All public chats are conducted within the directory: /CHAT
 * Once a user enters in a name for the chat room, a chat object gets created within the /CHAT directory, allowing users to view and contribute to the object. e,g /CHAT/BONDS
 * </p>
 * <h3>Private Chat Room</h3>
 * <p>
 * All private chats are conducted within the directory :/PRIVATECHAT
 * Each user creates a private chat directory once the Chat Widget is open. For example, user1@caplin.com automatically creates private chat directory :/PRIVATECHAT/user1@caplin.com
 * </p>
 * <p>
 * Creating a private chatroom:
 * A user has to enter the name of the chatroom and invite other users in order to conduct a private chat. If the user enters ‘Bonds’ and invites user2@caplin.com and user3@caplin.com, the following SL4B messages are sent.
 * Create the Bonds chat room:
 * CREATE /PRIVATECHAT/user1@caplin.com/BONDS (type CHAT object) - this creates a CHAT object which will enable other users to retrieve and contribute to this CHAT object.
 * </p>
 * <p>
 * Sending the invitations:
 * CREATE /PRIVATECHAT/user2@caplin.com/user1@caplin.com-BONDS (type: RECORD) ack=0 – invitation for user2@caplin.com
 * CREATE /PRIVATECHAT/user3@caplin.com/user1@caplin.com-BONDS (type: RECORD) ack=0 – invitation for user3@caplin.com
 * Once user2 and user3 receive the directory update and realizes it received a SL4B record update, it knows it’s an invitation.
 * To prevent invitation confirmation pop-up appearing continously, the invitation is examined to check if the user has received this invitation before by examining the ack flag.
 * Once the user receives an invitation, the 'ack' flag is set to 1 as an acknowledgement.
 * The ‘{username}-{chatroom}’ is extracted from the object name and now, user2 and user3 can receive updates and contribute to the chat object using : /PRIVATECHAT/{username}/{chatroom}.
 * </p>
 */

caplin.namespace("caplinx.chat");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.component.Component", true);
caplin.include("caplin.component.ComponentFactory", true);
caplin.include("caplinx.chat.ChatChannelManager");
caplin.include("caplinx.utilities.HTMLTemplate");
caplin.include("caplinx.chat.LanguageFactory");
caplin.include("caplinx.utilities.CreateCaptionAccessor");
caplin.include("caplinx.utilities.FixIEContainerWidth");
caplin.include("caplin.widget.formcontrols.DropDownBox");
caplin.include("caplin.widget.formcontrols.ThreeImageButton");
caplin.include("caplin.dom.Utility");
caplin.include("caplin.widget.events.EventManager", true);

/**
 * @class Creates a Chat Widget which allows one to conduct private and public chatrooms.
 * @extends SL4B_AbstractSubscriber - used to subscribe to the Liberator using SL4B API
 *
 */
caplinx.chat.Chat = function(sRoom)
{
	caplinx.utilities.CreateCaptionAccessor(this, 'setCaption', 'Chatroom');

	this.m_sObjectName = null;
	this.m_bIsSL4BReady = false;
	this.m_sUserName = SL4B_Accessor.getCredentialsProvider().getUsername();
	this.m_ePublicChatRoomDropdownWidget = null;
	this.m_bCreatedPublicChatRoom = false;

	this.m_bCreatedPrivateChatRoom = false;
	this.m_sUserPrivateChatDirectory = null;
	this.m_eUsersDropdownWidget = null;
	this.m_sPrivateChatObjectsAlreadySubscribed = "";
	this.m_oPrivateChatDirectoryPrefix = new RegExp("^"+caplinx.chat.Chat.PRIVATE_CHAT_DIRECTORY+"/"+this.m_sUserName+"/","g");

	this.m_pUsersInvitedToPrivateChat= [];
	this.m_eUsersInvited = null;
	this.m_eUsersInvitedContainer = null;
	this.m_eUserDropDownContainer = null;

	this.m_sInitialChatroom = sRoom;

	this.m_oChatChannelManager = caplinx.chat.ChatChannelManager;

	this.m_oElement = document.createElement('div');

	this.m_oTemplate = new caplinx.utilities.HTMLTemplate('source/caplinx/chat/chat.html');
	caplin.dom.Utility.setInnerHtml(this.m_oElement, this.m_oTemplate.html);

	this.m_sImgDirectory = 'source/images';
	
	this.logInButton = new caplin.widget.formcontrols.ThreeImageButton(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.LogIn"), this.m_sImgDirectory + '/buttons/capbutton', '');
	this.logInButton.setClassName('chatbutton');

	this.logOutButton = new caplin.widget.formcontrols.ThreeImageButton(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.LogOut"), this.m_sImgDirectory + '/buttons/capbutton', '');
	this.logOutButton.setClassName('chatbutton');

	this.sendButton = new caplin.widget.formcontrols.ThreeImageButton(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.Send"), this.m_sImgDirectory + '/buttons/capbutton', '');
	this.sendButton.setClassName('chatbutton');

	var fUserOnlineAction = caplin.dom.Utility.createMethodEventListener(this, 'addUserToDropdown');
	caplin.widget.events.GlobalEventManager.registerAsEventListener("ChatUserOnline", fUserOnlineAction);
	var fUserOfflineAction = caplin.dom.Utility.createMethodEventListener(this, 'removeUserFromDropdown');
	caplin.widget.events.GlobalEventManager.registerAsEventListener("ChatUserOffline", fUserOfflineAction);
	var fPublicChatOpenedAction = caplin.dom.Utility.createMethodEventListener(this, 'addPublicChatToDropdown');
	caplin.widget.events.GlobalEventManager.registerAsEventListener("PublicChatOpened", fPublicChatOpenedAction);
	var fPublicChatClosedAction = caplin.dom.Utility.createMethodEventListener(this, 'removePublicChatFromDropdown');
	caplin.widget.events.GlobalEventManager.registerAsEventListener("PublicChatClosed", fPublicChatClosedAction);
	var fPrivateChatDeletedAction = caplin.dom.Utility.createMethodEventListener(this, 'privateChatDeleted');
	caplin.widget.events.GlobalEventManager.registerAsEventListener("PrivateChatDeleted", fPrivateChatDeletedAction);


	this.oRttpProvider = SL4B_Accessor.getRttpProvider();

	this.initialise();
};

caplinx.chat.Chat.prototype = new SL4B_AbstractSubscriber;

caplin.implement(caplinx.chat.Chat, caplin.component.Component);

/**
 * @private
 */
caplinx.chat.Chat.PUBLIC_CHAT_DIRECTORY = "/CHAT";

/**
 * @private
 */
caplinx.chat.Chat.PRIVATE_CHAT_DIRECTORY = "/PRIVATECHAT";

/**
 * @private
 */
caplinx.chat.Chat.CREATE_PUBLIC_CHATROOM = "create_public_chatroom";

/**
 * @private
 */
caplinx.chat.Chat.CREATE_PRIVATE_CHATROOM = "create_private_chatroom";

/**
 * @private
 */
caplinx.chat.Chat.RESET_INVITATIONS = "reset";

/**
 * @private
 */
caplinx.chat.Chat.PUBLIC_CHAT_DIRECTORY_PREFIX = new RegExp("^"+caplinx.chat.Chat.PUBLIC_CHAT_DIRECTORY+"/","g");

caplinx.chat.Chat.prototype.ready = function()
{
	this.m_bIsSL4BReady = true;
};

///////////////////////////////////////////////////////////////////////////////
// WEBCENTRIC API
///////////////////////////////////////////////////////////////////////////////

caplinx.chat.Chat.prototype.getElement = function()
{
	return this.m_oElement;
};

caplinx.chat.Chat.prototype.onOpen = function(nWidth, nHeight)
{
//	this._setUpPrivateChatChannel();
//	this._setUpPublicChatChannel();

	// create actions
	var fLogInAction = caplin.dom.Utility.createMethodEventListener(this, '_logIn');
	var fLogOutAction = caplin.dom.Utility.createMethodEventListener(this, '_logOut');
	var fSendAction = caplin.dom.Utility.createMethodEventListener(this, '_sendMessage');

	// login screen
	this.m_eLoginScreen = this.m_oTemplate.getElementById('loginscreen');

	// Public Chatroom textbox
	this.m_ePublicChatroomInputContainer = this.m_oTemplate.getElementById('publicchatinputcontainer');
	this.m_ePublicRoomInput = this.m_oTemplate.getElementById('roominput');
	this.m_ePublicRoomInput.onkeyup = fLogInAction;

	// Private Chatroom textbox
	this.m_ePrivateChatroomInputContainer = this.m_oTemplate.getElementById('privatechatinputcontainer');
	this.m_ePrivateRoomInput = this.m_oTemplate.getElementById('privateroominput');
	this.m_eUsersInvitedContainer = this.m_oTemplate.getElementById('usersinvitedcontainer');
	this.m_eUsersInvited = this.m_oTemplate.getElementById('users_invited');
	this.m_eUserDropDownContainer = this.m_oTemplate.getElementById('userdropdowncontainer');
	this.m_ePrivateRoomInput.onkeyup = fLogInAction;

    // Chatroom Dropdown
	this._initializeChatroomDropdown();

	this._initializeUsersDropdown();

	// chat screen
	this.m_eChatScreen = this.m_oTemplate.getElementById('chatscreen');

	// message display
	this.m_eMessageArea = this.m_oTemplate.getElementById('messagearea');
	// message entry
	this.m_eMessageEntrySection = this.m_oTemplate.getElementById('messageentrysection');
	this.m_eMessageInput = this.m_oTemplate.getElementById('messageinput');
	this.m_eMessageInput.onkeyup = fSendAction;

	// send button
	this.sendButton.addOnClickListener(fSendAction);
	var eSendButtonHolder = this.m_oTemplate.getElementById('messagesendbutton');
	eSendButtonHolder.parentNode.replaceChild(this.sendButton.getElement(), eSendButtonHolder);

	// log in button
	this.logInButton.addOnClickListener(fLogInAction);
	var eLogInButtonHolder = this.m_oTemplate.getElementById('loginbutton');
	eLogInButtonHolder.parentNode.replaceChild(this.logInButton.getElement(), eLogInButtonHolder);

	// log out button
	this.logOutButton.addOnClickListener(fLogOutAction);
	var eLogOutButtonHolder = this.m_oTemplate.getElementById('logoutbutton');
	eLogOutButtonHolder.parentNode.replaceChild(this.logOutButton.getElement(), eLogOutButtonHolder);

	// calculate amount to adjust input bar by
	var nUsedOuterWidth = this.m_oElement.offsetWidth - this.m_eMessageEntrySection.offsetWidth;
	var nUsedInnerWidth = this.m_oTemplate.getElementById('chatbuttoncontainer').offsetWidth;
	this.m_nInputBarAdjustValue = nUsedOuterWidth + nUsedInnerWidth;

	// go to LogIn screen
	caplin.dom.Utility.addClassName(this.m_eChatScreen, 'chathidden');
	caplin.dom.Utility.removeClassName(this.m_eLoginScreen, 'chathidden');

	// set element start sizes
	this.onResize(nWidth, nHeight);

	if(this.m_sInitialChatroom)
	{
		this._removeCurrentChatChannel();
		var pChatRoomParts = this.m_sInitialChatroom.split('/');
		var sChatRoomName = pChatRoomParts[pChatRoomParts.length - 1];
		this.m_sObjectName = this.m_sInitialChatroom;
		this._displayChatRoom(sChatRoomName);
		this.oRttpProvider.getObjects(this, this.m_sObjectName);

	}
};

caplinx.chat.Chat.prototype.onClose = function()
{
	this._removeCurrentChatChannel();
};

caplinx.chat.Chat.prototype.onResize = function(nWidth, nHeight)
{
	// adjust for minimum width
	if(nWidth < 310)
	{
		nWidth = 310;

		// HACK - access webcentric parentNode of m_oElement container
		var eContentArea = this.m_oElement.parentNode;
		var nScrollBarHeight = eContentArea.offsetHeight - eContentArea.clientHeight;
		nHeight = nHeight - nScrollBarHeight;

		caplinx.utilities.fixIEContainerWidth(this.getElement());
	}

	// adjust widths
	if(document.all)
	{
		this.m_eMessageInput.style.width = (nWidth - this.m_nInputBarAdjustValue - 6) + 'px';
		this.m_eMessageArea.style.width = (nWidth - 14) + 'px';
	}
	else
	{
		this.m_eMessageInput.style.width = (nWidth - this.m_nInputBarAdjustValue - 4) + 'px';
	}


	var newMessageHeight = nHeight > 100? nHeight - 100: 1;

	this.m_eMessageArea.style.height = newMessageHeight + 'px';
	this.m_oTemplate.getElementById('chatwrapper').style.width = nWidth + 'px';
};

caplinx.chat.Chat.prototype.getSerializedState = function()
{
	return '<chat></chat>';
};

caplinx.chat.Chat.createChatComponentFromXml = function(sXml)
{
	var pRoom = sXml.match(/<room>([^<]+)<\/room>/)
	var sRoom = null;
	if (pRoom && pRoom[1])
	{
		sRoom = pRoom[1];
	}
	return new caplinx.chat.Chat(sRoom);
};

caplinx.chat.Chat.onAfterClassLoad = function()
{
	caplin.component.ComponentFactory.registerComponent("chat", caplinx.chat.Chat.createChatComponentFromXml);
};
caplin.notifyAfterClassLoad(caplinx.chat.Chat);

caplinx.chat.Chat.prototype._getUserName = function(l_sUsername)
{
	return l_sUsername.replace(/-\d+$/, "");
};

caplinx.chat.Chat.prototype._addMessage = function(l_sTime, l_sUser, l_sMessage, l_nType)
{

	// We need to make sure the message is safe. - Don't want html injection.
	// This would also be where you'd explicitly allow <b>, <a> or <i> if you wanted.
	l_sMessage = decodeURI(l_sMessage);

	if (l_nType == 1)
	{
		var sMsgString = '<span>' + l_sUser + ': </span><span class="chattext">' + l_sMessage + '</span>';
	}
	else
	{
		var oChannelRegExp = /\/[^\/]+\/[^\/]+\//;
		var sMsgString = '<span style="color: green"> *** ' + l_sMessage.replace(oChannelRegExp,'') + ' *** </span>';
	}

	var eMsg = document.createElement('div');
	caplin.dom.Utility.setInnerHtml(eMsg, sMsgString);
	this.m_eMessageArea.appendChild(eMsg);

	this.m_eMessageArea.scrollTop = this.m_eMessageArea.scrollHeight - this.m_eMessageArea.clientHeight;
};



///////////////////////////////////////////////////////////////////////////////
// UI API
///////////////////////////////////////////////////////////////////////////////

caplinx.chat.Chat.prototype.addUserToDropdown = function(event)
{
	var sObjectName = event.objectName;
	if (this.m_eUsersDropdownWidget == null)
	{
	    // Chatroom Dropdown
		this._initializeUsersDropdown();
	}
	this.m_eUsersDropdownWidget.addOption(sObjectName, caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.InviteUser", [sObjectName]));
};

caplinx.chat.Chat.prototype.removeUserFromDropdown = function(event)
{
	var sObjectName = event.objectName;
	if (this.m_eUsersDropdownWidget == null)
	{
	    // Chatroom Dropdown
		this._initializeUsersDropdown();
	}
	this.m_eUsersDropdownWidget.setValue("");
	this.m_eUsersDropdownWidget.removeOption(sObjectName);
};

caplinx.chat.Chat.prototype.addPublicChatToDropdown = function(event)
{
	var sObjectName = event.objectName;
	if (this.m_ePublicChatRoomDropdownWidget == null)
	{
	    // Chatroom Dropdown
		this._initializeChatroomDropdown();
	}
	this.m_ePublicChatRoomDropdownWidget.addOption(sObjectName, caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.JoinPublicChatRoom", [decodeURI(sObjectName)]));
};

caplinx.chat.Chat.prototype.removePublicChatFromDropdown = function(event)
{
	var sObjectName = event.objectName;
	var sDirObjectName = event.dirObjectName;
	if (this.m_ePublicChatRoomDropdownWidget == null)
	{
	    // Chatroom Dropdown
		this._initializeChatroomDropdown();
	}
	this.m_ePublicChatRoomDropdownWidget.setValue("");
	this.m_ePublicChatRoomDropdownWidget.removeOption(sObjectName);

	var sFullObjectName = sDirObjectName + "/" +sObjectName;

	// Alert user that chat object has been deleted
	if (sFullObjectName == this.m_sObjectName && this.m_bCreatedPublicChatRoom === false)
	{
		caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.ChatRoomRemoved",[sObjectName]));
	}
};


caplinx.chat.Chat.prototype.chat = function(l_sObjectName, l_sTime, l_sUsername, l_sMessage, l_nStatus)
{
	var sStripObjectNamePrefix = l_sObjectName.replace(caplinx.chat.Chat.PUBLIC_CHAT_DIRECTORY_PREFIX,"");

	switch (l_nStatus)
	{
		case SL4B_ChatStatus.USER_SUBSCRIBED:
			this._addMessage(l_sTime, null, caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.UserJoined",[this._getUserName(l_sUsername), sStripObjectNamePrefix]), 0);
		break;
		case SL4B_ChatStatus.SUBSCRIBED:
			this.m_sUserName = this._getUserName(l_sUsername);
		break;
		case SL4B_ChatStatus.USER_UNSUBSCRIBED:
			this._addMessage(l_sTime, null, caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.UserLeft",[this._getUserName(l_sUsername), sStripObjectNamePrefix]), 0);
		break;
		case SL4B_ChatStatus.MESSAGE:
			this._addMessage(l_sTime, this._getUserName(l_sUsername), l_sMessage, 1);
		break;
	}
}

caplinx.chat.Chat.prototype._sendMessage = function(oEvent){

	oEvent = (oEvent)? oEvent : event;

	if (oEvent.keyCode === 13 || !oEvent.type)
	{
		var sMessage = this.m_eMessageInput.value;
		this.m_eMessageInput.value = '';
		this.m_eMessageInput.focus();
		// create a new contribution field data object
		var l_oContributionData = new SL4B_ContributionFieldData();

		l_oContributionData.addField('msg', encodeURI(sMessage));

		this.oRttpProvider.contribObject(this, this.m_sObjectName, l_oContributionData);
	}
};

caplinx.chat.Chat.prototype.privateChatDeleted = function(event)
{
	var sObjectName = event.objectName;
	var sChatObjectName = sObjectName.replace("-","/");

	// Extract {username}-{chatroom} from object name
	var pChatRoomDetails = sObjectName.split("-");

	if (pChatRoomDetails.length == 2 && this.m_sObjectName != null && this.m_sObjectName.indexOf(sChatObjectName) != -1)
	{
		var sChatRoomOwner = pChatRoomDetails[0];
		var sChatRoomName = pChatRoomDetails[1];

		// Remove object subscription as chatroom has been deleted
		this.oRttpProvider.removeObject(this.m_sObjectName);

		caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.UserDeletedChatRoom",[sChatRoomOwner, sChatRoomName]));
	}
}


///////////////////////////////////////////////////////////////////////////////
// PRIVATE HELPER METHODS
///////////////////////////////////////////////////////////////////////////////

caplinx.chat.Chat.prototype._logIn = function(event)
{
	var event = event ? event : window.event;

	if (event.keyCode === 13 || !event.type)
	{
		if(this.m_bIsSL4BReady)
		{
			var sChatRoomSelected = this.m_ePublicChatRoomDropdownWidget.getValue();

			if (sChatRoomSelected == caplinx.chat.Chat.CREATE_PRIVATE_CHATROOM)
			{
				sChatRoomSelected = this.m_ePrivateRoomInput.value;

				if (this.m_sUserName == sChatRoomSelected)
				{
					return caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.NoPrivateChatToSelf"));
				}

				if (this.m_pUsersInvitedToPrivateChat.length == 0)
				{
					return caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.NeedToInviteUsers",[sChatRoomSelected]));
				}

				this.m_sObjectName = caplinx.chat.Chat.PRIVATE_CHAT_DIRECTORY  + "/"+this.m_sUserName + "/" +  sChatRoomSelected;

				if (this._hasPrivateChatChannelAlreadyCreated(sChatRoomSelected) === false)
				{
					this.oRttpProvider.createObject(this.m_sObjectName, SL4B_ObjectType.CHAT);
					this.m_bCreatedPrivateChatRoom = true;
				}
				this._sendPrivateInvitations(sChatRoomSelected);
			}
			else if (sChatRoomSelected == caplinx.chat.Chat.CREATE_PUBLIC_CHATROOM)
			{
				sChatRoomSelected = this.m_ePublicRoomInput.value;

				if (typeof(sChatRoomSelected) !== 'string' || sChatRoomSelected === '')
				{
					return caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.SpecifyValidName"));
				}
				else if (this._dropdownContains(this.m_ePublicChatRoomDropdownWidget, sChatRoomSelected) === true)
				{
					return caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.ChatRoomAlreadyExists",[sChatRoomSelected]),"");
				}
				else
				{
					this.m_bCreatedPublicChatRoom = true;
					this.m_sObjectName = caplinx.chat.Chat.PUBLIC_CHAT_DIRECTORY  + "/" +  sChatRoomSelected;
					this.oRttpProvider.createObject(this.m_sObjectName, SL4B_ObjectType.CHAT);
				}
			}
			else
			{
				this.m_bCreatedPublicChatRoom = false;
				this.m_bCreatedPrivateChatRoom = false;
				this.m_sObjectName = caplinx.chat.Chat.PUBLIC_CHAT_DIRECTORY + "/" + sChatRoomSelected;
			}

			this.oRttpProvider.getObjects(this, this.m_sObjectName);

			this._displayChatRoom(sChatRoomSelected)
		}
		else
		{
			throw new Error('Sorry SL4b Not Ready.');
		}
	}
};

caplinx.chat.Chat.prototype._logOut = function()
{
	this._removeCurrentChatChannel();

	this.m_bCreatedPublicChatRoom = false;
	this.m_bCreatedPrivateChatRoom = false;

	// set caption
	this._modifyCaption(ct.i18n("cx.chat.chatroom.caption"));

	// go to login screen
	caplin.dom.Utility.addClassName(this.m_eChatScreen, 'chathidden');
	caplin.dom.Utility.removeClassName(this.m_eLoginScreen, 'chathidden');

	// clear message area
	this.m_eMessageArea.innerHTML = '';
	this.m_eMessageInput.value = '';
};

caplinx.chat.Chat.prototype._hasPrivateChatChannelAlreadyCreated = function(sUserName)
{
	return (this.m_sPrivateChatObjectsAlreadySubscribed.indexOf('|'+sUserName+'|') > -1);
};

caplinx.chat.Chat.prototype._sendPrivateInvitations = function(sChatRoom)
{
	var sInvitationObjectName;

	for (var nCount = 0; nCount < this.m_pUsersInvitedToPrivateChat.length; ++ nCount)
	{
		sInvitationObjectName= caplinx.chat.Chat.PRIVATE_CHAT_DIRECTORY  + "/"+this.m_pUsersInvitedToPrivateChat[nCount]+"/"+this.m_sUserName + "-" +  sChatRoom;

		this.oRttpProvider.createObject(sInvitationObjectName, SL4B_ObjectType.RECORD);

		// Send the initial handshake 'ack' to 0. 'ack' will be set to 1 once user receives message
		var oContributionData = new SL4B_ContributionFieldData();
		oContributionData.addField('ack', 0);

		// Create a date in the format YYYYMMDD
		var oToday = new Date();
		var sYear = oToday.getFullYear().toString();
		var sMonth = (oToday.getMonth() + 1).toString();
		if(sMonth.length === 1)
		{
			sMonth = '0' + sMonth;
		}
		var sDate = oToday.getDate().toString();
		if(sDate.length === 1)
		{
			sDate = '0' + sDate;
		}
		var sToday = sYear + sMonth + sDate;

		oContributionData.addField('timestamp',sToday);

		this.oRttpProvider.contribObject(this, sInvitationObjectName, oContributionData);
	}
};

caplinx.chat.Chat.prototype._removePrivateInvitations = function()
{
	if (this.m_pUsersInvitedToPrivateChat.length > 0)
	{

		var sChatRoomName = this.m_sObjectName.replace(this.m_oPrivateChatDirectoryPrefix,"");

		var sInvitationObjectName;

		for (var nCount = 0; nCount < this.m_pUsersInvitedToPrivateChat.length; ++ nCount)
		{
			sInvitationObjectName= caplinx.chat.Chat.PRIVATE_CHAT_DIRECTORY  + "/"+this.m_pUsersInvitedToPrivateChat[nCount]+"/"+this.m_sUserName + "-" + sChatRoomName;
			this.oRttpProvider.deleteObject(sInvitationObjectName);
		}

		this._resetInvitations();
	}
};

caplinx.chat.Chat.prototype._resetInvitations = function()
{
	this.m_pUsersInvitedToPrivateChat = [];
	this.m_eUsersInvited.innerHTML = "";
	this.m_eUsersDropdownWidget.setValue("");
};

caplinx.chat.Chat.prototype._displayChatRoom = function(sChatRoom)
{
	// set caption
	this._modifyCaption(ct.i18n("cx.chat.chatroom.caption_title") + " " + sChatRoom);

	// go to chat screen
	caplin.dom.Utility.addClassName(this.m_eLoginScreen, 'chathidden');
	caplin.dom.Utility.removeClassName(this.m_eChatScreen, 'chathidden');

	// change focus to message input
	this.m_eMessageInput.focus();
};

caplinx.chat.Chat.prototype._modifyCaption = function(sCaption)
{
	try
	{
		this.setCaption(sCaption);
	}
	catch (e)
	{
		// Do nothing as caption element  is not unique and will generate errors
		// if there are more than 1 chatroom on page
	}
};

caplinx.chat.Chat.prototype._initializeChatroomDropdown = function()
{
	if (this.m_ePublicChatRoomDropdownWidget == null)
	{
		var f_displayPublicChatInputBox = caplin.dom.Utility.createMethodEventListener(this, '_displayPublicChatInputBox');

		var eHolder = this.m_oTemplate.getElementById('chatrooms_dropdown');
		this.m_ePublicChatRoomDropdownWidget = new caplin.widget.formcontrols.DropDownBox({width:300});
		eHolder.appendChild( this.m_ePublicChatRoomDropdownWidget.getElement());

		this.m_ePublicChatRoomDropdownWidget.addOption("", ct.i18n("cx.chat.chatroom.room_dropdown"));
		this.m_ePublicChatRoomDropdownWidget.addOption(caplinx.chat.Chat.CREATE_PUBLIC_CHATROOM, ct.i18n("cx.chat.chatroom.create_public"));
		this.m_ePublicChatRoomDropdownWidget.addOption(caplinx.chat.Chat.CREATE_PRIVATE_CHATROOM, ct,i18n("cx.chat.chatroom.create_private"));

		var pPublicChats = this.m_oChatChannelManager.getPublicChats();

		for (var i = 0; i < pPublicChats.length; i++)
		{
			this.m_ePublicChatRoomDropdownWidget.addOption(pPublicChats[i], caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.JoinPublicChatRoom", [pPublicChats[i]]));
		}

		this.m_ePublicChatRoomDropdownWidget.setValue("");

		this.m_ePublicChatRoomDropdownWidget.addChangeListener(f_displayPublicChatInputBox);
	}
};

caplinx.chat.Chat.prototype._initializeUsersDropdown = function()
{
	if (this.m_eUsersDropdownWidget == null)
	{
		var fAddUserToPrivateChat = caplin.dom.Utility.createMethodEventListener(this, '_addUserToPrivateChat');

		var eHolder = this.m_oTemplate.getElementById('users_dropdown');
	    this.m_eUsersDropdownWidget = new caplin.widget.formcontrols.DropDownBox({width:300});
	   	eHolder.appendChild( this.m_eUsersDropdownWidget.getElement());

	    this.m_eUsersDropdownWidget.addOption("", ct.i18n("cx.chat.chatroom.user_dropdown"));
	    this.m_eUsersDropdownWidget.addOption(caplinx.chat.Chat.RESET_INVITATIONS, ct.i18n("cx.chat.chatroom.reset_invitations"));

	    var pOnlineUsers = this.m_oChatChannelManager.getOnlineUsers();

	    for (var i = 0; i < pOnlineUsers.length; i++)
	    {
	    	this.m_eUsersDropdownWidget.addOption(pOnlineUsers[i], caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.InviteUser", [pOnlineUsers[i]]));
	    }

	    this.m_eUsersDropdownWidget.setValue("");

	    this.m_eUsersDropdownWidget.addChangeListener(fAddUserToPrivateChat);
	}
};

caplinx.chat.Chat.prototype._addUserToPrivateChat = function()
{
	var bUserAlreadyInvited = false;

	var sValue = this.m_eUsersDropdownWidget.getValue();

	if (sValue == caplinx.chat.Chat.RESET_INVITATIONS)
	{
		this._resetInvitations();
	}
	else if (sValue != "")
	{
		// Check if user has already ben invited
		for (var nCount = 0; nCount < this.m_pUsersInvitedToPrivateChat.length; ++ nCount)
		{
			if (this.m_pUsersInvitedToPrivateChat[nCount] == sValue)
			{
				bUserAlreadyInvited = true;
				break;
			}
		}

		if (bUserAlreadyInvited === false)
		{
			this.m_pUsersInvitedToPrivateChat.push(sValue);
			this.m_eUsersInvited.innerHTML = this.m_pUsersInvitedToPrivateChat.join(";");
		}
	}
}

caplinx.chat.Chat.prototype._removeCurrentChatChannel = function()
{
	if ( this.m_sObjectName != null)
	{
		this.oRttpProvider.removeObject(this, this.m_sObjectName);

		if (this.m_bCreatedPublicChatRoom  === true || this.m_bCreatedPrivateChatRoom === true)
		{
			this.oRttpProvider.deleteObject(this.m_sObjectName);
		}
		this._removePrivateInvitations();
	}
};


caplinx.chat.Chat.prototype._dropdownContains = function(eDropDownWidget, sValue)
{
	var bContainsValue = false;
	var pOptions = eDropDownWidget.getOptions();

	for (var nCount = 0, nLength = pOptions.length; nCount < nLength; ++ nCount)
	{
		if (pOptions[nCount].key == sValue)
		{
			bContainsValue = true;
			break;
		}
	}
	return bContainsValue;
};

caplinx.chat.Chat.prototype._displayPublicChatInputBox = function()
{
	var sPublicRoomsDropDownValue = this.m_ePublicChatRoomDropdownWidget.getValue();

	if (sPublicRoomsDropDownValue == caplinx.chat.Chat.CREATE_PRIVATE_CHATROOM)
	{
		this.m_ePublicRoomInput.value = "";
		this.m_ePrivateRoomInput.value = "";
		caplin.dom.Utility.removeClassName(this.m_ePrivateChatroomInputContainer, 'chathidden');
		caplin.dom.Utility.removeClassName(this.m_eUserDropDownContainer, 'chathidden');
		caplin.dom.Utility.removeClassName(this.m_eUsersInvitedContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_ePublicChatroomInputContainer, 'chathidden');
	}
	else if (sPublicRoomsDropDownValue == caplinx.chat.Chat.CREATE_PUBLIC_CHATROOM)
	{
		this.m_ePublicRoomInput.value = "";
		this.m_ePrivateRoomInput.value = "";

		caplin.dom.Utility.removeClassName(this.m_ePublicChatroomInputContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_ePrivateChatroomInputContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_eUserDropDownContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_eUsersInvitedContainer, 'chathidden');
	}
	else
	{
		this.m_ePublicRoomInput.value = "";
		this.m_ePrivateRoomInput.value = "";
		caplin.dom.Utility.addClassName(this.m_ePublicChatroomInputContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_ePrivateChatroomInputContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_eUserDropDownContainer, 'chathidden');
		caplin.dom.Utility.addClassName(this.m_eUsersInvitedContainer, 'chathidden');
	}
};