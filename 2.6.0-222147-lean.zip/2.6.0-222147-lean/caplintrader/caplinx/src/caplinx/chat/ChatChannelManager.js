caplin.namespace("caplinx.chat");

caplin.include("caplinx.chat.LanguageFactory");
caplin.include("caplin.widget.message.MessageManager");
caplin.include("caplin.core.XmlParser");
caplin.include("caplin.widget.events.EventManager", true);
caplin.include("caplin.widget.format.DateTextFormatter",true);

caplinx.chat.ChatChannelManager = function()
{
	this.oRttpProvider = SL4B_Accessor.getRttpProvider();
	this.m_sUserName = null;
	this.m_sUserPrivateChatDirectory = null;
	this.m_pOnlineUsers = [];
	this.m_pPublicChats = [];
	this.m_sPrivateChatObjectsAlreadySubscribed = '';
	this.m_oDateFormatter = new caplin.widget.format.DateTextFormatter();
	this.initialise();
};

caplinx.chat.ChatChannelManager.prototype = new SL4B_AbstractSubscriber;

/**
 * @private
 */
caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY = "/PRIVATECHAT";

/**
 * @private
 */
caplinx.chat.ChatChannelManager.PUBLIC_CHAT_DIRECTORY = "/CHAT";


caplinx.chat.ChatChannelManager.prototype.addListenerToChannel = function(oListener, sChannel)
{
};

caplinx.chat.ChatChannelManager.prototype.setUpChatChannels = function()
{
};



///////////////////////////////////////////////////////////////////////////////
// SL4B API
///////////////////////////////////////////////////////////////////////////////

caplinx.chat.ChatChannelManager.prototype.ready = function()
{
	this.m_bIsSL4BReady = true;

	this.m_sUserName = SL4B_Accessor.getCredentialsProvider().getUsername();
	this._setUpPrivateChatChannel();
	this._setUpPublicChatChannel();
};

/**
 * {@see SL4b_AbstractSubscriber#recordMultiUpdated}
 *
 * Used to display an invitation confirmation dialog if the user receives an invitation for a particular private
 * chatroom for the first time.
 *
 * @param {String} l_sObjectName - the name of the invitation object e.g. /PRIVATECHAT/user2@caplin.com/user1@caplin.com-BONDS
 * @param {SL4B_RecordFieldData} l_oFieldData - the field data associated with the invitation.
 * @param {Boolean} l_bIsCachedImage - indicates if update received is a cached update.
 */
caplinx.chat.ChatChannelManager.prototype.recordMultiUpdated = function(l_sObjectName, l_oFieldData, l_bIsCachedImage)
{
	var mSL4BData =  l_oFieldData.getFieldMap();

	if (mSL4BData['ack'] !== undefined && mSL4BData['ack'] == 0)
	{
		this._displayConfirmJoinPrivateChatDialog(l_sObjectName, mSL4BData['timestamp']);
	}

};

/**
 * {@see SL4b_AbstractSubscriber#directoryUpdated}
 *
 * Invoked once a user receives an update on either the public directory or a private directory
 * @param {String} sDirectObjectName - the name of the directory.
 * @param {String} sObjectName - the name of the object
 * @param {SL4B_ObjectType} nType - the type of object e.g. Chat, Record or Directory
 * @Param {Boolean} bAdded - indicates of {@param sObjectName} is being added or removed
 *
 */
caplinx.chat.ChatChannelManager.prototype.directoryUpdated = function(sDirObjectName, sObjectName, nType, bAdded)
{
	if (sDirObjectName == caplinx.chat.ChatChannelManager.PUBLIC_CHAT_DIRECTORY)
	{
		this._publicChatDirectoryUpdate(sDirObjectName, sObjectName, nType, bAdded);
	}
	else if (sDirObjectName == this.m_sUserPrivateChatDirectory)
	{
		this._userPrivateChatDirectoryUpdate(sDirObjectName, sObjectName, nType, bAdded);
	}
	else if (sDirObjectName == caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY && sObjectName != this.m_sUserName)
	{
		this._privateChatDirectoryUpdate(sDirObjectName, sObjectName, nType, bAdded);
	}
};

/**
 * {@see SL4b_AbstractSubscriber#objectNotFound}
 */
caplinx.chat.ChatChannelManager.prototype.objectNotFound = function(sObjectName)
{
	if (sObjectName == this.m_sUserPrivateChatDirectory )
	{
		this.oRttpProvider.createObject(this.m_sUserPrivateChatDirectory, SL4B_ObjectType.DIRECTORY);
		this.oRttpProvider.getObjects(this, this.m_sUserPrivateChatDirectory);
	}
	else if (sObjectName.indexOf(caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY) != -1)
	{
		var sChatUser = sObjectName.replace(this.m_oPrivateChatDirectoryPrefix,"");
		// TODO: Commented out alert due to flaw in Caplin event handling
		caplin.widget.message.MessageManager.getInstance().alert(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.UserNotLoggedIn",[sChatUser]));
	}
};

caplinx.chat.ChatChannelManager.prototype.getOnlineUsers = function()
{
	return this.m_pOnlineUsers;
}

caplinx.chat.ChatChannelManager.prototype.getPublicChats = function()
{
	return this.m_pPublicChats;
}

caplinx.chat.ChatChannelManager.prototype._displayConfirmJoinPrivateChatDialog = function(sObjectName, sTimestamp)
{
	var l_oChatChannelManager = this;

	// In form of : {username}-{chatroom_name}
	var sChatRoomDetails = sObjectName.replace(this.m_oPrivateChatDirectoryPrefix,"");
	var pChatRoomDetails = sChatRoomDetails.split("-");

	var sNameOfUserThatOwnsChatRoom = pChatRoomDetails[0].split('/').pop();
	var sChatRoomName = pChatRoomDetails[1];

	// Need to contribute to /PRIVATECHAT/{USER}/{CHATROOM}
	var sChatObjectName = caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY + "/" +sNameOfUserThatOwnsChatRoom + "/" + sChatRoomName;

	var fChatWithUser = function(bChatWithUser) {

		if (bChatWithUser === true)
		{
			var sXml = caplin.getResourceContents('caplinx.chat','chat.jsp');
			var oXml = caplin.core.XmlParser.getInstance().parseString(sXml);
			var eRoomNode = oXml.getElementsByTagName('room')[0];
			if(eRoomNode.textContent === "")
			{
				eRoomNode.textContent = sChatObjectName;
			}
			else
			{
				eRoomNode.text = sChatObjectName;
			}
			oDataNode = caplin.webcentric.model.XMLAdaptor.buildDataNode(oXml);
			webcentric.addComponent(oDataNode);
		}
		else
		{
			// create a new contribution field data object
			var l_oContributionData = new SL4B_ContributionFieldData();
			l_oContributionData.addField('msg', caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.UserBlockedPrivateChat"));

			l_oChatChannelManager.oRttpProvider.contribObject(l_oChatChannelManager, sChatObjectName, l_oContributionData );
		}

		l_oChatChannelManager._sendInvitationAck(sObjectName);
	}
	var sFormattedTimestamp = this.m_oDateFormatter.formatText(sTimestamp);
	caplin.widget.message.MessageManager.getInstance().confirm(caplinx.chat.LanguageFactory.getText("caplinx.chat.Chat.ConfirmUserWantsPrivateChat",[sNameOfUserThatOwnsChatRoom, sChatRoomName, sFormattedTimestamp]), fChatWithUser);
};

/**
 * @private
 */
caplinx.chat.ChatChannelManager.prototype._sendInvitationAck = function(sInvitationObjectName)
{
	// create a new contribution field data object
	var l_oContributionData = new SL4B_ContributionFieldData();
	l_oContributionData.addField('ack', "1");

	this.oRttpProvider.contribObject(this, sInvitationObjectName, l_oContributionData );

	// no longer interested in receiving updates on invitation
	this.oRttpProvider.removeObject(this, sInvitationObjectName);
};

caplinx.chat.ChatChannelManager.prototype._setUpPrivateChatChannel = function()
{
	this.m_sUserPrivateChatDirectory = caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY + "/"+this.m_sUserName;

	// Get list of logged on users for User dropdown
	this.oRttpProvider.getObjects(this, caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY);

	// TODO: Check user list - we already have list of users in dropdown
	// Private Chat Channel might already exist, createObject within objectNotFound
	this.oRttpProvider.getObjects(this, this.m_sUserPrivateChatDirectory);
};

caplinx.chat.ChatChannelManager.prototype._setUpPublicChatChannel = function()
{
	this.oRttpProvider.getObjects(this, caplinx.chat.ChatChannelManager.PUBLIC_CHAT_DIRECTORY);
};



caplinx.chat.ChatChannelManager.prototype._publicChatDirectoryUpdate = function(sDirObjectName, sObjectName, nType, bAdded)
{
	if( nType == SL4B_ObjectType.CHAT && bAdded === true)
	{
		caplin.widget.events.GlobalEventManager.raiseEvent({Name: "PublicChatOpened", objectName: sObjectName});
		this.m_pPublicChats.push(sObjectName);
	}
	else if (bAdded === false)
	{
		caplin.widget.events.GlobalEventManager.raiseEvent({Name: "PublicChatClosed", objectName: sObjectName, dirObjectName: sDirObjectName});
		for(var i = 0; 0 < this.m_pPublicChats.length; i++)
		{
			if(this.m_pPublicChats[i] === sObjectName)
			{
				this.m_pPublicChats.splice(i,1);
				break;
			}
		}
	}
};

caplinx.chat.ChatChannelManager.prototype._privateChatDirectoryUpdate = function(sDirObjectName, sObjectName, nType, bAdded)
{
	if( nType == SL4B_ObjectType.DIRECTORY && bAdded === true)
	{
		caplin.widget.events.GlobalEventManager.raiseEvent({Name: "ChatUserOnline", objectName: sObjectName});
		this.m_pOnlineUsers.push(sObjectName);
	}
	else if (bAdded === false)
	{
		caplin.widget.events.GlobalEventManager.raiseEvent({Name: "ChatUserOffline", objectName: sObjectName});
		for(var i = 0; 0 < this.m_pOnlineUsers.length; i++)
		{
			if(this.m_pOnlineUsers[i] === sObjectName)
			{
				this.m_pOnlineUsers.splice(i,1);
				break;
			}
		}
	}
};

caplinx.chat.ChatChannelManager.prototype._userPrivateChatDirectoryUpdate = function(sDirObjectName, sObjectName, nType, bAdded)
{
	if (bAdded === true && nType == SL4B_ObjectType.RECORD)
	{
		this.m_sPrivateChatObjectsAlreadySubscribed += "|"+ sObjectName + "|";
		this._checkIfAlreadyReceivedInvitation(sObjectName);
	}
	else if (bAdded === false)
	{
		this.m_sPrivateChatObjectsAlreadySubscribed= this.m_sPrivateChatObjectsAlreadySubscribed.replace("|"+ sObjectName + "|","");
		this._warnUserChatOwnerDeletedPrivateChatRoom(sObjectName);
	}
};


// TODO Find a way of reliably removing private chat channels when a user leaves the application.
//caplinx.chat.ChatChannelManager.prototype._removePrivateChatDirectory = function()
//{//	this.oRttpProvider.removeObject(this, caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY);
//	this.oRttpProvider.deleteObject(this.m_sUserPrivateChatDirectory);
//};

/**
 * @private
 */
caplinx.chat.ChatChannelManager.prototype._checkIfAlreadyReceivedInvitation = function( sObjectName)
{
	var sInvitationObjectName = caplinx.chat.ChatChannelManager.PRIVATE_CHAT_DIRECTORY + "/" + this.m_sUserName + "/" + sObjectName;
	this.oRttpProvider.getObjects(this, sInvitationObjectName);
};


caplinx.chat.ChatChannelManager.prototype._warnUserChatOwnerDeletedPrivateChatRoom = function( sObjectName)
{
	caplin.widget.events.GlobalEventManager.raiseEvent({Name: "PrivateChatDeleted", objectName: sObjectName});
};

///////////////////////////////////////////////////////////////////////////////
// Singleton
///////////////////////////////////////////////////////////////////////////////

caplin.singleton('caplinx.chat.ChatChannelManager');