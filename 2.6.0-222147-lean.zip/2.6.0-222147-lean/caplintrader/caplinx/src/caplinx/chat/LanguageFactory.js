/**
 * @fileoverview This class enables Caplin Trader to support internationalisation.
 */
caplin.namespace('caplinx.chat');

/**
 * @class Enables internalialisation so that text can be displayed in different languages
 * depending on the locale. 
 *
 * @constructor
 */
caplinx.chat.LanguageFactory = new function()
{ 

	this.m_pLanguageNameToObjectMap = {};

	this.m_pLanguageElements = [];

	this.m_oLanguage = null;


	function Language(sName)
	{
		this.m_sName = sName;
		this.m_pLanguageCodeToTextMap = {};
	}
	
	
	Language.prototype.getName = function() 
	{ 
		return this.m_sName; 
	};
	
	Language.prototype.getText = function(vCode, pReplacements) 
	{	
		var sText = this.m_pLanguageCodeToTextMap[vCode];
		
		if (sText) {
			if (pReplacements != undefined && pReplacements.length > 0) {
				var sReplacement;
				for (var i = 0, l = pReplacements.length; i < l; ++i) {
					sText = sText.replace('{' + i + '}', pReplacements[i]);
				}
			}
		}
		
		return ( (sText)? sText : null );
	};
	
	Language.prototype.addText = function(vCode, sText) 
	{
		this.m_pLanguageCodeToTextMap[vCode] = sText;
	};


	this.addLanguage = function(sLanguageName) 
	{ 
		var oLanguage = this.m_pLanguageNameToObjectMap[sLanguageName];

		if(!oLanguage){ 
			oLanguage = new Language(sLanguageName);
			this.m_pLanguageNameToObjectMap[oLanguage.getName()] = oLanguage;
			if (this.m_oLanguage == null)
			{
				this.m_oLanguage = oLanguage;
			}
		}

		return oLanguage;
	};

	this.setLanguage = function(sLanguageName) 
	{ 			
		if (this.m_pLanguageNameToObjectMap[sLanguageName])
		{
			this.m_oLanguage = this.m_pLanguageNameToObjectMap[sLanguageName];

			// now need to update all the elements text
			for (var nElement = 0, nLength = this.m_pLanguageElements.length; nElement < nLength ; ++nElement)
			{
				var oLanguageElement = this.m_pLanguageElements[nElement];
				oLanguageElement.m_oTextNode.nodeValue = this.getText(oLanguageElement.m_vCode)
			}
		}
		else
		{
			throw new caplin.core.Exception("Unknown language \"" + sLanguageName + "\"", "LanguageElementFactory.setLanguage");
		}
	};
	this.getLanguage = function() 
	{
		return this.m_oLanguage;
	};
	this.selectLanguage = function(sLanguageName) 
	{
		var oLanguage = this.m_pLanguageNameToObjectMap[sLanguageName];
		return (oLanguage)? oLanguage : this.addLanguage(sLanguageName);
	};

	function LanguageElement(oTextNode, vCode)
	{
		this.m_oTextNode = oTextNode;
		this.m_vCode = vCode;
	}

	this.createTextNode = function(vCode) 
	{
		var oTextNode = document.createTextNode(this.getText(vCode));
		var oLanguageElement = new LanguageElement(oTextNode, vCode);
		this.m_pLanguageElements.push(oLanguageElement);
		return oTextNode;
	};

	this.getText = function(vCode, pReplacements) 
	{	
		return (this.m_oLanguage? this.m_oLanguage.getText(vCode, pReplacements) : vCode);
	};

	this.addTextNode = function(oElement, vCode) 
	{
		// adds an existing text node element to the language factory, and changes its text to the
		// appropriate value, relative to the specified code
		// TODO: implement this
	};

	// TODO: need a way of removing elements
	// TODO: need a way of getting the available languages
	// TODO: need a way of adding elements with "value" attributes that can be modified	
	
};
