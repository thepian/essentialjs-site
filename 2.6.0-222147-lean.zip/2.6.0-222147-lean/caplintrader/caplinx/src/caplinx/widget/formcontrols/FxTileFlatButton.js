caplin.namespace("caplinx.widget.formcontrols");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.dom.Utility");
caplin.include("caplin.core.Utility");
caplin.include("caplin.core.MapFactory");
caplin.include("caplin.dom.AbstractFactory");

/** 
 * @constructor
 */
caplinx.widget.formcontrols.FxTileFlatButton = function(oContents, nWidth, nHeight, pClassNames)
{
	this.m_bHover = false;
	this.m_bDisabledHover = false;
	this.m_bEnabled = true;
	this.m_sDisabledAlertMessage = '';
	
	this.m_eElement = document.createElement("img");
	this.m_eElement.src = caplin.getPublicResourceUrl("images/shield.gif");
	this.m_eElement.width = nWidth;
	this.m_eElement.height = nHeight;
	this.m_eElement.style.position = "absolute";
	this.m_eElement.style.left = "0px";
	this.m_eElement.style.zIndex = 1;
	
	this.m_oContentDiv = document.createElement("div");
	this.m_oContentDiv.appendChild(oContents);
	
	this.m_eRFSElement = document.createElement("div");
	this.m_eRFSElement.className = "rfs-label ButtonContents";
	this.m_eRFSElement.style.display = "none";
	this.m_eRFSElement.innerHTML = "<span>RFS</span>";

	this.m_eBlankElement = document.createElement("div");
	this.m_eBlankElement.className = "blank-label ButtonContents";
	this.m_eBlankElement.style.display = "none";
	this.m_eBlankElement.innerHTML = "<span>&nbsp;</span>";
	
	this.m_eUnderlying = document.createElement("div");
	pClassNames.unshift('FlatButton');
	this.m_eUnderlying.className = pClassNames.join(' ');

	this.m_eUnderlying.appendChild(this.m_oContentDiv);
	this.m_eUnderlying.appendChild(this.m_eRFSElement);
	this.m_eUnderlying.appendChild(this.m_eBlankElement);
	
	this.m_nOnMouseOverId = this._addEventListener(this.m_eElement, "mouseover", "OnMouseOver");
	this.m_nOnMouseOutId = this._addEventListener(this.m_eElement, "mouseout", "OnMouseOut");
	this.m_nOnMouseDownId = this._addEventListener(this.m_eElement, "mousedown", "OnMouseDown");
	this.m_nOnClickId = null;
	this.m_nOnDblClickId = null;
	this.m_sDisabledAlertMsg = ct.i18n("cx.widget.formcontrols.fx.tile.flat.button.disabled_alert");
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype._addEventListener = function(eElement, sEvent, sMethod)
{
	return caplin.dom.Utility.addEventListener(eElement, sEvent, caplin.core.Utility.getEventListenerFromMethod(this, sMethod));
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.finalize = function()
{
	caplin.dom.Utility.removeEventListenerById(this.m_nOnMouseOverId);
	caplin.dom.Utility.removeEventListenerById(this.m_nOnMouseOutId);
	caplin.dom.Utility.removeEventListenerById(this.m_nOnClickId);
	caplin.dom.Utility.removeEventListenerById(this.m_nOnDblClickId);
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.addOnClickListener = function(fListener)
{
	if (this.m_nOnClickId === null)
	{
		this.m_nOnClickId = this._addEventListener(this.m_eElement, "click", "OnClick");
	}

	this.m_fOnClickListener = fListener;
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.addOnDblClickListener = function(fListener)
{
	if (this.m_nOnDblClickId === null)
	{
		this.m_nOnDblClickId = this._addEventListener(this.m_eElement, "dblclick", "OnDblClick");
	}

	this.m_fOnDblClickListener = fListener;
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.removeOnClickListener = function()
{
	this.m_fOnClickListener = null;
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.removeOnDblClickListener = function()
{
	this.m_fOnDblClickListener = null;
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.OnMouseOver = function(oEvent)
{
	this._mouseOver(true);
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.OnMouseOut = function()
{
	this._mouseOver(false);
	this._buttonUp();
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.OnMouseDown = function()
{
	if (this.m_bEnabled === true) 
	{
		this._replaceClassName(this.m_eUnderlying, 'flat-button-up', 'flat-button-down');
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype._buttonUp = function()
{
		this._replaceClassName(this.m_eUnderlying, 'flat-button-down', 'flat-button-up');
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.OnClick = function(oEvent)
{
	var nRightButton = 2;
	if (this.m_bEnabled === false && oEvent.button !== nRightButton && this.m_sDisabledAlertMessage !== '') 
	{
		caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(this.m_sDisabledAlertMessage);
		return;
	}
	if (this.m_bEnabled === true && typeof this.m_fOnClickListener === 'function') 
	{
		this.m_fOnClickListener();
	}
	this._buttonUp();
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.OnDblClick = function(oEvent)
{
	if (this.m_bEnabled === true && typeof this.m_fOnDblClickListener === 'function') 
	{
		this.m_fOnDblClickListener();
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype._mouseOver = function(bOver)
{
	if (this.m_bEnabled === true) 
	{
		this.m_bHover = bOver;
		this._updateBackgroundColor();
	}
	else 
	{
		this.m_bDisabledHover = bOver;
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.getElement = function()
{
	return this.m_eElement;
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.setTooltip = function(sTooltip)
{
	this.m_eElement.title = sTooltip;
	if(sTooltip !== "") 
	{
		this.m_eElement.id = 'button_' + sTooltip.replace(/[\s]/g, '_').replace(/[\(\)\.\*\+]/g, '').replace(/'/g, '').toLowerCase();
	}
	else
	{
		this.m_eElement.id = 'button_no_tooltip';
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.setEnabled = function(bEnable)
{
	if (this.m_bEnabled === bEnable) 
	{
		return;
	}
	this.m_bEnabled = bEnable;
	
	if (bEnable === true) 
	{
	
		this.m_bHover = this.m_bDisabledHover;
		this._replaceClassName(this.m_eUnderlying, 'flat-button-disabled', 'flat-button-enabled');
	}
	else 
	{
		this.m_bDisabledHover = this.m_bHover;
		this.m_bHover = false;
		this._replaceClassName(this.m_eUnderlying, 'flat-button-enabled', 'flat-button-disabled');
	}
	
	this._updateBackgroundColor();
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.setDisabledAlertMsg = function(sMessage)
{
	this.m_sDisabledAlertMessage = sMessage;
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.setButtonRFS = function(bSetRFS)
{
	if (bSetRFS === true) 
	{
		this.m_oContentDiv.style.display = "none";
		this.m_eRFSElement.style.display = "block";
	}
	else 
	{
		this.m_oContentDiv.style.display = "block";
		this.m_eRFSElement.style.display = "none";
	}
};
caplinx.widget.formcontrols.FxTileFlatButton.prototype.setButtonRFS = function(bSetRFS)
{
	if (bSetRFS === true) 
	{
		this.m_oContentDiv.style.display = "none";
		this.m_eRFSElement.style.display = "block";
	}
	else 
	{
		this.m_oContentDiv.style.display = "block";
		this.m_eRFSElement.style.display = "none";
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.setButtonBlank = function(bSetBlank)
{
	if (bSetBlank === true) 
	{
		this.m_oContentDiv.style.display = "none";
		this.m_eBlankElement.style.display = "block";
		this.m_bIsRFSDisplaying = false;
		this.m_eRFSElement.style.display = "none";
	}
	else if (!this.m_bIsRFSDisplaying) {
		this.m_oContentDiv.style.display = "block";
		this.m_eBlankElement.style.display = "none";
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype._updateBackgroundColor = function()
{
	if (this.m_bHover === true && this.m_bEnabled === true) 
	{
		caplin.dom.Utility.addClassName(this.m_eUnderlying, 'flat-button-hover');
	}
	else 
	{
		caplin.dom.Utility.removeClassName(this.m_eUnderlying, 'flat-button-hover');
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype._replaceClassName = function(eElement, sCurrentState, sNewState)
{
	if (eElement.className.indexOf(sCurrentState) === -1) 
	{
		caplin.dom.Utility.addClassName(eElement, sNewState);
	}
	else 
	{
		caplin.dom.Utility.replaceClassName(eElement, sCurrentState, sNewState);
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.updateElements = function(oUpdate)
{
	if (!this.m_oUpdatableElements) 
	{
		return;
	}
	for (var sElement in oUpdate) 
	{
		this.m_oUpdatableElements[sElement].innerHTML = oUpdate[sElement];
	}
};

caplinx.widget.formcontrols.FxTileFlatButton.prototype.setUpdatableElements = function(oElements)
{
	this.m_oUpdatableElements = oElements || null;
};
