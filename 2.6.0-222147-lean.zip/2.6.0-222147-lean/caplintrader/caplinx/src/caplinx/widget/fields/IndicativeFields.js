caplin.namespace("caplinx.widget.fields");

/**
 * @class Singleton that provides the names of all the fields that are used by the grids.
 */
caplinx.widget.fields.IndicativeFields = function()
{
	// CaplinTrader style fields
	this.INSTRUMENT_DESCRIPTION = "InstrumentDescription";
	this.INSTRUMENT_ID = "InstrumentId";
	this.BEST_BID = "BestBid";
	this.BEST_ASK = "BestAsk";
	this.BEST_BID_SIZE = "BestBidSize";
	this.BEST_ASK_SIZE = "BestAskSize";
	this.NUMBER_OF_TIERS = "NumberOfTiers";
	
	this.PRICE_VERSION = "PriceVersion";
	// first, set up tier part identifiers
	this.BID_PART_ID = "BID";
	this.ASK_PART_ID = "ASK";
	// second, generate tiers
	this.TIER = new Array();
	this.TIER1 = this._generateTier(1);
	this.TIER[1] = this.TIER1;
	this.TIER2 = this._generateTier(2);
	this.TIER[2] = this.TIER2;
	this.TIER3 = this._generateTier(3);
	this.TIER[3] = this.TIER3;
	
	this.INSTRUMENT_ID_TYPE = "IdentifierType";
	this.PRICING_TYPE = "PricingType";
	// FX only
	this.RATE_PRECISION = "ratePrcsn";
	this.POINTS_PRECISION = "pntsPrcsn";
	this.POINTS_SCALE_FACTOR = "pntsSclFct";

// probably not used:	
	// FI only
	this.BEST_BID_YIELD = "BidYld";
	this.BEST_ASK_YIELD = "AskYld";
	this.YIELD_CHANGE_ON_DAY = "YldChgOnDay";
	this.BENCHMARK = "BenchmarkSubject";
	this.ISSUING_CURRENCY = "IssCrcy";
	// IRS only
	this.EFFECTIVE_DATE = "StlmD";
	this.MATURITY_DATE = "MatD";
	this.RESET_FREQUENCY = "CpnFrq";
	this.DAY_COUNT = "DaysTyp";

	this.ACCRUED_INTEREST_LIST = "AccruedInterests";
	this.ACCRUED_DAYS_LIST = "AccruedDayCnts";
	this.SETTLEMENT_DATE_LIST = "StlmDates";    
};

/*
 * Generates a set of fields for a tier of the specified number
 * 
 * @private
 */
caplinx.widget.fields.IndicativeFields.prototype._generateTier = function(l_nTierNumber)
{
	var tier = {};
	var l_sPrefix = "Tier" + l_nTierNumber;
	
	tier[this.BID_PART_ID] = l_sPrefix + "Bid";
	tier[this.ASK_PART_ID] = l_sPrefix + "Ask";
	tier.LIMIT = l_sPrefix + "Limit";
	tier.PROCESSED_LIMIT = l_sPrefix + "ProcessedLimit";
	
	return tier;
};

caplin.singleton("caplinx.widget.fields.IndicativeFields");
