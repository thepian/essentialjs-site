caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.TextFormatter", true);
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");

/**
 * Constructs a new <code>Bond64thNotationTextFormatter</code>.
 * Abstract class only
 * 
 * @class Responsible for converting a decimal price to bond (32nd) notation.
 * 
 */
caplinx.widget.format.Bond32ndNotationTextFormatter = function()
{

};

caplin.extend(caplinx.widget.format.Bond32ndNotationTextFormatter, caplin.widget.format.TextFormatter);

/**
 * Regular expression used to match prices received from the Liberator, and split them into
 * their component parts.
 * 
 * @type RegExp
 * @private
 */
caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.m_oRegExp = new RegExp("^(-?)(\\d*)(\\.\\d*)?$");

/**
 * 1/64th, which is used by the <code>formatText</code> method to determine what the bond
 * notation value for a particular price is.
 * 
 * @type int
 * @private
 */
caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.m_n32nd = 1 / 32;

/**
 * The character that is used to separate the whole number from the 32nd value.
 * 
 * @type String
 * @private
 */
caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.m_s32ndSeparator = "-";

/**
 * The character that is used to indicate that an extra 64th should be added to the value.
 * 
 * @type String
 * @private
 */
caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.m_s64thIndicator = "+";

/**
 * The character that is used instead of the <code>m_s64thIndicator</code> indicator if an extra
 * 64th is not added to the value. This is a non-breaking space.
 * 
 * @type String
 * @private
 */
caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.m_sNonBreakingSpace = "\u00a0";


/**
 * formatText method - formats bond prices into "32nd" notation - deferring to getTrailingSymbol(0 for the final char
 */
caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.formatText = function(sValue)
{
	var sFormattedValue;
	var oMatch = sValue.match(this.m_oRegExp);
	if (oMatch && (oMatch[2] || oMatch[3]))
	{
		// the value is a valid number
		var sFractionalPart;
		if (oMatch[3] && oMatch[3] != "" && oMatch[3] != ".")
		{
			// we have a fraction part
			var n32nds = oMatch[3] / this.m_n32nd;
			var n32 = Math.floor(n32nds);
			
			// process the last symbol
			var sSymbol = this.getTrailingSymbol(n32nds - n32);
			if (sSymbol)
			{
				// we have a valid fraction part
				sFractionalPart = ((n32 < 10)?"0":"") + n32 + sSymbol;
			}
		}
		else
		{
			// there are no numbers after the decimal - the value is a whole number only
			sFractionalPart = "00" + this.getTrailingSymbol(0);
		}

		if (sFractionalPart)
		{
			// construct the final bond notation format value
			sFormattedValue = oMatch[1] + ((oMatch[2] == "")?"0":oMatch[2]) + this.m_s32ndSeparator + sFractionalPart;
		}
		else
		{
			// the number could not be displayed in bond notation format - convert it to a decimal
			// with 3 decimal places instead
			sFormattedValue = this.getBackupFormatter().formatText(sValue);
		}
	}
	else
	{
		// the value was not a number, return it unchanged
		sFormattedValue = sValue;
	}
	return sFormattedValue;
};

caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.getBackupFormatter= function () {
	if (this.m_oDecimalPlaceFormatter == undefined)
	{
		this.m_oDecimalPlaceFormatter = new caplin.widget.format.DecimalPlaceTextFormatter(3);
		return this.m_oDecimalPlaceFormatter;
	}
	return this.m_oDecimalPlaceFormatter;
}

caplinx.widget.format.Bond32ndNotationTextFormatter.prototype.getTrailingSymbol = function (n32ndsLeftover) {
	switch (n32ndsLeftover) {
		case 0: return this.m_sNonBreakingSpace;
		default: return null;
	}
}