// MUSTDO: document

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.AbstractFieldValueProcessor", true);
caplin.include("caplinx.widget.format.PriceTextFormatter");
caplin.include("caplinx.widget.format.FxPriceFieldValueProcessor");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.widget.format.BlotterPriceFieldValueProcessor = function()
{
	this.m_oFxPriceFieldValueProcessor = new caplinx.widget.format.FxPriceFieldValueProcessor();

	this.m_sBlotterTypeFieldName = "BlotterType";

	var l_oFormatterFactory = caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory();
	this.m_oBondNotationFormatter = l_oFormatterFactory.getTextFormatter("caplinx.widget.format.PriceTextFormatter");
	this.m_o3DpFormatter = l_oFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "3");
};

caplin.extend(caplinx.widget.format.BlotterPriceFieldValueProcessor, caplin.widget.format.AbstractFieldValueProcessor);

caplinx.widget.format.BlotterPriceFieldValueProcessor.prototype.getValue = function(l_oObject, l_sFieldName)
{
	var l_sValue = l_oObject.getFieldValue(l_sFieldName);
	if (l_sValue != null)
	{
		var l_sBlotterType = l_oObject.getFieldValue(this.m_sBlotterTypeFieldName);
		switch (l_sBlotterType)
		{
		case "UST":
		case "AG":
		case "HG":
			// display the price in bond notation
			l_sValue = this.m_oBondNotationFormatter.formatText(l_sValue);
			break;
		case "FX":
			// display the price in FX format
			l_sValue = this.m_oFxPriceFieldValueProcessor.getValue(l_oObject, l_sFieldName);
			break;
		default:
			// display the price to 3 decimal places
			l_sValue = this.m_o3DpFormatter.formatText(l_sValue);
		}
	}
	
	return l_sValue;
};
