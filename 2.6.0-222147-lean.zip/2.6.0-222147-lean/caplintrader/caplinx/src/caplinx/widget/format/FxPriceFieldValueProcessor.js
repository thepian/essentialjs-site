// MUSTDO: document

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.AbstractFieldValueProcessor", true);
caplin.include("caplinx.widget.format.PriceTextFormatter");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplin.widget.format.SignificantFigureTextFormatter");

caplinx.widget.format.FxPriceFieldValueProcessor = function(l_sPrecisionFieldName, l_bBracketNegativeAmounts)
{
	this.m_oFormatterFactory = caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory();
	this.m_pDecimalPlaceFormatters = new Object();
	this.m_oDefaultTextFormatter = this.m_oFormatterFactory.getTextFormatter("caplin.widget.format.SignificantFigureTextFormatter", 5);
	this.m_oBracketNegativeAmountFormatter;
	this.m_bBracketNegativeAmounts = (l_bBracketNegativeAmounts)?l_bBracketNegativeAmounts:false;
};

caplin.extend(caplinx.widget.format.FxPriceFieldValueProcessor, caplin.widget.format.AbstractFieldValueProcessor);

caplinx.widget.format.FxPriceFieldValueProcessor.prototype.getValue = function(l_oObject, l_sFieldName)
{
	var l_sPrice = l_oObject.getFieldValue(l_sFieldName);

	if (!(l_sPrice === undefined))
	{
		if (this.m_bBracketNegativeAmounts)
		{
			l_sPrice = this.getBracketNegativeValuesTextFormatter().formatText(l_sPrice);
		}
	}
	else
	{
		l_sPrice = null;
	}
	
	return l_sPrice;
};

caplinx.widget.format.FxPriceFieldValueProcessor.prototype.getBracketNegativeValuesTextFormatter = function()
{
	if (typeof this.m_oBracketNegativeAmountFormatter == "undefined")
	{
		this.m_oBracketNegativeAmountFormatter = this.m_oFormatterFactory.getTextFormatter("caplinx.widget.format.BracketNegativeAmountsTextFormatter");
	}
	return this.m_oBracketNegativeAmountFormatter;
};
