/**
 * @fileoverview Provides the {@link caplinx.widget.format.PercentDecimalPlaceTextFormatter}
 * Class that formats a decimal figure into a percentage
 */
 
caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.DecimalPlaceTextFormatter", true);

/**
 * @class - formats a decimal figure into a percentage
 *          for EMTN dialog
 * @param {int} nNumberOfDecimalPlaces The number of decimal places that prices will be formatted
 *        to.
 * 
 * @class Responsible for restricting a decimal to the specific number of decimal places and adding
 * a percentage sign '%'.
 * @extends caplin.widget.format.DecimalPlaceTextFormatter
 * @constructor
 */
caplinx.widget.format.PercentDecimalPlaceTextFormatter = function(nNumberOfDecimalPlaces)
{
 	caplin.widget.format.DecimalPlaceTextFormatter.apply(this,[nNumberOfDecimalPlaces, false]);
};

caplin.extend(caplinx.widget.format.PercentDecimalPlaceTextFormatter, caplin.widget.format.DecimalPlaceTextFormatter);

/**
 * Converts the specified price to a specific number of decimal places with a percent. If a non number is
 * specified, then the value will be returned without any formatting.
 * 
 * @param {String} sValue The price to be formatted.
 * @type String
 * @return The formatted price.
 */
caplinx.widget.format.PercentDecimalPlaceTextFormatter.prototype.formatText = function(sValue)
{
	if (sValue !== "") 
	{
		return caplin.widget.format.DecimalPlaceTextFormatter.prototype.formatText.apply(this, [sValue]) + "%";
	}
	else 
	{
		return "";
	}
};
