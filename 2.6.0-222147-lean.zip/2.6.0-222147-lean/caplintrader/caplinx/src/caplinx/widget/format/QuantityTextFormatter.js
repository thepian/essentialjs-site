caplin.namespace("caplinx.widget.format");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.widget.format.TextFormatter", true);
caplin.include("caplin.widget.format.SignificantFigureTextFormatter", true);

//bZeroAsBlank is not used
caplinx.widget.format.QuantityTextFormatter = function(bZeroAsBlank, nNumberOfSignificantFigures)
{
	this.m_oCommaAndWhiteSpaceRegExp = /,|\s/g;
	this.m_bZeroAsBlank = bZeroAsBlank || false;

	if (nNumberOfSignificantFigures !== undefined)
	{
		this.m_oSignificantFigureTextFormatter = new caplin.widget.format.SignificantFigureTextFormatter(nNumberOfSignificantFigures);
		this.m_bSignificantFigureDefined = true;
	}
	else
	{
		this.m_bSignificantFigureDefined = false;
	}

};
caplin.extend(caplinx.widget.format.QuantityTextFormatter, caplin.widget.format.TextFormatter);

caplinx.widget.format.QuantityTextFormatter.onAfterClassLoad = function()
{
	caplinx.widget.format.QuantityTextFormatter.INVALID_QUANTITY_EXCEPTION = ct.i18n("cx.widget.format.quantity.invalid_quantity_exception");
	caplinx.widget.format.QuantityTextFormatter.RATIONAL_NUMBER_EXCEPTION = ct.i18n("cx.widget.format.quantity.rational_number_exception");
};
caplin.notifyAfterClassLoad(caplinx.widget.format.QuantityTextFormatter);

/**
  @deprecated
 * @param {Object} bZeroAsBlank
 */
caplinx.widget.format.QuantityTextFormatter.prototype.setZeroAsBlank = function(bZeroAsBlank)
{
};

caplinx.widget.format.QuantityTextFormatter.prototype.formatText = function(nQuantity)
{
	if (nQuantity < 0)
	{
		nQuantity = 0;
	}

	var mMagnitude = this._getMagnitude(nQuantity.toString());
	var nAmount = nQuantity / Math.pow(10, mMagnitude.denominator);

	if	(this.m_bSignificantFigureDefined)
	{
		return this.m_oSignificantFigureTextFormatter.formatText(nAmount).toString().replace(/\.0+$/, "") + mMagnitude.suffix;
	}
	else
	{
		return nAmount + mMagnitude.suffix;
	}
};

/**
 * @private
 */
caplinx.widget.format.QuantityTextFormatter.prototype._getMagnitude = function(sQuantity)
{
	if (/^\d{10}/.test(sQuantity))
	{
		return {suffix: ct.i18n("cx.widget.format.quantity.formatter.billion"), denominator: 9};
	}
	else if(/^\d{7}/.test(sQuantity))
	{
		return {suffix: ct.i18n("cx.widget.format.quantity.formatter.million"), denominator: 6};
	}
	else if (/^\d{4}/.test(sQuantity))
	{
		return {suffix: ct.i18n("cx.widget.format.quantity.formatter.thousand"), denominator: 3};
	}
	else 
	{
		return {suffix: "", denominator: 0};
	}
};

/**
 * @private
 */
caplinx.widget.format.QuantityTextFormatter.prototype.insertCommas = function(sToInsertInto)
{
	var rCommas = /(-?\d+)(\d{3})/;
	var sResult = sToInsertInto + "";
	while (rCommas.test(sResult)) 
	{
		sResult = sResult.replace(rCommas, "$1,$2");
	}
	return sResult;
};

caplinx.widget.format.QuantityTextFormatter.prototype.parseUserInput = function(vToConvert)
{
	if (vToConvert === null || vToConvert === undefined || /[eE]/.test(vToConvert + ""))
	{
		throw caplinx.widget.format.QuantityTextFormatter.INVALID_QUANTITY_EXCEPTION;
	}
	
	if (!isNaN(vToConvert))
	{
		this._validate(vToConvert);
		return Number(vToConvert);
	}
	
	var sStrippedValue = this.stripCommas(vToConvert);
	var pMatches = sStrippedValue.toLowerCase().match(/^(\d*\.?\d*\s*)(k|mil|m|bil|b)$/);

	if(!pMatches)
	{
		this._validate(sStrippedValue);
		return Number(sStrippedValue);
	}
	var nResult = this._getResult(pMatches[1], pMatches[2]);
	this._validate(nResult);
	return nResult;
};

/**
 * @private
 */
caplinx.widget.format.QuantityTextFormatter.prototype._validate = function(vResult)
{
	var nResult = Number(vResult);
	if( !isFinite(nResult) || nResult <= 0 )
	{
		throw caplinx.widget.format.QuantityTextFormatter.INVALID_QUANTITY_EXCEPTION;
	}
	if( String(nResult).match(/\./) )
	{
		throw caplinx.widget.format.QuantityTextFormatter.RATIONAL_NUMBER_EXCEPTION;
	}
};


/**
 * @private
 */
caplinx.widget.format.QuantityTextFormatter.prototype._getResult = function(sNumber, sSuffix)
{
	var nDotPos = sNumber.indexOf(".");
	var nRatio = this._getRatio(sSuffix);
	if(nDotPos == -1)
	{
		return Number(sNumber) * nRatio;
	}
	else
	{
		var nDecimalPlaces = sNumber.length - nDotPos - 1;
		nRatio /= Math.pow(10, nDecimalPlaces);
		return Number(sNumber.replace(".", "")) * nRatio;
	}
};

/**
 * @private
 */
caplinx.widget.format.QuantityTextFormatter.prototype.stripCommas = function(sToStrip)
{
	 return sToStrip.replace(this.m_oCommaAndWhiteSpaceRegExp, "");
};

/**
 * @private
 */
caplinx.widget.format.QuantityTextFormatter.prototype._getRatio = function(sSuffix)
{
	switch(sSuffix) 
	{
		case "bil":
		case "b":
			return Math.pow(10, 9);
		case "mil":
		case "m":
			return Math.pow(10, 6);
		case "k":
			return Math.pow(10, 3);
		default:
			return 1;
	}
};
