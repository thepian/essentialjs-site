caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.TextFormatter", true);

// MUSTDO: document
caplinx.widget.format.BlotterTradeIdTextFormatter = function()
{
	this.m_oMultipleLegTradeIdRegExp = new RegExp("_[23]$");
};

caplin.extend(caplinx.widget.format.BlotterTradeIdTextFormatter, caplin.widget.format.TextFormatter);

caplinx.widget.format.BlotterTradeIdTextFormatter.prototype.formatText = function(l_sValue)
{
	// if the trade id is for a second or third leg, then display a blank string
	return ((l_sValue.match(this.m_oMultipleLegTradeIdRegExp))?"":l_sValue);
};
