/**
 * @fileoverview Provides the {@link caplinx.widget.format.PriceTextFormatter} class which is
 * responsible for formatting the price fields according to the user preferences.
 */

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.TextFormatter", true);
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplin.widget.format.SignificantFigureTextFormatter");

caplin.include("caplinx.widget.format.Bond32ndNotationTextFormatter");
caplin.include("caplinx.widget.format.Bond64thNotationTextFormatter");
caplin.include("caplinx.widget.format.Bond256thNotationTextFormatter");
caplin.include("caplinx.widget.format.BracketNegativeAmountsTextFormatter");

/**
 * Constructs a new <code>PriceTextFormatter</code> that is configured to use a 3 decimal place
 * formatter.
 * 
 * @class Responsible for converting all price field values to the format specified by the user
 * preferences. It delegates the actual price formatting to the
 * {@link caplin.widget.format.DecimalPlaceTextFormatter},
 * {@link caplinx.widget.format.Bond64thNotationTextFormatter} and
 * {@link caplinx.widget.format.Bond256thNotationTextFormatter} classes.
 */
caplinx.widget.format.PriceTextFormatter = function()
{
	/**
	 * Array of all the specific price formatters that are supported by this formatter.
	 * 
	 * @type Array
	 * @private
	 */
	this.m_pPriceFormatters = new Array(new caplin.widget.format.DecimalPlaceTextFormatter(3), new caplinx.widget.format.Bond64thNotationTextFormatter(), new caplinx.widget.format.Bond256thNotationTextFormatter());

	/**
	 * The index of the price formatter that is currently being used.
	 * 
	 * @type int
	 * @private
	 */
	this.m_nFormatterIndex = caplinx.widget.format.PriceTextFormatter.BOND_256TH_NOTATION;
};
caplin.extend(caplinx.widget.format.PriceTextFormatter, caplin.widget.format.TextFormatter);

/**
 * The identifier that must be passed into the
 * {@link caplinx.widget.format.PriceTextFormatter#setFormatter} method to change the active
 * price formatter to the 3 decimal place format. This corresponds to the
 * {@link caplin.widget.format.DecimalPlaceTextFormatter}.
 * 
 * @type int
 * @private
 */
caplinx.widget.format.PriceTextFormatter.THREE_DECIMAL_PLACES = 0;

/**
 * The identifier that must be passed into the
 * {@link caplinx.widget.format.PriceTextFormatter#setFormatter} method to change the active
 * price formatter to the bond (64th) notation format. This corresponds to the
 * {@link caplin.widget.format.Bond64thNotationTextFormatter}.
 * 
 * @type int
 * @private
 */
caplinx.widget.format.PriceTextFormatter.BOND_64TH_NOTATION = 1;

/**
 * The identifier that must be passed into the
 * {@link caplinx.widget.format.PriceTextFormatter#setFormatter} method to change the active
 * price formatter to the bond (256th) notation format. This corresponds to the
 * {@link caplin.widget.format.Bond256thNotationTextFormatter}.
 * 
 * @type int
 * @private
 */
caplinx.widget.format.PriceTextFormatter.BOND_256TH_NOTATION = 2;

/**
 * Sets the formatter that will be used to format price fields.
 * 
 * @param {int} nIndex The index of the formatter to be set.
 * @throws Exception if the specified identifier is not
 *         {@link caplinx.widget.format.PriceTextFormatter.THREE_DECIMAL_PLACES} or
 *         {@link caplinx.widget.format.PriceTextFormatter.BOND_NOTATION}.
 */
caplinx.widget.format.PriceTextFormatter.prototype.setFormatter = function(nIndex) {
	if (nIndex < 0 || nIndex >= this.m_pPriceFormatters.length)
	{
		throw "PriceTextFormatter.setFormatter: specified identifier is unknown";
	}
	this.m_nFormatterIndex = nIndex;
};

/**
 * Proxies the method call onto the underlying price formatter that was configured using the
 * {@link caplinx.widget.format.PriceTextFormatter#setFormatter} method.
 * 
 * @param {String} sValue The price to be formatted.
 * @type String
 * @return The formatted price.
 */
caplinx.widget.format.PriceTextFormatter.prototype.formatText = function(sValue) {
	return this.m_pPriceFormatters[this.m_nFormatterIndex].formatText(sValue);
};