/**
 * @fileoverview Contains the definition for the {@link caplinx.widget.element.renderer.FxTileTextBoxElementRenderer} class.
 */

caplin.namespace("caplinx.widget.element.renderer");
caplin.include("caplin.widget.element.renderer.TextBoxElementRenderer", true);
caplin.include("caplin.widget.element.renderer.TextBoxElement", true);
caplin.include("caplin.widget.Exception");
caplin.include("caplin.widget.element.ElementFactory");
caplin.include("caplin.widget.message.MessageManager");
caplin.include("caplin.dom.AbstractFactory");

/**
 * @class Used to create and render a {@link caplinx.widget.element.renderer.FxTileTextBoxElement}.
 * @constructor
 * Set up the object testing that processors and listener are/is specified.
 * @param {Array} l_pFieldValueProcessors
 * @param {Array} l_pFieldNames Passed to ElementRenderer to create FieldUpdateAdapters
 * @param {FieldManager} oFieldManager Passed to ElementRenderer
 * @param {Object} oChangeListener Validation listener
 * @param {String} sClassName CSS class for the input element/text box
 *
 * @extends caplin.widget.element.renderer.ElementRenderer
 */
caplinx.widget.element.renderer.FxTileTextBoxElementRenderer = function(l_pFieldValueProcessors, l_pFieldNames, oFieldManager, oChangeListener, sClassName, oFxTile)
{
	caplin.widget.element.renderer.TextBoxElementRenderer.apply(this, [l_pFieldValueProcessors, l_pFieldNames, oFieldManager, oChangeListener, sClassName]);
	this.m_oFxTile = oFxTile;
};
caplin.extend(caplinx.widget.element.renderer.FxTileTextBoxElementRenderer, caplin.widget.element.renderer.TextBoxElementRenderer);

/**
 * @see caplin.widget.element.renderer.ElementRenderer#createElement
 */
caplinx.widget.element.renderer.FxTileTextBoxElementRenderer.prototype.createElement = function(oObject, oContainerElement)
{
	var sId = this.getElementIdentifier(oObject);

	var oTextBoxElement = new caplinx.widget.element.renderer.FxTileTextBoxElement(this, oObject, oContainerElement, this.m_oFxTile, this.m_sDisplayedField);

	this.m_sElementIdToTextBoxElementMap[sId] = oTextBoxElement;

	// required standard implementation call.
	this.doInitialUpdates(oObject);

	return oTextBoxElement;
};

/**
 * @class
 * A text box for the renderer
 *
 * @param {caplinx.widget.element.renderer.FxTileTextBoxElementRenderer} oElementRenderer renderer
 * @param {Object} oObject
 * @param {Object} oContainerElement
 */
caplinx.widget.element.renderer.FxTileTextBoxElement = function(oElementRenderer, oObject, oContainerElement, oFxTile, sField)
{
	caplin.widget.element.renderer.TextBoxElement.apply(this, [oElementRenderer, oObject, oContainerElement]);
	this.m_oFxTile = oFxTile;
	this.m_sField = sField;
};
caplin.extend(caplinx.widget.element.renderer.FxTileTextBoxElement, caplin.widget.element.renderer.TextBoxElement);

caplinx.widget.element.renderer.FxTileTextBoxElement.prototype.onKeyDown = function(oEvent, oElement)
{
	if(oEvent.keyCode==13 && this.m_sFormattedValue !== this.readValue())
	{
		this.onEdit();
	}
};

caplinx.widget.element.renderer.FxTileTextBoxElement.prototype.onBlur = function(oEvent, oElement)
{
	if(this.m_sFormattedValue !== this.readValue())
	{
		this.onEdit();
	}
};

caplinx.widget.element.renderer.FxTileTextBoxElement.prototype.onChange = function(oEvent, oElement)
{
	if(this.m_sFormattedValue !== this.readValue())
	{
		this.onEdit();
	}
};

/**
 * @private
 */
caplinx.widget.element.renderer.FxTileTextBoxElement.prototype.onEdit = function()
{
	if (this.m_bProcessingEdit)
	{
		return;
	}
	var sErrorMessage;

	this.m_bProcessingEdit = true;

	// get the newly edited value from the text box
	var sFormattedValue = this.readValue();
	
	// revert any formatting on the data within the text box
	try
	{
		var sRawValue = this.m_oElementRenderer.getFieldValueProcessors()[0].getTextFormatter().parseUserInput(sFormattedValue);
	}
	catch(e)
	{
		sErrorMessage = e.toString();
	}

	if(sErrorMessage)
	{
		caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(sErrorMessage);		
		this.writeValue(this.m_sFormattedValue);
	}
	else if (sRawValue == this.m_sRawValue)
	{
		// nothing changed		
		this.writeValue(this.m_sFormattedValue);			
	}
	else
	{
		// the change is valid - ask the onChange listener whether the update should be propagated
		// onto the underlying object model or not, if not, it is the responsiblity of the
		// onChange listener to propogate the update onto the model
		if (this.m_oElementRenderer.m_oChangeListener.shouldPropagateUpdate(this.m_oObject, sRawValue))
		{
			// inject the field update into the underlying object model
			this.m_oObject.setValue(this.m_oElementRenderer.m_sDisplayedField, sRawValue);
		}

		// MUSTDO: need to handle the case where the underlying model MAY NOT be updated, and the
		// text may be shown in its unformatted form - to do this properly we need a proxy to wrap
		// around the underlying object and present the "new" raw value for the displayed field
	}
	this.m_bProcessingEdit = false;
};

/**
 * Called from updateElement
 * @see caplin.widget.element.renderer.TextBoxElementRenderer#updateElement
 * @param {Object} oObject
 */
caplinx.widget.element.renderer.FxTileTextBoxElement.prototype.objectModelUpdated = function(oObject)
{
	// get the value to be displayed from the model
	var oFieldValueProcessor = this.m_oElementRenderer.getFieldValueProcessors()[0];
	
	var sFieldName = this.m_oElementRenderer.m_sDisplayedField;

	// keep raw value
	this.m_sRawValue = oObject.getFieldValue(sFieldName);

	// get formatted value
	this.m_sFormattedValue = oFieldValueProcessor.getValue(oObject, sFieldName);

	if (this.m_sFormattedValue !== undefined)
	{
		this.writeValue(this.m_sFormattedValue);
	}
};