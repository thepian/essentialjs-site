caplin.namespace("caplinx.widget.objectset");

caplin.include("caplin.core.Observable", true);
caplin.include("caplin.widget.objectset.IndexedRecordObject", true);
caplin.include("caplin.widget.serialization.Serializer");


caplinx.widget.objectset.BlotterRecordObject = function(sObjectName, sIndexFieldName, nMaxNumberChildren)
{
	// call super constructor
	caplin.widget.objectset.IndexedRecordObject.apply(this, [sObjectName, sIndexFieldName, nMaxNumberChildren]);
	
	// Removed temporarily due to City dependance
	// this.m_oBlotterUtils = caplin.widget.objectset.blotter.BlotterUtils.getInstance();
	this.m_oLeg2FieldRegExp = new RegExp("^L2_");
	this.m_oLeg3FieldRegExp = new RegExp("^L3_");
	
	this.m_bAttemptResubscription = false;
	
	caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.addBlotterRecordObject(this);
};
caplin.extend(caplinx.widget.objectset.BlotterRecordObject, caplin.widget.objectset.IndexedRecordObject);

// documented in DataObject
caplinx.widget.objectset.BlotterRecordObject.prototype.getClassIdentifier = function()
{
	return "caplinx.widget.objectset.BlotterRecordObject";
};

// documented in DataObject
caplinx.widget.objectset.BlotterRecordObject.prototype.getSerializer = function()
{
	var l_oSerializer = new caplin.widget.serialization.Serializer();
	
	l_oSerializer.setConstructor("caplinx.widget.objectset.BlotterRecordObject", [this.getName(), this.getIndexFieldName(), this.getMaxNumberChildren()]);
	
	return l_oSerializer;
};

// documented by super class
caplinx.widget.objectset.BlotterRecordObject.prototype.activate = function()
{
	this.m_bAttemptResubscription = false;

	// remove the listener for DataSources going up or down
	caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.addBlotterRecordObject(this);
		
	// pass the call onto the super class
	caplin.widget.objectset.AbstractRttpObject.prototype.activate.apply(this);
};

// documented by super class
caplinx.widget.objectset.BlotterRecordObject.prototype.deactivate = function()
{
	this.m_bAttemptResubscription = false;
	
	// remove the listener for DataSources going up or down
	caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.removeBlotterRecordObject(this);
	
	// pass the call onto the super class
	caplin.widget.objectset.AbstractRttpObject.prototype.deactivate.apply(this);
};

caplinx.widget.objectset.BlotterRecordObject.prototype.recordMultiUpdated = function(l_sObjectName, l_oFieldData)
{
	if(!this.m_bRequestMade)
	{
		return;
	}
	
	var l_oLeg2FieldData = new SL4B_RecordFieldData();
	var l_oLeg3FieldData = new SL4B_RecordFieldData();

	// loop through all the field data and create new field data updates for leg 2 and leg 3 data
	for (var l_nField = 0, l_nSize = l_oFieldData.size(); l_nField < l_nSize; ++l_nField)
	{
		var l_sFieldName = l_oFieldData.getFieldName(l_nField);
		
		// if this is a leg 2 or 3 field, then add it to the appropriate leg field data object,
		// replacing it with the leg 1 field name which is what is expected by the column
		if (l_sFieldName.match(this.m_oLeg2FieldRegExp))
		{
			l_oLeg2FieldData.add(l_sFieldName.replace(this.m_oLeg2FieldRegExp, "L1_"), l_oFieldData.getFieldValue(l_nField));
		}
		else if (l_sFieldName.match(this.m_oLeg3FieldRegExp))
		{
			l_oLeg3FieldData.add(l_sFieldName.replace(this.m_oLeg3FieldRegExp, "L1_"), l_oFieldData.getFieldValue(l_nField));
		}
	}

	// send the leg 3 field data through - if appropriate
	if (l_oLeg3FieldData.size() > 3)
	{
		caplin.widget.objectset.IndexedRecordObject.prototype.recordMultiUpdated.apply(this, [l_sObjectName, l_oLeg3FieldData]);
	}
	
	// send the leg 2 field data through - if appropriate	
	if (l_oLeg2FieldData.size() > 3)
	{
		caplin.widget.objectset.IndexedRecordObject.prototype.recordMultiUpdated.apply(this, [l_sObjectName, l_oLeg2FieldData]);
	}

	// send through the original field data - this is leg 1
	caplin.widget.objectset.IndexedRecordObject.prototype.recordMultiUpdated.apply(this, [l_sObjectName, l_oFieldData]);
};

/**
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.prototype.objectError = function()
{
	this.m_bIsActivated = false;
	this.m_bAttemptResubscription = true;
};

/**
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.prototype.objectUnavailable = function(sObjectName)
{
	this.objectError();
};

/**
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.prototype.objectNotFound = function(sObjectName)
{
	this.objectError();
};

/**
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.prototype.objectReadDenied = function(sObjectName)
{
	this.objectError();
};

/**
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.prototype.objectWriteDenied = function(sObjectName)
{
	this.objectError();
};

/**
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.prototype.resubscribe = function()
{
	if (!this.m_bAttemptResubscription)
	{
		return;
	}
	this.m_bAttemptResubscription = false;
	
	// determine whether there are any fields to be requested
	var sFieldList = this._getFieldList();
	if (sFieldList !== null)
	{
		this.requestFieldList(sFieldList);
	}
};



/**
 * @class
 * Notifies the specified trade subscriber when a data service becomes available. 
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener = function()
{
	this.m_oBlotterRecordObjects = new caplin.core.Observable();
};

caplin.implement(caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener, SL4B_ConnectionListener);

caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.prototype.serviceMessage = function(l_nRttpCode, l_sServiceId, l_sServiceName, l_sMessage)
{
	if (l_nRttpCode == SL4B_RttpCodes.const_SERVICE_OK)
	{
		this.m_oBlotterRecordObjects.notifyObservers("resubscribe");
	}
};

caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.prototype.addBlotterRecordObject = function(oBlotterRecordObject)
{
	this.m_oBlotterRecordObjects.addObserver(oBlotterRecordObject);
};

caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.prototype.removeBlotterRecordObject = function(oBlotterRecordObject)
{
	this.m_oBlotterRecordObjects.removeObserver(oBlotterRecordObject);
};

/**
 * For unit testing purposes only.
 * @private
 */
caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener.prototype._$clear = function()
{
	this.m_oBlotterRecordObjects.removeAllObservers();
};

caplin.singleton("caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener");

// check added for unit tests
if (SL4B_Accessor.getRttpProvider !== undefined)
{
	// add this as a connection listener
	SL4B_Accessor.getRttpProvider().addConnectionListener(caplinx.widget.objectset.BlotterRecordObject.ServiceUpConnectionListener);
}
