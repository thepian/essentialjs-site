caplin.namespace("caplinx.widget.objectset");

caplin.include("caplin.widget.objectset.grid.AbstractGridController", true);
caplin.include("caplin.widget.serialization.Serializer");

caplinx.widget.objectset.TradePanelController = function()
{
	this.m_sStateFieldName = "state";
};

caplin.extend(caplinx.widget.objectset.TradePanelController, caplin.widget.objectset.grid.AbstractGridController);

/**
 * <p>Determines whether the state field has been modified, and if so, invokes the
 * {@link caplinx.widget.objectset.TradePanelController#handleStateChange} method.</p>
 */

caplinx.widget.objectset.TradePanelController.prototype.objectUpdated = function(l_oObject, l_pChangedFields)
{
	var l_nLength;

	for(var i = 0, l_nLength = l_pChangedFields.length; i < l_nLength; ++i)
	{
		var l_sFieldName = l_pChangedFields[i];
		if(l_sFieldName == this.m_sStateFieldName)
		{
			var l_sState = l_oObject.getFieldValue(this.m_sStateFieldName);
			this.handleStateChange(l_oObject, l_sState);
		}
	}
};

/**
 * <p>Handles state changes for a particular object within the Quick Trade panel. If the state is
 * one of the final states, it clones the trade model so that the object can be reused for trading
 * in the future.</p>
 *
 * @param {caplin.widget.objectset.DataObject} l_oObject The object for which the state has
 *                                                 changed.
 *                 for the available states).
 */

caplinx.widget.objectset.TradePanelController.prototype.handleStateChange = function(l_oObject, l_sState)
{
	this.FINAL_STATES = {
			confirmed	: true,
			expired		: true,
			cancelled	: true,
			passed		: true,
			error		: true
	};
	//this resets the trade data...must go after state changes
	if (l_sState in this.FINAL_STATES)
	{
		// MUSTDO: encapsulate the trade model reuse properly
		var l_oPanel = this.getView().getPanel();
		l_oPanel.recycleTradeModel(l_oObject);
	}
};

// documented in AbstractController
caplinx.widget.objectset.TradePanelController.prototype.getSerializer = function()
{
    var l_oSerializer = new caplin.widget.serialization.Serializer();

    l_oSerializer.setConstructor("caplinx.widget.objectset.TradePanelController",[]);
    return l_oSerializer;
};
