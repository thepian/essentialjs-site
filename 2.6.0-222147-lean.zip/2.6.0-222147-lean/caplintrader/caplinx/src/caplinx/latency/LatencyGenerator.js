caplin.namespace("caplinx.latency");

caplin.include("caplin.element.ElementFactory");
caplin.include("caplin.core.Logger");
caplin.include("caplin.element.buffer.DisplayLatencyListener", true);
caplin.include("caplin.bootstrap.ThreadQueueListener", true);
caplin.include("caplin.core.LogLevel");

caplinx.latency.LatencyGenerator = function()
{
	this.m_sLatencyPulseSubject = "/LATENCY/PULSE";
	this.m_sLatencyFieldName = "LATENCY_TIMESTAMP";
	
	this.m_pListeners = [];
	this.m_bSubscriptionOk = false;
	this.m_nBrowserTimeQuantizationOffset = this._getBrowserTimeQuantization() / 2;
	
	this.m_nConnectionLatency = null;
	this.m_nDisplayLatency = 0;
	this.m_nDueTimers = 0;
	this.m_nTotalTimers = 0;
	caplin.element.ElementFactory.getDisplayBuffer().addDisplayLatencyListener(this);
	caplin.bootstrap.ThreadScheduler.addThreadQueueListener(this);
	this.initialise();
};
caplin.extend(caplinx.latency.LatencyGenerator, SL4B_AbstractSubscriber);
caplin.extend(caplinx.latency.LatencyGenerator, SL4B_ConnectionListener);
caplin.implement(caplinx.latency.LatencyGenerator, caplin.element.buffer.DisplayLatencyListener);
caplin.implement(caplinx.latency.LatencyGenerator, caplin.bootstrap.ThreadQueueListener);

/**
 *	@param (caplinx.latency.LatencyListener) oListener
 */
caplinx.latency.LatencyGenerator.prototype.addListener = function(oListener)
{
	this.m_pListeners.push(oListener);
	this._sendCurrentLatencyStatus(oListener);
};


/******************************************************************************
 * SL4B Callbacks
 *****************************************************************************/

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.ready = function()
{
	SL4B_Accessor.getRttpProvider().addConnectionListener(this);
	this._subscribeToLatencyPulse();
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.recordMultiUpdated = function(Objectname, fields, cachedimage)
{
	this.m_bSubscriptionOk = true;
	if(SL4B_Accessor && SL4B_Accessor.getStatistics && SL4B_Accessor.getStatistics().getLatency)
	{
		var oStatistics = SL4B_Accessor.getStatistics();
		this.m_nConnectionLatency = oStatistics.getLatency() + this.m_nBrowserTimeQuantizationOffset;
	}
	
	// if there hasn't been a display latency for a longer period then the the display latency would normally take, then
	// put it down to zero -- we are probably on a blank sheet with no updates
	if(new Date().getTime() > (this.m_nLastDisplayLatencyUpdate + (this.m_nDisplayLatency * 1.5) + 1000))
	{
		this.m_nDisplayLatency = 0;
	}
	
	this._informListenersOfLatencyUpdate();
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.objectStatus = function(sObjectName, nType, nCode, sMessage)
{
	if(nType != SL4B_ObjectStatus.OK)
	{
		this.m_nConnectionLatency = null;
		this._informListenersOfLatencyAvailabiltyProblem();
	}
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.objectUnavailable = function(sObjectName)
{
	this._subscriptionError("unavailable");
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.objectNotFound = function(sObjectName)
{
	this._subscriptionError("not found");
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.objectReadDenied = function(sObjectName)
{
	this._subscriptionError("read denied");
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.objectWriteDenied = function(sObjectName)
{
	this._subscriptionError("write denied");
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.objectDeleted = function(sObjectName)
{
	this._subscriptionError("deleted");
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.serviceMessage = function(nRttpCode, sServiceId, sServiceName, sMessage)
{
	if (nRttpCode == SL4B_RttpCodes.const_SERVICE_OK && this.m_bSubscriptionOk === false)
	{
		this._informListenersOfLatencyAvailabiltyProblem();
		
		this.m_bSubscriptionOk = true;
		this._subscribeToLatencyPulse();
	}
};


/******************************************************************************
 * DisplayLatencyListener
 *****************************************************************************/

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.onDisplayLatencyUpdate = function(nDisplayLatency)
{
	this.m_nDisplayLatency = nDisplayLatency;
	this.m_nLastDisplayLatencyUpdate = new Date().getTime();
	
	this._informListenersOfLatencyUpdate();
};


/******************************************************************************
 * ThreadQueueListener
 *****************************************************************************/

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype.onThreadQueueUpdate = function(nDueTimers, nTotalTimers)
{
	// todo: what are the performance implications of doing this more often?
	// don't bother updating the screen every thread queue update
	this.m_nDueTimers = nDueTimers;
	this.m_nTotalTimers = nTotalTimers;
};


/******************************************************************************
 * Private Methods
 *****************************************************************************/

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._subscribeToLatencyPulse = function()
{
	SL4B_Accessor.getRttpProvider().getObject(this, this.m_sLatencyPulseSubject, this.m_sLatencyFieldName);
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._subscriptionError = function(sReason)
{
	caplin.core.Logger.log(caplin.core.LogLevel.CRITICAL, "Subscription to latency pulse subject \"" + this.m_sLatencyPulseSubject + "\" failed: {0}", sReason);
	this.m_bSubscriptionOk = false;
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._sendCurrentLatencyStatus = function(oListener)
{
	if (this.m_nConnectionLatency === null)
	{
		oListener.onLatencyNotAvailable();
	}
	else
	{
		this._updateSL4BQueueStatistics();
		this._informListenerOfLatencyUpdate(oListener);
	}
}

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._informListenersOfLatencyUpdate = function()
{
	if(this.m_nConnectionLatency !== null)
	{
		this._updateSL4BQueueStatistics();
		
		for(var i = 0, l = this.m_pListeners.length; i < l; ++i)
		{
			var oListener = this.m_pListeners[i];
			
			this._informListenerOfLatencyUpdate(oListener);
		}
	}
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._informListenerOfLatencyUpdate = function(oListener)
{
	oListener.onLatencyUpdate(this.m_nConnectionLatency, this.m_nDisplayLatency, this.m_nUnprocessedMessageCount,
		this.m_nUnprocessedMessageBatchCount, this.m_nDueTimers, this.m_nTotalTimers);
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._informListenersOfLatencyAvailabiltyProblem = function()
{
	for(var i = 0, l = this.m_pListeners.length; i < l; ++i)
	{
		var oListener = this.m_pListeners[i];
		
		oListener.onLatencyNotAvailable();
	}
};

/**
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._updateSL4BQueueStatistics = function()
{
	if(SL4B_Accessor && SL4B_Accessor.getStatistics && SL4B_Accessor.getStatistics().getResponseQueueStatistics)
	{
		this.m_nUnprocessedMessageBatchCount = SL4B_Accessor.getStatistics().getResponseQueueStatistics().getQueuedBatchCount();
		this.m_nUnprocessedMessageCount = SL4B_Accessor.getStatistics().getResponseQueueStatistics().getQueuedMessageCount();
	}
};

/**
 * Returns the browser time quantization length (time is always rounded down).
 * @private
 */
caplinx.latency.LatencyGenerator.prototype._getBrowserTimeQuantization = function()
{
	var nStartTime = new Date().getTime();
	var nCurrentTime = null;
	
	do
	{
		nCurrentTime =  new Date().getTime();
	} while(nCurrentTime === nStartTime);
	
	return nCurrentTime - nStartTime;
};
