caplin.namespace("caplinx.latency");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplinx.latency.LatencyGenerator", true);

caplinx.latency.StatusBarLatencyDisplay = function()
{
	this.m_oLatencyGenerator = new caplinx.latency.LatencyGenerator();
	this.m_oLatencyGenerator.addListener(this);
};

caplinx.latency.StatusBarLatencyDisplay.prototype.onLatencyUpdate = function(nConnectionLatency, nDisplayLatency, nUnprocessedMessageCount,
	nUnprocessedMessageBatchCount, nDueTimers, nTotalTimers)
{
	if(!this.m_eConnectionLatency)
	{
		this._initializeHtml();
	}
	
	if(this.m_eConnectionLatency)
	{
		this.m_eConnectionLatency.nodeValue = nConnectionLatency;
		this.m_eDisplayLatency.nodeValue = nDisplayLatency;
		this.m_eUnprocessedMessageCount.nodeValue = nUnprocessedMessageBatchCount + "/" + nUnprocessedMessageCount;
		this.m_eScheduledTimers.nodeValue = nDueTimers + " of " + nTotalTimers;
	}
};

caplinx.latency.StatusBarLatencyDisplay.prototype.onLatencyNotAvailable = function()
{
	if(!this.m_eConnectionLatency)
	{
		this._initializeHtml();
	}
	
	if(this.m_eConnectionLatency)
	{
		this.m_eConnectionLatency.nodeValue = "-";
		this.m_eDisplayLatency.nodeValue = "-";
		this.m_eUnprocessedMessageCount = "-";
		this.m_eScheduledTimers = "-";
	}
};

caplinx.latency.StatusBarLatencyDisplay.prototype._initializeHtml = function()
{
	var eLatencyPlaceHolder = document.getElementById("latencyInfo");
	
	if(eLatencyPlaceHolder)
	{
		eLatencyPlaceHolder.style.width = "550px";
		
		eLatencyPlaceHolder.innerHTML =
			"<div style='width:140px;'>" + ct.i18n("cx.latency.status.bar.connection") + " <span>-</span></div>" +
			"<div style='width:120px; position:absolute; top:0; left:140px;'>" + ct.i18n("cx.latency.status.bar.display") + " <span>-</span></div>" +
			"<div style='width:140px; position:absolute; top:0; left:260px;'>" + ct.i18n("cx.latency.status.bar.messages") + " <span>-</span></div>" +
			"<div style='width:140px; position:absolute; top:0; left:400px;'>" + ct.i18n("cx.latency.status.bar.queue") + " <span>-</span></div>";
		this.m_eConnectionLatency = eLatencyPlaceHolder.childNodes[0].childNodes[1].firstChild;
		this.m_eDisplayLatency = eLatencyPlaceHolder.childNodes[1].childNodes[1].firstChild;
		this.m_eUnprocessedMessageCount = eLatencyPlaceHolder.childNodes[2].childNodes[1].firstChild;
		this.m_eScheduledTimers = eLatencyPlaceHolder.childNodes[3].childNodes[1].firstChild;
	}
};