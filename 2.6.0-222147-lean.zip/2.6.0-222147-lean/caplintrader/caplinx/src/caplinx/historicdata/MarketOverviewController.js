/**
 * @fileoverview
 * Defines caplinx.historicdata.MarketOverviewController class.
 */

caplin.namespace("caplinx.historicdata");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.component.composite.CompositeComponentController", true);
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplinx.historicdata.MarketOverviewSettingsController");
caplin.include("caplin.chart.menu.ContextMenu");
caplin.include("caplin.chart.TableFormatter");
caplin.include("caplin.chart.HTMLTableGenerator");
caplin.include("caplin.core.Utility");

/**
 * Constructs a new <code>MarketOverviewController</code>.
 * <p>This class implements the {@link caplin.component.composite.CompositeComponentController} interface
 * and is responsible for handling the communication between each of its components.</p>
 * @class
 * @implements caplin.component.composite.CompositeComponentController
 */
caplinx.historicdata.MarketOverviewController = function()
{
	/**
	 * @private
	 * @type Map
	 * The components held within this composite component.
	 */
	this.m_mComponents = null;
	
	/** 
	 * @private
	 * @type caplin.component.composite.CompositeComponent
	 */
	this.m_oCompositeComponent = null;
	
	/**
	 * An Array of caplin.component.comms.OpenAjaxChannelSubscriptionHelper
	 * @type Array
	 * @private
	 */
	this.m_pOpenAjaxSubscriptionHelpers = [];
	
	/**
	 * @private
	 * @type caplinx.historicdata.MarketOverviewSettingsController
	 * Object that handles the form settings panel.
	 */
	this.m_oSettingsPanelController = null;
	
	/**
	 * @private
	 * @type caplin.chart.menu.HDCContextMenu
	 * Object used to display a context menu
	 */
	this.m_oContextMenu = this._createContextMenu();
};
caplin.implement(caplinx.historicdata.MarketOverviewController, caplin.component.composite.CompositeComponentController);

/*******************************************************************************
 *      caplin.component.composite.CompositeComponentController Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#initialize
 */
caplinx.historicdata.MarketOverviewController.prototype.initialize = function(mComponents, oCompositeComponent)
{
	this.m_mComponents = mComponents;
	for(sComponentName in this.m_mComponents)
	{
		if(sComponentName === "chartSettingsPanel")
		{
			this.m_oSettingsPanelController =
				new caplinx.historicdata.MarketOverviewSettingsController( this.m_mComponents[sComponentName] );
		}
	}	
	
	if(!OpenAjax)
	{
		throw new caplin.core.Exception("The OpenAjax hub is not defined", "caplinx.historicdata.MarketOverviewController.initialize");
	}
		
	this.m_oCompositeComponent = oCompositeComponent;

	this._setupChannels();	
	this._setupContextMenu(this.m_oCompositeComponent);
};	

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#finalize
 */
caplinx.historicdata.MarketOverviewController.prototype.finalize = function()
{
	if(this.m_pOpenAjaxSubscriptionHelpers.length > 0)
	{
		for(var i = 0, l = this.m_pOpenAjaxSubscriptionHelpers.length ; i < l ; i++)
		{
			this.m_pOpenAjaxSubscriptionHelpers[ i ].finalize();
		}
		this.m_pOpenAjaxSubscriptionHelpers = null;
	}
	
	this.m_oSettingsPanelController.finalize();
	this.m_mComponents = null;
	this.m_oContextMenu.finalize();
};

/*******************************************************************************
 *             					Public Methods
 *******************************************************************************/

/**
 * This method is responsible for showing/hiding the settings panel
 */
caplinx.historicdata.MarketOverviewController.prototype.toggleSettingsPanel = function()
{
	var nSettingsPanelSize = this.m_oCompositeComponent.getComponentSize("chartSettingsPanel");
	if(nSettingsPanelSize > 0)
	{
		this.m_oCompositeComponent.hideComponent("chartSettingsPanel");
	}
	else
	{
		this.m_oCompositeComponent.$setComponentSize("chartSettingsPanel", 78);
	}
};

/**
 * This method is responsible for printing the chart
 */
caplinx.historicdata.MarketOverviewController.prototype.print = function()
{
	// Print 3m_interbank_chart
	var oChart = this.m_mComponents["3m_interbank_chart"];
	caplinx.historicdata.MarketOverviewController.Chart3m = oChart;

	//Set the domain and chart title as parameters. The html page picks it up using location.href.
	var sTitle = webcentric.getActiveComponent().get("caption");
	var l_sUrl = "3m_interbank_chart_print_template.html?domain=" + window.document.domain + "&title=" + sTitle;

	var nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
	var l_sFeatures = "width=650,height=800,left=10,top=10";
	l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
	l_o3mPrintWindow = window.open(l_sUrl, nWindowId, l_sFeatures);

	// Print 3m_interbank_chart
	oChart = this.m_mComponents["10y_swap_chart"];
	caplinx.historicdata.MarketOverviewController.Chart10y = oChart;

	//Set the domain and chart title as parameters. The html page picks it up using location.href.
	sTitle = webcentric.getActiveComponent().get("caption");
	l_sUrl = "10y_swap_chart_print_template.html?domain=" + window.document.domain + "&title=" + sTitle;
	
	nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
	l_sFeatures = "width=650,height=800,left=60,top=60";
	l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
	l_o3mPrintWindow = window.open(l_sUrl, nWindowId, l_sFeatures);

	var oGridView = this.m_mComponents.fi_historic_grid;
	var oGridRowModel = oGridView.getGridRowModel();
	var oDataProvider = oGridRowModel._$getDataProvider();
	var pTableData = oDataProvider.getDataForAllRows();
	var mRendererTypes = oGridView.getRendererTypesIndexedByColumnName();
	var oTableFormatter = new caplin.chart.TableFormatter();
	var pData = oTableFormatter.formatTable(pTableData, mRendererTypes);
	var pFields = oDataProvider.getDataSetFields();
	
	var htmlTableGenerator = new caplin.chart.HTMLTableGenerator();
	var sTable = htmlTableGenerator.generateHTMLTable(pFields, pData);
	
	var sUrl = "gridPrintPage.html?domain=" + window.document.domain;
	nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
	l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
	l_oPrintWindow = window.open(sUrl, nWindowId, l_sFeatures);

	setTimeout(function(){
		if(l_oPrintWindow){
			l_oPrintWindow.document.body.innerHTML = sTable;
		}
	}, 1000);
	return false;
};

/**
 * This method is responsible for showing and hiding the context menu
 */
caplinx.historicdata.MarketOverviewController.prototype.toggleContextMenu = function()
{
	this._refreshContextMenu();
	this.m_oContextMenu.toggle();
};

/*******************************************************************************
 *             					Private Methods
 *******************************************************************************/

/**
 * @private
 * Sets up objects that help with the listening for events over the OpenAjax hub.
 */
caplinx.historicdata.MarketOverviewController.prototype._setupChannels = function()
{
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "toggleSettingsPanel", this, this.toggleSettingsPanel));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "print", this, this.print));
	
	var pComponentsToLink = [this.m_oCompositeComponent];
	
	for (var sKey in this.m_mComponents)
	{
		pComponentsToLink.push(this.m_mComponents[sKey]);
	}
	
	caplin.component.comms.InterComponentComms.linkComponents(pComponentsToLink);
};

/**
 * @private
 */
caplinx.historicdata.MarketOverviewController.prototype._setupContextMenu = function(oComponent)
{	
	var eCompositeComponentElement = this.m_oCompositeComponent.getElement();	
	eCompositeComponentElement.appendChild(this.m_oContextMenu.getElement());
	this.m_oContextMenu.setRelativeElement(eCompositeComponentElement);
	this.m_oContextMenu.setComponent(oComponent);
};

/**
 * @private
 */
caplinx.historicdata.MarketOverviewController.prototype._createContextMenu = function()
{
	var oContextMenuConfig = {
		settings: {
			text:ct.i18n("cx.historic.data.context.menu.hide_settings"),
			disabled:false,
			event:"toggleSettingsPanel"
		},
		exportToExcel: {
			text:ct.i18n("cx.historic.data.context.menu.export_to_excel"),
			disabled:false,
			event:"export",
			separate: true
		},
		print: {
			text:ct.i18n("cx.historic.data.context.menu.print"),
			disabled:false,
			event:"print"
		}
	};
	
	return new caplin.chart.menu.ContextMenu(oContextMenuConfig);
};

/**
 * @private
 */
caplinx.historicdata.MarketOverviewController.prototype._refreshContextMenu = function()
{
	var nSettingPanelSize = this.m_oCompositeComponent.getComponentSize("chartSettingsPanel");
	if (nSettingPanelSize === 0) {
		this.m_oContextMenu.setItemText("settings", ct.i18n("cx.historic.data.context.menu.show_settings"));
	} else {
		this.m_oContextMenu.setItemText("settings", ct.i18n("cx.historic.data.context.menu.hide_settings"));
	}
};

