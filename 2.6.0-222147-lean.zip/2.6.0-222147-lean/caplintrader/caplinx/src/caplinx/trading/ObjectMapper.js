// WARNING:
// this is a clone of a previous implementation that needs to be replaced with (perhaps) an interface, with 
// various implementations (of which this will be one)

caplin.namespace("caplinx.trading");

caplinx.trading.ObjectMapper = function()
{
   this.m_oSectorToCusipBasedObjectMap = new Object();
   this.m_oSectorToCusipBasedObjectMap["UST"] = true;
   this.m_oSectorToCusipBasedObjectMap["AG"] = true;
   this.m_oSectorToCusipBasedObjectMap["HG"] = true;
   this.m_oSectorToCusipBasedObjectMap["IRS"] = true;
};

caplinx.trading.ObjectMapper.FX_INSTRUMENT_REG_EXP = new RegExp("^/FT/FX/");
caplinx.trading.ObjectMapper.FX_OBJECT_NAME_REPLACEMENT_REG_EXP = new RegExp("\\.C\\d$");

/**
 * @param {DOMElement} l_oDataNode XML Element representing one result row in the following form:
 *<Product>
 *		<EntityId>100180</EntityId>
 *		<Sector>UST</Sector>
 *		<ProductType/>
 *		<Cusip>912810DF2</Cusip>
 *		<ISIN/>
 *		<Axed/>
 *		<Ticker/>
 *		<ProductDesc>TREAS BONDS</ProductDesc>
 *		<Coupon>12.0</Coupon>
 *		<Maturity>Aug 15 2013 12:00AM</Maturity>
 *		<SettlementDate>T+1</SettlementDate>
 *		<IssurCountry/>
 *		<Currency>USA</Currency>
 *	</Product>
 */
caplinx.trading.ObjectMapper.prototype.mapRttpObject = function(l_oDataNode)
{
   var l_sRttpObjectName = "";
   var l_sBaseName = "/FT/FI";
   var l_pSectorTags = l_oDataNode.getElementsByTagName("Sector");
   var l_pCusipTags = l_oDataNode.getElementsByTagName("Cusip");
   var l_pIsinTags = l_oDataNode.getElementsByTagName("ISIN");
   if (l_pSectorTags.length == 1)
   {
     	var l_sSector = l_pSectorTags[0].childNodes[0].nodeValue;
	   if (this.isCusipBasedObjectName(l_oDataNode))
	   {
	   	if (l_pCusipTags.length == 1 && l_pCusipTags[0].childNodes.length == 1)
	   	{
	  	      var l_sCusip = l_pCusipTags[0].childNodes[0].nodeValue;
		   	l_sRttpObjectName = l_sBaseName + "/" + this.convertSectorToRttpDirectory(l_sSector, l_sCusip) + "/" + l_sCusip;
	   	}
	   }
	   else
	   {
	   	if (l_pIsinTags.length == 1 && l_pIsinTags[0].childNodes.length == 1)
	   	{
	  	      var l_sIsin = l_pIsinTags[0].childNodes[0].nodeValue;
		   	l_sRttpObjectName = l_sBaseName + "/" + this.convertSectorToRttpDirectory(l_sSector, l_sIsin) + "/" + l_sIsin;
	   	}
	   }
	}
   return l_sRttpObjectName;
};

caplinx.trading.ObjectMapper.prototype.convertSectorToRttpDirectory = function(l_sSector, l_sIdentifier)
{
	var l_sDirectory;
	switch (l_sSector)
	{
	case "EUR_CORP":
		l_sDirectory = "EB";
		break;
	case "EG":
		// check if this instrument is a Gilt or not
		if (l_sIdentifier.match(/^GB/))
		{
			l_sDirectory = "GLT";
		}
		else
		{
			l_sDirectory = l_sSector;
		}
		break;
	default: l_sDirectory = l_sSector;
	}
	return l_sDirectory;
};

caplinx.trading.ObjectMapper.prototype.mapCurrencyPair = function(l_sCurrencyPair)
{
   var l_sResult = "/FT/FX/" + l_sCurrencyPair;
   return l_sResult;
};

caplinx.trading.ObjectMapper.prototype.isCusipBasedObjectName = function(l_oDataNode)
{
	var l_bIsCusipBasedObjectName = false;
   var l_pSectorTags = l_oDataNode.getElementsByTagName("Sector");
   if (l_pSectorTags.length == 1)
   {
   	var l_sSector = l_pSectorTags[0].childNodes[0].nodeValue;
   	l_bIsCusipBasedObjectName = (this.m_oSectorToCusipBasedObjectMap[l_sSector] == true);
   }
   return l_bIsCusipBasedObjectName;
};

caplinx.trading.ObjectMapper.prototype.transformObjectName = function(l_sObjectName)
{
	// remove object mapping data from the end of an FX object from a container, otherwise an object
	// not found response will be received
	if (l_sObjectName.match(caplinx.trading.ObjectMapper.FX_INSTRUMENT_REG_EXP))
	{
		l_sObjectName = l_sObjectName.replace(caplinx.trading.ObjectMapper.FX_OBJECT_NAME_REPLACEMENT_REG_EXP, "");
	}
	return l_sObjectName;
};
