caplin.namespace("caplinx.trading.fx");

/**
 * Skeleton for an FX ticket controller
 * 
 * Illustrates how to wire up an FX ticket
 */
caplinx.trading.fx.FxComponentFormControllerSkeleton = function( )
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "constructed FxComponentFormControllerSkeleton");
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.initialize = function(mFormProperties,mPropertyByName,mPropertyBySetter)
{
	var pProp = [];
	if (mPropertyByName) for(var n in mPropertyByName) pProp.push(n+"="+mPropertyByName[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "initialized by name ["+pProp.join(" ")+"] ");
	var pProp = [];
	if (mPropertyBySetter) for(var n in mPropertyBySetter) pProp.push(n+"="+mPropertyBySetter[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "(!!) initialized by setter ["+pProp.join(" ")+"] ");
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.reinitialize = function(mFormProperties,mPropertyByName,mPropertyBySetter)
{
	var pProp = [];
	if (mPropertyByName) for(var n in mPropertyByName) pProp.push(n+"="+mPropertyByName[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "reinitialized by name ["+pProp.join(" ")+"] ");
	var pProp = [];
	if (mPropertyBySetter) for(var n in mPropertyBySetter) pProp.push(n+"="+mPropertyBySetter[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "reinitialized by setter ["+pProp.join(" ")+"] ");
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.initializeView = function(oView,mFormProperties,mPropertyByName,mPropertyBySetter)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "initialized view ");
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.reset = function(oView,sNamespace,sName,vValue,sStage)
{
	return vValue == undefined? "" : vValue;
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.toggle = function(oView,sNamespace,sName,vValue)
{
	return !vValue; 
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.increase = function(oView,sNamespace,sName,vValue,vStep)
{
	if (typeof vValue == "string") vValue = parseFloat(vValue) || 0;
	return vValue + vStep; 
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.decrease = function(oView,sNamespace,sName,vValue,vStep)
{
	if (typeof vValue == "string") vValue = parseFloat(vValue) || 0;
	return vValue - vStep; 
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.editdone = function(oView, sNamespace,sName, vValue)
{

};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.set = function(oView, sNamespace,sName, vValue)
{
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.command = function(oView,sNamespace,sCommand)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "command triggered "+ sCommand);
};


caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.onOpen = function(oView)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onOpen "+oView);
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.onShow = function()
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onShow called");
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.onResize = function(mParams)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onResize "+ (window.JSON? JSON.stringify(mParams) : ""));
};


caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.onClose = function(oView)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onClose "+oView);
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.onBeforeClose = function(oView)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onBeforeClose "+oView);
};




caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.setProtocol = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "protocol = "+ sValue);
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.setObjectName = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "object name = "+ sValue);
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.setBuySell = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "buy/sell = "+ sValue);
};

caplinx.trading.fx.FxComponentFormControllerSkeleton.prototype.setAmount = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "amount = "+ sValue);
};

/*

	<property setter="setInitialDealtCurrency"/>
	<property setter="setAccount"/>
	<property setter="setFwdSizeIncrease" value="41"/>
	<property setter="setSwapSizeIncrease" value="171"/>  
 */
