caplin.namespace("caplinx.trading.trademodel");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.trading.trademodel.TenorProvider", true);

/**
 * 
 */
caplinx.trading.trademodel.FxTenorProvider = function(){
	
};

caplin.implement(caplinx.trading.trademodel.FxTenorProvider, caplin.trading.trademodel.TenorProvider);

/**
 * Gets all the available Tenors for this leg.
 * 
 * @param {caplin.trading.trademodel.TradeLeg} l_oTradeLeg The trade leg for which these tenors are being requested.
 * @type Object
 * @return Map of Server Tenor code to Display Tenor String
 */
caplinx.trading.trademodel.FxTenorProvider.prototype.getTenors = function(l_oTradeLeg)
{
	return  {
		ON: ct.i18n('fxtile.tenor.on'),
		TN: ct.i18n('fxtile.tenor.tn'),
		SPOT: ct.i18n('fxtile.tenor.spot'),
		SN: ct.i18n('fxtile.tenor.sn'),
		'5D': ct.i18n('fxtile.tenor.5d'),
		'1W':ct.i18n('fxtile.tenor.1w'),
		'2W':ct.i18n('fxtile.tenor.2w'),
		'3W':ct.i18n('fxtile.tenor.3w'),
		'4W':ct.i18n('fxtile.tenor.4w'),
		'1M':ct.i18n('fxtile.tenor.1m'),
		'2M':ct.i18n('fxtile.tenor.2m'),
		'3M':ct.i18n('fxtile.tenor.3m'),
		'4M':ct.i18n('fxtile.tenor.4m'),
		'5M':ct.i18n('fxtile.tenor.5m'),
		'6M':ct.i18n('fxtile.tenor.6m'),
		'7M':ct.i18n('fxtile.tenor.7m'),
		'8M':ct.i18n('fxtile.tenor.8m'),
		'9M':ct.i18n('fxtile.tenor.9m'),
		'10M':ct.i18n('fxtile.tenor.10m'),
		'11M':ct.i18n('fxtile.tenor.11m'),
		'12M':ct.i18n('fxtile.tenor.12m'),
		'1Y':ct.i18n('fxtile.tenor.1y'),
		'15M':ct.i18n('fxtile.tenor.15m'),
		'18M':ct.i18n('fxtile.tenor.18m'),
		'21M':ct.i18n('fxtile.tenor.21m'),
		'24M':ct.i18n('fxtile.tenor.24m'),
		'2Y':ct.i18n('fxtile.tenor.2y')
	};
};

/**
 * Gets the initialization Tenor for a leg. The tenor which the tradeleg is defaulted to upon creation.
 * @param {caplin.trading.trademodel.TradeLeg} l_oTradeLeg The trade leg for which these tenors are being requested.
 * @type String
 * @return the default Server tenor code
 */
caplinx.trading.trademodel.FxTenorProvider.prototype.getDefaultTenor = function(l_oTradeLeg)
{
	if (l_oTradeLeg.getTrade().getTradingType() == "SPOT")
	{
		return "SPOT";
	}
	else
	{
		return "1W";
	}
};