caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.TradeTypeListener = function(l_oTradeTicket)
{
	 this.m_oTradeTicket = l_oTradeTicket;
	 this.m_oTradeModel  = null;
};

caplinx.trading.presentation.listeners.TradeTypeListener.prototype.setModel = function(l_oTradeModel)
{
	 if(this.m_oTradeModel != null){
	 	this.m_oTradeModel.removeDataFieldChangedListener(this);
	 }
	 this.m_oTradeModel = l_oTradeModel;
	 this.m_oTradeModel.addDataFieldChangedListener(this, "TradingType");
};

/*
 * Called when the date or trade type,  is changed
 */
caplinx.trading.presentation.listeners.TradeTypeListener.prototype.dataFieldChanged = function(sTradingType, sOldTradingType)
{	
	var l_oTicket = this.m_oTradeTicket;

	if(sTradingType == "SWAP" || sTradingType == "FWDFWDSWAP" )
	{
		var oLeg2 = this.m_oTradeModel.getLeg(1);
		l_oTicket.m_oLeg2Adapter = l_oTicket._bindLeg(l_oTicket.m_oLeg2Adapter, oLeg2); 
		
		if(l_oTicket.m_oSettlementTenorLeg2Control == null)
		{
			l_oTicket.m_oTicketBodyElement.className = l_oTicket._getTicketClassname();
			l_oTicket._initialiseSwapRenderers.call(l_oTicket, l_oTicket.m_oLeg2Adapter);
		}

		// if switching from spot to swap for the first time the second leg won't have any values and so don't persist the values
		if (l_oTicket._doResetTradeModelValues(sTradingType, sOldTradingType) === true)
		{
			var bPersitsTradeValues = true;
			if (oLeg2.getAmount() == undefined) bPersitsTradeValues = false;
			l_oTicket._resetTradeModel(true, true, bPersitsTradeValues);
		}

	}
	else
	{
		if (l_oTicket._doResetTradeModelValues(sTradingType, sOldTradingType) === true) 
		{
			l_oTicket._resetTradeModel(true, true, false);
		}
	}
	
	l_oTicket.resizeTicket(sTradingType);
	l_oTicket.m_oTicketBodyElement.className = l_oTicket._getTicketClassname();
};
