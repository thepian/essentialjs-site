////////////////////////////////////////
// FXTrade StateChangedListener
////////////////////////////////////////
caplin.namespace("caplinx.trading.presentation.listeners");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplinx.tobo.TOBOUserManager");

caplinx.trading.presentation.listeners.StateChangedListener = function(l_oTradeTicket)
{
    this.m_oTradeTicket = l_oTradeTicket;
    this.m_oTradeModel = null
};

caplinx.trading.presentation.listeners.StateChangedListener.prototype.setModel = function(l_oTradeModel)
{
	if(this.m_oTradeModel != null)
	{
		 this.m_oTradeModel.removeStateChangedListener(this);
	}
	this.m_oTradeModel = l_oTradeModel;
	this.m_oTradeModel.addStateChangedListener(this);
	this.m_sStateName = "";
};

caplinx.trading.presentation.listeners.StateChangedListener.prototype.stateChanged = function(l_oState)
{	
	if(l_oState.getName() == this.m_sStateName){
		return;
	}
	
	this.m_sStateName = l_oState.getName();

	switch(this.m_sStateName){
		case "Initial":
			this.m_oTradeTicket._setButtonsForInitial();
			this.m_oTradeTicket._setTicketDataFieldsDisabled(false);
			this.m_oTradeTicket._checkIfGetQuoteIsEnabled();
			break;
		case "OpenSent":
			caplinx.tobo.TOBOUserManager.tradeStarted();
			this.m_oTradeTicket._setStatusMessage(ct.i18n("cx.trading.presentation.state.change.status.message.requesting_quote"));
			this.m_oTradeTicket._setTimerMessage("");
			this.m_oTradeTicket._displayAmountAsText();
			this.m_oTradeTicket._setTicketDataFieldsDisabled(true);
			this.m_oTradeTicket.m_oFooterCancelButton.disable(false);
			this.m_oTradeTicket.m_oRequestQuoteButton.setEnabled(false);
			break;
		case "Opened":
			var l_sTradeId = this.m_oTradeTicket.m_oTradeModel.getTradeID();
			this.m_nOverallTimeOut = this.m_oTradeTicket.m_oTradeModel.getOverallTimeOut();
			this.m_oTradeTicket._setStatusMessage(ct.i18n("cx.trading.presentation.state.change.status.message.waiting_for_quote"));
			this.m_oTradeTicket._setTradeIdTitle("ID: " + l_sTradeId);
			//This if added because of PCTD-492 else the last used currency is visible until an executable is received			
			this.m_oTradeTicket._setTradeExecuteButtonCaptions();
			this.m_oTradeTicket._disableExecuteButtons();	
			this.m_oTradeTicket._displayTradeFields();
			break;
		case "Executable":
			this.m_oTradeTicket._startOverallTimeout(this.m_nOverallTimeOut);			
			this.m_oTradeTicket._enableExecuteButtons();
			break;
		case "ExecuteSent":
			this.m_oTradeTicket.m_oFooterCancelButton.disable(true);
			this.m_oTradeTicket.m_oFooterCloseButton.disable(true);
			this.m_oTradeTicket._setStatusMessage(ct.i18n("cx.trading.presentation.state.change.status.message.executing"));
			this.m_oTradeTicket._setTimerMessage("");
			break;
		case "Executed":
			this.m_oTradeTicket._setStatusMessage(ct.i18n("cx.trading.presentation.state.change.status.message.awaiting_confirmation"));
			break;
		case "TradeConfirmed":
			caplinx.tobo.TOBOUserManager.tradeFinished();
			var l_oTradeData = this.m_oTradeModel.getSerializedData();
			this.m_oTradeTicket._displayConfirmation(l_oTradeData.getDataAsMap());
			this.m_oTradeTicket._setButtonsForTradeAgain();
		 	break;
		case "ClientCloseSent": 
			 caplinx.tobo.TOBOUserManager.tradeFinished();
			 break;
		case "ClientClosed":  
			 break;
		case "TradePassed":  
			this.m_oTradeTicket._setTimeoutMessageAndRecycle(ct.i18n("cx.trading.presentation.state.change.status.message.trade_passed")); 
			caplinx.tobo.TOBOUserManager.tradeFinished();
			break;
		case "ExecuteExpired": 
			this.m_oTradeTicket._setTimeoutMessageAndRecycle(ct.i18n("cx.trading.presentation.state.change.status.message.execute_expired"));
			caplinx.tobo.TOBOUserManager.tradeFinished();
			break;
		case "Withdrawn": 
			this.m_oTradeTicket._setTimeoutMessageAndRecycle(ct.i18n("cx.trading.presentation.state.change.status.message.withdrawn"));
			caplinx.tobo.TOBOUserManager.tradeFinished();
			break;
		case "Expired":
		  	this.m_oTradeTicket._setTimeoutMessageAndRecycle(ct.i18n("cx.trading.presentation.state.change.status.message.expired"));
			caplinx.tobo.TOBOUserManager.tradeFinished();
		  	break;
	}
	
	this.m_oTradeTicket.m_oTicketBodyElement.className = this.m_oTradeTicket._getTicketClassname();
};
