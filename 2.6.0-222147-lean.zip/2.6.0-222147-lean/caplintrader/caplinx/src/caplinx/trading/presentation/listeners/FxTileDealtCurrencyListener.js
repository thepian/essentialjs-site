caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxTileDealtCurrencyListener = function(oFxTile)
{
	this.m_oFxTile = oFxTile;	
};

caplinx.trading.presentation.listeners.FxTileDealtCurrencyListener.prototype.dataFieldChanged  = function(oValue, oOldValue)
{
	this.m_oFxTile.dealtCurrencyEventHandler(oValue);
};