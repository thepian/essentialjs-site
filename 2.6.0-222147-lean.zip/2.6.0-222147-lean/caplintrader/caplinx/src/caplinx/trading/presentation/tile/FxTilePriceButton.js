caplin.namespace("caplinx.trading.presentation.tile");

caplin.include("caplinx.widget.formcontrols.FxTileFlatButton");
caplin.include("caplinx.trading.presentation.tile.FxTileController");
caplin.include("caplinx.widget.format.FxPipPriceFieldValueProcessor");
caplin.include("caplin.widget.element.renderer.ElementRenderer");
caplin.include("caplinx.widget.element.renderer.TileButtonElementRenderer");

//TODO_TILE: remove references to FxTile
caplinx.trading.presentation.tile.FxTilePriceButton = function(oFxTile, sSide, sTileElementLookupIdPrefix) {
	this.m_oFxTile = oFxTile;
	this.m_sSide = sSide;
	this.m_oButton = null;
	this.m_oValueRenderer = null;
	this.m_sLastDisplayedPrice = null;
	this._setupButton(sSide, sTileElementLookupIdPrefix, oFxTile);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.enable = function(){
	this.m_oButton.enable();
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.updateElements = function(oProperties){
	this.m_oButton.updateElements(oProperties);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.disable = function(){
	this.m_oButton.disable(oProperties);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.clear = function(){
	this.m_oValueRenderer.dataFieldChanged(null, null, {});
}

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setEnabled = function(bEnabled){
	this.m_oButton.setEnabled(bEnabled);
};
caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setDisabledAlertMsg = function(sMessage){
	this.m_oButton.setDisabledAlertMsg(sMessage);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setButtonBlank = function(bIsBlank){
	this.m_oButton.setButtonBlank(bIsBlank);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setButtonRFS = function(bIsRFS){
	this.m_oButton.setButtonRFS(bIsRFS);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setSmallPipToBeShown = function(bShow){
	this.m_oValueRenderer.setSmallPipToBeShown(bShow);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setTooltip = function(sMessage){
	this.m_oButton.setTooltip(sMessage);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.getId = function(){
	this.m_oButton.getId();
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.finalize = function(){
	this.m_oButton.finalize();
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype.setButtonRFS = function(bOverTierLimit){
	this.m_oButton.setButtonRFS(bOverTierLimit);
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype._setupButton = function(sSide, sTileElementLookupIdPrefix, oFxTile)
{
	var fPriceDisplayedToUser = function(sPrice, mTraceData) {
		var sInstanceVariableName = "m_sLastDisplayedBest" + sSide;
		oFxTile[sInstanceVariableName] = sPrice;
		oFxTile.m_oController.updateTileState();
		oFxTile.m_oLeg.appendTraceData(mTraceData);
	};
	
	var eButtonHolder = document.getElementById(sTileElementLookupIdPrefix + "_" + sSide.toLowerCase() + "Button");
	return eButtonHolder ? this._createButtonHolder(sSide, fPriceDisplayedToUser, sTileElementLookupIdPrefix, eButtonHolder) : null;
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype._createButtonHolder = function(sSide, fRenderFunction, sTileElementLookupIdPrefix, eButtonHolder)
{
	var eBidButtonContents = document.createElement("div");
	eBidButtonContents.className = "ButtonContents";
	
	var eSellBuy = this._getButtonContents(sTileElementLookupIdPrefix, sSide, eBidButtonContents, fRenderFunction);
	
	var button = new caplinx.widget.formcontrols.FxTileFlatButton(eBidButtonContents, 76, 46, ["button-inner"], this, eButtonHolder);
	this.m_oButton = button;
	button.setUpdatableElements({
		sellbuy: eSellBuy
	});
	
	var eBidButtonElement = button.getElement();
	
	if (this.m_oFxTile.m_bTileTradingPermissioned && this.m_oFxTile.m_bHasAccounts) 
	{
		this.m_oButton.setDisabledAlertMsg(caplinx.trading.presentation.tile.FxTileController.MESSAGE.SELECT_ACCOUNT);
	}
	else if (this.m_oFxTile.m_bHasAccounts) 
	{
		button.setDisabledAlertMsg(caplinx.trading.presentation.tile.FxTileController.MESSAGE.MISSING_PERMISSIONS);
		button.setEnabled(false);
	}
	else 
	{
		button.setDisabledAlertMsg(caplinx.trading.presentation.tile.FxTileController.MESSAGE.MISSING_ACCOUNTS);
		button.setEnabled(false);
	}
	
	button.addOnClickListener(this.m_oFxTile._onButtonClick(sSide, this.m_oFxTile));
	
	eButtonHolder.appendChild(eBidButtonElement);
	eButtonHolder.appendChild(button.m_eUnderlying);
	
};

caplinx.trading.presentation.tile.FxTilePriceButton.prototype._getButtonContents = function(sTileElementLookupIdPrefix, sSide, eHolder, fRenderFunction)
{
	var oBidValueElem = document.createElement("div");
	oBidValueElem.id = sTileElementLookupIdPrefix + "_" + sSide.toLowerCase() + "Value";
	oBidValueElem.className = sSide.toLowerCase() + "Value price1";
	
	var eSellBuy = document.createElement("p");
	eSellBuy.className = "sellbuy";
	eSellBuy.innerHTML = "Buy";
	eHolder.appendChild(eSellBuy);
	
	var oProcessor1 = new caplinx.widget.format.FxPipPriceFieldValueProcessor(caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_ONE);
	var oProcessor2 = new caplinx.widget.format.FxPipPriceFieldValueProcessor(caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_TWO);
	var oProcessor3 = new caplinx.widget.format.FxPipPriceFieldValueProcessor(caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_THREE);
	
	var oValueRenderer = new caplinx.widget.element.renderer.TileButtonElementRenderer(
			this.m_oFxTile.m_sInstrumentName,
			[oProcessor1,oProcessor2,oProcessor3], 
			[sSide + "Price"],
			this.m_oFxTile.m_oFieldManager);
	oValueRenderer.setFunctionToBeCalledOnRender(fRenderFunction);
	oValueRenderer.setUseRawValueForChangeChecking(true);
	oValueRenderer.setFlashStrategy(caplin.widget.element.renderer.ElementRenderer.getRateFlash);
	oValueRenderer.setDataModel(this.m_oFxTile, "-");
	
	var eArrow = document.createElement("DIV");
	eArrow.className = "arrow";
	var eArrowHolder = document.createElement("DIV");
	eArrow.appendChild(eArrowHolder);
	oValueRenderer.createElement(this.m_oFxTile, eHolder, eArrow);
	this.m_oValueRenderer = oValueRenderer;
	
	return eSellBuy;
};
