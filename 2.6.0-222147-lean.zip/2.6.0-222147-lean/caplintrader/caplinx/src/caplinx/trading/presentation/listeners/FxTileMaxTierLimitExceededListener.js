caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxTileMaxTierLimitExceededListener = function(oFxTile)
{
	this.m_oFxTile = oFxTile;
};

caplinx.trading.presentation.listeners.FxTileMaxTierLimitExceededListener.prototype.dataFieldChanged  = function(oValue, oOldValue)
{
	this.m_oFxTile.tierLimitExceededHandler(oValue);
};