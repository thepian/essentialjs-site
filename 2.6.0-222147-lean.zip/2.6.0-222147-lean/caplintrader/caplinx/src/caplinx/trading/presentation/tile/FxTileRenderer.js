caplin.namespace("caplinx.trading.presentation.tile");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.widget.element.ElementFactory");
caplin.include("caplinx.trading.presentation.tile.FxTileController");

caplinx.trading.presentation.tile.FxTileRenderer = function(m_nId)
{
	this.m_nId = m_nId;
	this.m_eErrorMessage = null;
};

/**
 * Renders the FxTile within the parent container provided.
 * @param {DOMElement} oContainer The DOM Element inside which the Tile renders itself.
 */
caplinx.trading.presentation.tile.FxTileRenderer.prototype.render = function()
{

	var mMarkers = {};
	
	mMarkers.SETTLEMENT_DATE = this._getMarkerHtml(this.m_nId + "_settlementDate", null, "settlement-date");
	mMarkers.RFS_BUTTON = this._getMarkerHtml(this.m_nId + "_rfsButton", null, "rfs-button button small-button");
	mMarkers.BID_VALUE = this._getMarkerHtml(this.m_nId + "_bidValue", null, "bidValue price1");
	mMarkers.BID_ARROW = this._getMarkerHtml(this.m_nId + "_bidArrow", null, "bidArrow arrow");
	mMarkers.BID_BUTTON = this._getMarkerHtml(this.m_nId + "_bidButton", null, "left-button button");
	mMarkers.ASK_VALUE = this._getMarkerHtml(this.m_nId + "_askValue", null, "askValue price1");
	mMarkers.ASK_ARROW = this._getMarkerHtml(this.m_nId + "_askArrow", null, "askArrow arrow");
	mMarkers.ASK_BUTTON = this._getMarkerHtml(this.m_nId + "_askButton", "", "right-button button");
	mMarkers.DEALT_CURRENCY = this._getMarkerHtml(this.m_nId + "_dealtCurrency", null, "invert-button button small-button button_switch_dealt_currency");
	mMarkers.CLOSE_BUTTON = this._getMarkerHtml(this.m_nId + "_closeButton", null, "close-button");
	mMarkers.TILE_TITLE = this._getMarkerHtml(this.m_nId + "_tileTitle", "", "tileTitle");
	mMarkers.TRADE_QTY = this._getMarkerHtml(this.m_nId + "_tradeQty");
	mMarkers.TIER_LIMIT = this._getMarkerHtml(this.m_nId + "_tierLimit", null, "tier-limit");
	
	this.m_oFxTileElement = this._getLayoutHtml(mMarkers);
	return this.m_oFxTileElement;
};

/*
caplinx.trading.presentation.tile.FxTileRenderer.prototype._getMarkerHtml = function(elementId, sPosition, sClass){
	return "<div style='" + (sPosition || "") + "' id='" + elementId + "' class='" + (sClass || "") + "'></div>";
};
*/

caplinx.trading.presentation.tile.FxTileRenderer.prototype._getMarkerHtml = function(elementId, sPosition, sClass)
{
	var result = "<div id='";
	result += elementId;
	result += "'";
	
	if(sPosition){
		result += " style='";
		result += sPosition;
		result += "'";
	}
	
	if(sClass){
		result += " class='";
		result += sClass;
		result += "'";
	}
	
	result +="></div>";
	return result;
};


caplinx.trading.presentation.tile.FxTileRenderer.prototype._getLayoutHtml = function(markers)
{
	var oElementFactory = caplin.widget.element.ElementFactory;
	
	var oFxTileElement = oElementFactory.createElement("div");
	oFxTileElement.style.display = "none";
	var oFxTileInner = oElementFactory.createElement("div");
	oFxTileInner.className = "fxtile fxtile-not-tradable";

	var sTileInnerHtml ='<div class="header">' +
				markers.CLOSE_BUTTON +
				markers.TILE_TITLE +
			'</div>' +
			'<div class="main-prices">' +
				markers.BID_BUTTON +
				markers.ASK_BUTTON +
			'</div>' +
			'<div class="amount">' +
				markers.TRADE_QTY +
				markers.DEALT_CURRENCY +
			'</div>' +
			'<div class="permission-feedback">' +
				'<span style="margin-top: 5px;">'+
					'<img class="permission-lock permission-icon" src="source/theme/packages/trading/presentation/tile/images/permissions-ico-16x16.gif"/>' +
					'<img class="permission-lock no-connection-icon" src="source/theme/packages/trading/presentation/tile/images/no-connection-ico-16x16.gif"/>' +
					'<img class="permission-lock error-icon" src="source/theme/packages/trading/presentation/tile/images/error-flat.png"/>' +
					'<img class="permission-lock info-icon" src="source/theme/packages/trading/presentation/tile/images/info-ico-16x16.gif"/>' +
				'</span>&nbsp;' +
				'<div class="permission-message">-</div>' +
			'</div>' +
			'<div class="footer">' +
				markers.RFS_BUTTON +
				markers.SETTLEMENT_DATE +
				markers.TIER_LIMIT +
			'</div>' +
			'<div class="permission-shield">' +
				'<span class="permission-shield-image-holder"><img src="source/theme/packages/trading/presentation/tile/images/permissions-ico-24x24.png"/></span>' +
				'<span class="permission-shield-message">' + ct.i18n("cx.trading.presentation.fx.tile.permission_shield_message")+ '</span>' +
				'<span class="tell-me-more">'+ ct.i18n("cx.trading.presentation.fx.tile.tell_me_more")+ '</span>' +
			'</div>';

	oFxTileInner.innerHTML = sTileInnerHtml;
	var eErrorShieldHolder = oElementFactory.createElement("div");
	var eErrorShield = oElementFactory.createElement("div");
	this.m_eErrorMessage = oElementFactory.createElement("div");
	eErrorShield.className = "error-shield";
	
	oFxTileElement.appendChild(oFxTileInner);
	eErrorShieldHolder.appendChild(eErrorShield);
	eErrorShield.appendChild(this.m_eErrorMessage);
	oFxTileInner.appendChild(eErrorShieldHolder);
	
	return oFxTileElement;
};

caplinx.trading.presentation.tile.FxTileRenderer.prototype.showError = function(sTitle, sErrorHtml)
{
	//var sHolderId = "tile_error_holder" + this.m_oFxTrade.getRequestID();
	var sHolderId = "tile_error_holder" + this.m_nId;
	
	var sHtml = "<div style=\"position: absolute; top: 2px; left: 2px\"><img src=\"source/theme/packages/trading/presentation/tile/images/error-flat.png\" /></div>";
	sHtml += "<div id=\"" + sHolderId + "\" style=\"position: absolute; top: 2xp; left: 21px; width: 144px\"><div style=\"padding-bottom: 5px\">";
	sHtml += sTitle + "<hr style=\"width: 120px; border: none; border-top: 1px dotted #999; margin: 2px 0px\" />";
	sHtml += "<span style=\"font-weight: normal; font-size: smaller\">";
	sHtml += sErrorHtml + "</span></div></div>";
	
	this.m_eErrorMessage.innerHTML = sHtml;
	this.m_eErrorMessage.style.padding = "4px";
	
	var eErrorHolder = document.getElementById(sHolderId);
	
	var sHtml = this._getMarkerHtml(this.m_nId + "_dismissErrorButton", null, "rfs-button button small-button");
	eErrorHolder.innerHTML += sHtml;
	
	var eDismissErrorButton = document.getElementById(this.m_nId + "_dismissErrorButton");
	eDismissErrorButton.style.textAlign = "left";
		
	var eButtonContents = document.createElement("div");
	eButtonContents.className = "small-button-label";
	eButtonContents.style.textAlign = "center";
	var oOkLaunchButton = new caplin.dom.controls.form.FlexibleButton(eButtonContents, 26, 16, [], eDismissErrorButton);
	oOkLaunchButton.setUpdatableElements({
		contents: eButtonContents
	});
	var self = this;
	oOkLaunchButton.addOnClickListener(function() { 
		self.m_oController.clearError();
		self._reset();
	 });

	oOkLaunchButton.create();
	oOkLaunchButton.setEnabled(true);
	oOkLaunchButton.updateElements({
		contents: "<span style=\"font-weight: normal;\">OK</span>"
	});
};
