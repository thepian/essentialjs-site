caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxTileAmountListener = function(oFxTile, sLadderKey)
{
	this.m_oFxTile = oFxTile;
};

caplinx.trading.presentation.listeners.FxTileAmountListener.prototype.dataFieldChanged  = function(oValue, oOldValue)
{
	this.m_oFxTile.amountEventHandler(oValue, oOldValue);
};