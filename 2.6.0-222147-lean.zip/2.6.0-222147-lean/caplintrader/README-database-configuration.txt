DATABASE CONFIGURATION:
=======================

By default Caplin Trader is configured to run against a MySQL database, however 
it is possible to configure it to run against other databases. Currently 
supported databases are:

  *  MySQL
  *  Sybase

To switch between databases you will need to:

  1. Edit X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader/build.xml to import the 
     build file for the required database. You should see a line similar to:
	 
	   <import file="${CAPLIN.SDK.HOME}/build/common/database/[database].xml"/>
	 
	 This can be changed in the following ways depending on the database you 
	 want to use:
	 
	   *  MySQL
	      <import file="${CAPLIN.SDK.HOME}/build/common/database/mysql.xml"/>
	   *  Sybase
	      <import file="${CAPLIN.SDK.HOME}/build/common/database/sybase.xml"/>

  2. Edit X:/scm_root/CT2/2.0.X-nnnnnn/build.properties with the settings for 
     the database you want to connect to. There are two blocks of settings you 
     will need to change, the "WEBCENTRIC DATABASE" settings and the 
     "APPLICATION SERVER" settings. As well as changing the database connection 
     settings, you will need to change the JDBC connection settings (DRIVER, 
     DIALECT and CONNECTION.URL). Caplin currently provides the Connector/J 
     JDBC driver for MySQL and the JTDS JDBC driver for Sybase. Example 
     configurations for each of these are included below:
     
       *  MySQL
       	  DATABASE.DRIVER=com.mysql.jdbc.Driver
		  DATABASE.DIALECT=org.hibernate.dialect.MySQLDialect
		  DATABASE.CONNECTION.URL=jdbc:mysql://[DATABASE.HOST]:[DATABASE.PORT]/[DATABASE.NAME]?user=[DATABASE.USERNAME]&password=[DATABASE.PASSWORD]
		  
	   *  Sybase
	      DATABASE.DRIVER=net.sourceforge.jtds.jdbc.Driver
		  DATABASE.DIALECT=org.hibernate.dialect.SybaseDialect
		  DATABASE.CONNECTION.URL=jdbc:jtds:sybase://[DATABASE.HOST]:[DATABASE.PORT]/[DATABASE.NAME];user=[DATABASE.USERNAME];password=[DATABASE.PASSWORD]
		  
 3. Edit X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader/user.properties with the 
    database password settings.
    
 4. If you are planning to use Sybase, you will need to set the SYBASE.ISQL 
    property in one of the build property files to point to the Sybase ISQL 
    utility executable. This is needed to execute scripts/commands against 
    the Sybase database, specifically to remove/create databases and to 
    populate the application server database.