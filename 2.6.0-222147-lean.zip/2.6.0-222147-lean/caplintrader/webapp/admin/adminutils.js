
function getValueFromQueryString(sField)  {
	var sQueryString = window.location.search.substring(1);
	var sFieldValuePair = sQueryString.split("&");
	for (var i = 0, nLength = sFieldValuePair.length; i < nLength; ++i) {
		var pFieldValuePair = sFieldValuePair[i].split("=");
		if (pFieldValuePair[0] === sField) {
			return pFieldValuePair[1];
		}
	}
};

function buildTagString(params) {
	var builder = [];
	builder.push("\x3Cscript type='text/javascript' ");
	for (var key in params) {
		builder.push(key);
		builder.push("='");
		builder.push(params[key]);
		builder.push("' ");
	}
	builder.push(">\x3C/script>");
	return builder.join("");
};

function writeScripts(scripts) {
	for (var i = 0; i < scripts.length; ++i) {
		var str = buildTagString(scripts[i]);
		document.write(str);
	}
};

var accessorConfiguration = {};
SL4B_Accessor = {
	getConfiguration: function() {
		return {
			setAttribute: function(attribute, value) {
				accessorConfiguration[attribute] = value;
			}
		}
	}
};

function getConfig(sOffsetToBase) {
	function getXmlHttpRequest() {
		try {
			return new XMLHttpRequest();
		} catch(e) {}
		var pXMLParserList = ["MSXML2.XMLHttp.6.0", "MSXML2.XMLHttp.3.0", "Microsoft.XMLHTTP"];
		for (var i = 0, l = pXMLParserList.length; i < l; ++i) {
			try {
				return new window.ActiveXObject(pXMLParserList[i]);
			} catch(e) {}
		}
	};
	
	var xhr = getXmlHttpRequest();
	xhr.open("GET", sOffsetToBase + accessorConfiguration.service, false);
	xhr.send(null);
	var addresses = xhr.responseXML.getElementsByTagName("address");
	var pConfig = [];
	for (var i = 0; i < addresses.length; ++i) {
		var entry = {};
		entry.address = addresses[i].textContent || addresses[i].text;
		var ports = addresses[i].parentNode.getElementsByTagName("ports");
		if (ports.length) {
			var firstChild = ports[0].firstElementChild || ports[0].firstChild;
			entry.port = firstChild.textContent || firstChild.text;
			entry.protocol = firstChild.tagName;
		}
		var sServer = addresses[i].parentNode.tagName;
		pConfig.push({
			server: sServer.charAt(0).toUpperCase() + sServer.replace("server","").substring(1),
			url: entry.protocol + '://' + entry.address + ':' + entry.port
		});
	}
	return pConfig;
};