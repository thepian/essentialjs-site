function DataSourceData()
{
    this.m_pData = DataSourceData.DATA;
    this.m_pTimers = new Array();
    this.initialise();
}

DataSourceData.prototype = new SL4B_AbstractSubscriber;

DataSourceData.COLUMNS = 2;
DataSourceData.NBSP = "\u00a0";
DataSourceData.CONST_FIELD_VAL = "==CONST==";

DataSourceData.SYSTEM_INFO = "/SYSTEM/INFO";

DataSourceData.DATA_SERVICE_SYMBOL = "/SYSTEM/NODE-%NODE%/SERVICE";
DataSourceData.DATA_SERVICE_TBL_ID = "tblServices";
DataSourceData.DATA_SERVICE_FIELDS = new Array("ServiceName", "ServiceState", "ServiceDateTime");
DataSourceData.DATA_SERVICE_LABELS = new Array("Name:", "Status:", "Last Change:");
DataSourceData.DATA_SERVICE = new Array(DataSourceData.DATA_SERVICE_SYMBOL, DataSourceData.DATA_SERVICE_TBL_ID, DataSourceData.DATA_SERVICE_FIELDS, DataSourceData.DATA_SERVICE_LABELS);

DataSourceData.DATA_SOURCE_SYMBOL = "/SYSTEM/NODE-%NODE%";
DataSourceData.DATA_SOURCE_TBL_ID = "tblSources";
DataSourceData.DATA_SOURCE_FIELDS = new Array("SourceID", "SourceName", "SourceStatus", "SourceDateTime", "SourceAddr", "SourceLabel");
DataSourceData.DATA_SOURCE_LABELS = new Array("ID:", "Name:", "Status:", "Last Change:", "Address:", "Label:");
DataSourceData.DATA_SOURCE = new Array(DataSourceData.DATA_SOURCE_SYMBOL, DataSourceData.DATA_SOURCE_TBL_ID, DataSourceData.DATA_SOURCE_FIELDS, DataSourceData.DATA_SOURCE_LABELS);

DataSourceData.DATA = new Array();
DataSourceData.DATA[DataSourceData.DATA_SERVICE_SYMBOL] = DataSourceData.DATA_SERVICE;
DataSourceData.DATA[DataSourceData.DATA_SOURCE_SYMBOL] = DataSourceData.DATA_SOURCE;

DataSourceData.instance = new DataSourceData();

DataSourceData.getInstance = function()
{
   return DataSourceData.instance;
};

DataSourceData.prototype.ready = function()
{
    SL4B_Accessor.getRttpProvider().getObjects(this, DataSourceData.SYSTEM_INFO, "NodeID");
};

DataSourceData.prototype.recordMultiUpdated = function(l_sObjectName, l_oFieldData)
{
    if (l_sObjectName == DataSourceData.SYSTEM_INFO)
    {
        for (l_sName in this.m_pData)
        {
            var l_sNewName = l_sName.replace("%NODE%", l_oFieldData.getFieldValue(0));
            this.m_pData[l_sNewName] = this.m_pData[l_sName];
            this.m_pData[l_sNewName]["count"] = 0;
            SL4B_Accessor.getRttpProvider().getObjects(this, l_sNewName);
        }
    }
    else
    {
        if (this.m_pData[l_sObjectName] != null)
        {
            this.addTable(l_sObjectName, "");
        }

        for (var i = 0; i < l_oFieldData.size(); i++) 
        {
            var l_sFieldName = l_oFieldData.getFieldName(i);
            var l_sValue = l_oFieldData.getFieldValue(i);
            this.fieldUpdated(l_sObjectName, l_sFieldName, l_sValue);
        }
    }
};

DataSourceData.prototype.directoryUpdated = function(l_sDirObjectName, l_sObjectName, l_nType, l_bAdded)
{
    // Create a table for each directory.
    if (l_bAdded)
    {
        var l_sName = l_sDirObjectName + "/" + l_sObjectName;
        if (l_sName.match(/^\/SYSTEM\/NODE-\d+\/SRC-\d+$/) !== null || l_sDirObjectName.match(/^\/SYSTEM\/NODE-\d+\/SERVICE$/) !== null)
        {
            this.addTable(l_sDirObjectName, l_sObjectName);
        }
    }

    // Subscribe to directory.
    SL4B_Accessor.getRttpProvider().getObjects(this, l_sDirObjectName + "/" + l_sObjectName);
};

DataSourceData.prototype.addTable = function(l_sDirObjectName, l_sObjectName)
{
    // Construct the full object name.
    var l_sName;
    if (l_sObjectName == "")
    {
        l_sName = l_sDirObjectName;
    }
    else
    {
        l_sName = l_sDirObjectName + "/" + l_sObjectName;
    }

    // See if we have a table for it already.
    if (document.getElementById(l_sName) == null)
    {
        // If not, create one.
        var l_sTableBody = this.m_pData[l_sDirObjectName][1];
        var l_pFields = this.m_pData[l_sDirObjectName][2];
        var l_pLabels = this.m_pData[l_sDirObjectName][3];

        var l_oTableBody = document.getElementById(l_sTableBody);

        if (this.isEven(++this.m_pData[l_sDirObjectName]["count"]))
        {
            // We have a blank spot in the right hand column. Fill it.
            var l_oRow = l_oTableBody.lastChild
            this.addInnerTable(l_oRow, l_sName, l_pFields, l_pLabels);
        }
        else
        {
            // Create a new row.
            var l_oRow = document.createElement("tr");
            this.addInnerTable(l_oRow, l_sName, l_pFields, l_pLabels);
            l_oTableBody.appendChild(l_oRow);
        }
    }
};

DataSourceData.prototype.addInnerTable = function(l_oBaseTableRow, l_sName, l_pFields, l_pLabels)
{
    var l_oCell = document.createElement("td");
    var l_oTable = document.createElement("table");
    var l_oTableBody = document.createElement("tbody");

    for (var l_nRow = 0; l_nRow < l_pFields.length; l_nRow++) 
    {
        var l_oRow = document.createElement("tr");
        this.addCells(l_oRow, l_nRow, l_sName + "/" + l_pFields[l_nRow], l_pLabels[l_nRow]);
        l_oTableBody.appendChild(l_oRow);
    }

    l_oTable.id = l_sName;

    l_oTable.appendChild(l_oTableBody);
    l_oCell.appendChild(l_oTable);
    l_oBaseTableRow.appendChild(l_oCell);
};

DataSourceData.prototype.addCells = function(l_oRow, l_nRow, l_sName, l_sLabel)
{
    for (var l_nCol = 0; l_nCol < DataSourceData.COLUMNS; l_nCol++) 
    {
        var l_oCell = document.createElement("td");

        if (l_nCol == 0)
        {
            l_oCell.id = l_sName + "/Label";
            l_oCell.className = 'tbl-label';
            l_oCell.appendChild(document.createTextNode(l_sLabel));
        }
        else
        {
            l_oCell.id = l_sName + "/Value";
            l_oCell.className = 'tbl-data';

            if (l_sName.indexOf(DataSourceData.CONST_FIELD_VAL) == -1)
            {
                l_oCell.appendChild(document.createTextNode(DataSourceData.NBSP + "Please wait..." + DataSourceData.NBSP));
            }
            else
            {
                l_sValue = l_sName.substring(l_sName.lastIndexOf("/") + 1).replace(DataSourceData.CONST_FIELD_VAL, "");
                l_oCell.appendChild(document.createTextNode(DataSourceData.NBSP + l_sValue + DataSourceData.NBSP));
            }
        }
        l_oRow.appendChild(l_oCell);
    }
};

DataSourceData.prototype.isEven = function(l_nNum)
{
    return (l_nNum % 2) == 0;
};

DataSourceData.prototype.setDefaultCellColours = function(l_sCell)
{
    DataSourceData.setCellColours(l_sCell, "white", "#22155A", true);
};

DataSourceData.setCellColours = function(l_sCell, l_sColour, l_sBackgroundColour, l_bRemoveFlash)
{
    var l_oCell = document.getElementById(l_sCell);

    if (l_sColour == null)
    {
       l_oCell.style.color = '';
    }
    else
    {
       l_oCell.style.color = l_sColour;
    }

    if (l_sBackgroundColour == null)
    {
       l_oCell.style.backgroundColor = '';
    }
    else
    {
       l_oCell.style.backgroundColor = l_sBackgroundColour;
    }

    if (l_bRemoveFlash == null || l_bRemoveFlash == true)
    {
        setTimeout("DataSourceData.setCellColours('" + l_sCell + "', null, null, false);", 2000);
    }
};

DataSourceData.prototype.fieldUpdated = function(l_sObjectName, l_sFieldName, l_sValue)
{
    var l_oCell = document.getElementById(l_sObjectName + "/" + l_sFieldName + "/Value");

    if (l_oCell != null)
    {
        l_oCell.firstChild.nodeValue = DataSourceData.NBSP + l_sValue + DataSourceData.NBSP;

        switch (l_sFieldName)
        {
            case 'ServiceState':
            case 'SourceStatus':
                this.setDSFlash(l_oCell.id, l_sValue);
                break;
            default:
                this.setDefaultCellColours(l_oCell.id);
                break;
        }
    }
};

DataSourceData.prototype.setDSFlash = function(l_sCell, l_sValue)  
{
    var l_sColour;
    var l_sBackgroundColour;

    switch (l_sValue)
    {
        case "DOWN":
            l_sColour = "white"
            l_sBackgroundColour = "red"
            break;
        case "UP":
        case "OK":
            l_sColour = "white"
            l_sBackgroundColour = "blue"
            break;
        default:
            l_sColour = "white"
            l_sBackgroundColour = "gray"
            break;
    }

    DataSourceData.setCellColours(l_sCell, l_sColour, l_sBackgroundColour, false);

    if (this.m_pTimers[l_sCell] != null)
    {
        clearTimeout(this.m_pTimers[l_sCell]);
    }
    this.m_pTimers[l_sCell] = setTimeout("DataSourceData.setCellColours('" + l_sCell + "', '" + l_sBackgroundColour + "', null, false);", 2000);
};
