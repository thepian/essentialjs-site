function ClusterData()
{
    this.m_sNode = -1;
    this.m_nMaxCols = 0;
    this.m_bClusteringShown = false;
    this.initialise();
}

ClusterData.prototype = new SL4B_AbstractSubscriber;

ClusterData.NBSP = "\u00a0";

ClusterData.DISPLAY_ID = "clustering";
ClusterData.DISPLAY_TOGGLER_ID = "clusteringToggler";

ClusterData.TABLE_ID = "tblClusterInformation";

ClusterData.SYSTEM = "/SYSTEM";
ClusterData.SYSTEM_INFO = "/SYSTEM/INFO";

ClusterData.SESSION_TITLES = new Array(ClusterData.NBSP, "Total", "Type 1", "Type 2", "Type 3", "Type 4", "Type 5");

ClusterData.SESSIONS_LABEL = "Current Sessions";
ClusterData.MAX_SESSIONS_LABEL = "Peak Sessions";
ClusterData.NUM_OBJECTS_LABEL = "Number Of Objects";
ClusterData.LABELS = new Array(ClusterData.SESSIONS_LABEL, ClusterData.MAX_SESSIONS_LABEL, ClusterData.NUM_OBJECTS_LABEL);

ClusterData.SESSION_FIELDS = new Array("Sessions", "SessionsType1", "SessionsType2", "SessionsType3", "SessionsType4", "SessionsType5");
ClusterData.MAX_SESSION_FIELDS = new Array("MaxSessions", "MaxSessionsType1", "MaxSessionsType2", "MaxSessionsType3", "MaxSessionsType4", "MaxSessionsType5");
ClusterData.NUM_OBJECTS_FIELD = new Array("NumObjects");
ClusterData.FIELDS = new Array(ClusterData.SESSION_FIELDS, ClusterData.MAX_SESSION_FIELDS, ClusterData.NUM_OBJECTS_FIELD);

ClusterData.instance = new ClusterData();

ClusterData.getInstance = function()
{
   return ClusterData.instance;
};

ClusterData.prototype.ready = function()
{
    SL4B_Accessor.getRttpProvider().getObjects(this, ClusterData.SYSTEM_INFO, "NodeID");
};

ClusterData.prototype.recordMultiUpdated = function(l_sObjectName, l_oFieldData)
{
    if (l_sObjectName == ClusterData.SYSTEM_INFO)
    {
        this.m_sNode = l_oFieldData.getFieldValue(0);
        SL4B_Accessor.getRttpProvider().getObjects(this, ClusterData.SYSTEM);
    }
    else
    {
        for (var i = 0; i < l_oFieldData.size(); i++) 
        {
            var l_sFieldName = l_oFieldData.getFieldName(i);
            var l_sValue = l_oFieldData.getFieldValue(i);
            this.fieldUpdated(l_sObjectName, l_sFieldName, l_sValue);
        }
    }
};

ClusterData.prototype.directoryUpdated = function(l_sDirObjectName, l_sObjectName, l_nType, l_bAdded)
{
    // Create a table for each directory.
    if (l_bAdded)
    {
        var l_sName = l_sDirObjectName + "/" + l_sObjectName;
        if (l_sName.match(/^\/SYSTEM\/NODE-\d+$/) !== null)
        {
            this.addTable(l_sName);
            SL4B_Accessor.getRttpProvider().getObjects(this, l_sName + "/INFO");
        }
    }
};

ClusterData.prototype.addTable = function(l_sObjectName)
{
    // See if we have a table for it already.
    if (document.getElementById(l_sObjectName) == null)
    {
        // If not, create one.
        var l_oTableBody = document.getElementById(ClusterData.TABLE_ID);

        var i;
        var l_nNode = l_sObjectName.substring(l_sObjectName.lastIndexOf("NODE-") + 5);

        for (i = 0; i <= parseInt(l_nNode) * 2; i += 2)
        {
           if (l_oTableBody.childNodes[i*2] == null)
           {
               var textPlaceHolder = document.createElement("tr");
               l_oTableBody.appendChild(textPlaceHolder);

               var rowPlaceHolder = document.createElement("tr");
               l_oTableBody.appendChild(rowPlaceHolder);
           }
        }

        i -= 2;

        var newTextRow = document.createElement("tr");
        var newTextData = document.createElement("td");

        var newText = document.createElement("div");
        newText.className = l_nNode == this.m_sNode ? "tbl-hdr-data-svr" : "tbl-hdr-data";
        newText.style.padding = "3px";
        newText.align = "center";
        newText.appendChild(document.createTextNode("Liberator " + l_nNode + (l_nNode == this.m_sNode ? " (this server)" : "")));
        newTextRow.appendChild(newTextData);
        newTextData.appendChild(newText);

        var oldText = l_oTableBody.childNodes[i];
        l_oTableBody.replaceChild(newTextRow, oldText);

        var newRow = document.createElement("tr");
        this.addInnerTable(newRow, l_sObjectName, l_nNode);

        var oldRow = l_oTableBody.childNodes[i+1];
        l_oTableBody.replaceChild(newRow, oldRow);
    }
};

ClusterData.prototype.addInnerTable = function(l_oBaseTableRow, l_sName, l_nIndex)
{
    var l_oCell = document.createElement("td");
    var l_oTable = document.createElement("table");
    var l_oTableBody = document.createElement("tbody");

    var l_oTitleRow = document.createElement("tr");
    for (var i = 0; i < ClusterData.SESSION_TITLES.length; i++)
    {
        var l_oTitleCell = document.createElement("td");
        l_oTitleCell.className = "tbl-col-hdr-label";
        l_oTitleCell.appendChild(document.createTextNode(ClusterData.SESSION_TITLES[i]));
        l_oTitleRow.appendChild(l_oTitleCell);
    }
    l_oTableBody.appendChild(l_oTitleRow);

    for (var l_nRow = 0; l_nRow < ClusterData.LABELS.length; l_nRow++) 
    {
        var l_oRow = document.createElement("tr");
        this.addCells(l_oRow, l_nIndex, l_sName, ClusterData.LABELS[l_nRow], ClusterData.FIELDS[l_nRow]);
        l_oTableBody.appendChild(l_oRow);
    }

    l_oTable.id = l_sName;

    l_oTable.appendChild(l_oTableBody);
    l_oCell.appendChild(l_oTable);
    l_oBaseTableRow.appendChild(l_oCell);
};

ClusterData.prototype.addCells = function(l_oRow, l_nIndex, l_sName, l_sLabel, l_pFields)
{
    var l_oLabelCell = document.createElement("td");

    l_oLabelCell.className = l_nIndex == this.m_sNode ? 'tbl-hdr-label-svr' : 'tbl-hdr-label';
    l_oLabelCell.appendChild(document.createTextNode(l_sLabel));
    l_oLabelCell.width = 115;

    l_oRow.appendChild(l_oLabelCell);

    if (l_pFields.length > this.m_nMaxCols) this.m_nMaxCols = l_pFields.length;

    var l_oCell;
    var l_nCol;
    for (l_nCol = 0; l_nCol < l_pFields.length; l_nCol++) 
    {
        l_oCell = document.createElement("td");

        l_oCell.id = l_sName + "/INFO/" + l_pFields[l_nCol] + "/Value";
        l_oCell.className = l_nIndex == this.m_sNode ? 'tbl-hdr-data-svr' : 'tbl-hdr-data';
        l_oCell.appendChild(document.createTextNode(ClusterData.NBSP + "Waiting..." + ClusterData.NBSP));
        l_oCell.width = 51;

        l_oRow.appendChild(l_oCell);
    }

    if (l_nCol < this.m_nMaxCols)
    { 
        l_oCell.colSpan = this.m_nMaxCols - l_nCol + 1;
    }
};

ClusterData.prototype.fieldUpdated = function(l_sObjectName, l_sFieldName, l_sValue)
{
    var l_oCell = document.getElementById(l_sObjectName + "/" + l_sFieldName + "/Value");

    if (l_oCell != null)
    {
        l_oCell.firstChild.nodeValue = ClusterData.NBSP + l_sValue + ClusterData.NBSP;
        this.setDefaultCellColours(l_oCell.id);
    }
};

ClusterData.prototype.setDefaultCellColours = function(l_sCell)
{
    ClusterData.setCellColours(l_sCell, "white", "#22155A", true);
};

ClusterData.setCellColours = function(l_sCell, l_sColour, l_sBackgroundColour, l_bRemoveFlash)
{
    var l_oCell = document.getElementById(l_sCell);

    if (l_sColour == null)
    {
       l_oCell.style.color = '';
    }
    else
    {
       l_oCell.style.color = l_sColour;
    }

    if (l_sBackgroundColour == null)
    {
       l_oCell.style.backgroundColor = '';
    }
    else
    {
       l_oCell.style.backgroundColor = l_sBackgroundColour;
    }

    if (l_bRemoveFlash == null || l_bRemoveFlash == true)
    {
        setTimeout("ClusterData.setCellColours('" + l_sCell + "', null, null, false);", 2000);
    }
}

ClusterData.prototype.toggleVisibility = function()
{
    var l_sDisplay;
    var l_sText;
    if (this.m_bClusteringShown == true) 
    {
        l_sDisplay = "none";
        l_sText = "+ Cluster Information";
        this.m_bClusteringShown = false;
    }
    else 
    {
        l_sDisplay = "block";
        l_sText = "- Cluster Information";
        this.m_bClusteringShown = true;
    }
    document.getElementById(ClusterData.DISPLAY_ID).style.display = l_sDisplay;
    document.getElementById(ClusterData.DISPLAY_TOGGLER_ID).firstChild.nodeValue = l_sText;
};
