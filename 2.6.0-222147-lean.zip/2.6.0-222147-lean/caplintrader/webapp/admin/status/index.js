function StatusSubscriber()
{
    this.initialise();
}

StatusSubscriber.prototype = new SL4B_AbstractSubscriber;

StatusSubscriber.SystemDir = '/SYSTEM';
StatusSubscriber.SystemInfo = '/SYSTEM/INFO';
StatusSubscriber.NodeInfo = '/SYSTEM/NODE-%NODE%/INFO';
StatusSubscriber.LicenseObject = '/SYSTEM/LICENSE';
StatusSubscriber.const_NBSP = "\u00a0";

StatusSubscriber.instance = new StatusSubscriber();

StatusSubscriber.prototype.ready = function()
{
    SL4B_Accessor.getRttpProvider().getObject(this, StatusSubscriber.SystemInfo, "NodeID");
    document.getElementById("tblSL4BVersion").innerHTML = '&nbsp;' + SL4B_Version.getVersion() + '&nbsp;';
};

StatusSubscriber.prototype.recordMultiUpdated = function(sObjectName, oFieldData)
{
    if (sObjectName == StatusSubscriber.SystemInfo && oFieldData.getFieldName(0) == "NodeID")
    {
        var l_sNode = oFieldData.getFieldValue(0);
        SL4B_Accessor.getRttpProvider().getObjects(this, StatusSubscriber.SystemDir + " " + StatusSubscriber.SystemInfo + " " + StatusSubscriber.LicenseObject + " " + StatusSubscriber.NodeInfo.replace("%NODE%", l_sNode));
    }
    else
    {
        for (var i = 0; i < oFieldData.size(); i++) 
        {
            var sFieldName = oFieldData.getFieldName(i);
            var sValue = oFieldData.getFieldValue(i);
            this.recordUpdated(sObjectName, sFieldName, sValue);
        }
    }
};

StatusSubscriber.prototype.recordUpdated = function(l_sSymbol, l_sField, l_sValue)
{
    var l_oElement = document.getElementById("tbl" + l_sField);
    var l_nFlashClr = '#22155A';
    var l_nTextClr = 'white';

    if (l_oElement != null)
    { 
        if (l_sField == "GracePeriodExpireTime")
        {
            if (l_sValue == "-")
            {
                l_sValue = "Not in Grace Period";
                setTimeout("removeFlash('" + l_sSymbol + "', '" + l_sField + "', 'black');", 2000);
            }
            else
            {
                l_nFlashClr = 'red';
            }
        }
        else
        {
            setTimeout("removeFlash('" + l_sSymbol + "', '" + l_sField + "', 'black');", 2000);
        }

        l_oElement.firstChild.nodeValue = StatusSubscriber.const_NBSP + l_sValue + StatusSubscriber.const_NBSP;
        l_oElement.style.backgroundColor = l_nFlashClr;
        l_oElement.style.color = l_nTextClr;
    }
};

function removeFlash(l_sSymbol, l_sField, l_sColour)
{
    var l_oElement = document.getElementById("tbl" + l_sField);

    if (l_oElement != null) 
    {
        l_oElement.style.color = l_sColour;
        l_oElement.style.backgroundColor = '';
    }
}

function toggler_OnMouseOver(toggler)
{
    toggler.style.color = '9999F0';
}

function toggler_OnMouseOut(toggler)
{
    toggler.style.color = '';
}
