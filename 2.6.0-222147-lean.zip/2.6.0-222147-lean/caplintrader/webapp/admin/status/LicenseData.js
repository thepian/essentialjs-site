function LicenseData()
{
    this.m_pData = LicenseData.DATA;
    this.initialise();
}

LicenseData.prototype = new SL4B_AbstractSubscriber;

LicenseData.COLUMNS = 2;
LicenseData.NBSP = "\u00a0";
LicenseData.CONST_FIELD_VAL = "==CONST==";

LicenseData.TRADING_GROUP_SYMBOL = "/SYSTEM/LICENSING/TRADINGGROUP";
LicenseData.TRADING_GROUP_TBL_ID = "tblTradingGroupLicensing";
LicenseData.TRADING_GROUP_H3_ID = "trading_groups_heading";
LicenseData.TRADING_GROUP_FIELDS = new Array("TradingGroupName", "LicencedUsageLimit", "Usage", "FailedUsage", "StatusText");
LicenseData.TRADING_GROUP_LABELS = new Array("Name:", "Max Users:", "Cumulative Users:", "Rejected Users:", "Status:");
LicenseData.TRADE_GROUP = new Array(LicenseData.TRADING_GROUP_SYMBOL, LicenseData.TRADING_GROUP_TBL_ID, LicenseData.TRADING_GROUP_FIELDS, LicenseData.TRADING_GROUP_LABELS);

LicenseData.GENERAL_USERS_SYMBOL = "/SYSTEM/LICENSING/APPLICATION";
LicenseData.GENERAL_USERS_TBL_ID = "tblGeneralUserLicensing";
LicenseData.GENERAL_USERS_FIELDS = new Array("ApplicationName", "LicencedSessionLimit", "TotalSessions", "FailedSessions", "StatusText");
LicenseData.GENERAL_USERS_LABELS = new Array("Name:", "Max Logins:", "Cumulative Logins:", "Failed Logins Count:", "Status:");
LicenseData.GENERAL_USERS = new Array(LicenseData.GENERAL_USERS_SYMBOL, LicenseData.GENERAL_USERS_TBL_ID, LicenseData.GENERAL_USERS_FIELDS, LicenseData.GENERAL_USERS_LABELS);

LicenseData.UNIQUE_USERS_SYMBOL = "/SYSTEM/LICENSING/UNIQUE_USERS";
LicenseData.UNIQUE_USERS_TBL_ID = "tblGeneralUserLicensing";
LicenseData.UNIQUE_USERS_FIELDS = new Array("(Any)" + LicenseData.CONST_FIELD_VAL, "MaxUniqueUsers", "UniqueUsers", "RejectedUniqueUsers", "StatusText");
LicenseData.UNIQUE_USERS_LABELS = LicenseData.GENERAL_USERS_LABELS;
LicenseData.UNIQUE_USERS = new Array(LicenseData.UNIQUE_USERS_SYMBOL, LicenseData.UNIQUE_USERS_TBL_ID, LicenseData.UNIQUE_USERS_FIELDS, LicenseData.UNIQUE_USERS_LABELS);

LicenseData.DATA = new Array();
LicenseData.DATA[LicenseData.TRADING_GROUP_SYMBOL] = LicenseData.TRADE_GROUP;
LicenseData.DATA[LicenseData.GENERAL_USERS_SYMBOL] = LicenseData.GENERAL_USERS;
LicenseData.DATA[LicenseData.UNIQUE_USERS_SYMBOL] = LicenseData.UNIQUE_USERS;

LicenseData.instance = new LicenseData();

LicenseData.getInstance = function()
{
   return LicenseData.instance;
};

LicenseData.prototype.ready = function()
{
    for (l_sObjectName in this.m_pData)
    {
        SL4B_Accessor.getRttpProvider().getObjects(this, l_sObjectName);
        this.m_pData[l_sObjectName]["count"] = 0;
    }
};

LicenseData.prototype.recordMultiUpdated = function(l_sObjectName, l_oFieldData)
{
    if (this.m_pData[l_sObjectName] != null)
    {
        this.addTable(l_sObjectName, "");
    }

    for (var i = 0; i < l_oFieldData.size(); i++) 
    {
        var l_sFieldName = l_oFieldData.getFieldName(i);
        var l_sValue = l_oFieldData.getFieldValue(i);
        this.fieldUpdated(l_sObjectName, l_sFieldName, l_sValue);
    }
};

LicenseData.prototype.directoryUpdated = function(l_sDirObjectName, l_sObjectName, l_nType, l_bAdded)
{
    // Create a table for each directory.
    if (l_bAdded)
    {
        this.addTable(l_sDirObjectName, l_sObjectName);

			if( l_sDirObjectName == LicenseData.TRADING_GROUP_SYMBOL )
			{
				var oHeading = document.getElementById( LicenseData.TRADING_GROUP_H3_ID );
				oHeading.style.display = "block";
			}
    }

    // Subscribe to directory.
    SL4B_Accessor.getRttpProvider().getObjects(this, l_sDirObjectName + "/" + l_sObjectName);
};

LicenseData.prototype.addTable = function(l_sDirObjectName, l_sObjectName)
{
    // Construct the full object name.
    var l_sName;
    if (l_sObjectName == "")
    {
        l_sName = l_sDirObjectName;
    }
    else
    {
        l_sName = l_sDirObjectName + "/" + l_sObjectName;
    }

    // See if we have a table for it already.
    if (document.getElementById(l_sName) == null)
    {
        // If not, create one.
        var l_sTableBody = this.m_pData[l_sDirObjectName][1];
        var l_pFields = this.m_pData[l_sDirObjectName][2];
        var l_pLabels = this.m_pData[l_sDirObjectName][3];

        var l_oTableBody = document.getElementById(l_sTableBody);

        if (this.isEven(++this.m_pData[l_sDirObjectName]["count"]))
        {
            // We have a blank spot in the right hand column. Fill it.
            var l_oRow = l_oTableBody.lastChild
            this.addInnerTable(l_oRow, l_sName, l_pFields, l_pLabels);
        }
        else
        {
            // Create a new row.
            var l_oRow = document.createElement("tr");
            this.addInnerTable(l_oRow, l_sName, l_pFields, l_pLabels);
            l_oTableBody.appendChild(l_oRow);
        }
    }
};

LicenseData.prototype.addInnerTable = function(l_oBaseTableRow, l_sName, l_pFields, l_pLabels)
{
    var l_oCell = document.createElement("td");
    var l_oTable = document.createElement("table");
    var l_oTableBody = document.createElement("tbody");

    for (var l_nRow = 0; l_nRow < l_pFields.length; l_nRow++) 
    {
        var l_oRow = document.createElement("tr");
        this.addCells(l_oRow, l_nRow, l_sName + "/" + l_pFields[l_nRow], l_pLabels[l_nRow]);
        l_oTableBody.appendChild(l_oRow);
    }

    l_oTable.id = l_sName;

    l_oTable.appendChild(l_oTableBody);
    l_oCell.appendChild(l_oTable);
    l_oBaseTableRow.appendChild(l_oCell);
};

LicenseData.prototype.addCells = function(l_oRow, l_nRow, l_sName, l_sLabel)
{
    for (var l_nCol = 0; l_nCol < LicenseData.COLUMNS; l_nCol++) 
    {
        var l_oCell = document.createElement("td");

        if (l_nCol == 0)
        {
            l_oCell.id = l_sName + "/Label";
            l_oCell.className = 'tbl-label';
            l_oCell.appendChild(document.createTextNode(l_sLabel));
        }
        else
        {
            l_oCell.id = l_sName + "/Value";
            l_oCell.className = 'tbl-data';

            if (l_sName.indexOf(LicenseData.CONST_FIELD_VAL) == -1)
            {
                l_oCell.appendChild(document.createTextNode(LicenseData.NBSP + "Please wait..." + LicenseData.NBSP));
            }
            else
            {
                l_sValue = l_sName.substring(l_sName.lastIndexOf("/") + 1).replace(LicenseData.CONST_FIELD_VAL, "");
                l_oCell.appendChild(document.createTextNode(LicenseData.NBSP + l_sValue + LicenseData.NBSP));
            }
        }
        l_oRow.appendChild(l_oCell);
    }
};

LicenseData.prototype.isEven = function(l_nNum)
{
    return (l_nNum % 2) == 0;
};

LicenseData.prototype.setFlash = function(l_sCell, l_bRemoveFlash, l_sColour, l_sBackgroundColour)
{
    var l_oCell = document.getElementById(l_sCell);

    l_oCell.style.color = 'white';
    if (l_sColour != null)
    {
        l_oCell.style.color = l_sColour;
    }

    l_oCell.style.backgroundColor = '#22155A';
    if (l_sBackgroundColour != null)
    {
        l_oCell.style.backgroundColor = l_sBackgroundColour;
    }

    if (l_bRemoveFlash == null || l_bRemoveFlash == true)
    {
        setTimeout("LicenseData.removeFlash('" + l_oCell.id + "');", 2000);
    }
};

LicenseData.removeFlash = function(l_sCell)
{
    var l_oCell = document.getElementById(l_sCell);
    l_oCell.style.backgroundColor = '';
    l_oCell.style.color = '';
};

LicenseData.prototype.fieldUpdated = function(l_sObjectName, l_sFieldName, l_sValue)
{
    var l_oCell = document.getElementById(l_sObjectName + "/" + l_sFieldName + "/Value");

    if (l_oCell != null)
    {
        l_oCell.firstChild.nodeValue = LicenseData.NBSP + l_sValue + LicenseData.NBSP;

        switch (l_sFieldName)
        {
            case 'StatusText':
                switch (l_sValue)
                {
                    case "Warning level reached":
                        this.setFlash(l_oCell.id, false, "white", "orange");
                        break;
                    case "License limit exceeded":
                        this.setFlash(l_oCell.id, false, "white", "red");
                        break;
                    default:
                        this.setFlash(l_oCell.id)
                        break;
                }
                break;
            default:
                this.setFlash(l_oCell.id);
                break;
        }
    }
};
