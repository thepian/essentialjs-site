CREATING YOUR OWN XAQUA RESTART ANT TARGET:
===========================================

Some build features require restarting Caplin Xaqua components. 
To do so, the relevant start/stop scripts in the Caplin Xaqua installation directory will be executed.

It is assumed that the installation directory for Caplin Xaqua components is:

   ~/standard_environments/CaplinTrader.

If your Caplin Xaqua installation directory differs � you will need to perform the following steps:
(Please interchange all references to 'novobank' to what is suitable for your bank/organisation).

   1.   Create a new file, for example 'novobank-xaqua.xml' under X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader/build 
	
   2.   Edit the file so that it contains project tags:
        
        <project>
	       ...
        </project>

   2.	Copy the ant target named 'xaqua-caplintrader-restart' from X:/scm_root/CT2/2.0.X-nnnnnn\sdk\build\common\xaqua.xml to the novobank-xaqua.xml file created in step 1, inside the project tags:

        <project>
               ... <-- copied ant target goes here
        </project>

   3.   Edit the ant target sshexec variables for 'username' and 'password' for ssh and update them as necessary. 
        The default values are 'tester' for both.	

   4.   Edit the ant target that was copied to novobank-xaqua.xml so that it refers to the correct directory for your Caplin Xaqua components.
	
        E.g. Modify the ant target xml line

        cd ~/standard-environments/CaplinTrader 
        TO
        cd ~/<Path to Caplin Xaqua installation>/apps/caplin			     

   5.   Edit file: X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader/build.xml 
        to include the line: 

	<import file="${TRADER.BRANCH.DIR}/${TRADER.NAME}/build/novobank-xaqua.xml"/> 

	BEFORE the line containing:

	<import file="${CAPLIN.HOME}/${CAPLIN.SDK.VERSION}/sdk/build/caplin.xml"/>.

   6.   Edit file: X:/scm_root/CT2/2.0.X-nnnnnn/caplintrader/acceptance-tests/build.xml 
        to include the line: 

        <import file="${TRADER.BRANCH.DIR}/${TRADER.NAME}/build/novobank-xaqua.xml"/> 

        BEFORE the line containing:
 
        <import file="${CAPLIN.HOME}/${CAPLIN.SDK.VERSION}/sdk/build/caplin.xml"/>.

NOTE: Modifying �xaqua-caplintrader-restart� in X:/scm_root/CT2/2.0.X-nnnnnn\sdk\build\common\xaqua.xml is not advised as any changes will be lost during an upgrade.



