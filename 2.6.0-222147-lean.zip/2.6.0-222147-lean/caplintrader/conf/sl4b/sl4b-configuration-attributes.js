
//namespace to prevent global varibles
(function () 
{

	function _getValueFromQueryString(sField) 
	{
		var sQueryString = window.location.search.substring(1);
		var sFieldValuePair = sQueryString.split("&");
		for (var i = 0, nLength = sFieldValuePair.length; i < nLength; ++i) 
		{
			var pFieldValuePair = sFieldValuePair[i].split("=");
			if (pFieldValuePair[0] === sField) 
			{
				return pFieldValuePair[1];
			}
		}
	}
	
	var oConfiguration = SL4B_Accessor.getConfiguration();
	oConfiguration.setAttribute("rttpprovider", "javascript");
	oConfiguration.setAttribute("maxgetlength", "0");
	oConfiguration.setAttribute("commondomain", "@TRADER.DOMAIN@");
	oConfiguration.setAttribute("applicationId", "CaplinTraderReferenceImplementation");
	oConfiguration.setAttribute("timestampfield", "LATENCY_TIMESTAMP");
	oConfiguration.setAttribute("enablelatency", "true");
	
	var sQueryStrings = window.location.search;
	if (sQueryStrings.indexOf("test") > 0)
	{
		oConfiguration.setAttribute("serverurl", "http://integrationlinux1.caplin.com:41980");
		// determines whether sl4b onload/onbeforeunload should be automatically invoked
		oConfiguration.setAttribute("enableautoloading", "true");
	
	}
	else 
	{
		// KeyMaster configuration
		oConfiguration.setAttribute("keymasterurl", "servlet/StandardKeyMaster");
		oConfiguration.setAttribute("keymasterxhrurl", "servlet/XHRKeymaster");
		oConfiguration.setAttribute("keymasterconnectiontimeout", "60000");
		oConfiguration.setAttribute("keymasterkeepaliveinterval", "300000");
		oConfiguration.setAttribute('clocksyncstrategy', 'GF_SlidingClockSyncStrategy');

		// determines whether sl4b onload/onbeforeunload should be automatically invoked
		oConfiguration.setAttribute("enableautoloading", "false");
		
		
		if (sQueryStrings.indexOf("liberatorAdminTestConfig") > 0)
		{
			var server = _getValueFromQueryString("liberatorName");
			var address = _getValueFromQueryString("liberatorHost");
			var port = _getValueFromQueryString("liberatorPort");
			var protocol = _getValueFromQueryString("liberatorProtocol");
			
			
			if (!server || !address || !port || !protocol) {
				throw "request parameters must contain all of: liberatorName, liberatorHost, liberatorPort, liberatorProtocol";
			}
			var conf = {};
			conf[server] = {
				address: address,
				port: port,
				protocol: protocol
			};
			oConfiguration.setAttribute("liberatorConfig", conf);
			
		}
		else if (sQueryStrings.indexOf("liberatorHost") > 0)
		{
			var sHost = _getValueFromQueryString("liberatorHost");
			oConfiguration.setAttribute("serverurl", sHost);
		}
		else if (sQueryStrings.indexOf("scripted") > 0)
		{
	
			oConfiguration.setAttribute("serverurl", "http://@XAQUA.HOSTNAME@:@XAQUA.SCRIPTED.HTTP.PORT@");
		}
		else
		{
		    if(window.location.protocol == "http:")
		    {
		        // ZUN failover configuration
		        oConfiguration.setAttribute("service", "conf/liberator-service-configuration.xml");
		    }
		    else // https
		    {
		        // ZUN failover configuration
		        oConfiguration.setAttribute("service", "conf/liberator-service-configuration-https.xml");
		    }
		}
	}
	
	if(this.enhanceSl4bConfig)
	{
		this.enhanceSl4bConfig(oConfiguration);
	};

})();