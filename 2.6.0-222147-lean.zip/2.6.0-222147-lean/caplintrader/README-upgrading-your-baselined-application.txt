TO UPGRADE YOUR BASELINED APPLICATION:
=============================================

Objective: To upgrade an existing baselined application to a new version of the caplin trader libraries.

Prerequisites: 	You have previously created a baselined application following the instructions
	in README-first.txt and README-to-baseline-your-trading-application.txt.

       
To upgrade your baselined application to a new version of the caplin trader libraries perform the following
steps: 
	
	1. Extract the new version of the caplin trader SDK and thirdparty archives into the same directory
	as the previous caplin trader version.
	
	2. Open the file 'installer.properties' located in the root directory of your baselined application and
	change the CAPLIN.SDK.VERSION to reflect the new version you are upgrading to and
	CAPLIN.TRADER.SDK.VERSION to the same version appending '-SNAPSHOT'.
	
	3. Open a command prompt in the root directory of your baselined application (for example 
	X:/scm_root/NovoBank/1.0/novotrader) and execute the following command:
	
		ant upgrade

	NOTE: Please check the RELEASENOTE.txt file for any compatibility issues and the steps	


