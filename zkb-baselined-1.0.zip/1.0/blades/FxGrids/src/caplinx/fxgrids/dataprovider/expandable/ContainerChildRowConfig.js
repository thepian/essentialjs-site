caplin.namespace("caplinx.fxgrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinx.fxgrids.dataprovider.expandable.ContainerChildRowConfig = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
};

caplinx.fxgrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getContainerToExpanded = function(mRowData, sRendererId)
{
	return '/CONTAINER/FX/Emerging';
};

caplinx.fxgrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return oGridColumnModel.getRequiredFields();
};

caplinx.fxgrids.dataprovider.expandable.ContainerChildRowConfig.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	if (mRecordUpdates.InstrumentDescription && mRecordUpdates.InstrumentDescription.substring(0, 3)!="...") 
	{
		mRecordUpdates = caplin.core.MapUtility.clone(mRecordUpdates);
		mRecordUpdates.MagicInstrumentDescription = mRecordUpdates.InstrumentDescription;
		mRecordUpdates.InstrumentDescription = "";
	}
	return mRecordUpdates;
};
