caplin.namespace("caplinx.fxgrids.dataprovider.expandable");

caplinx.fxgrids.dataprovider.expandable.FxGridSL4BSubjectChildRowConfig = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
};

caplinx.fxgrids.dataprovider.expandable.FxGridSL4BSubjectChildRowConfig.prototype.getSubjectToExpanded = function(mRowData, sSubject)
{
	return sSubject;
};

caplinx.fxgrids.dataprovider.expandable.FxGridSL4BSubjectChildRowConfig.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return [];
};

caplinx.fxgrids.dataprovider.expandable.FxGridSL4BSubjectChildRowConfig.prototype.getNumberOfChildRowsRows = function(oGridColumnModel, oFieldData)
{
	var nChildRows = 0;
	
	for(var sField in oFieldData.getFieldMap())
	{
		var pMatchArray = sField.match(/^Tier([0-9]).*/);
		if(pMatchArray)
		{
			var nTier = parseInt(pMatchArray[1], 10);
			nChildRows = nTier > nChildRows ? nTier : nChildRows;
		}
	}
	return nChildRows;
};

caplinx.fxgrids.dataprovider.expandable.FxGridSL4BSubjectChildRowConfig.prototype.getChildRows = function(sSubject, oFieldData)
{
	var pRows = [];
	var mFieldMap = oFieldData.getFieldMap();
	
	for(var sFieldName in mFieldMap)
	{
		var pMatchArray = sFieldName.match(/^Tier([0-9]).*/);
		if(pMatchArray)
		{
			var nRow = parseInt(pMatchArray[1], 10) - 1;
			pRows[nRow] = pRows[nRow] ? pRows[nRow] : {};
			pRows[nRow][sFieldName] = mFieldMap[sFieldName];
		}
	}
	return pRows;
};

caplinx.fxgrids.dataprovider.expandable.FxGridSL4BSubjectChildRowConfig.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	var mRowRecords = {};
	
	for(var sFieldName in mRecordUpdates)
	{
		var pMatchArray = sFieldName.match(/^Tier([0-9])(.*)/);
		if(pMatchArray)
		{
			if(pMatchArray[2].match(/Ask|Bid/))
			{
				mRowRecords['Best' + pMatchArray[2]] = mRecordUpdates[sFieldName];
			}
			else
			{
				mRowRecords[sFieldName] = mRecordUpdates[sFieldName];
			}
		}
	}
	return mRowRecords;
};