caplin.namespace("caplinx.fxgrids.handler");

caplin.include("caplin.element.Handler", true);
caplin.include("caplinx.tobo.TOBOUserManager");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.fxgrids.handler.TradeOnClickHandler = function() {
};

caplin.extend(caplinx.fxgrids.handler.TradeOnClickHandler, caplin.element.Handler);

caplinx.fxgrids.handler.TradeOnClickHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes) {
	
	if (oRenderer.getVariable("TRADABLE") == "true" && caplinx.tobo.TOBOUserManager.canPerformTrade())  {
		var sPrimaryFieldName = oRenderer.getAllFieldNames()[0];
		var sSide = (sPrimaryFieldName.match(/bid/i)) ? "Bid" : "Ask";
		caplin.framework.ApplicationFactory.getInstance().openTradeTicketV4(oRenderer, sSide);
	}
};

caplinx.fxgrids.handler.TradeOnClickHandler.prototype.toString = function() {
	return "caplinx.fxgrids.handler.TradeOnClickHandler";
};

caplin.singleton("caplinx.fxgrids.handler.TradeOnClickHandler");
