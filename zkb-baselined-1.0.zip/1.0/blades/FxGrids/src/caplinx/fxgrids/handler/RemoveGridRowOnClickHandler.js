/**
 * @fileoverview
 * 
 * This handler traps click events and passes an 'trade' the {@link caplin.element.RendererEventListener}.
 */

caplin.namespace("caplinx.fxgrids.handler");

caplin.include("caplin.element.Handler", true);

/**
 * RemoveGridRowOnClickHandler is a flyweight singleton, and therefore this constructor should never be invoked directly.
 * <p/>
 * Instead, it is instantiated by the RendererFactory, which reads RendererType specifications from XML and
 * instantiates the handlers by name.
 * 
 * @extends {caplin.element.Handler}
 * @constructor
 */
caplinx.fxgrids.handler.RemoveGridRowOnClickHandler = function() {
};

caplin.extend(caplinx.fxgrids.handler.RemoveGridRowOnClickHandler, caplin.element.Handler);

/**
 * Traps the <code>onclick</code> event and returns an 'trade' event for passing up to the RendererEventListener.
 * 
 * All the functions that begin with <code>on</code> are assumed to be event handler functions, and are attached
 * to DOM elements by reflection.
 * 
 * @param {Object} oDomEvent  The DOM event
 * @param {Object} oRenderer  The renderer 
 *  
 * @type Map
 * @return  An 'trade' event
 */
caplinx.fxgrids.handler.RemoveGridRowOnClickHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes) {
	var oControl = oRenderer.getControl();
	if (oControl.isEnabled()) {
		oRenderer.raiseEvent("removeRowClick", {"event":oDomEvent});
	}
};

/**
 * Returns a human-readable string representation of the handler, which is useful for debugging.
 * 
 * @return  The string representation
 * @type String
 */
caplinx.fxgrids.handler.RemoveGridRowOnClickHandler.prototype.toString = function() {
	return "caplinx.fxgrids.handler.RemoveGridRowOnClickHandler";
};

caplin.singleton("caplinx.fxgrids.handler.RemoveGridRowOnClickHandler");
