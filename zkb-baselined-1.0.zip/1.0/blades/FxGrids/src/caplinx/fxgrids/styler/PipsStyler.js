/**
 * @fileoverview
 * 
 * Applies CSS styles to reflect combination of tradable and status states.  
 * <p/>
 * The following attributes are required by the style:
 * <p/>
 * <ul>
 * <li><code>tradableState</code> - The model field representing the tradable state (true or false)</li>
 * <li><code>recordStatus</code> - The model field representing the record status (SL4B object status)</li>
 * <li><code>tradableClass</code> - The CSS class to apply when the instrument is tradable but not stale</li>
 * <li><code>staleClass</code> - The CSS class to apply when the instrument is stale but not tradable</li>
 * <li><code>tradablestaleClass</code> - The CSS class to apply when the instrument is both tradable and stale</li>
 * </ul>
 */
caplin.namespace("caplinx.fxgrids.styler");

caplin.include("caplin.element.Styler", true);


/**
 * Applies CSS styles to reflect combination of tradable and status states.  
 * 
 * Stylers are instantiated by the RendererFactory, which reads RendererType specifications from XML and
 * instantiates the stylers by name.
 * 
 * <p/>
 * The following attributes are required by the style:
 * <p/>
 * <ul>
 * <li><code>tradableState</code> - The model field representing the tradable state (true or false)</li>
 * <li><code>recordStatus</code> - The model field representing the record status (SL4B object status)</li>
 * <li><code>tradableClass</code> - The CSS class to apply when the instrument is tradable but not stale</li>
 * <li><code>staleClass</code> - The CSS class to apply when the instrument is stale but not tradable</li>
 * <li><code>tradablestaleClass</code> - The CSS class to apply when the instrument is both tradable and stale</li>
 * </ul>
 * 
 * @constructor
 */
caplinx.fxgrids.styler.PipsStyler = function() {
};

caplin.extend(caplinx.fxgrids.styler.PipsStyler, caplin.element.Styler);

/**
 * Styles the supplied control with tradable and stale CSS styles, according to the supplied renderer attributes.
 * 
 * @param {String} sValue  The field value, which may be partially formatted, depending on when the Styler is applied
 * @param {caplin.element.Control} oControl  The control to style
 * @param {Map} mAttributes  Renderer attributes, containing all needed state information needed
 * @return The field value
 * @type String
 */
caplinx.fxgrids.styler.PipsStyler.prototype.style = function(sValue, mAttributes, oControl) {
	var bSmallPip = this.isTrue("smallPip", mAttributes);
	oControl.setAttribute("smallPip", bSmallPip? 1 : 0);
	return sValue;
};

/**
 * Returns a human-readable string representation of the styler, which is useful for debugging.
 * 
 * @return  The string representation
 * @type String
 */
caplinx.fxgrids.styler.PipsStyler.prototype.toString = function() {
	return "caplinx.fxgrids.styler.PipsStyler";
};

caplin.singleton("caplinx.fxgrids.styler.PipsStyler");
