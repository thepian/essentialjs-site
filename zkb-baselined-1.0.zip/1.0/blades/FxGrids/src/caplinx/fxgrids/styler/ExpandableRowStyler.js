caplin.namespace("caplinx.fxgrids.styler");

caplin.include("caplin.element.Styler", true);
caplin.include("caplin.dom.Utility");

/**
 * @class
 * 
 * Styles an expandable grid row control to display expanded, collapsed and child
 * row icons.  
 * 
 * @extends caplin.element.Styler
 */
caplinx.fxgrids.styler.ExpandableRowStyler = function(){
};
caplin.extend(caplinx.fxgrids.styler.ExpandableRowStyler, caplin.element.Styler);

/**
 * Styles an expandable grid row control to display expanded, collapsed and child
 * row icons.
 * 
 * @param {String} sValue Field value
 * @param {Map} mAttributes  Attributes defined in the renderer definitions file
 * @param {caplin.element.Control} oControl  The control to style
 */
caplinx.fxgrids.styler.ExpandableRowStyler.prototype.style = function(vValue, mAttributes, oControl)
{
	var oUtility = caplin.dom.Utility;
	var eElem = oControl.getElement();
	var eRow = eElem ? oUtility.getAncestorElementWithClass(oControl.getElement(), "row") : null;

	if (eRow)
	{
		var isExpandable = mAttributes["parentRowId"] ? false : true;
		var sExpandableClass = mAttributes["expandableClass"];
		var sExpandedClass = mAttributes["expandableExpandedClass"];
		var sChildClass = mAttributes["childClass"];
		var sLastChildClass = mAttributes["lastChildClass"];
		var sRowState = mAttributes["rowState"];
		var pClassToAdd = [];
		var pClassToRemove = [];
		
		if (isExpandable)
		{
			pClassToRemove.push(sChildClass);
			pClassToRemove.push(sLastChildClass);
			pClassToAdd.push(sExpandableClass);
			
			if (sRowState === "expandedRow")
			{
				pClassToAdd.push(sExpandedClass);
			}
			else
			{
				pClassToRemove.push(sExpandedClass);
			}
		}
		else
		{
			pClassToRemove.push(sExpandableClass);
			pClassToRemove.push(sExpandedClass);
			
			if (sRowState === "expandedChildRow")
			{
				pClassToRemove.push(sLastChildClass);
				pClassToAdd.push(sChildClass);
			}
			else if (sRowState === "lastExpandedChildRow")
			{
				pClassToAdd.push(sChildClass);
				pClassToAdd.push(sLastChildClass);
			}
			else
			{
				pClassToRemove.push(sChildClass);
				pClassToRemove.push(sLastChildClass);
			}
		}
		oUtility.addAndRemoveClassNames(eRow,pClassToAdd,pClassToRemove);
	}
    return vValue;
};

/**
 * @private
 */
caplinx.fxgrids.styler.ExpandableRowStyler.prototype.toString = function()
{
    return "caplinx.fxgrids.styler.ExpandableRowStyler";
};

caplin.singleton("caplinx.fxgrids.styler.ExpandableRowStyler");
