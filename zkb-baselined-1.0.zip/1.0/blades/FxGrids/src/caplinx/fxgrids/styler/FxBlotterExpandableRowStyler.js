caplin.namespace("caplinx.fxgrids.styler");

caplin.include("caplin.element.Styler", true);
caplin.include("caplin.dom.Utility");

/**
 * @class
 * 
 * Styles an expandable grid row control to display expanded, collapsed and child
 * row icons.  
 * 
 * @extends caplin.element.Styler
 */
caplinx.fxgrids.styler.FxBlotterExpandableRowStyler = function(){
};
caplin.extend(caplinx.fxgrids.styler.FxBlotterExpandableRowStyler, caplin.element.Styler);

/**
 * Styles an expandable grid row control to display expanded, collapsed and child
 * row icons.
 * 
 * @param {String} sValue Field value
 * @param {Map} mAttributes  Attributes defined in the renderer definitions file
 * @param {caplin.element.Control} oControl  The control to style
 */
caplinx.fxgrids.styler.FxBlotterExpandableRowStyler.prototype.style = function(vValue, mAttributes, oControl)
{
	var sTradingType = mAttributes['tradingType'];
	var sRowState = mAttributes['rowState'];
	
	if(sTradingType === 'SWAP' || sTradingType === 'FWDFWDSWAP')
	{
		if(sRowState === "expandedRow")
		{
			oControl.replaceClass('expandableRow', 'expandableRowExpanded');
		}
		else if(sRowState === '')
		{
			oControl.replaceClass('expandableRowExpanded', 'expandableRow');
		}
	}
	else if(sRowState !== '')
	{
		oControl.addClass(sRowState);
	}
	
    return vValue;
};

/**
 * @private
 */
caplinx.fxgrids.styler.FxBlotterExpandableRowStyler.prototype.toString = function()
{
    return "caplinx.fxgrids.styler.FxBlotterExpandableRowStyler";
};

caplin.singleton("caplinx.fxgrids.styler.FxBlotterExpandableRowStyler");
