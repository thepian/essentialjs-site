caplin.namespace("caplinx.figrids.handler");

caplin.include("caplin.element.Handler", true);

caplinx.figrids.handler.ActivesTradeOnDoubleClickHandler = function() {
};

caplin.extend(caplinx.figrids.handler.ActivesTradeOnDoubleClickHandler, caplin.element.Handler);

caplinx.figrids.handler.ActivesTradeOnDoubleClickHandler.prototype.ondblclick = function(oDomEvent, oRenderer, mAttributes) {
	oRenderer.raiseEvent("doubleClick");
};

caplinx.figrids.handler.ActivesTradeOnDoubleClickHandler.prototype.toString = function() {
	return "caplinx.figrids.handler.ActivesTradeOnDoubleClickHandler";
};

caplin.singleton("caplinx.figrids.handler.ActivesTradeOnDoubleClickHandler");
