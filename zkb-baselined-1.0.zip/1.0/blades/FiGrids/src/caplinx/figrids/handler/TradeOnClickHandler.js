caplin.namespace("caplinx.figrids.handler");

caplin.include("caplin.element.Handler", true);
caplin.include("caplinx.tobo.TOBOUserManager");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.figrids.handler.TradeOnClickHandler = function() {
};

caplin.extend(caplinx.figrids.handler.TradeOnClickHandler, caplin.element.Handler);

caplinx.figrids.handler.TradeOnClickHandler.prototype.onclick = function(oDomEvent, oRenderer, mAttributes) {
	
	if (oRenderer.getVariable("TRADABLE") == "true" && caplinx.tobo.TOBOUserManager.canPerformTrade())  {
		var sPrimaryFieldName = oRenderer.getAllFieldNames()[0];
		var sSide = (sPrimaryFieldName.match(/bid/i)) ? "Bid" : "Ask";
		caplin.framework.ApplicationFactory.getInstance().openTradeTicketV4(oRenderer, sSide);
	}
};

caplinx.figrids.handler.TradeOnClickHandler.prototype.toString = function() {
	return "caplinx.figrids.handler.TradeOnClickHandler";
};

caplin.singleton("caplinx.figrids.handler.TradeOnClickHandler");
