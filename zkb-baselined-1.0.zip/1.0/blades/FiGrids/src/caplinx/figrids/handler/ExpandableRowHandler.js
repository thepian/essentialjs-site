caplin.namespace("caplinx.figrids.handler");

caplin.include("caplin.element.Handler");

/**
 * @class
 * 
 * ExpandableRowHandler is a flyweight singleton, and therefore this constructor should never be invoked directly.
 * <p/>
 * Instead, it is instantiated by the RendererFactory, which reads RendererType specifications from XML and
 * instantiates the handlers by name.
 * 
 * @extends caplin.element.Handler
 * @singleton
 */
caplinx.figrids.handler.ExpandableRowHandler = function(){
};
caplin.extend(caplinx.figrids.handler.ExpandableRowHandler, caplin.element.Handler);

/**
 * Raises a 'rowToggle' renderer event when the user clicks the expand or collapse
 * icons.
 * 
 * @param {Object} oEvent The DOM event
 * @param {Object} oRenderer The renderer
 * @param {Object} mAttributes Atributes that have been defined in the renderer definitions file
 */
caplinx.figrids.handler.ExpandableRowHandler.prototype.onclick = function(oEvent, oRenderer, mAttributes){
	oRenderer.raiseEvent('rowToggle', oEvent);
};

/**
 * Returns a human-readable string representation of the handler, which is useful for debugging.
 * 
 * @return  The string representation
 * @type String
 */
caplinx.figrids.handler.ExpandableRowHandler.prototype.toString = function(){
    return "caplinx.figrids.handler.ExpandableRowHandler";
};

caplin.singleton("caplinx.figrids.handler.ExpandableRowHandler");
