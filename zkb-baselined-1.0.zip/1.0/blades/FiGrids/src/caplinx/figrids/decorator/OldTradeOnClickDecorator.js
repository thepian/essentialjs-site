caplin.namespace("caplinx.figrids.decorator");

caplin.include("caplin.dom.Utility");
caplin.include("caplin.dom.event.Event");
caplin.include("caplin.grid.decorator.GridDecorator", true);
caplin.include("caplin.framework.ApplicationFactory");


caplinx.figrids.decorator.OldTradeOnClickDecorator = function()
{
	this.m_oGridView = null;
	this.m_oGridRowModel = null;
};

caplin.implement(caplinx.figrids.decorator.OldTradeOnClickDecorator, caplin.grid.decorator.GridDecorator);
caplin.implement(caplinx.figrids.decorator.OldTradeOnClickDecorator, caplin.grid.GridViewListener);

caplinx.figrids.decorator.OldTradeOnClickDecorator.prototype.setGridView = function(oGridView)
{
	this.m_oGridView = oGridView;
	this.m_oGridView.addGridViewListener(this);
	this.m_oGridRowModel = oGridView.getGridRowModel();
};

/**
 * @private
 * @see caplin.grid.GridViewListener#onContainerHtmlRendered
 */
caplinx.figrids.decorator.OldTradeOnClickDecorator.prototype.onContainerHtmlRendered = function()
{
	var eElement = this.m_oGridView.getElement();
	this.m_nLeftClickListenerId = caplin.dom.Utility.addEventListener(eElement, "click", this._getLeftClickHandler());
};

/**
 * @private
 * @see caplin.grid.GridViewListener#onRowStructureChanged
 */
caplinx.figrids.decorator.OldTradeOnClickDecorator.prototype.onRowStructureChanged = function(pIndicies)
{
	for(var i = 0, l = pIndicies.length; i < l; i++) 
	{
		var nRowIndex = pIndicies[i];
		this._makeRowClickable(this.m_oGridView.getRowElement(nRowIndex), nRowIndex);
	}
};

/**
 * @private
 * @param {Object} oRowElem
 * @param {Object} nRowIndex
 */
caplinx.figrids.decorator.OldTradeOnClickDecorator.prototype._makeRowClickable = function(oRowElem,nRowIndex)
{
	oRowElem.rowIndex = nRowIndex;
};

/**
 * @private
 */
caplinx.figrids.decorator.OldTradeOnClickDecorator.prototype._getLeftClickHandler = function() 
{
	var self = this;
	return function(oEvent)
	{
		oEvent = caplin.dom.event.Event.getNormalizedEvent(oEvent);
		if(oEvent.button === caplin.dom.event.Event.MouseButtons.LEFT)
		{
			self._openOldTradeTicket(oEvent);
		}
	};
};

/**
 * @private
 */
caplinx.figrids.decorator.OldTradeOnClickDecorator.prototype._openOldTradeTicket = function(oEvent) 
{
	var eRow = caplin.dom.Utility.getAncestorElementWithClass(oEvent.target, "row");
	if (eRow)
	{
		var nRowIndex = eRow.rowIndex;
		var mData = this.m_oGridRowModel.getRowData(nRowIndex);
		
		if(mData && mData["RequestID"])
		{
			var service = caplin.framework.ApplicationFactory.getInstance().getTradeService();
			var tradeInQuestion = service.getTradeByID(mData["RequestID"]);
			caplin.framework.ApplicationFactory.getInstance().openTradeTicketFromTrade(tradeInQuestion);
		}
	}
};