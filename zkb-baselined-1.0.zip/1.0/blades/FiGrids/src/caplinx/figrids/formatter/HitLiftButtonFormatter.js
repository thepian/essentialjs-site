/*
 * SNAPSHOT MATURITY DATE FORMATTER
 */

caplin.namespace("caplinx.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.core.Number");

/**
 * @class
 * 
 * @extends caplin.element.Formatter
 * @singleton
 */
caplinx.figrids.formatter.HitLiftButtonFormatter = function() {
};

caplin.implement(caplinx.figrids.formatter.HitLiftButtonFormatter, caplin.element.Formatter);

/**
 * 
 * @param {Variant} vValue  not used
 * @param {Map} mAttributes  not used
 * @return  the number expressed in months or years.
 * @type  String
 */
caplinx.figrids.formatter.HitLiftButtonFormatter.prototype.format = function(vValue, mAttributes)
{
	if(mAttributes["BuySell"]=== "Bid")
	{
		return "Hit";
	}
	else
	{
		return "Lift";
	}
};

caplinx.figrids.formatter.HitLiftButtonFormatter.prototype.toString = function() {
	return "caplinx.figrids.formatter.HitLiftButtonFormatter";
};

caplin.singleton("caplinx.figrids.formatter.HitLiftButtonFormatter");