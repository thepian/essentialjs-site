caplin.namespace("caplinx.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.element.formatter.DateFormatter");

caplinx.figrids.formatter.ActivesDateFormatter = function() {
};

caplin.implement(caplinx.figrids.formatter.ActivesDateFormatter, caplin.element.Formatter);

caplinx.figrids.formatter.ActivesDateFormatter.prototype.format = function(sValue, mAttributes) {
	mAttributes["viewFormat"] = mAttributes["ActiveGroup"] == "Bills" ? "m/d/Y" : "m/Y";
	return caplin.element.formatter.DateFormatter.format(sValue, mAttributes);
};

caplinx.figrids.formatter.ActivesDateFormatter.prototype.toString = function() {
	return "caplinx.figrids.formatter.ActivesDateFormatter";
};

caplin.singleton("caplinx.figrids.formatter.ActivesDateFormatter");
