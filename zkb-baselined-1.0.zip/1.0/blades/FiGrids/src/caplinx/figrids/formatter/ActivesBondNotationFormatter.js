caplin.namespace("caplinx.figrids.formatter");

caplin.include("caplin.element.Formatter", true);
caplin.include("caplin.element.formatter.BondNotationFormatter");
caplin.include("caplin.element.formatter.DecimalFormatter");

caplinx.figrids.formatter.ActivesBondNotationFormatter = function() {
};

caplin.implement(caplinx.figrids.formatter.ActivesBondNotationFormatter, caplin.element.Formatter);

caplinx.figrids.formatter.ActivesBondNotationFormatter.prototype.format = function(sValue, mAttributes) {
	if (sValue > 0) {
		if (mAttributes["QuoteType"] == "F") {
			sValue = caplin.element.formatter.BondNotationFormatter.format(sValue, mAttributes);
		} else {
			sValue = caplin.element.formatter.DecimalFormatter.format(sValue, mAttributes);
		}
	}
	return sValue;
};

caplinx.figrids.formatter.ActivesBondNotationFormatter.prototype.toString = function() {
	return "caplinx.figrids.formatter.ActivesBondNotationFormatter";
};

caplin.singleton("caplinx.figrids.formatter.ActivesBondNotationFormatter");
