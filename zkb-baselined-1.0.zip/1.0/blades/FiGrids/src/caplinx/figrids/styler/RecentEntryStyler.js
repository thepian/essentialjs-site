caplin.namespace("caplinx.figrids.styler");

caplin.include("caplin.element.Styler", true);

caplinx.figrids.styler.RecentEntryStyler = function()
{
	// 24 hours
	this.m_nRecentEntryDuration = (1000 * 60 * 60 * 24);
};
caplin.extend(caplinx.figrids.styler.RecentEntryStyler, caplin.element.Styler);

caplinx.figrids.styler.RecentEntryStyler.prototype.style = function(sValue, mAttributes, oControl)
{
	// portfolios updated within the last 24 hours are bolded
	if(mAttributes.lastModifiedTime > (new Date().getTime() - this.m_nRecentEntryDuration))
	{
		oControl.addClass("recentlyModifiedPortfolio");
	}
	else
	{
		oControl.removeClass("recentlyModifiedPortfolio");
	}
	
	return sValue;
};

caplinx.figrids.styler.RecentEntryStyler.prototype.toString = function()
{
	return "caplinx.portfolio.RecentEntryStyler";
};

caplin.singleton("caplinx.figrids.styler.RecentEntryStyler");
