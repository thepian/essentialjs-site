caplin.namespace("caplinx.figrids.styler");

caplin.include("caplin.element.Styler", true);

caplinx.figrids.styler.ActivesTooltipStyler = function() {
};

caplin.extend(caplinx.figrids.styler.ActivesTooltipStyler, caplin.element.Styler);

caplinx.figrids.styler.ActivesTooltipStyler.prototype.style = function(sValue, mAttributes, oControl) {
	oControl.setAttribute("tooltip", sValue);
	return sValue;
};

caplinx.figrids.styler.ActivesTooltipStyler.prototype.toString = function() {
	return "caplinx.figrids.styler.ActivesTooltipStyler";
};

caplin.singleton("caplinx.figrids.styler.ActivesTooltipStyler");
