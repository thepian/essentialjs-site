/**
 * @fileoverview
 */

caplin.namespace("caplinx.figrids.styler");

caplin.include("caplin.element.Styler", true);

/**
 * @class
 * 
 * Styles a price control to reflect its tradable and SL4B state status.  
 * <p/>
 * PriceStyler is typically used in the {@link caplin.element.Renderer} framework
 * <a href="/jsdoc/libraries/element/demo-url/styler/PriceStyler.html">within a downstream transform</a>.
 * 
 * @extends caplin.element.Styler
 */
caplinx.figrids.styler.PriceStyler = function() {
};

caplin.extend(caplinx.figrids.styler.PriceStyler, caplin.element.Styler);

/**
 * Styles a price control to reflect its tradable and SL4B state status.
 * 
 * @attribute tradableState  model field representing the tradable state (true or false)
 * @attribute recordStatus  model field representing the record status (SL4B object status)
 * @attribute tradableClass  CSS class to apply when the instrument is tradable but not stale
 * @attribute staleClass  CSS class to apply when the instrument is stale but not tradable
 * @attribute tradablestaleClass  CSS class to apply when the instrument is both tradable and stale
 * 
 * @param {String} sValue  field value
 * @param {Map} mAttributes  attributes defined above
 * @param {caplin.element.Control} oControl  The control to style
 */
caplinx.figrids.styler.PriceStyler.prototype.style = function(sValue, mAttributes, oControl) {
	// determine price state
	var bTradable = this.isTrue("tradableState", mAttributes);
	var bStale = (parseInt(mAttributes.recordStatus) == SL4B_ObjectStatus.STALE);
	// apply appropriate price class
	if (bTradable && bStale) {
		oControl.addClass(mAttributes["class-tradablestale"]);
		oControl.removeClass(mAttributes["class-tradable"]);
		oControl.removeClass(mAttributes["class-stale"]);
	} else if (bTradable) {
		oControl.addClass(mAttributes["class-tradable"]);
		oControl.removeClass(mAttributes["class-tradablestale"]);
		oControl.removeClass(mAttributes["class-stale"]);
	} else if (bStale) {
		oControl.addClass(mAttributes["class-stale"]);
		oControl.removeClass(mAttributes["class-tradablestale"]);
		oControl.removeClass(mAttributes["class-tradable"]);
	} else {
		oControl.removeClass(mAttributes["class-tradablestale"]);
		oControl.removeClass(mAttributes["class-stale"]);
		oControl.removeClass(mAttributes["class-tradable"]);
	}
};

/**
 * @private
 */
caplinx.figrids.styler.PriceStyler.prototype.toString = function() {
	return "caplinx.figrids.styler.PriceStyler";
};

caplin.singleton("caplinx.figrids.styler.PriceStyler");
