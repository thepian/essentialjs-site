caplin.namespace("caplinx.figrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
	this.m_mIdToContainer = {};
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.INDEX = 2;

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.getContainerToExpanded = function(mRowData, sRendererId)
{
	caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.INDEX++;
	if (!this.m_mIdToContainer[sRendererId]) {
		this.m_mIdToContainer[sRendererId] = '/TEST/CONTAINER/Items5Grow' + caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.INDEX + this.randomString(); 
	}
	return this.m_mIdToContainer[sRendererId];
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return oGridColumnModel.getRequiredFields();
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	if (mRecordUpdates && mRecordUpdates.InstrumentDescription && mRecordUpdates.InstrumentDescription.substring(0, 3)!="...") 
	{
		mRecordUpdates = caplin.core.MapUtility.clone(mRecordUpdates);
		mRecordUpdates.MagicInstrumentDescription = mRecordUpdates.InstrumentDescription;
		mRecordUpdates.InstrumentDescription = "";
	}
	return mRecordUpdates;
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfigDynamic.prototype.randomString = function()
{
	var pChars = 'ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');
    var nLength = 5;
    
    var sString = '';
    for (var i = 0; i < nLength; i++) {
        sString += pChars[Math.floor(Math.random() * pChars.length)];
    }
    return sString;
};
