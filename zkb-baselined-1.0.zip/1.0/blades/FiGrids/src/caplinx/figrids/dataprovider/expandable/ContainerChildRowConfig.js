caplin.namespace("caplinx.figrids.dataprovider.expandable");

caplin.include("caplin.core.MapUtility");

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfig = function(oExpandedRowDataProvider, oGridColumnModel, oExpandableRowGridDataProvider)
{
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getContainerToExpanded = function(mRowData, sRendererId)
{
	return '/CONTAINER/FX/Emerging';
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfig.prototype.getFieldsToRequest = function(oGridColumnModel)
{
	return oGridColumnModel.getRequiredFields();
};

caplinx.figrids.dataprovider.expandable.ContainerChildRowConfig.prototype.mapUpdateFieldsToCurrentGridFields = function(mRecordUpdates)
{
	if (mRecordUpdates.InstrumentDescription && mRecordUpdates.InstrumentDescription.substring(0, 3)!="...") 
	{
		mRecordUpdates = caplin.core.MapUtility.clone(mRecordUpdates);
		mRecordUpdates.MagicInstrumentDescription = mRecordUpdates.InstrumentDescription;
		mRecordUpdates.InstrumentDescription = "";
	}
	return mRecordUpdates;
};
