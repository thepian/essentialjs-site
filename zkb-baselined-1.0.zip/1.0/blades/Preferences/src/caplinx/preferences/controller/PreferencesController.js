caplin.namespace("caplinx.preferences.controller");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.form.presentation.BaseFormController", true);
caplin.include("caplinx.preferences.view.PreferencesPresentationModel");
caplin.include("caplin.form.presentation.Form");

caplinx.preferences.NUMBER_FORMAT_PREFERENCES = {
	",.": ct.i18n("blade.preferences.number.format.gb"),
	".,": ct.i18n("blade.preferences.number.format.eu")
};

caplinx.preferences.DATE_FORMAT_PREFERENCES = {
	"d M Y": ct.i18n("blade.preferences.date.format.eu"),
	"M d, Y": ct.i18n("blade.preferences.date.format.us")
};

caplinx.preferences.controller.PreferencesController = function() {
	this.m_oContainer = null;
	this.m_oPreferencesAdaptor = caplinx.preferences.util.PreferencesAdaptor.INSTANCE;
};

caplin.extend(caplinx.preferences.controller.PreferencesController, caplin.form.presentation.BaseFormController);

caplinx.preferences.controller.PreferencesController.prototype.setFormData = function(oFormData) {
	this.oPresentationModel = new caplinx.preferences.view.PreferencesPresentationModel(this.m_oPreferencesAdaptor);
	caplin.form.presentation.BaseFormController.call(this, oFormData, this.oPresentationModel);
};

caplinx.preferences.controller.PreferencesController.prototype.setContainer = function(oContainer){
	this.m_oContainer = oContainer;
};

caplinx.preferences.controller.PreferencesController.prototype.command = function(oView, sNamespace, sCommand) {
	if (sCommand == "save") {
		this.save();
	}
	else {
		this.m_oContainer.close();
	}
};

caplinx.preferences.controller.PreferencesController.prototype.save = function(m_oFormData) {
	
	var oPrefs = this.oPresentationModel.getFormData();
	
	// Set locale values via our adaptor
	this.m_oPreferencesAdaptor.save(oPrefs);	
	
	// Do any other logic around restarting/confirming, you name it.
	var mAlertOptions = this._getAlertOptions();
	var oAlertDispatcher = caplin.dom.AbstractFactory.getInstance().getAlertDispatcher();
	var sConfirmationMessage = ct.i18n("blade.preferences.save.confirmation");
	oAlertDispatcher.alert(sConfirmationMessage, mAlertOptions);
};

caplinx.preferences.controller.PreferencesController.prototype._getAlertOptions = function()
{
	var oPreferencesController = this;
	return {
		callback: function() { 
			oPreferencesController.m_oContainer.close();
		}
	};
};

caplinx.preferences.controller.PreferencesController.prototype.convertPrefsToCookieString = function(oPrefs){
	var out = oPrefs.locale + oPrefs.dateFormat + oPrefs.numberFormat;
};

