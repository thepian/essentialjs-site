caplin.namespace("caplinx.preferences.util");


/**
 * @fileoverview
 * Preferences Loading and Saving Interface.
 * 
 * @class
 * <p><code>Control</code>s are used to control how values are rendered onto the screen inside screen areas. An example of such a screen area is the
 * individual cells of a data grid which each have a controller.</p>
 * 
 * @constructor
 */
caplinx.preferences.util.PreferencesAdaptor = function() {
	//don't do that.
};

caplinx.preferences.util.PreferencesAdaptor.prototype.setPreferences = function(pPrefs){

};
	
caplinx.preferences.util.PreferencesAdaptor.prototype.getPreferences = function(){

};

caplinx.preferences.util.PreferencesAdaptor.prototype.save = function(){

};