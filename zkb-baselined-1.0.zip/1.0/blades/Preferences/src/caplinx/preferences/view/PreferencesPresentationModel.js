caplin.namespace("caplinx.preferences.view");

caplin.include("caplin.i18n.Translator", true);

caplinx.preferences.view.PreferencesPresentationModel = function(oPreferencesAdaptor) {
	/** @private */
	this.m_oForm = null;
	this.m_oPreferencesAdaptor = oPreferencesAdaptor;
	
};

caplinx.preferences.view.PreferencesPresentationModel.prototype.initialise = function(oForm) {
	this.m_oForm = oForm;
	var pProperties = oForm.autoGenerateProperties();
	var oPrefs = this.m_oPreferencesAdaptor.getPreferences();
	oForm.bindProperties(pProperties);

};

caplinx.preferences.view.PreferencesPresentationModel.prototype.setInitialValues = function() {
	var oPrefs = this.m_oPreferencesAdaptor.getPreferences();
	
	this.m_oForm.setValue("locale", caplin.i18n.getTranslator().getLocale());
	
	if (oPrefs["dateFormat"]) {
		this.m_oForm.setValue("dateFormat", oPrefs["dateFormat"]);
	}
	else {
		this.m_oForm.setValue("dateFormat", ct.i18n("ct.i18n.date.format"));
	}
	
	if (oPrefs["numberFormat"]) {
		this.m_oForm.setValue("numberFormat", oPrefs["numberFormat"]);
	} else {
		this.m_oForm.setValue("numberFormat", ct.i18n("ct.i18n.number.grouping.separator") + ct.i18n("ct.i18n.decimal.radix.character"));
	}
};

caplinx.preferences.view.PreferencesPresentationModel.prototype.initialiseExternalComponents = function(oForm)
{
	// Nothing to do
};

caplinx.preferences.view.PreferencesPresentationModel.prototype.getLocales = function() {
	
	var pLocales = caplin.core.ApplicationProperties.getProperty("CAPLIN.LOCALE.LIST").split(",");
	
	var mLocaleMap = {};
	
	for (var i=0; i<pLocales.length; i++) {
		mLocaleMap[pLocales[i]] = ct.i18n("ct.i18n.language.name." + pLocales[i]);
	}
	return mLocaleMap;	
};

caplinx.preferences.view.PreferencesPresentationModel.prototype.getDateFormats = function() {
	return caplinx.preferences.DATE_FORMAT_PREFERENCES;
};

caplinx.preferences.view.PreferencesPresentationModel.prototype.getNumberFormats = function() {
	return caplinx.preferences.NUMBER_FORMAT_PREFERENCES;
};

caplinx.preferences.view.PreferencesPresentationModel.prototype.getFormData = function() {
	var ret = {
		locale: this.m_oForm.getValue("locale"),
		dateFormat: this.m_oForm.getValue("dateFormat"),
		numberFormat: this.m_oForm.getValue("numberFormat")
	};
	return ret;
};
