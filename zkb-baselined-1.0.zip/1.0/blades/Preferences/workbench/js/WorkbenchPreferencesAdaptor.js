caplin.namespace("caplinx.preferences.util");


/**
 * Mock adaptor for loading and saving prefs. 
 */
caplinx.preferences.util.WorkbenchPreferencesAdaptor = function() {
};

caplinx.preferences.util.WorkbenchPreferencesAdaptor.prototype.setPreferences = function(pPrefs){
	console.log("prefs set: ", pPrefs);
};
	
caplinx.preferences.util.WorkbenchPreferencesAdaptor.prototype.getPreferences = function(){
	return {locale: "en_US"};
};

caplinx.preferences.util.WorkbenchPreferencesAdaptor.prototype.save = function(pPrefs){
	console.log("prefs save: ", pPrefs);
};