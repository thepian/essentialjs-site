caplin.namespace("workbench.preferences");

caplin.include("caplin.dom.AbstractFactory");

workbench.preferences.WorkbenchFactory = function () {
	
}

caplin.implement(workbench.preferences.WorkbenchFactory, caplin.dom.AbstractFactory);

workbench.preferences.WorkbenchFactory.prototype.getAlertDispatcher = function(){
	return {
		alert : function(sMessage, mOptions) {
			window.alert(sMessage);
		}
	};
};

caplin.dom.AbstractFactory.setInstance(new workbench.preferences.WorkbenchFactory());