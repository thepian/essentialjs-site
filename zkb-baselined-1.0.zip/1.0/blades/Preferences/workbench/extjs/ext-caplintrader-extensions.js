// ExtJS 2.2 //

/* Allows form library to specify the tag used for the wrapper element.
 * Essential to styling of forms 
 */
Ext.override(Ext.form.TriggerField, {
    // private
    onRender : function(ct, position){
        this.doc = Ext.isIE ? Ext.getBody() : Ext.getDoc();
        Ext.form.TriggerField.superclass.onRender.call(this, ct, position);

        this.wrap = this.el.wrap(this.wrapTag? 
			{ tag: this.wrapTag, cls: "x-form-field-wrap x-form-field-trigger-wrap"}
			: {cls: "x-form-field-wrap x-form-field-trigger-wrap"});
        this.trigger = this.wrap.createChild(this.triggerConfig ||
                {tag: "img", src: Ext.BLANK_IMAGE_URL, cls: "x-form-trigger " + this.triggerClass});
        this.initTrigger();
        if(!this.width && !this.autoWidth){
            this.wrap.setWidth(this.el.getWidth()+this.trigger.getWidth());
        }
        this.resizeEl = this.positionEl = this.wrap;
    }
});

Ext.override(Ext.form.ComboBox, {
	
	
    initList : function(){
        if(!this.list){
            var cls = 'x-combo-list';

            this.list = new Ext.Layer({
                parentEl: document.body, //this.getListParent(),
                shadow: this.shadow,
                cls: [cls, this.listClass].join(' '),
                constrain:false
            });
			
            this.innerList = this.list.createChild({cls:cls+'-inner'});
            this.mon(this.innerList, 'mouseover', this.onViewOver, this);
            this.mon(this.innerList, 'mousemove', this.onViewMove, this);

            if(this.pageSize){
                this.footer = this.list.createChild({cls:cls+'-ft'});
                this.pageTb = new Ext.PagingToolbar({
                    store: this.store,
                    pageSize: this.pageSize,
                    renderTo:this.footer
                });
                this.assetHeight += this.footer.getHeight();
            }

            if(!this.tpl){
                this.tpl = '<tpl for="."><div class="'+cls+'-item">{' + this.displayField + '}</div></tpl>';
            }
            this.view = new Ext.DataView({
                applyTo: this.innerList,
                tpl: this.tpl,
                singleSelect: true,
                selectedClass: this.selectedClass,
                itemSelector: this.itemSelector || '.' + cls + '-item',
                emptyText: this.listEmptyText
            });

            this.mon(this.view, 'click', this.onViewClick, this);

            //Only after the store is loaded will we know the real width of items in the drop down list
            this.bindStore(this.store, true);
            
            var lw;
            if(this.listWidth === 'auto'){
                var rect = 0;
                if(Ext.isIE){
                    //list-auto-width-IE class contains one line --> display:inline;
               //This will allow us to get the actual width of innerList div
                    this.innerList.addClass('list-auto-width-IE');
                    rect = this.list.getBox();  
               //Remove this class once we got the width
                    this.innerList.removeClass('list-auto-width-IE');
                }
                else{
                    rect = this.list.getBox(); 
                }
                lw = Math.max(this.wrap.getWidth(), rect.width);
				lw += 4; // 4 extra pixels overhang
                this.list.setSize(lw, 0);
            }
            else {
                lw = this.listWidth || Math.max(this.wrap.getWidth() + 4, this.minListWidth);  // 4 extra pixels overhang
                this.list.setSize(lw, 0);
            }
            this.list.swallowEvent('mousewheel');
            this.assetHeight = 0;
            if(this.syncFont !== false){
                this.list.setStyle('font-size', this.el.getStyle('font-size'));
            }
            if(this.title){
                this.header = this.list.createChild({cls:cls+'-hd', html: this.title});
                this.assetHeight += this.header.getHeight();
            }
            this.innerList.setWidth(lw - this.list.getFrameWidth('lr'));

            if(this.resizable){
                this.resizer = new Ext.Resizable(this.list,  {
                   pinned:true, handles:'se'
                });
                this.mon(this.resizer, 'resize', function(r, w, h){
                    this.maxHeight = h-this.handleHeight-this.list.getFrameWidth('tb')-this.assetHeight;
                    this.listWidth = w;
                    this.innerList.setWidth(w - this.list.getFrameWidth('lr'));
                    this.restrictHeight();
                }, this);

                this[this.pageSize?'footer':'innerList'].setStyle('margin-bottom', this.handleHeight+'px');
            }
        }
    }

});

// ---- TreeCheckbox ---- //

Ext.override(Ext.tree.TreeNodeUI, {
	grayedValue:null,
	onDisableChange :function(node, state){
		this.disabled = state;
		this[state ? 'addClass' :'removeClass']("x-tree-node-disabled");
	},
	initEvents :function(){
		this.node.on("move", this.onMove, this);
		if(this.node.disabled){
			this.disabled = true;
			this.addClass("x-tree-node-disabled");
		}
		if(this.node.hidden){
			this.hide();
		}
		var ot = this.node.getOwnerTree();
		var dd = ot.enableDD || ot.enableDrag || ot.enableDrop;
		if(dd && (!this.node.isRoot || ot.rootVisible)){
			Ext.dd.Registry.register(this.elNode, {
				node:this.node,
				handles:this.getDDHandles(),
				isHandle:false
			});
		}
	},
    onDblClick :function(e){
        e.preventDefault();
        if(this.disabled){
            return;
        }
        if(!this.animating && this.node.isExpandable()){
            this.node.toggle();
        }
        this.fireEvent("dblclick", this.node, e);
    },
	onCheckChange :function(){
		var checked = this.isChecked();
		this.node.attributes.checked = checked;
		this.fireEvent('checkchange', this.node, checked);
	},
	toggleCheck :function(checked){
		var cb = this.checkbox;
		if(!cb){
			return false;
		}
		var bIsChecked = this.isChecked();
		if (bIsChecked === checked) {
			return;
		}

		if(checked === undefined){
			checked = bIsChecked === false;
		}
		if(checked === true){
			Ext.fly(cb).replaceClass('x-tree-node-grayed', 'x-tree-node-checked');
		} else if(checked !== false){
			Ext.fly(cb).replaceClass('x-tree-node-checked', 'x-tree-node-grayed');
		} else {
			Ext.fly(cb).removeClass(['x-tree-node-checked', 'x-tree-node-grayed']);
		}
		this.onCheckChange();
		return checked;
	},
	onCheckboxClick:function() {
		if(!this.disabled){
			this.toggleCheck();
		}
	},
	onCheckboxOver:function() {
		this.addClass('x-tree-checkbox-over');
	},
	onCheckboxOut:function() {
		this.removeClass(['x-tree-checkbox-over', 'x-tree-checkbox-down']);
	},
	onCheckboxDown:function() {
		this.addClass('x-tree-checkbox-down');
	},
	onCheckboxUp:function() {
		this.removeClass('x-tree-checkbox-down');
	},
	renderElements :function(n, a, targetNode, bulkRender){
		this.indentMarkup = n.parentNode ? n.parentNode.ui.getChildIndent() :'';
		var cb = a.checked !== undefined;
		var href = a.href ? a.href :Ext.isGecko ? "" :"#";
        var buf = ['<li class="x-tree-node"><div ext:tree-node-id="',n.id,'" class="x-tree-node-el x-tree-node-leaf x-unselectable ', a.cls,'" unselectable="on">',
            '<span class="x-tree-node-indent">',this.indentMarkup,"</span>",
            '<img src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />',
            '<img src="', a.icon || this.emptyIcon, '" class="x-tree-node-icon',(a.icon ? " x-tree-node-inline-icon" :""),(a.iconCls ? " "+a.iconCls :""),'" unselectable="on" />',
			cb ? ('<img src="'+this.emptyIcon+'" class="x-tree-checkbox'+(a.checked === true ? ' x-tree-node-checked' :(a.checked !== false ? ' x-tree-node-grayed' :''))+'" />') :'',
            '<a hidefocus="on" class="x-tree-node-anchor" href="',href,'" tabIndex="1" ',
             a.hrefTarget ? ' target="'+a.hrefTarget+'"' :"", '><span unselectable="on">',n.text,"</span></a></div>",
            '<ul class="x-tree-node-ct" style="display:none;"></ul>',
            "</li>"].join('');
		var nel;
		if(bulkRender !== true && n.nextSibling && (nel = n.nextSibling.ui.getEl())){
			this.wrap = Ext.DomHelper.insertHtml("beforeBegin", nel, buf);
		}else{
			this.wrap = Ext.DomHelper.insertHtml("beforeEnd", targetNode, buf);
		}
		this.elNode = this.wrap.childNodes[0];
		this.ctNode = this.wrap.childNodes[1];
		var cs = this.elNode.childNodes;
		this.indentNode = cs[0];
		this.ecNode = cs[1];
		this.iconNode = cs[2];
		var index = 3;
		if(cb){
			this.checkbox = cs[3];
			index++;
		}
		this.anchor = cs[index];
		this.textNode = cs[index].firstChild;
	},
	isChecked :function(){
		return this.checkbox
			? (Ext.fly(this.checkbox).hasClass('x-tree-node-checked')
				? true
				:Ext.fly(this.checkbox).hasClass('x-tree-node-grayed')
					? this.grayedValue
					:false)
			:false;
	}
});
Ext.override(Ext.tree.TreeEventModel, {
    initEvents :function(){
        var el = this.tree.getTreeEl();
        el.on('click', this.delegateClick, this);
        if(this.tree.trackMouseOver !== false){
            el.on('mouseover', this.delegateOver, this);
            el.on('mouseout', this.delegateOut, this);
        }
        el.on('mousedown', this.delegateDown, this);
        el.on('mouseup', this.delegateUp, this);
        el.on('dblclick', this.delegateDblClick, this);
        el.on('contextmenu', this.delegateContextMenu, this);
    },
    delegateOver :function(e, t){
        if(!this.beforeEvent(e)){
            return;
        }
        if(this.lastEcOver){
            this.onIconOut(e, this.lastEcOver);
            delete this.lastEcOver;
        }
        if(this.lastCbOver){
            this.onCheckboxOut(e, this.lastCbOver);
            delete this.lastCbOver;
        }
        if(e.getTarget('.x-tree-ec-icon', 1)){
            this.lastEcOver = this.getNode(e);
            this.onIconOver(e, this.lastEcOver);
        }
        else if(e.getTarget('.x-tree-checkbox', 1)){
            this.lastCbOver = this.getNode(e);
            this.onCheckboxOver(e, this.lastCbOver);
        }
        if(t = this.getNodeTarget(e)){
            this.onNodeOver(e, this.getNode(e));
        }
    },
    delegateOut :function(e, t){
        if(!this.beforeEvent(e)){
            return;
        }
        if(e.getTarget('.x-tree-ec-icon', 1)){
            var n = this.getNode(e);
            this.onIconOut(e, n);
            if(n == this.lastEcOver){
                delete this.lastEcOver;
            }
        }
        else if(e.getTarget('.x-tree-checkbox', 1)){
            var n = this.getNode(e);
            this.onCheckboxOut(e, n);
            if(n == this.lastCbOver){
                delete this.lastCbOver;
            }
        }
        if((t = this.getNodeTarget(e)) && !e.within(t, true)){
            this.onNodeOut(e, this.getNode(e));
        }
    },
    delegateDown :function(e, t){
        if(!this.beforeEvent(e)){
            return;
        }
        if(e.getTarget('.x-tree-checkbox', 1)){
            this.onCheckboxDown(e, this.getNode(e));
        }
    },
    delegateUp :function(e, t){
        if(!this.beforeEvent(e)){
            return;
        }
        if(e.getTarget('.x-tree-checkbox', 1)){
            this.onCheckboxUp(e, this.getNode(e));
        }
    },
    delegateOut :function(e, t){
        if(!this.beforeEvent(e)){
            return;
        }
        if(e.getTarget('.x-tree-ec-icon', 1)){
            var n = this.getNode(e);
            this.onIconOut(e, n);
            if(n == this.lastEcOver){
                delete this.lastEcOver;
            }
        }
        else if(e.getTarget('.x-tree-checkbox', 1)){
            var n = this.getNode(e);
            this.onCheckboxOut(e, n);
            if(n == this.lastCbOver){
                delete this.lastCbOver;
            }
        }
        if((t = this.getNodeTarget(e)) && !e.within(t, true)){
            this.onNodeOut(e, this.getNode(e));
        }
    },
	delegateClick :function(e, t){
		if(!this.beforeEvent(e)){
			return;
		}
		if(e.getTarget('.x-tree-checkbox', 1)){
			this.onCheckboxClick(e, this.getNode(e));
		}
		else if(e.getTarget('.x-tree-ec-icon', 1)){
			this.onIconClick(e, this.getNode(e));
		}
		else if(this.getNodeTarget(e)){
			this.onNodeClick(e, this.getNode(e));
		}
	},
	onCheckboxClick :function(e, node){
		node.ui.onCheckboxClick();
	},
	onCheckboxOver :function(e, node){
		node.ui.onCheckboxOver();
	},
	onCheckboxOut :function(e, node){
		node.ui.onCheckboxOut();
	},
	onCheckboxDown :function(e, node){
		node.ui.onCheckboxDown();
	},
	onCheckboxUp :function(e, node){
		node.ui.onCheckboxUp();
	}
});


// ---- TriStateNodeUI ---- //

Ext.tree.TriStateNodeUI = Ext.extend(Ext.tree.TreeNodeUI, {
	onCheckChange :function(){
		Ext.tree.TriStateNodeUI.superclass.onCheckChange.apply(this, arguments);
		var oNode = this.node;
		if (oNode.childrenRendered === false &&
			oNode.isExpandable()) {
			oNode.expand();
			oNode.collapse();
		}
		var p;
		if((p = oNode.parentNode) && p.getUI().updateParent && !p.getUI().isUpdating) {
			p.getUI().updateParent();
		}
	},
	toggleCheck :function(){
		var checked = Ext.tree.TriStateNodeUI.superclass.toggleCheck.apply(this, arguments);
		this.updateChild(checked);
		return checked;
	},
	renderElements :function(n, a, targetNode, bulkRender){
		Ext.tree.TriStateNodeUI.superclass.renderElements.apply(this, arguments);
		this.updateChild(this.node.attributes.checked);
	},
	updateParent :function(){
		var checked;
		this.node.eachChild(function(n){
			if(checked === undefined){
				checked = n.attributes.checked;
			}else if (checked !== n.attributes.checked) {
				checked = this.grayedValue;
				return false;
			}
		}, this);
		this.toggleCheck(checked);
	},
	updateChild:function(checked){
		if(typeof checked == 'boolean'){
			this.isUpdating = true;
			this.node.eachChild(function(n){
				n.getUI().toggleCheck(checked);
			}, this);
			delete this.isUpdating;
		}
	}
});

// moved from ext-tree.build.js
Ext.dd.DragDropMgr.handleMouseDown = function(e, oDD) {
	if (Ext.QuickTips) {
		Ext.QuickTips.disable();
	}
	if (this.dragCurrent) {
		// the original browser mouseup wasn't handled (e.g. outside FF browser window)
		// so clean up first to avoid breaking the next drag
		this.handleMouseUp(e);
	}
	
	this.currentTarget = e.getTarget();
	this.dragCurrent = oDD;
	
	var el = oDD.getEl();
	
	// track start position
	this.startX = e.getPageX();
	this.startY = e.getPageY();
	
	this.deltaX = this.startX - el.offsetLeft;
	this.deltaY = this.startY - el.offsetTop;
	
	this.dragThreshMet = false;
};


// ################################### New fireEvents method #########################################

Ext.dd.DragDropMgr.fireEvents = function(e, isDrop) 
{
	var dc = this.dragCurrent;	
	if (!dc || dc.isLocked()) 
	{
	    return;
	}
	
	var pt = e.getPoint();
	
	var outEvts   = [];
	var overEvts  = [];
	var dropEvts  = [];
	var enterEvts = [];
		
	this.enqueueEvents(e, dc, pt, isDrop, outEvts, overEvts, dropEvts, enterEvts);
	
    if (this.mode) 
    {
        if (outEvts.length)
        {
            dc.b4DragOut(e, outEvts);
            dc.onDragOut(e, outEvts);
        }

        if (enterEvts.length)
        {
            dc.onDragEnter(e, enterEvts);
        }

        if (overEvts.length) 
        {
            dc.b4DragOver(e, overEvts);
            dc.onDragOver(e, overEvts);
        }

        if (dropEvts.length) 
        {
            dc.b4DragDrop(e, dropEvts);
            dc.onDragDrop(e, dropEvts);
        }

    } 
    else
    {        
        var len = 0;
        for (i=0, len=outEvts.length; i<len; ++i) 
        {
            dc.b4DragOut(e, outEvts[i].id);
            dc.onDragOut(e, outEvts[i].id);
        }        
        for (i=0,len=enterEvts.length; i<len; ++i) 
        {            
            dc.onDragEnter(e, enterEvts[i].id);
        }        
        for (i=0,len=overEvts.length; i<len; ++i) 
        {
            dc.b4DragOver(e, overEvts[i].id);
            dc.onDragOver(e, overEvts[i].id);
        }        
        for (i=0, len=dropEvts.length; i<len; ++i) 
        {
            dc.b4DragDrop(e, dropEvts[i].id);
            dc.onDragDrop(e, dropEvts[i].id);
        }
    }
    
    if (isDrop && !dropEvts.length) 
    {
        dc.onInvalidDrop(e);
    }
	
};

Ext.dd.DragDropMgr.enqueueEvents = function(e, dc, pt, isDrop, outEvts, overEvts, dropEvts, enterEvts) 
{
	var eTopMostTarget = this.getDropTarget(e, dc);
	if (eTopMostTarget !== this.ePreviousTopMostTarget)
	{
		this.addOutEventForPreviousTopMostTarget(outEvts);
		this.addEventForTopMostTarget(eTopMostTarget, (isDrop ? dropEvts : enterEvts));
	}
	else
	{
		this.addEventForTopMostTarget(eTopMostTarget, (isDrop ? dropEvts : overEvts));
	}
	this.setPreviousTopMostTarget(eTopMostTarget, isDrop);
};


Ext.dd.DragDropMgr.getDropTarget = function(oEvent, dc)
{
	var mIds = this.getDropTargetIdsOfCorrectType(dc);
	var ePotentialDropTarget = (oEvent.target)?oEvent.target:oEvent.srcElement;
	while (ePotentialDropTarget)
	{
		if (this.isDropTargetElement(mIds, ePotentialDropTarget))
		{			
			return ePotentialDropTarget;
		}		
		ePotentialDropTarget = ePotentialDropTarget.parentNode;
	}
	return null;
};

Ext.dd.DragDropMgr.isDropTargetElement = function(mIds, ePotentialDropTarget)
{
	return (mIds[ePotentialDropTarget.id] !== undefined);
};

Ext.dd.DragDropMgr.getDropTargetIdsOfCorrectType = function(dc)
{
	var mIds = {};
	var sGroup = dc.ddGroup;
	if (this.ids[sGroup] !== undefined)
	{				
	    for (i in this.ids[sGroup]) 
	    {	    	
	        var oDD = this.ids[sGroup][i];
	        if (oDD.isTarget && !oDD.isLocked() && oDD != dc) 
	        {
	            mIds[i] = oDD;
			}
		}
	}		
	return mIds;
};

Ext.dd.DragDropMgr.addEventForTopMostTarget = function(eTopMostTarget, evtArray)
{
	if (eTopMostTarget !== null)
	{
		evtArray.push(eTopMostTarget);
	}
};

Ext.dd.DragDropMgr.addOutEventForPreviousTopMostTarget = function(outEvts)
{
	if (this.ePreviousTopMostTarget !== undefined && this.ePreviousTopMostTarget !== null)
	{
		outEvts.push(this.ePreviousTopMostTarget);
	}
};

Ext.dd.DragDropMgr.setPreviousTopMostTarget = function(eTopMostTarget, isDrop)
{
	this.ePreviousTopMostTarget = (isDrop ? null : eTopMostTarget);
};

Ext.Notify = function() {
	
    var messageContainer;

    function createBox(title, body) {
        return ['<div class="chart-notification">',
                	'<div class="message-top">',
						'<div class="message-top-left"></div>',
						'<div class="message-top-center"></div>',
						'<div class="message-top-right">',
					'</div>',
					'<div class="message-middle">',
						'<div class="message-middle-left"></div>',
						'<div class="message-middle-center">',
							'<div class="message-title">', title, '</div>',
							'<div class="message-body">', body, '</div>',
						'</div>',
						'<div class="message-middle-right"></div>',
					'</div>',
					'<div class="message-bottom">',
						'<div class="message-bottom-left"></div>',
						'<div class="message-bottom-center"></div>',
						'<div class="message-bottom-right"></div>',
					'</div>',
				'</div>'].join('');
    }
	
    return {
        message : function (title, format, options) {
			options = options || {};
			var pauseFor = options.delay || 5;
			var attachTo = options.attachTo || document.body;
			
            if (!messageContainer) {
                messageContainer = Ext.DomHelper.insertFirst(attachTo, {id:'msg-div'}, true);
            }

            var s = String.format.apply(String, Array.prototype.slice.call(arguments, 1));
            var m = Ext.DomHelper.append(messageContainer, {html:createBox(title, s)}, true);
			m.applyStyles({zIndex: 2000, position: 'relative'});
            m.slideIn('t').pause(pauseFor).ghost("t", {remove:true});
        }
    };

}();

