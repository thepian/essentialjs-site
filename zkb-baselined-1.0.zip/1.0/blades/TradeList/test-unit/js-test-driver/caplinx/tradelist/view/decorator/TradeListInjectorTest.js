TradeListInjectorTest = TestCase("TradeListInjectorTest");

caplin.include("caplin.event.Registry");
caplin.include("caplin.event.Hub");

TradeListInjectorTest.prototype.setUp = function()
{
	var sTestSubject = "test.subject";
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	this.m_mockGridModel = mock(caplin.grid.GridRowModel);	
	this.m_oHub = new caplin.event.Hub(caplin.event.registry);
	this.m_mockGridView = mock(caplin.grid.GridView);
	this.m_oTradeListInjector = this._setUpTradeListInjector(sTestSubject);
};

TradeListInjectorTest.prototype.tearDown = function(){
	this.m_oTradeListInjector = null;
	this.m_mConfig = null;
	this.m_oHub = null;
	this.m_mockGridView = null;
	this.m_mockGridModel = null;
	
	Mock4JS.verifyAllMocks();
};

TradeListInjectorTest.prototype.testItPublishesReadyEventWithGridModelOnHtmlRendered = function(){
	//given
	var oGridModel = null;
	this.m_oHub.subscribe("ui.tradelist.ready", function(sSubject, oValue) {
		oGridModel = oValue;
	}, this);
	var oRowModel = new Object();
	var oColumnModel = new Object();
	
	//expectations
	this.m_mockGridView.expects(once()).getGridRowModel().will(returnValue(oRowModel));
	this.m_mockGridView.expects(once()).getGridColumnModel().will(returnValue(oColumnModel));
	
	//when
	this.m_oTradeListInjector.onContainerHtmlRendered();
	
	//then
	assertEquals(oGridModel.getRowModel(), oRowModel);
	assertEquals(oGridModel.getColumnModel(), oColumnModel);
};

TradeListInjectorTest.prototype.testItSendsInstrumentSubjectsToGridViewOnReceive = function(){
	//given
	var sSubject = "test.grid.publish";
	var oTradeListInjector = this._setUpTradeListInjector(sSubject);	
	
	var sInstrumentSubjectOne = "subject one";
	var sInstrumentSubjectTwo = "subject two";
	var pInstrumentSubjects = [sInstrumentSubjectOne, sInstrumentSubjectTwo];
	
	//expects
	this.m_mockGridView.expects(once()).receiveObjects(pInstrumentSubjects);
	
	//when
	this.m_oHub.publish(sSubject, pInstrumentSubjects);
};

TradeListInjectorTest.prototype.testItDisplaysNoRowsFoundMessageWhenEmptyListIsLaunched = function() {
	//given
	var sSubject = "test.grid.publish";
	var oTradeListInjector = this._setUpTradeListInjector(sSubject);
	var pInstrumentSubjects = [];
	
	//expectations
	this.m_mockGridView.expects(once()).receiveObjects(pInstrumentSubjects);

	//when
	this.m_oHub.publish(sSubject, pInstrumentSubjects);
	
	//assert
	assertEquals("1", "none", eInProgressBubble.style.display);
	assertEquals("2", "block", eNoRowsBubble.style.display);
	assertEquals("3","none", eDefaultBubble.style.display);
};


TradeListInjectorTest.prototype.testItDisplaysLoadingInProgressMessageOnReceivingSubjects = function() {
	//given
	var sSubject = "test.grid.publish";
	var oTradeListInjector = this._setUpTradeListInjector(sSubject);
	
	var sInstrumentSubjectOne = "subject one";
	var sInstrumentSubjectTwo = "subject two";
	var pInstrumentSubjects = [sInstrumentSubjectOne, sInstrumentSubjectTwo];
	
	//expectations
	this.m_mockGridView.expects(once()).receiveObjects(pInstrumentSubjects);

	//when
	this.m_oHub.publish(sSubject, pInstrumentSubjects);
	
	//assert
	assertEquals("1", "block", eInProgressBubble.style.display);
	assertEquals("2", "none", eNoRowsBubble.style.display);
	assertEquals("3", "none", eDefaultBubble.style.display);
};

TradeListInjectorTest.prototype.testItDisplaysNoRowDataMessageIfSizeChangesToZero = function() {
	//given
	this.m_oTradeListInjector.onAllDataReceived();
	
	//when
	this.m_oTradeListInjector.onSizeChanged(0, 0);
	
	//assert
	assertEquals("1", "none", eInProgressBubble.style.display);
	assertEquals("2", "block", eNoRowsBubble.style.display);
	assertEquals("3", "none", eDefaultBubble.style.display);
};

TradeListInjectorTest.prototype.testItDisplaysInProgressMessageIfSizeIsZeroButListIsNotReady = function() {
	//given
	var sSubject = "test.grid.publish";
	var oTradeListInjector = this._setUpTradeListInjector(sSubject);
	
	var sInstrumentSubjectOne = "subject one";
	var sInstrumentSubjectTwo = "subject two";
	var pInstrumentSubjects = [sInstrumentSubjectOne, sInstrumentSubjectTwo];

	this.m_mockGridView.stubs().receiveObjects(pInstrumentSubjects);

	this.m_oHub.publish(sSubject, pInstrumentSubjects);
	
	//when
	oTradeListInjector.onSizeChanged(0, 0);
	
	//assert
	assertEquals("1", "block", eInProgressBubble.style.display);
	assertEquals("2", "none", eNoRowsBubble.style.display);
	assertEquals("3", "none", eDefaultBubble.style.display);
};

TradeListInjectorTest.prototype.testItDisplaysDefaultMessageIfNoDataFound= function() {
	
	//when
	this.m_oTradeListInjector.onRowDataUnavailable("[some reason]");
	
	//then
	assertEquals("1", "none", eInProgressBubble.style.display);
	assertEquals("2", "none", eNoRowsBubble.style.display);
	assertEquals("3", "block", eDefaultBubble.style.display);
};

TradeListInjectorTest.prototype.testItCreatesDecoratorWithConfiguredMessage = function() {
	//given
	var mConfig = {
			defaultHeaderText:"FI Trade List", 
			defaultBodyText:"No data available",
			inProgressHeaderText:"FI Trade List",
			inProgressBodyText:"Loading instruments from Watchlist",
			noRowsFoundHeaderText:"FI Trade List",
			noRowsFoundBodyText:"Drag and drop FI instruments here to populate your FI Trade List",
			classname:"noDataBubble"
	};
	var oTradeListInjector = new caplinx.tradelist.view.decorator.TradeListInjector(mConfig);
	
	//assert
	assertTrue("1", eDefaultBubble.innerHTML.indexOf("FI Trade List") !== -1);
	assertTrue("2", eDefaultBubble.innerHTML.indexOf("No data available") !== -1);	
	assertTrue("3", eNoRowsBubble.innerHTML.indexOf("FI Trade List") !== -1);
	assertTrue("4", eNoRowsBubble.innerHTML.indexOf("Drag and drop FI instruments here to populate your FI Trade List") !== -1);	
	assertTrue("5", eInProgressBubble.innerHTML.indexOf("FI Trade List") !== -1);
	assertTrue("6", eInProgressBubble.innerHTML.indexOf("Loading instruments from Watchlist") !== -1);	
};


TradeListInjectorTest.prototype._setUpTradeListInjector = function(sSubject){
	var eGridBody = this._setUpGridBody();
	var mConfig = this._setUpConfigData(sSubject);
	var oTradeListInjector = new caplinx.tradelist.view.decorator.TradeListInjector(mConfig);
	
	//mock
	this.m_mockGridModel.stubs().addRowModelListener(oTradeListInjector);
	this.m_mockGridView.stubs().getGridRowModel().will(returnValue(this.m_mockGridModel.proxy()));
	this.m_mockGridView.stubs().addGridViewListener(oTradeListInjector);
	this.m_mockGridView.stubs().getElement().will(returnValue(eGridBody));
	
	oTradeListInjector.setGridView(this.m_mockGridView.proxy());
	return oTradeListInjector;
};

TradeListInjectorTest.prototype._setUpConfigData = function(sTestSubject){
	var mConfig = { 
			defaultHeaderText :"FI Trade List", 
			defaultBodyText:"No data available",
			inProgressHeaderText:"FI Trade List",
			inProgressBodyText:"Loading instruments from Watchlist",
			noRowsFoundHeaderText:"FI Trade List",
			noRowsFoundBodyText:"Drag and drop FI instruments here to populate your FI Trade List",
			classname:"noDataBubble",
			subject : sTestSubject
			};
	return mConfig;
};

TradeListInjectorTest.prototype._setUpGridBody = function(){
	var eGridBody = {			
			appendChild : function(eNode) {
				eInProgressBubble = eNode.children[0];
				eNoRowsBubble = eNode.children[1];
				eDefaultBubble = eNode.children[2];
			}
		};
	return eGridBody;
};

