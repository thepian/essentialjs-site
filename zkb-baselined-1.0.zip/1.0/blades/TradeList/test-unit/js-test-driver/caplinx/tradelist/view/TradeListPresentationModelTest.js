TradeListPresentationModelTest = TestCase("TradeListPresentationModelTest");

caplin.include("caplin.event.Registry");
caplin.include("caplin.event.Hub");

TradeListPresentationModelTest.prototype.setUp = function() {
	Mock4JS.clearMocksToVerify();
	this.m_oHub = new caplin.event.Hub(caplin.event.registry);
	
	this.m_mockSubmitTradeListCommand = mock(caplinx.tradelist.view.command.SubmitTradeListCommand);
	this.m_mockToggleTradeCommand = mock(caplinx.tradelist.view.command.ToggleTradeCommand);
	var mCommandFactory = {};
	mCommandFactory[caplinx.tradelist.TradeListConstants.SUBMIT_TRADELIST] = this.m_mockSubmitTradeListCommand.proxy();
	mCommandFactory[caplinx.tradelist.TradeListConstants.TOGGLE_TRADETYPE] = this.m_mockToggleTradeCommand.proxy();
	
	this.m_oPresentationModel = new caplinx.tradelist.view.TradeListPresentationModel(this.m_oHub, mCommandFactory);
	
	this.m_oGridColumnModel = new Object();
	this.m_mockGridRowModel = mock(caplin.grid.GridRowModel);
	this.m_oGridSnapshot = new caplinx.tradelist.view.model.GridSnapshot(this.m_mockGridRowModel.proxy(),this.m_oGridColumnModel);

	this.m_oPresentationModel.m_oGridSnapshot = this.m_oGridSnapshot;
	
	this.m_mockForm = mock(caplinx.form.Form);
	this.m_oPresentationModel.m_oForm = this.m_mockForm.proxy();
	this.m_mockBusinessDateProvider = mock(caplin.services.date.BusinessDateProvider);
	
	this._setupTestApplicationFactory();
	
	/* commented for EXT
	 * this.m_oDummyFiAccountStore = new Ext.data.SimpleStore({
		"fields": ["value", "label"],
		"data" : [
			["GOLD", "GOLD_ACCOUNT"],
			["BRONZE", "BRONZE_ACCOUNT"]
		]
	});*/

};

TradeListPresentationModelTest.prototype._setupTestApplicationFactory = function(){
	//Dummy test factory 
	oSelf = this;
	TestFactory = function() {};
	
	TestFactory.prototype.getFiAccounts = function() { 
	};
	
	TestFactory.prototype.getBusinessDateProvider = function() {
	};
	
	this.m_mockTestFactory = mock(TestFactory);
	caplin.framework.ApplicationFactory.INSTANCE = this.m_mockTestFactory.proxy();
};

TradeListPresentationModelTest.prototype.tearDown = function(){
	this.m_oHub.unsubscribe();
	this.m_oHub = null;
	this.m_oPresentationModel = null;
	
	Mock4JS.verifyAllMocks();
};

/* commented for EXT
 TradeListPresentationModelTest.prototype.testItSetsFormAndItsPropertiesOnInitialise = function() {
	//expectations
	this.m_mockForm.expects(once()).add(caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_mockForm.expects(once()).add(this.m_oPresentationModel.ACCOUNT, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_mockForm.expects(once()).add(this.m_oPresentationModel.SETTLEMENT_DATE, caplinx.tradelist.TradeListConstants.NAMESPACE,"");
	this.m_mockForm.expects(once()).add(this.m_oPresentationModel.ENABLE_SUBMIT, caplinx.tradelist.TradeListConstants.NAMESPACE, false);
	this.m_mockForm.expects(once()).add(this.m_oPresentationModel.SUBMIT_BUTTON_CLASS, caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.BUTTON_DISABLED);
	this.m_mockForm.expects(once()).add(caplinx.tradelist.TradeListConstants.SHOW_BUY, caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.BUY_CLASS);
	this.m_mockForm.expects(once()).add(caplinx.tradelist.TradeListConstants.SHOW_SELL, caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS);
	this.m_mockForm.expects(once()).add(caplinx.tradelist.TradeListConstants.FI_SETTLEMENT_DATES, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_mockForm.expects(once()).add(caplinx.tradelist.TradeListConstants.FI_ACCOUNTS, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_mockForm.expects(once()).set(caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME, "somename");
	
	this.m_mockForm.expects(once()).set(caplinx.tradelist.TradeListConstants.FI_ACCOUNTS, ANYTHING);
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.ACCOUNT, ANYTHING);
	
	this.m_mockTestFactory.expects(once()).getFiAccounts().will(returnValue(this.m_oDummyFiAccountStore));
	this.m_mockTestFactory.expects(once()).getBusinessDateProvider().will(returnValue(this.m_mockBusinessDateProvider.proxy()));
	this.m_mockBusinessDateProvider.expects(once()).getFISettlementDates(this.m_oPresentationModel);
	
	//when
	this.m_oPresentationModel.initialise(this.m_mockForm.proxy(), "somename");
	
	//then
	this.m_oPresentationModel.m_bBuyTradeType.shouldBeTrue();
};

TradeListPresentationModelTest.prototype.testItDisablesSubmitButtonIfTradeListNameIsEmpty = function() {
	//given
	var oForm = new caplinx.form.Form(this.m_oPresentationModel);
	this.m_mockTestFactory.stubs().getBusinessDateProvider().will(returnValue(this.m_mockBusinessDateProvider));
	this.m_mockTestFactory.stubs().getFiAccounts().will(returnValue(this.m_oDummyFiAccountStore));

	//when
	this.m_oPresentationModel.initialise(oForm);
	oForm.set(caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME, "");
	
	//then
	oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, this.m_oPresentationModel.ENABLE_SUBMIT).shouldBeFalse();
	oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, this.m_oPresentationModel.SUBMIT_BUTTON_CLASS).shouldBe(caplinx.tradelist.TradeListConstants.BUTTON_DISABLED);

};
 */

TradeListPresentationModelTest.prototype.testItDisablesSubmitButtonIfTradeListGridIsEmpty = function() {
	
	//given
	this.m_mockForm.expects(once()).getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, this.m_oPresentationModel.TRADE_LIST_NAME).will(returnValue("foo"));
	
	//expectations	
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.ENABLE_SUBMIT, false);	
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.SUBMIT_BUTTON_CLASS, caplinx.tradelist.TradeListConstants.BUTTON_DISABLED);	
	//when
	this.m_oPresentationModel.onSizeChanged(0,1);	
};

TradeListPresentationModelTest.prototype.testItEnableSubmitButtonWhenTradeListGridAndTradeListNameAreNotEmpty = function() {
	
	//given
	this.m_mockForm.expects(once()).getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, this.m_oPresentationModel.TRADE_LIST_NAME).will(returnValue("foo"));
	
	//expectations	
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.ENABLE_SUBMIT, true);	
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.SUBMIT_BUTTON_CLASS, caplinx.tradelist.TradeListConstants.BUTTON_ENABLED);

	//when
	this.m_oPresentationModel.onSizeChanged(1,1);	
};

TradeListPresentationModelTest.prototype.testItSubscribesToTradeListReadyEvent = function() {
	
	//given
	var mockHub =  mock(caplin.event.Hub);
	
	//expectations
	mockHub.expects(once()).subscribe("ui.tradelist.ready", ANYTHING, ANYTHING);
	
	//when
	new caplinx.tradelist.view.TradeListPresentationModel(mockHub.proxy());
};

//TradeListPresentationModelTest.prototype.testItSetsTheGridModelOnReadyAndUnsubscribes = function() {
//	
//	//given
//	var mockHub =  mock(caplin.event.Hub);
//	var sSubscriptionId = "1";
//	mockHub.stubs().subscribe("ui.tradelist.ready", ANYTHING, ANYTHING).will(returnValue(sSubscriptionId));
//	var oTradeListPresenatationModel = new caplinx.tradelist.view.TradeListPresentationModel(mockHub.proxy());
//	oTradeListPresenatationModel.m_oForm = this.m_mockForm.proxy();
//	
//	//expectations
//	this.m_mockGridRowModel.expects(once()).addRowModelListener(oTradeListPresenatationModel);
//	this.m_mockForm.expects(once()).addPropertyListener(ANYTHING, ANYTHING);
//	mockHub.expects(once()).unsubscribe(sSubscriptionId);
//	
//	//when
//	oTradeListPresenatationModel._onReady("ui.tradelist.ready", this.m_oGridSnapshot);
//	
//	//then
//	assertEquals(oTradeListPresenatationModel.m_oGridSnapshot, this.m_oGridSnapshot); 
//};

TradeListPresentationModelTest.prototype.testItExecutesSubmitTradeListCommandOnSubmit = function() {
	//given
	var sPostSubmitEvent = "test.event";
	this.m_oPresentationModel.setPostSubmitEventName(sPostSubmitEvent);
	this.m_oPresentationModel.m_bBuyTradeType = true;
	var mockGridSnapshot = mock(caplinx.tradelist.view.model.GridSnapshot) ;
	var oTradeListFormData = {
		TradeListName : "TradeListName",
		Account : "SSI",
		SettlementDate : "T+3",
		Side : "ASK"
	};
	this.m_oPresentationModel.m_oGridSnapshot = mockGridSnapshot.proxy();
	
	mockGridSnapshot.stubs().getRowModel().will(returnValue(this.m_mockGridRowModel.proxy()));
	
	//expectations
	this._verifyItReadsFromFormData();
	
	this.m_mockGridRowModel.removeRowModelListener(this.m_oPresentationModel);
	this.m_mockSubmitTradeListCommand.expects(once()).execute(this.m_oHub, oTradeListFormData, mockGridSnapshot.proxy(), sPostSubmitEvent);
	this.m_mockForm.expects(once()).close();
			
	//when
	this.m_oPresentationModel.submit();
};

TradeListPresentationModelTest.prototype.testItExecutesToggleTradeCommand = function() {
	this.m_oPresentationModel.m_bBuyTradeType = false;
	
	//expectations
	this.m_mockToggleTradeCommand.expects(once()).execute(this.m_oGridColumnModel, this.m_mockForm.proxy(), true);
			
	//when
	this.m_oPresentationModel.toggleTrade();
	
	assertTrue(this.m_oPresentationModel.m_bBuyTradeType);
};

TradeListPresentationModelTest.prototype.testItClosesFormAndPublishesCloseEventOnSubmit = function() {
	//given
	var bCloseEventPublished = false;
	this.m_oHub.subscribe("ui.tradelist.close", function(){bCloseEventPublished = true; }, this);
	//expectations
	this._verifyItReadsFromFormData();
	this.m_mockGridRowModel.removeRowModelListener(this.m_oPresentationModel);
	this.m_mockSubmitTradeListCommand.expects(once()).execute(ANYTHING, ANYTHING, ANYTHING, ANYTHING);
	this.m_mockForm.expects(once()).close();
	
	//when
	this.m_oPresentationModel.submit();
	
	//then
	assertTrue(bCloseEventPublished);
};

TradeListPresentationModelTest.prototype.testItShouldCloseTradeListPanelOnCancel = function() {
	//given
	var bCloseEventPublished = false;
	this.m_oHub.subscribe("ui.tradelist.close", function(){bCloseEventPublished = true; }, this);
	
	//expectations
	this.m_mockGridRowModel.removeRowModelListener(this.m_oPresentationModel);
	this.m_mockForm.expects(once()).close();
	
	//when
	this.m_oPresentationModel.cancel();
	
	//then
	assertTrue(bCloseEventPublished);
};

TradeListPresentationModelTest.prototype.testItSetsTradeListName = function() {
	//expectations
	this.m_mockForm.expects(once()).set(caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME, "foo");
	
	//when
	this.m_oPresentationModel.setTradeListName("foo");
	
};

TradeListPresentationModelTest.prototype.testItAddsListenerOnGridRowWhenReady = function(){
	//given
	var mockGridSnapshot = mock(caplinx.tradelist.view.model.GridSnapshot);
	var oTradeListPresentationModel = new caplinx.tradelist.view.TradeListPresentationModel(this.m_oHub);	
	oTradeListPresentationModel.m_oForm = this.m_mockForm.proxy();
	
	//expectations
	mockGridSnapshot.expects(once()).addGridRowModelListener(oTradeListPresentationModel);
	this.m_mockForm.expects(once()).addPropertyListener(ANYTHING, ANYTHING);
	
	//when
	oTradeListPresentationModel._onReady("ui.tradelist.ready", mockGridSnapshot.proxy());
};

TradeListPresentationModelTest.prototype.testItAccessesDataOnlyForVisibleRowsToCheckAmount = function() {
	//given
	var mRowDataOne = {"Amount" : 11, "BidPrice": 222.2};
	var mRowDataTwo = {"Amount" : 22, "BidPrice": 222.2};
	
	this.m_mockGridRowModel.stubs().getSize().will(returnValue(10));
	this.m_mockGridRowModel.stubs().getRowRangeSize().will(returnValue(2));
	this.m_mockGridRowModel.stubs().getRowData(0).will(returnValue(mRowDataOne));
	this.m_mockGridRowModel.stubs().getRowData(1).will(returnValue(mRowDataTwo));
	
	//expectations
	this.m_mockForm.set(this.m_oPresentationModel.ENABLE_SUBMIT, true);
	this.m_mockForm.set(this.m_oPresentationModel.SUBMIT_BUTTON_CLASS, "button");
	//when
	this.m_oPresentationModel.onRowContentsChanged([],["some update"]);
};

TradeListPresentationModelTest.prototype.testItDisablesSubmitIfAmountIsLessThanZeroForVisibleRows = function() {
	//given
	var mRowDataOne = {"Amount" : 11, "BidPrice": 222.2};
	var mRowDataTwo = {"Amount" : 0, "BidPrice": 222.2};
	
	this.m_mockGridRowModel.stubs().getSize().will(returnValue(2));
	this.m_mockGridRowModel.stubs().getRowRangeSize().will(returnValue(2));
	this.m_mockGridRowModel.stubs().getRowData(0).will(returnValue(mRowDataOne));
	this.m_mockGridRowModel.stubs().getRowData(1).will(returnValue(mRowDataTwo));
	
	//expectations	
	this.m_mockForm.set(this.m_oPresentationModel.ENABLE_SUBMIT, false);
	this.m_mockForm.set(this.m_oPresentationModel.SUBMIT_BUTTON_CLASS, "button-disabled");
	
	//when
	this.m_oPresentationModel.onRowContentsChanged([0],["some update"]);
};

TradeListPresentationModelTest.prototype.testItEnablesSubmitIfAllRowsHaveAmountGreaterThanZero = function() {
	//given
	var mRowDataOne = {"Amount" : 11, "BidPrice": 222.2};
	var mRowDataTwo = {"Amount" : 22, "BidPrice": 222.2};
	
	this.m_mockGridRowModel.stubs().getSize().will(returnValue(2));
	this.m_mockGridRowModel.stubs().getRowRangeSize().will(returnValue(2));
	this.m_mockGridRowModel.stubs().getRowData(0).will(returnValue(mRowDataOne));
	this.m_mockGridRowModel.stubs().getRowData(1).will(returnValue(mRowDataTwo));
	
	//expectations
	this.m_mockForm.set(this.m_oPresentationModel.ENABLE_SUBMIT, true);
	this.m_mockForm.set(this.m_oPresentationModel.SUBMIT_BUTTON_CLASS, "button");
	//when
	this.m_oPresentationModel.onRowContentsChanged([],["some update"]);
};

/* commented for EXT
 * TradeListPresentationModelTest.prototype.testItSetsDefaultFiAccountInDropDown = function() {
	//given
	var mockAccountDataStore = mock(Ext.data.SimpleStore);
	var mockAccountDataStoreInstance = mockAccountDataStore.proxy();

	//expectations
	this.m_mockTestFactory.expects(once()).getFiAccounts().will(returnValue(mockAccountDataStoreInstance));
	this.m_mockForm.expects(once()).set(caplinx.tradelist.TradeListConstants.FI_ACCOUNTS, mockAccountDataStoreInstance);
	mockAccountDataStore.expects(once()).getAt(0).will(returnValue(this.m_oDummyFiAccountStore.getAt(0)));
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.ACCOUNT, 'GOLD');
	
	//when
	this.m_oPresentationModel.getFiAccounts();
};

TradeListPresentationModelTest.prototype.testItPopulatesAccountDropdownWithFiAccounts = function() {
	//given
	var mockAccountDataStore = mock(Ext.data.SimpleStore);
	var mockAccountDataStoreInstance = mockAccountDataStore.proxy();
	this.m_oPresentationModel.m_oAccountDataStore = mockAccountDataStoreInstance;
	
	//expectations
	mockAccountDataStore.expects(once()).getCount().will(returnValue(2));
	mockAccountDataStore.expects(once()).getAt(0).will(returnValue(this.m_oDummyFiAccountStore.getAt(0)));
	mockAccountDataStore.expects(once()).getAt(1).will(returnValue(this.m_oDummyFiAccountStore.getAt(1)));
	
	//when
	this.m_oPresentationModel.getAccountOptions();
};
*/
TradeListPresentationModelTest.prototype.testItInitialisesTradeListPanelWithTPlusTwoSettlementDate = function() {
	//given
	var pSettlementDates = [20090202,20090203,20090204,20090205,20090206,20090207,20090208];
	
	//expectations
	this.m_mockForm.expects(once()).set(caplinx.tradelist.TradeListConstants.FI_SETTLEMENT_DATES, pSettlementDates);
	this.m_mockForm.expects(once()).set(this.m_oPresentationModel.SETTLEMENT_DATE, 20090203);

	//when
	this.m_oPresentationModel.businessCalendarCallback("[some value]", 0, 0, pSettlementDates);

	//then
	assertEquals(pSettlementDates, this.m_oPresentationModel.m_pSettlementDates);
};

TradeListPresentationModelTest.prototype.testItPopulatesSettlementDateDropdownWithT7Dates = function() {
	//given
	var pSettlementDates = [20090202,20090203,20090204,20090205,20090206,20090207,20090208];
	var pResultOptions = [{formatted : "T+1", key : pSettlementDates[0]},
	                      {formatted : "T+2", key : pSettlementDates[1]},
	                      {formatted : "T+3", key : pSettlementDates[2]},
	                      {formatted : "T+4", key : pSettlementDates[3]},
	                      {formatted : "T+5", key : pSettlementDates[4]},
	                      {formatted : "T+6", key : pSettlementDates[5]},
	                      {formatted : "T+7", key : pSettlementDates[6]}
	                      ];
	this.m_oPresentationModel.m_pSettlementDates = pSettlementDates;
	//when
	var pOptions = this.m_oPresentationModel.getSettlementDateOptions();
	
	//then
	assertEquals(pResultOptions, pOptions);
	
};

TradeListPresentationModelTest.prototype._verifyItReadsFromFormData = function() {
	this.m_mockForm.stubs().getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME).will(returnValue("TradeListName"));
	this.m_mockForm.stubs().getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, this.m_oPresentationModel.ACCOUNT).will(returnValue("SSI"));
	this.m_mockForm.stubs().getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, this.m_oPresentationModel.SETTLEMENT_DATE).will(returnValue("T+3"));
};
