GridControlTest = TestCase("GridControlTest");

GridControlTest.prototype.setUp = function() {
	Mock4JS.clearMocksToVerify();
	this.m_mAttributes  = {
		gridId : "GRID ID",
		gridHeight : 250,
		gridWidth : 300
	}
	oControlType = new DummyControlType(this.m_mAttributes);
	this.m_oGridControl = new caplinx.tradelist.view.control.GridControl(oControlType);
	this.m_oGridControl.m_gridHolder = new Object();
};

GridControlTest.prototype.tearDown = function() {
	this.m_oGridControl = null;
	Mock4JS.verifyAllMocks();
};

GridControlTest.prototype.testItCreatesGridIfNoGridIsRenderedOnClassLoad = function(){
	//given
	var oMockGridCreator = mock(caplinx.form.grid.util.GridViewCreator);
	this.m_oGridControl.m_gridCreator = oMockGridCreator.proxy();
	
	//expectations
	oMockGridCreator.stubs().isReady().will(returnValue(true));
	oMockGridCreator.expects(once()).create(this.m_mAttributes.gridId, this.m_oGridControl.m_gridHolder, 
											this.m_mAttributes.gridHeight, this.m_mAttributes.gridWidth);
		
	//when
	this.m_oGridControl.onAfterClassLoad();
	
	//then
	assertTrue(this.m_oGridControl.isGridRendered);
	
};

GridControlTest.prototype.testItDoesNotCreateGridIfGridIsAlreadyRendered = function(){
	//given
	var oMockGridCreator = mock(caplinx.form.grid.util.GridViewCreator);
	this.m_oGridControl.m_gridCreator = oMockGridCreator.proxy();
	this.m_oGridControl.isGridRendered = true;
	
	//expectations
	oMockGridCreator.stubs().isReady().will(returnValue(true));
		
	//when
	this.m_oGridControl.onAfterClassLoad();
};

GridControlTest.prototype.testItDoesNotCreateGridIfGridCreatorIsNotReady = function(){
	//given
	var oMockGridCreator = mock(caplinx.form.grid.util.GridViewCreator);
	this.m_oGridControl.m_gridCreator = oMockGridCreator.proxy();
	
	//expectations
	oMockGridCreator.stubs().isReady().will(returnValue(false));
		
	//when
	this.m_oGridControl.onAfterClassLoad();
	
	//then
	assertFalse(this.m_oGridControl.isGridRendered);
	
};

DummyControlType = function(mAttributes) {
	this.m_mAttributes = mAttributes;
}

DummyControlType.prototype.getAttributes = function(){
	return this.m_mAttributes;
}

DummyControlType.prototype.getTemplate = function(){
}