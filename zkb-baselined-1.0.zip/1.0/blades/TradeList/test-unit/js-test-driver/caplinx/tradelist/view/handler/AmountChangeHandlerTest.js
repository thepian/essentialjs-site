AmountChangeHandlerTest = TestCase("AmountChangeHandlerTest");

AmountChangeHandlerTest.prototype.setUp = function() {
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	oMockRenderer = mock(caplin.element.renderer.StreamRenderer);
	oRenderer = oMockRenderer.proxy();
	
	oAttributes = { action: "onchange" , oldValue : '10000'};
	oDomEvent = {};
	oDomEvent.target = document.createElement("input");
	
	
	this.m_oAmountChangeHandler = caplinx.tradelist.view.handler.AmountChangeHandler;
};

AmountChangeHandlerTest.prototype.tearDown = function() {
	oMockRenderer = null;
	this.m_oAmountChangeHandler = null;
	
	Mock4JS.verifyAllMocks();
};

AmountChangeHandlerTest.prototype.testItSetsFieldValueAndRaisesEventOnEnterKeyUp = function() {
	//given
	oDomEvent.keyCode = 13 ;
	var sValue = "200000";
	oDomEvent.target.value = sValue;
	
	
	//expectations
	oMockRenderer.expects(once()).getParsedValue().will(returnValue(sValue));
	oMockRenderer.expects(once()).setValue(sValue);
	oMockRenderer.expects(once()).raiseEvent('editGridRow', {});
	
	//when
	this.m_oAmountChangeHandler.onkeyup(oDomEvent, oRenderer, oAttributes);
};

AmountChangeHandlerTest.prototype.testItDoesNotSetFieldValueNorRaisesEventOnOtherEvents = function() {
	//given
	oDomEvent.keyCode = 100 ;
	var sValue = "454500";
	oDomEvent.target.value = sValue;
	
	//expectations
	oMockRenderer.expects(never()).getParsedValue().will(returnValue(sValue));
	oMockRenderer.expects(never()).setValue(sValue);
	oMockRenderer.expects(never()).raiseEvent('editGridRow', {});
	
	//when
	this.m_oAmountChangeHandler.onkeyup(oDomEvent, oRenderer, oAttributes);
};

AmountChangeHandlerTest.prototype.testItSetsFieldValueAndRaisesEventOnBlur = function() {
	//given
	var sValue = "300000";	
	oDomEvent.target.value = sValue;
	
	//expectations
	oMockRenderer.expects(once()).getParsedValue().will(returnValue(sValue));
	oMockRenderer.expects(once()).setValue(sValue);
	oMockRenderer.expects(once()).raiseEvent('editGridRow', {});
	
	//when
	this.m_oAmountChangeHandler.onblur(oDomEvent, oRenderer, oAttributes);
};

AmountChangeHandlerTest.prototype.testItRevertsToPreviousIfValueIsNegative = function() {
	//given
	var sParsedValue = '-23300';
	
	oDomEvent.target.value = sParsedValue;
	
	//expectations
	oMockRenderer.expects(once()).getParsedValue().will(returnValue(sParsedValue));
	oMockRenderer.expects(once()).setValue(oAttributes['oldValue']);
	
	//when
	this.m_oAmountChangeHandler.onblur(oDomEvent, oRenderer, oAttributes);
};

AmountChangeHandlerTest.prototype.testItChangesTargetValueIfValid = function() {
	//given
	var sOldValue = '10000';
	var sValue = '23300';
	
	oDomEvent.target.value = sValue;
	
	//expectations
	oMockRenderer.expects(once()).getParsedValue().will(returnValue(sValue));
	oMockRenderer.expects(once()).setValue(sValue);
	oMockRenderer.expects(once()).raiseEvent('editGridRow', {});
	
	
	//when
	this.m_oAmountChangeHandler.onblur(oDomEvent, oRenderer, oAttributes);
	
	//assert
	assertEquals(oDomEvent.target.value, sValue);
};