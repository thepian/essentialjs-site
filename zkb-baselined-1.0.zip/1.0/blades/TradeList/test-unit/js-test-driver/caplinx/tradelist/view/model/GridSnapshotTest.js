GridSnapshotTest = TestCase("GridSnapshotTest");

GridSnapshotTest.prototype.setUp = function() {
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	this.m_oRowModel = mock(caplin.grid.DataProviderRowModel);
	this.m_oColumnModel = mock(caplin.grid.GridColumnModel);
	this.m_oGridSnapshot = new caplinx.tradelist.view.model.GridSnapshot(this.m_oRowModel.proxy(), this.m_oColumnModel.proxy());
};

GridSnapshotTest.prototype.tearDown = function() {
	this.m_oColumnModel = null;
	this.m_oRowModel = null;
	this.m_oGridSnapshot = null;
	
	Mock4JS.verifyAllMocks();
};

GridSnapshotTest.prototype.testItAddsRowModelListenerToGridRowModel = function() {
	//given
	var oGridRowModelListener = {};
	
	//expectations
	this.m_oRowModel.expects(once()).addRowModelListener(oGridRowModelListener);
	
	//when
	this.m_oGridSnapshot.addGridRowModelListener(oGridRowModelListener);
};


GridSnapshotTest.prototype.testItReturnsOnlyVisibleRows = function() {
	//given
	this.m_oRowModel.stubs().getSize().will(returnValue(10));
	
	//expectations
	this.m_oRowModel.expects(once()).getRowRangeSize().will(returnValue(5));
	
	//when
	this.m_oGridSnapshot.getVisibleRowRange().shouldBe(5);
};

GridSnapshotTest.prototype.testItNotifiesObserverOnSnapshotReceived = function() {
	//given
	var mGridData = {subject: "223", Amount:2000};
	var oTestGridSnapshotListener = {
			onGridDataReceived: function(oGridData) {
				assertEquals(1, mGridData, oGridData);
			}
		
	};
	var mockObservable = mock(caplin.core.Observable);
	this.m_oGridSnapshot.m_oObservable = mockObservable.proxy();
	mockObservable.stubs().addObserver(oTestGridSnapshotListener);
	
	//expectations
	mockObservable.expects(once()).notifyObservers("onGridDataReceived", [mGridData]);
	
	//when
	this.m_oGridSnapshot.onGridSnapshotAvailable(mGridData);
};

