SubmitTradeListCommandTest = TestCase("SubmitTradeListCommandTest");

caplin.include("caplin.event.Registry");
caplin.include("caplin.event.Hub");

SubmitTradeListCommandTest.prototype.setUp = function() {	
	this.m_oHub = new caplin.event.Hub(caplin.event.registry);	
	this.m_oSubmitTradeListCommand = new caplinx.tradelist.view.command.SubmitTradeListCommand();
};

SubmitTradeListCommandTest.prototype.tearDown = function() {
	this.m_oSubmitTradeListCommand = null;
	this.m_oHub.unsubscribe();
	this.m_oHub = null;
};

SubmitTradeListCommandTest.prototype.testItPublishesGridDataAsAfoSet = function(){
	//given
	var sTradeListSubmitSubject = "tradelist.sendInstruments";
	this.m_oHub.subscribe(sTradeListSubmitSubject, this._assertTradeAfoSet, this);
	var mockGridModel = mock(caplinx.tradelist.view.model.GridSnapshot) ;
	var oTradeListFormData = {"TradeListName" : "TradeListName"};	

	//expectations
	mockGridModel.expects(once()).addGridSnapshotListener(this.m_oSubmitTradeListCommand);
	mockGridModel.expects(once()).getAllRecords();
	
	//when
	this.m_oSubmitTradeListCommand.execute(this.m_oHub, oTradeListFormData, mockGridModel.proxy(), sTradeListSubmitSubject);
	
};

SubmitTradeListCommandTest.prototype._assertTradeAfoSet = function(sSubject, oTradeAfoSet) {
	var pTradeAfos = oTradeAfoSet.getTradeAfos();
	assertEquals(2, pTradeAfos.length);
	this._assertTradeAfoValues(pTradeAfos[0], "1");
	this._assertTradeAfoValues(pTradeAfos[1], "2");
};

SubmitTradeListCommandTest.prototype._assertTradeAfoValues = function(oTradeAfo, sIndex) {
	assertEquals(oTradeAfo["id"], "023456" + sIndex);
	assertEquals(oTradeAfo["InstrumentName"], "1234"+ sIndex);
	assertEquals(oTradeAfo["Description"], 'GS 5.25 12/04/2015');
	assertEquals(oTradeAfo["Amount"], '10M');
	assertEquals(oTradeAfo["BidPrice"],'102.543' + sIndex);
	assertEquals(oTradeAfo["AskPrice"], '102.549' + sIndex);
	assertEquals(oTradeAfo["TradeListName"], "TradeListName");
};


StubGridRowModel = function() {
	var gridRowOne = this._setupGridData("1");
	var gridRowTwo = this._setupGridData("2");
	this.m_pGridData = [gridRowOne, gridRowTwo];  
	
};

StubGridRowModel.prototype.getSize = function() {
	return this.m_pGridData.length;
};

StubGridRowModel.prototype.getRowData = function(index) {
	return this.m_pGridData[index];
};

StubGridRowModel.prototype.getSubjectId = function(index) {
	return this.m_pGridData[index].subject;
};

StubGridRowModel.prototype._setupGridData = function(sIndex) {
	return  {  id : "023456" + sIndex, 
			   subject : "FI/1234"+ sIndex, 
			   Description : 'GS 5.25 12/04/2015', 
			   Amount :'10M', 
			   BidPrice: '102.543' + sIndex,  
			   AskPrice : '102.549' + sIndex  
			};
};