EditableGridDecoratorTest = TestCase("EditableGridDecoratorTest");

EditableGridDecoratorTest.prototype.setUp = function(){
	Mock4JS.addMockSupport(window);
	oMockRenderer = mock(caplin.element.Renderer);
	oRenderer = oMockRenderer.proxy();
	oMockGridRowModel = mock(caplin.grid.GridRowModel);
	oGridRowModel = oMockGridRowModel.proxy();
	oMockGridView = mock(caplin.grid.GridView);
	oGridView = oMockGridView.proxy();

	this.m_oEditableGridDecorator = new caplinx.tradelist.view.decorator.EditableGridDecorator({});
	this.m_oEditableGridDecorator.m_oGridView = oGridView;
};

EditableGridDecoratorTest.prototype.testItShouldNotUpdateRowModelIfNotEditGridRowEvent = function() {
	//given
	oMockRenderer.stubs().getName().will(returnValue('[some field]'));
	
	//expectations
	oMockGridRowModel.expects(never()).setRowData(ANYTHING, ANYTHING);
	
	//when
	this.m_oEditableGridDecorator.onRendererEvent(oRenderer, '[someOtherEvent]', {});
};

EditableGridDecoratorTest.prototype.testItShouldUpdateGridRowModelWithFieldValueAndSetEditedTrue = function() {
	//given
	var sRendererEvent = 'editGridRow';
	var sSubjectId = '[FI/TEST1]';
	var nIndex = 2;
	var sFieldName = '[Amount]';
	var sFieldValue = '[1000]';
	var mRowData = {};	
	mRowData[sFieldName] = sFieldValue; 
	

	oMockGridView.stubs().getGridRowModel().will(returnValue(oGridRowModel));
	oMockRenderer.stubs().getNamespace().will(returnValue(sSubjectId));
	oMockRenderer.stubs().getName().will(returnValue(sFieldName));
	oMockRenderer.stubs().getValue().will(returnValue(sFieldValue));
	
	//expectations
	oMockGridRowModel.expects(once()).getIndexBySubject(sSubjectId).will(returnValue(nIndex));
	oMockGridRowModel.expects(once()).setRowData(nIndex, mRowData);
	
	//when
	this.m_oEditableGridDecorator.onRendererEvent(oRenderer, sRendererEvent, {});
};
