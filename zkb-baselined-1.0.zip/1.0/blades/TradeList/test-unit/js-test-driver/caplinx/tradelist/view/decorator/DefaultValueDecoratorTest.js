DefaultValueDecoratorTest = TestCase("DefaultValueDecoratorTest");

DefaultValueDecoratorTest.prototype.setUp = function(){
	Mock4JS.addMockSupport(window);
	this.m_mConfig = {column : "tradeAmount" ,
				defaultValue : "100000"};
	this.m_oDefaultValueDecorator = new caplinx.tradelist.view.decorator.DefaultValueDecorator(this.m_mConfig);
	
};

DefaultValueDecoratorTest.prototype.tearDown = function(){
	Mock4JS.verifyAllMocks();
};

DefaultValueDecoratorTest.prototype.testItGetsFieldNameFromColumnId = function() {
	//given
	var oMockGridView = mock(caplin.grid.GridView);
	var oGridView = oMockGridView.proxy();
	var oMockGridColumnModel = mock(caplin.grid.GridColumnModel);
	var oGridColumnModel = oMockGridColumnModel.proxy();
	var oMockGridColumn = mock(caplin.grid.GridColumn);
	var oGridColumn = oMockGridColumn.proxy();
	
	//expectations
	oMockGridView.expects(once()).getGridColumnModel().will(returnValue(oGridColumnModel));
	oMockGridColumnModel.expects(once()).getColumnById(this.m_mConfig["column"]).will(returnValue(oGridColumn));
	oMockGridColumn.expects(once()).getPrimaryFieldName().will(returnValue("Amount"));
	oMockGridView.stubs().addGridViewListener(ANYTHING);
	
	//when
	this.m_oDefaultValueDecorator.setGridView(oGridView);
	
	//then
	assertEquals(this.m_oDefaultValueDecorator.m_sFieldId, "Amount");
};

DefaultValueDecoratorTest.prototype.testItSetsDefaultValueToFieldIfNotEdited = function() {
	//given
	var oMockGridView = mock(caplin.grid.GridView);
	var oGridView = oMockGridView.proxy();
	this.m_oDefaultValueDecorator.m_oGridView = oGridView;
	this.m_oDefaultValueDecorator.m_sFieldId = "Amount";
	var oGridRowModel = new DummyGridRowModel("Amount", "", "", "1Y GILT", "2Y GILT");
	
	//expectations
	oMockGridView.expects(once()).getGridRowModel().will(returnValue(oGridRowModel));
	
	//when
	this.m_oDefaultValueDecorator.onGridSnapshotAvailable(oGridRowModel._$getDataProvider().fetchSnapshot());
	
	//then
	assertEquals(oGridRowModel.getRowDataBySubject("1Y GILT")["Amount"], "100000");
};

DefaultValueDecoratorTest.prototype.testItShouldFetchGridSnapShotFromDataProvider = function() {
	//given
	var oMockGridView = mock(caplin.grid.GridView);
	var oGridView = oMockGridView.proxy();
	this.m_oDefaultValueDecorator.m_oGridView = oGridView;
	this.m_oDefaultValueDecorator.m_sFieldId = "Amount";
	var oGridRowModel = new DummyGridRowModel("Amount", "1000", "2000", "1Y GILT", "2Y GILT");
	var oMockDataProvider = mock(DummyGridDataProvider);
	var oDataProvider = oMockDataProvider.proxy();
	oGridRowModel.setDataProvider(oDataProvider);
	
	//expectations
	oMockDataProvider.expects(once()).fetchSnapshot(this.m_oDefaultValueDecorator).will(returnValue(1));
	oMockGridView.expects(once()).getGridRowModel().will(returnValue(oGridRowModel));	
	
	//when
	this.m_oDefaultValueDecorator.onAllRowsReceived();
	
	//Then - all expectations should be met
};

DefaultValueDecoratorTest.prototype.testItDoesNotSetDefaultValueToFieldIfValueIsAlreadySet = function() {
	//given
	var oMockGridView = mock(caplin.grid.GridView);
	var oGridView = oMockGridView.proxy();
	this.m_oDefaultValueDecorator.m_oGridView = oGridView;
	this.m_oDefaultValueDecorator.m_sFieldId = "Amount";
	var oGridRowModel = new DummyGridRowModel("Amount", "1000", "2000", "1Y GILT", "2Y GILT");
	
	//expectations
	oMockGridView.expects(once()).getGridRowModel().will(returnValue(oGridRowModel))
	
	//when
	this.m_oDefaultValueDecorator.onGridSnapshotAvailable(oGridRowModel._$getDataProvider().fetchSnapshot());
	
	//then
	assertEquals(oGridRowModel.getRowDataBySubject("1Y GILT")["Amount"], "1000");
};

var DummyGridRowModel = function(fieldId, valueOne, valueTwo, sSubjectOne, sSubjectTwo) {
	var oGridData = {};
	var row = {};
	row[fieldId] = valueOne;
	oGridData[sSubjectOne] = row;
	row = {};
	row[fieldId] = valueTwo;
	oGridData[sSubjectTwo] = row;
	this.m_oDataProvider = new DummyGridDataProvider(oGridData);
	this.m_pGridData = oGridData;
	
};

DummyGridRowModel.prototype.getRowDataBySubject = function(sSubject) {
	return this.m_pGridData[sSubject];
};

DummyGridRowModel.prototype.setRowDataBySubject = function(sSubject, oRowData) {
	this.m_pGridData[sSubject] = oRowData;
};

DummyGridRowModel.prototype.setDataProvider = function(oDataProvider) {
	this.m_oDataProvider = oDataProvider;
};

DummyGridRowModel.prototype.getDataProvider = function() {
	return this.m_oDataProvider;
};

DummyGridRowModel.prototype._$getDataProvider = function() {
	 return this.m_oDataProvider;
};

var DummyGridDataProvider = function(oSnapshot) {
	this.m_oSnapshot = oSnapshot;
};

DummyGridDataProvider.prototype.fetchSnapshot = function(oListener) {
	return this.m_oSnapshot;
};
