caplin.namespace("caplinx.tradelist.view.command");

caplin.include("caplinx.tradelist.afo.TradeAfo");
caplin.include("caplinx.tradelist.afo.TradeAfoSet");

caplinx.tradelist.view.command.SubmitTradeListCommand = function(){
};

caplinx.tradelist.view.command.SubmitTradeListCommand.prototype.execute = function(oHub, oTradeListFormData, oGridModel, sPublishSubject) {
	oGridModel.addGridSnapshotListener(this);
	oGridModel.getAllRecords();
	this.m_oHub= oHub;
	this.m_oTradeListFormData = oTradeListFormData;
	this.m_oGridModel = oGridModel;
	this.m_sEventSubject = sPublishSubject;
};

caplinx.tradelist.view.command.SubmitTradeListCommand.prototype.onGridDataReceived = function(oGridData) {
	this.m_oGridModel.removeGridSnapshotListener(this);
	var oTradeAfoSet = this._convertGridDataToTradeAfoSet(oGridData);
	this.m_oHub.publish(this.m_sEventSubject, oTradeAfoSet);
};

caplinx.tradelist.view.command.SubmitTradeListCommand.prototype._convertGridDataToTradeAfoSet = function(oGridData) {
	var oTradeAfoSet = new caplinx.tradelist.afo.TradeAfoSet();
	for (var sSubject in oGridData) {
		if(sSubject != 'remove') {
			var oTradeAfo = this._createTradeAfoFrom(sSubject, oGridData[sSubject]);
			oTradeAfoSet.add(oTradeAfo);
		}
	}
	return oTradeAfoSet;
};

caplinx.tradelist.view.command.SubmitTradeListCommand.prototype._createTradeAfoFrom = function(sSubject, oGridRowData) {
	var oTradeAfo = new caplinx.tradelist.afo.TradeAfo();
	oTradeAfo.InstrumentName = this._getInstrumentName(sSubject);
	oTradeAfo = this._populateTradeAfoFrom(oTradeAfo, oGridRowData);
	return this._populateTradeAfoFrom(oTradeAfo, this.m_oTradeListFormData);
};

caplinx.tradelist.view.command.SubmitTradeListCommand.prototype._populateTradeAfoFrom = function(oTradeAfo, oSource) {
	for(var sFieldName in oTradeAfo) {
		if(oSource[sFieldName] != undefined) {
			oTradeAfo[sFieldName] = oSource[sFieldName] ;
		}
	}
	return oTradeAfo;
};

caplinx.tradelist.view.command.SubmitTradeListCommand.prototype._getInstrumentName = function(sSubjectName) {
	var pSubjectParts = sSubjectName.split("/");
	return pSubjectParts[pSubjectParts.length -1];
};

