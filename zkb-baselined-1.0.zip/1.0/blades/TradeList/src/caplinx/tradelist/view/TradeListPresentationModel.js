caplin.namespace("caplinx.tradelist.view");
caplin.include("caplin.event.Hub", true);
caplin.include("caplinx.form.PresentationProperty", true);
caplin.include("caplin.grid.GridRowModelListener", true);
caplin.include("caplin.services.date.BusinessDateListener", true);

caplinx.tradelist.view.TradeListPresentationModel = function(oHub, mCommandFactory) {
	this.m_oHub = oHub;
	this.m_mCommandFactory = mCommandFactory;
	this.m_sPostSubmitEventName = null;
	this.m_sGridSubscriptionId = this.m_oHub.subscribe("ui.tradelist.ready", this._onReady, this);
	this.m_pSettlementDates = [];
	this.m_oAccountDataStore = null;
};

caplin.implement(caplinx.tradelist.view.TradeListPresentationModel, caplin.grid.GridRowModelListener);
caplin.implement(caplinx.tradelist.view.TradeListPresentationModel, caplin.services.date.BusinessDateListener);

caplinx.tradelist.view.TradeListPresentationModel.prototype.ACCOUNT = "Account";
caplinx.tradelist.view.TradeListPresentationModel.prototype.SETTLEMENT_DATE = "SettlementDate";
caplinx.tradelist.view.TradeListPresentationModel.prototype.ENABLE_SUBMIT = "submit-enabled";
caplinx.tradelist.view.TradeListPresentationModel.prototype.SUBMIT_BUTTON_CLASS = "submit-button-class";
caplinx.tradelist.view.TradeListPresentationModel.prototype.TRADE_LIST_NAME = "TradeListName";
caplinx.tradelist.view.TradeListPresentationModel.prototype.SIDE = "Side";

caplinx.tradelist.view.TradeListPresentationModel.prototype.initialise = function(oForm, sTradeListName, sPostSubmitEventName) {
	this.m_oGridSnapshot = null;
	this.m_oForm = oForm;
	this._initialiseProperties();
	this.setTradeListName(sTradeListName);
	this.setPostSubmitEventName(sPostSubmitEventName);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._onReady = function(sSubject, oGridSnapshot) {
	this.m_oGridSnapshot = oGridSnapshot;
	this.m_oGridSnapshot.addGridRowModelListener(this);
	this._addPropertyListeners();
	this.m_oHub.unsubscribe(this.m_sGridSubscriptionId);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._initialiseProperties = function() {
	this.m_bBuyTradeType = true;
	this.m_oForm.add(this.TRADE_LIST_NAME, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_oForm.add(this.ACCOUNT, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_oForm.add(this.SETTLEMENT_DATE, caplinx.tradelist.TradeListConstants.NAMESPACE,"");
	this.m_oForm.add(this.ENABLE_SUBMIT, caplinx.tradelist.TradeListConstants.NAMESPACE, false);
	this.m_oForm.add(this.SUBMIT_BUTTON_CLASS, caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.BUTTON_DISABLED);
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.SHOW_BUY, caplinx.tradelist.TradeListConstants.NAMESPACE, caplinx.tradelist.TradeListConstants.BUY_CLASS);
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.SHOW_SELL, caplinx.tradelist.TradeListConstants.NAMESPACE,caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS);
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.FI_SETTLEMENT_DATES, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
	this.m_oForm.add(caplinx.tradelist.TradeListConstants.FI_ACCOUNTS, caplinx.tradelist.TradeListConstants.NAMESPACE, "");
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._addPropertyListeners = function(){
	this._addPropertyListenerToTradeListName();
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._addPropertyListenerToTradeListName = function() {
	var oSelf = this;
	this.m_oForm.addPropertyListener(this.TRADE_LIST_NAME, function(sNamespace, sName, sValue){
		oSelf._handleSubmitButton(sValue, oSelf._getNumberOfRows());
	});
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._getNumberOfRows = function(){
	return this.m_oGridSnapshot.getTotalRowSize();
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.setTradeListName = function(sTradeListName) {
	this.m_oForm.set(caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME, sTradeListName);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.setPostSubmitEventName = function(sPostSubmitEventName) {
	this.m_sPostSubmitEventName = sPostSubmitEventName;
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.cancel = function() {
	this._close();
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.toggleTrade = function() {
	this.m_bBuyTradeType = !this.m_bBuyTradeType;
	this.m_mCommandFactory[caplinx.tradelist.TradeListConstants.TOGGLE_TRADETYPE].execute(this.m_oGridSnapshot.getColumnModel(), this.m_oForm, this.m_bBuyTradeType);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._toggleTradeType = function(sTradeType){
	this.m_mCommandFactory[caplinx.tradelist.TradeListConstants.TOGGLE_TRADETYPE].execute(this.m_oGridSnapshot.getColumnModel(), this.m_oForm, sTradeType);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.submit = function() {
	var oCommand = this.m_mCommandFactory[caplinx.tradelist.TradeListConstants.SUBMIT_TRADELIST];
	oCommand.execute(this.m_oHub, this._getTradeListFormData(), this.m_oGridSnapshot, this.m_sPostSubmitEventName);
	this._close();
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.getT7SettlementDates = function() {
	var oBusinessDateProvider = caplin.framework.ApplicationFactory.INSTANCE.getBusinessDateProvider();
	oBusinessDateProvider.getFISettlementDates(this);	
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.businessCalendarCallback = function(sObject, nYear, nMonth, pSettlementDates) {
	this.m_pSettlementDates = pSettlementDates;
	this.m_oForm.set(caplinx.tradelist.TradeListConstants.FI_SETTLEMENT_DATES, pSettlementDates);	
	this.m_oForm.set(this.SETTLEMENT_DATE, this.m_pSettlementDates[1]);
	
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.getFiAccounts = function() {
	this.m_oAccountDataStore = caplin.framework.ApplicationFactory.INSTANCE.getFiAccounts();
	this.m_oForm.set(caplinx.tradelist.TradeListConstants.FI_ACCOUNTS, this.m_oAccountDataStore);
	this.m_oForm.set(this.ACCOUNT, this.m_oAccountDataStore.getAt(2).get('value'));
};
caplinx.tradelist.view.TradeListPresentationModel.prototype.getAccountOptions = function() {
	var pAccounts = [];
	if(this.m_oAccountDataStore) {
		var nAccounts = this.m_oAccountDataStore.getCount();
		for(var i = 0;i < nAccounts; i++) {
			var oStoreData = this.m_oAccountDataStore.getAt(i);
			var mOption = {formatted : oStoreData.get("label"), key : oStoreData.get("value")};
			pAccounts.push(mOption);
		}
	}
	return pAccounts;
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.getSettlementDateOptions = function() {
	var pSettlementDates = [];
	if(this.m_pSettlementDates) {
		for(var i = 0; i < this.m_pSettlementDates.length; i++) {
			var mOption = {formatted : "T+" + (i+1), key : this.m_pSettlementDates[i]};
			pSettlementDates.push(mOption);
		}
	}
	return pSettlementDates;
	
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._close = function() {
	if(this.m_oGridSnapshot) {
		var oRowModel = this.m_oGridSnapshot.getRowModel();
		oRowModel.removeRowModelListener(this);
	}
	this.m_oHub.publish("ui.tradelist.close");
	this.m_oForm.close();
};


caplinx.tradelist.view.TradeListPresentationModel.prototype._getFormValue = function(sDataName) {
	return this.m_oForm.getValue(caplinx.tradelist.TradeListConstants.NAMESPACE, sDataName);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.onSizeChanged = function(nNewSize, nOldSize) {
	this._handleSubmitButton(this._getFormValue(this.TRADE_LIST_NAME), nNewSize);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype.onRowContentsChanged = function(pIndicies, pUpdates) {
	for (var index = 0; index < this.m_oGridSnapshot.getTotalRowSize() && index < this.m_oGridSnapshot.getVisibleRowRange(); index++) {
		var oRowData = this.m_oGridSnapshot.getRowData(index);
		if(oRowData[caplinx.tradelist.TradeListConstants.AMOUNT] <= 0) {
			return this._disableSubmit();
		}
	}
	this._enableSubmit();
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._handleSubmitButton = function(sTradeListName, nGridRows){
	if(sTradeListName != "" && nGridRows > 0){
		this._enableSubmit();
	}else{
		this._disableSubmit();
	}
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._enableSubmit = function(){
	this.m_oForm.set(this.ENABLE_SUBMIT, true);
	this.m_oForm.set(this.SUBMIT_BUTTON_CLASS,  caplinx.tradelist.TradeListConstants.BUTTON_ENABLED);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._disableSubmit = function(){
	this.m_oForm.set(this.ENABLE_SUBMIT, false);
	this.m_oForm.set(this.SUBMIT_BUTTON_CLASS, caplinx.tradelist.TradeListConstants.BUTTON_DISABLED);
};

caplinx.tradelist.view.TradeListPresentationModel.prototype._getTradeListFormData = function() {
	var oFormData = {};
	oFormData[this.TRADE_LIST_NAME] = this._getFormValue(this.TRADE_LIST_NAME);
	oFormData[this.ACCOUNT] = this._getFormValue(this.ACCOUNT);
	oFormData[this.SIDE] = (this.m_bBuyTradeType) ? "ASK" : "BID";
	oFormData[this.SETTLEMENT_DATE] = this._getFormValue(this.SETTLEMENT_DATE);
	return oFormData;
};
