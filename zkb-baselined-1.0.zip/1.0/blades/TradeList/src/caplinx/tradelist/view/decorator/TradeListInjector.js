/**
 * Responsibility:
 * 1. Subscribes on the subject configured in gridDefinitions('ui.tradelist.add')
 * 2. Injects the instrument subjects into the grid, received over the channel
 *   
 */
caplin.namespace("caplinx.tradelist.view.decorator");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.grid.decorator.GridDecorator", true);
caplin.include("caplin.grid.GridViewListener", true);
caplin.include("caplin.grid.GridRowModelListener", true);
caplin.include("caplinx.tradelist.view.model.GridSnapshot");
caplin.include("caplin.event.Hub");

caplinx.tradelist.view.decorator.TradeListInjector = function(mConfig) {
	this.m_mConfig = mConfig;
    this.m_oGridView = null;
	this.m_sClassname = mConfig.classname;
	this.m_oNoRowsBubble = null;
	this.m_DefaultBubble = null;
	this.m_sDefaultHeaderText = mConfig.defaultHeaderText || ct.i18n("ct.grid.no.data.data.unavailable");
	this.m_sDefaultBodyText = mConfig.defaultBodyText ||  ct.i18n("ct.grid.no.data.received");
	this.m_sNoRowsHeaderText = mConfig.noRowsFoundHeaderText || this.m_sDefaultHeaderText;
	this.m_sNoRowsBodyText = mConfig.noRowsFoundBodyText || this.m_sDefaultBodyText;
	this.m_sInProgressHeaderText = mConfig.inProgressHeaderText || this.m_sDefaultHeaderText;
	this.m_sInProgressBodyText = mConfig.inProgressBodyText || this.m_sDefaultBodyText;
	this.m_bDataUnavailable = false;
    this.m_bListReady = false;
	this.m_oHub = new caplin.event.Hub(caplin.event.registry);
	this.m_sAddInstrumentsSubscriptionId = this.m_oHub.subscribe(this.m_mConfig["subject"], this._onReceive, this);
};

caplin.implement(caplinx.tradelist.view.decorator.TradeListInjector, caplin.grid.decorator.GridDecorator);
caplin.implement(caplinx.tradelist.view.decorator.TradeListInjector, caplin.grid.GridViewListener);
caplin.implement(caplinx.tradelist.view.decorator.TradeListInjector, caplin.grid.GridRowModelListener);

caplinx.tradelist.view.decorator.TradeListInjector.prototype.setGridView = function(oGridView) {
    this.m_oGridView = oGridView;
    oGridView.getGridRowModel().addRowModelListener(this);
    oGridView.addGridViewListener(this);
    var eGridBody = oGridView.getElement();
	
    var eContainer = document.createElement("DIV");
	eContainer.className = "noDataFoundMessageHolder-tradelist";
	this.m_oLoadingInProgressBubble = this._createBubble(eContainer, this.m_sInProgressHeaderText, this.m_sInProgressBodyText);
	this.m_oNoRowsBubble = this._createBubble(eContainer, this.m_sNoRowsHeaderText, this.m_sNoRowsBodyText);
	this.m_DefaultBubble = this._createBubble(eContainer, this.m_sDefaultHeaderText, this.m_sDefaultBodyText);
	eGridBody.appendChild(eContainer);
	this.m_eContainer = eContainer;
};

caplinx.tradelist.view.decorator.TradeListInjector.prototype._createBubble = function(eGridBody, sHeaderText, sBodyText)
{
	return new caplin.component.contextmessage.PanelMessage(eGridBody, sHeaderText, sBodyText, this.m_sClassname);
};


caplinx.tradelist.view.decorator.TradeListInjector.prototype.onOpen = function(nWidth, nHeight) 
{
	this.m_oScrollPane = this.m_oGridView.getScrollPane();
	this.m_eContainer.style.top = this.m_oScrollPane.getExtrasTop() + "px";
};

/**
 * @private
 * @see caplin.grid.decorator.GridDecorator#onClose
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype.onClose = function(oGridView)
{
	if (this._notInitialized())
	{
		return;	
	}
	
	this.m_oGridView.getGridRowModel().removeRowModelListener(this);
};

caplinx.tradelist.view.decorator.TradeListInjector.prototype.onContainerHtmlRendered = function() {
	var oGridSnapshot = new caplinx.tradelist.view.model.GridSnapshot(this.m_oGridView.getGridRowModel(),
			 this.m_oGridView.getGridColumnModel());
	this.m_oHub.publish("ui.tradelist.ready", oGridSnapshot);
};

caplinx.tradelist.view.decorator.TradeListInjector.prototype._onReceive = function(sSubject, pInstrumentSubjects) {
	if(pInstrumentSubjects.length > 0) {
		this._showLoadingInProgressBubble();
	} else {
		this.m_bListReady = true;
		this._showNoRowsBubble();
	} 
	this.m_oGridView.receiveObjects(pInstrumentSubjects);
	this.m_oHub.unsubscribe(this.m_sAddInstrumentsSubscriptionId);
};

caplinx.tradelist.view.decorator.TradeListInjector.prototype.onAllDataReceived = function() {
	this.m_bListReady = true;
};

caplinx.tradelist.view.decorator.TradeListInjector.prototype.onSizeChanged = function(nNewSize, nOldSize) {
	if(this.m_bListReady && nNewSize === 0) {
		this._showNoRowsBubble();
	} else if(!this.m_bListReady && nNewSize === 0){
		this._showLoadingInProgressBubble();
	} else {
		this._hideBubble();
		
	}
};

/**
 * @private
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype.onRowDataUnavailable = function(sReason){
	this._showDefaultBubble();
};

/**
 * @private
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype._showDefaultBubble = function(){
	if (this._notInitialized())
	{
		return;	
	}

	this.m_DefaultBubble.show();
	this.m_oLoadingInProgressBubble.hide();
	this.m_oNoRowsBubble.hide();
    this.m_eContainer.style.display = "";
};

/**
 * @private
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype.onRowDataRequested = function(){
	this._hideBubble();
};

/**
 * @private
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype._showNoRowsBubble = function(){
	if (this._notInitialized())
	{
		return;	
	}

	this.m_DefaultBubble.hide();
	this.m_oLoadingInProgressBubble.hide();
	this.m_oNoRowsBubble.show();
    this.m_eContainer.style.display = "";
};

caplinx.tradelist.view.decorator.TradeListInjector.prototype._showLoadingInProgressBubble = function()
{
	if (this._notInitialized())
	{
		return;	
	}

	this.m_DefaultBubble.hide();
	this.m_oNoRowsBubble.hide();
	this.m_oLoadingInProgressBubble.show();
    this.m_eContainer.style.display = "";
};

/**
 * @private
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype._hideBubble = function()
{
	if (this._notInitialized())
	{
		return;	
	}

	this.m_DefaultBubble.hide();
	this.m_oNoRowsBubble.hide();
	this.m_oLoadingInProgressBubble.hide();
    this.m_eContainer.style.display = "none";
};

/**
 * @private
 */
caplinx.tradelist.view.decorator.TradeListInjector.prototype._notInitialized = function()
{
	return this.m_oGridView === null || this.m_oLoadingInProgressBubble === null || this.m_DefaultBubble === null || this.m_oNoRowsBubble === null;
};

