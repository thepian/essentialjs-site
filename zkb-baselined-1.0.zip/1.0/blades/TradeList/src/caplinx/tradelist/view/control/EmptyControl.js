caplin.namespace("caplinx.tradelist.view.control");

caplin.include("caplin.control.basic.BasicControl", true);

caplinx.tradelist.view.control.EmptyControl = function(oControlType){
	 caplin.control.basic.BasicControl.apply(this, arguments);
	
};
caplin.extend(caplinx.tradelist.view.control.EmptyControl, caplin.control.basic.BasicControl);

caplinx.tradelist.view.control.EmptyControl.prototype.bind = function(eControlElement, bIsDummy) {
	caplin.control.basic.BasicControl.prototype.bind.apply(this, arguments);
	
};

caplinx.tradelist.view.control.EmptyControl.prototype.unbind = function() {
    caplin.control.basic.BasicControl.prototype.unbind.call(this);
};

caplinx.tradelist.view.control.EmptyControl.prototype.setDomValue = function(sValue) {
};

caplinx.tradelist.view.control.EmptyControl.prototype.createHtml = function(sValue, sInitialClassName) {
};

caplinx.tradelist.view.control.EmptyControl.prototype.buildXhtml = function(sValue, sClass) {};

caplinx.tradelist.view.control.EmptyControl.prototype.toString = function() {
    return "caplinx.tradelist.view.control.EmptyControl";
};