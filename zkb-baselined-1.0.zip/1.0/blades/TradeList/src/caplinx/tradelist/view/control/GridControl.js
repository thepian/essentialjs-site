caplin.namespace("caplinx.tradelist.view.control");

caplin.include("caplin.control.basic.BasicControl", true);

caplin.include("caplin.event.Hub");
caplin.include("caplinx.form.grid.util.GridViewCreator");

caplinx.tradelist.view.control.GridControl = function(oControlType){
	 caplin.control.basic.BasicControl.apply(this, arguments);
	 this.m_gridHolder = null;
	 this.m_sGridId = oControlType.getAttributes()["gridId"];
	 this.m_nGridHeight = parseInt(oControlType.getAttributes()["gridHeight"]);
	 this.m_nGridWidth = parseInt(oControlType.getAttributes()["gridWidth"]);
	 this.m_oHub = new caplin.event.Hub(caplin.event.registry);
	 this.m_gridCreator = new caplinx.form.grid.util.GridViewCreator();
	 this.isGridRendered = false;
	 caplin.notifyAfterClassLoad(this);
	
};
caplin.extend(caplinx.tradelist.view.control.GridControl, caplin.control.basic.BasicControl);

caplinx.tradelist.view.control.GridControl.prototype.onAfterClassLoad = function() {
	this._bind();
};

caplinx.tradelist.view.control.GridControl.prototype._bind = function() {
	//TODO : can we get rid of
	if(this.m_gridCreator.isReady() && !this.isGridRendered && this.m_gridHolder != null) {
		this.m_gridCreator.create(this.m_sGridId, this.m_gridHolder, this.m_nGridHeight, this.m_nGridWidth);
		this.isGridRendered = true;
	}
	
};

caplinx.tradelist.view.control.GridControl.prototype.bind = function(eControlElement, bIsDummy) {
	caplin.control.basic.BasicControl.prototype.bind.apply(this, arguments);
	if(eControlElement.tagName == "DIV") {
		this.m_gridHolder = eControlElement;
	}
};

caplinx.tradelist.view.control.GridControl.prototype.unbind = function() {
    caplin.control.basic.BasicControl.prototype.unbind.call(this);
    this.m_gridHolder = null;
};

caplinx.tradelist.view.control.GridControl.prototype.setDomValue = function(vValue) {
	if(this.isGridRendered === false)
	{
		this._bind();
	}
};

caplinx.tradelist.view.control.GridControl.prototype.createHtml = function(sValue, sInitialClassName) {
};

caplinx.tradelist.view.control.GridControl.prototype.buildXhtml = function(sValue, sClass) {};

caplinx.tradelist.view.control.GridControl.prototype.toString = function() {
    return "caplinx.tradelist.view.control.GridControl";
};