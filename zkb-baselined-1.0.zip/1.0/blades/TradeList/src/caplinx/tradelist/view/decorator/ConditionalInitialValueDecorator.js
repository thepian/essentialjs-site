caplin.namespace("caplinx.tradelist.view.decorator");

caplin.include("caplin.core.Exception");
caplin.include("caplin.grid.decorator.GridDecorator", true);
caplin.include("caplin.grid.GridViewListener", true);
caplin.include("caplin.grid.GridColumnModelListener", true);

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator = function(mConfig) {
    this.m_sColumnId = mConfig['column'];
    this.pSubscriberFields = mConfig['subscribeTo'].split("|");
   	this.pDependsOn = mConfig['whenColumnVisibile'].split("|");
   	this._checkConfiguration();
    this.initialise();
    this.m_mFieldValues = []; 
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._checkConfiguration = function() {
	if(this.pSubscriberFields.length != this.pDependsOn.length) {
		throw new caplin.core.Exception("Invalid Configuration");
	}
};

caplin.implement(caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator, caplin.grid.decorator.GridDecorator);
caplin.implement(caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator, caplin.grid.GridViewListener);
caplin.implement(caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator, caplin.grid.GridColumnModelListener);
caplin.extend(caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator, SL4B_AbstractSubscriber);

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype.ready = function() {
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype.setGridView = function(oGridView) {
    this.m_oGridView = oGridView;
    this.m_oGridRowModel = this.m_oGridView.getGridRowModel();
    this.m_sFieldName = this._getFieldNameFromColumnId(oGridView.getGridColumnModel(), this.m_sColumnId);
	this._mapColumnsToSubscriberFields(oGridView.getGridColumnModel());
    oGridView.addGridViewListener(this); 
	oGridView.getGridColumnModel().addColumnModelListener(this);
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._mapColumnsToSubscriberFields = function(oGridColumnModel) {
	this.m_mColumnFieldsMap = [];
	for(var index =0 ;  index < this.pSubscriberFields.length; index++) {
		this.m_mColumnFieldsMap[this.pDependsOn[index]] = this.pSubscriberFields[index];
	}
    this.m_sCurrentVisible = this.pDependsOn[0];
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._getFieldNameFromColumnId = function(oGridColumnModel, sColumnId) {
    var oGridColumn = oGridColumnModel.getColumnById(sColumnId);
	return oGridColumn.getPrimaryFieldName();
	
};


caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype.onAllRowsReceived = function() {
	this._subscribeFieldValues();
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._subscribeFieldValues = function() {
	for (var index = 0; index <  this.m_oGridRowModel.getSize(); index++) {
		var mRowData = this.m_oGridRowModel.getRowData(index);
		if(this._isNewRowAdded(mRowData)) {
			SL4B_Accessor.getRttpProvider().getObject(this, this._getSubjectId(index), this.pSubscriberFields.join(","));			
		}
	}
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._getSubjectId = function(nIndex) {
	return this.m_oGridRowModel.getSubjectId(nIndex);
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._isNewRowAdded = function(mRowData) {
	return mRowData[this.m_sFieldName] == undefined || mRowData[this.m_sFieldName] == null || mRowData[this.m_sFieldName] == "";
};



caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype.recordMultiUpdated =  function(sObjectName, oFieldData) {
	for (var i = 0; i < oFieldData.size();i++) {
		var sFieldName = oFieldData.getFieldName(i);
		var sValue = oFieldData.getFieldValue(i);
		if(!this.m_mFieldValues[sObjectName]) {
			this.m_mFieldValues[sObjectName] = [];
		} 
		if(!this.m_mFieldValues[sObjectName][sFieldName]) {
			this.m_mFieldValues[sObjectName][sFieldName] = sValue;
		}
	}
	SL4B_Accessor.getRttpProvider().removeObject(this, sObjectName);
	this._setFieldValueFromModel(sObjectName, this.m_mColumnFieldsMap[this.m_sCurrentVisible]);
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._setFieldValueFromModel = function(sSubjectId, sModelFieldName) {
	var index = this.m_oGridRowModel.getIndexBySubject(sSubjectId);
	if(this.m_mFieldValues[sSubjectId]) {
		var mRowData = {};
		mRowData[this.m_sFieldName] = this.m_mFieldValues[sSubjectId][sModelFieldName];
		this.m_oGridRowModel.setRowData(index, mRowData);
	}
};


caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype.onColumnsAdded = function(pGridColumns, nStartIndex) {
	for(var index =0 ;  index < pGridColumns.length; index++) {
		var oGridColumn = pGridColumns[index];
		var sColumnName = oGridColumn.getIdentityName()
		if(this._columnDependsOnAddedToGrid(sColumnName)) {
			this._updateAllRowsNotEdited(sColumnName);
		}
	}
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._updateAllRowsNotEdited = function(sColumnName) {
	for (var index = 0; index <  this.m_oGridRowModel.getSize(); index++) {
		var sSubjectId = this._getSubjectId(index);
		if(this.m_mFieldValues[sSubjectId] && !this._isRowEdited(index)) {
			var mRowData = {};
			var sModelFieldName = this.m_mColumnFieldsMap[sColumnName];
			mRowData[this.m_sFieldName] = this.m_mFieldValues[sSubjectId][sModelFieldName];
			this.m_oGridRowModel.setRowData(index, mRowData);
		}
	}
	this.m_sCurrentVisible = sColumnName;
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._isRowEdited = function(nIndex) {
	var sSubjectId = this._getSubjectId(nIndex);
	var sFieldValueFromRowModel = this.m_oGridRowModel.getRowData(nIndex)[this.m_sFieldName];
	if(sFieldValueFromRowModel) {
		var sModelFieldName = this.m_mColumnFieldsMap[this.m_sCurrentVisible];
		return sFieldValueFromRowModel != this.m_mFieldValues[sSubjectId][sModelFieldName];
	}
	return false;
	
};

caplinx.tradelist.view.decorator.ConditionalInitialValueDecorator.prototype._columnDependsOnAddedToGrid = function(sColumnId) {
	for(var index =0 ;  index < this.pDependsOn.length; index++) {
		if(this.pDependsOn[index] == sColumnId) {
			return true;
		}
	}
	return false;
};



