caplin.namespace("caplinx.tradelist.view.handler");

caplin.include("caplin.element.handler.ChangeHandler", true);

caplinx.tradelist.view.handler.AmountChangeHandler = function () {
};

caplin.extend(caplinx.tradelist.view.handler.AmountChangeHandler, caplin.element.handler.ChangeHandler);

/**
 * @private
 */
caplinx.tradelist.view.handler.AmountChangeHandler.prototype.onkeyup = function(oDomEvent, oRenderer, mAttributes) {
	if (oDomEvent.keyCode == 13) {
		this._raiseChangeEvent(oDomEvent, oRenderer, mAttributes);
	}
};

/**
 * @private
 */
caplinx.tradelist.view.handler.AmountChangeHandler.prototype.onblur = function(oDomEvent, oRenderer, mAttributes) {
	this._raiseChangeEvent(oDomEvent, oRenderer, mAttributes);
};


caplinx.tradelist.view.handler.AmountChangeHandler.prototype._validate = function(sValue) {
	return this._isPositive(sValue);
};

caplinx.tradelist.view.handler.AmountChangeHandler.prototype._isPositive = function(sValue) {
	return (sValue > 0) ;
};

caplinx.tradelist.view.handler.AmountChangeHandler.prototype._raiseChangeEvent = function(oDomEvent, oRenderer, mAttributes) {
	var eTarget = oDomEvent.target || oDomEvent.srcElement;
	if(this._isChanged(mAttributes['oldValue'], eTarget)) {
		var sParsedValue = oRenderer.getParsedValue();		
		if(this._validate(sParsedValue)) {
			oRenderer.setValue(sParsedValue);
			oRenderer.raiseEvent(caplinx.tradelist.TradeListConstants.TRADELIST_EDIT_EVENT, {});
		} else {
			//set old value 
			oRenderer.setValue(mAttributes['oldValue']);
		} 
	}
};

caplinx.tradelist.view.handler.AmountChangeHandler.prototype._isChanged = function(oldValue, eTarget) {
	return oldValue != eTarget.value;
};

caplinx.tradelist.view.handler.AmountChangeHandler.prototype.toString = function() {
    return "caplinx.tradelist.view.handler.AmountChangeHandler";
};

caplin.singleton("caplinx.tradelist.view.handler.AmountChangeHandler");
