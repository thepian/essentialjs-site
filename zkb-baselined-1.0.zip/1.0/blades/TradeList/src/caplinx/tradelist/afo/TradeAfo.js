caplin.namespace("caplinx.tradelist.afo");

/**
 * @constructor
 */
caplinx.tradelist.afo.TradeAfo = function(id) {
	this.id = id;
	// grid
	this.InstrumentName = null;
	this.Description = null;
	this.CpnRate = null;
	this.MaturityDate = null;
	this.Amount = null;
	this.BidPrice = null;
	this.AskPrice = null;
	// TODO: extra fields for grid
	this.Benchmark = null;
	this.QuotedSize = null;
	this.Spread = null;
	// form
	this.Side = null;
	this.TradeListName = null;
	this.Account = null;
	this.SettlementDate = null;
	this.TradingType = null;
	this.QuoteResponseTime = null;	
};

