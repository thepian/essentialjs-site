caplin.namespace("caplinx.tradelist");

caplinx.tradelist.TradeListConstants = function()
{
};

caplinx.tradelist.TradeListConstants.NAMESPACE = "namespace";
caplinx.tradelist.TradeListConstants.BUY_CLASS = "buy";
caplinx.tradelist.TradeListConstants.SELL_CLASS = "sell";
caplinx.tradelist.TradeListConstants.SUBMIT_TRADELIST = "submit";
caplinx.tradelist.TradeListConstants.TOGGLE_TRADETYPE = "toggleTradeType";
caplinx.tradelist.TradeListConstants.TRADE_LIST_NAME = "TradeListName";
caplinx.tradelist.TradeListConstants.AMOUNT = "Amount";
caplinx.tradelist.TradeListConstants.TRADELIST_EDIT_EVENT = "editGridRow";
caplinx.tradelist.TradeListConstants.BUTTON_ENABLED = "button";
caplinx.tradelist.TradeListConstants.BUTTON_DISABLED = "button-disabled";
caplinx.tradelist.TradeListConstants.FI_SETTLEMENT_DATES = "fi-t7-settlement-dates";
caplinx.tradelist.TradeListConstants.FI_ACCOUNTS = "fi-accounts";
caplinx.tradelist.TradeListConstants.HIDE_TRADE_CLASS = "hideTradeType";
caplinx.tradelist.TradeListConstants.SHOW_BUY = "show-buy";
caplinx.tradelist.TradeListConstants.SHOW_SELL = "show-sell";
