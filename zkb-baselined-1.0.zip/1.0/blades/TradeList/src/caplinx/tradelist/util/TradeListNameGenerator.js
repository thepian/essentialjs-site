caplin.namespace("caplinx.tradelist.util");

caplinx.tradelist.util.TradeListNameGenerator = function() {
	this.m_nTradeListId = 1;
};

caplinx.tradelist.util.TradeListNameGenerator.prototype.TRADE_LIST_NAME_PREFIX = "New List ";

caplinx.tradelist.util.TradeListNameGenerator.prototype.generate = function() {
	return this.TRADE_LIST_NAME_PREFIX + this.m_nTradeListId++;
};

caplin.singleton("caplinx.tradelist.util.TradeListNameGenerator");