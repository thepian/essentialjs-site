var oConfiguration = SL4B_Accessor.getConfiguration();
oConfiguration.setAttribute("enableautoloading", "false");
oConfiguration.setAttribute("commondomain", "caplin.com");
