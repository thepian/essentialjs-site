Ext.dd.DragDropMgr.stopPropagation=false;
Ext.BLANK_IMAGE_URL = 'source/images/extjs/s.gif';