SL_BC = function(){this.REMOVAL_LIMIT=1000;this.m_bBrowserMapsLeakMemory=(navigator.userAgent.match(/MSIE/)!=undefined);};
SL_BC.prototype.createMap = function(){if(this.m_bBrowserMapsLeakMemory){var fClass=new Function();
fClass.deleteCount=0;return new fClass();
}else 
{return {};
}};
SL_BC.prototype.removeItem = function(B,A){delete B[A];if(this.m_bBrowserMapsLeakMemory){if(B.constructor.deleteCount++>=this.REMOVAL_LIMIT){var mNewMap=this.createMap();
for(sItem in B){mNewMap[sItem]=B[sItem];}B=mNewMap;}}return B;
};
SL_BC=new SL_BC();var SL4B_RttpProviderFactory=function(){};
if(false){function SL4B_RttpProviderFactory(){}
}SL4B_RttpProviderFactory = function(){this.m_oLastProvider=null;};
SL4B_RttpProviderFactory.prototype.createRttpProvider = SL_LQ;function SL_LQ(A){var l_oConfiguration=SL4B_Accessor.getConfiguration();
var l_oProvider=null;
if(l_oConfiguration.getRttpProvider()==SL4B_ScriptLoader.const_APPLET_RTTP_PROVIDER){l_oProvider=new SL4B_AppletRttpProvider(A);}else 
if(l_oConfiguration.getRttpProvider()==SL4B_ScriptLoader.const_OBJECT_RTTP_PROVIDER){alert("Object RTTP Provider support is not available in this version of SL4B");}else 
if(l_oConfiguration.getRttpProvider()==SL4B_ScriptLoader.const_JAVASCRIPT_RTTP_PROVIDER){l_oProvider=SL4B_JavaScriptRttpProvider.createProvider(A,this.m_oLastProvider);}else 
if(l_oConfiguration.getRttpProvider()==SL4B_ScriptLoader.const_TEST_RTTP_PROVIDER){l_oProvider=new SL4B_TestRttpProvider();}if(this.m_oLastProvider!==null){SL4B_WindowEventHandler.removeListener(this.m_oLastProvider);}this.m_oLastProvider=l_oProvider;return l_oProvider;
}
var SL4B_Accessor=function(){};
if(false){function SL4B_Accessor(){}
}SL4B_Accessor = new function(){this.m_oExceptionHandler=null;this.m_oConfiguration=null;this.m_oBrowserAdapter=null;this.m_oCredentialsProvider=null;this.m_oRttpProvider=null;this.m_oUnderlyingRttpProvider=null;this.m_oStatistics=null;this.m_oRttpProviderFactory=new SL4B_RttpProviderFactory();this.setExceptionHandler = function(A){this.m_oExceptionHandler=A;};
this.getExceptionHandler = function(){return this.m_oExceptionHandler;
};
this.getConfiguration = function(){return this.m_oConfiguration;
};
this.setConfiguration = function(A){if(this.m_oConfiguration!=null){throw new SL4B_Exception("The SL4B_Configuration has already been set and cannot be changed.");
}else 
{this.m_oConfiguration=A;}};
this.getBrowserAdapter = function(){if(this.m_oBrowserAdapter==null){throw new SL4B_Exception("BrowserAdapter has not been set");
}return this.m_oBrowserAdapter;
};
this.setBrowserAdapter = function(A){this.m_oBrowserAdapter=A;};
this.getCredentialsProvider = function(){if(this.m_oCredentialsProvider==null){throw new SL4B_Exception("CredentialsProvider has not been set");
}return this.m_oCredentialsProvider;
};
this.setCredentialsProvider = function(A){this.m_oCredentialsProvider=A;};
this.getRttpProvider = function(){if(this.m_oRttpProvider==null){throw new SL4B_Exception("RttpProvider has not been set");
}return this.m_oRttpProvider;
};
this.getUnderlyingRttpProvider = function(){if(this.m_oUnderlyingRttpProvider==null){throw new SL4B_Exception("UnderlyingRttpProvider has not been set");
}return this.m_oUnderlyingRttpProvider;
};
this.setRttpProvider = function(A){this.m_oRttpProvider=A;A.internalInitialise();};
this.setUnderlyingRttpProvider = function(A){this.m_oUnderlyingRttpProvider=A;};
this.getLogger = function(){return SL4B_Logger;
};
this.getRttpProviderFactory = function(){return this.m_oRttpProviderFactory;
};
this.setRttpProviderFactory = function(A){this.m_oRttpProviderFactory=A;};
this.setStatistics = function(A){this.m_oStatistics=A;};
this.getStatistics = function(){if(this.m_oStatistics==null){throw new SL4B_Exception("Statistics has not been set");
}return this.m_oStatistics;
};
this.setCapabilities = function(A){this.m_oCapabilities=A;};
this.getCapabilities = function(){if(this.m_oCapabilities==null){throw new SL4B_Exception("Capabilities has not been set");
}return this.m_oCapabilities;
};
this.resetConfig = function(A){this.m_oConfiguration=null;this.setConfiguration(A);};
this.resetRttpProvider = function(A){this.m_oRttpProvider=A;this.m_oUnderlyingRttpProvider=A;};
};
var SL4B_WindowEventHandler=function(){};
if(false){function SL4B_WindowEventHandler(){}
}SL4B_WindowEventHandler = new function(){this.m_pRegisteredListeners=new Array();this.addListener = function(A){if(typeof A.onLoad=="function"||typeof A.onUnload=="function"){this.m_pRegisteredListeners.push(A);}else 
{throw new SL4B_Exception("addListener: listener object must implement either the onLoad or onUnload methods");
}};
this.removeListener = function(A){for(var i=0,l_nLength=this.m_pRegisteredListeners.length;i<l_nLength;++i){if(this.m_pRegisteredListeners[i]===A){this.m_pRegisteredListeners.splice(i,1);return true;
}}return false;
};
this.initialise = function(){if(SL4B_Accessor.getConfiguration().isAutoLoadingEnabled()){SL4B_Accessor.getBrowserAdapter().addEventListener(window,"load",SL_ND);}SL4B_Accessor.getBrowserAdapter().addEventListener(window,"unload",SL_OC);};
this.onLoad = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"WindowEventHandler.onLoad: method invoked");A=this.getEvent(A);for(var l_nListener=0;l_nListener<this.m_pRegisteredListeners.length;l_nListener++){var l_oListener=this.m_pRegisteredListeners[l_nListener];
if(typeof l_oListener.onLoad=="function"){l_oListener.onLoad(A);}}};
this.onUnload = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"WindowEventHandler.onUnload: method invoked");A=this.getEvent(A);for(var l_nListener=0;l_nListener<this.m_pRegisteredListeners.length;l_nListener++){var l_oListener=this.m_pRegisteredListeners[l_nListener];
if(typeof l_oListener.onUnload=="function"){l_oListener.onUnload(A);}}};
this.getEvent = function(A){return ((typeof A=="undefined") ? ((typeof event!="undefined") ? event : null) : A);
};
};
function SL_ND(A){SL4B_WindowEventHandler.onLoad(A);}
function SL_OC(A){SL4B_WindowEventHandler.onUnload(A);}
var SL4B_StringEncoder=function(){this.m_oCharactersToEncodeRegExp=/[<>&"]/g;this.m_mDecodedToEncodedValueMap={"<":"&lt;", ">":"&gt;", "&":"&amp;", "\"":"&quot;"};};
if(false){function SL4B_StringEncoder(){}
}SL4B_StringEncoder.prototype.encodeValue = function(A){if(this.m_oCharactersToEncodeRegExp.test(A)){return A.replace(this.m_oCharactersToEncodeRegExp,this._encodeCharacter);
}return A;
};
SL4B_StringEncoder.prototype._encodeCharacter = function(A){return SL4B_StringEncoder.m_mDecodedToEncodedValueMap[A];
};
SL4B_StringEncoder=new SL4B_StringEncoder();function SL_AZ(A){var i=function(){};
i.prototype = A.prototype;return new i();
}
var GF_SlidingWindow=function(A){if((A>0)==false){throw new SL4B_Exception("Sliding window cannot be created with a size of "+A);
}this.m_nMaxsize=A;this.clear();};
if(false){function GF_SlidingWindow(){}
}GF_SlidingWindow.prototype.clear = function(){this.m_pBuffer=new Array(this.m_nMaxsize);this.m_nNext=0;this.m_bFilled=false;};
GF_SlidingWindow.prototype.newest = function(){var oNewest=null;
var nIndex=(this.m_nNext+this.m_nMaxsize-1)%this.m_nMaxsize;
if(this.m_bFilled||mIndex<this.m_nNext){oNewest=this.m_pBuffer[nIndex];}return oNewest;
};
GF_SlidingWindow.prototype.oldest = function(){var oOusted=null;
if(this.m_bFilled){oOusted=this.m_pBuffer[this.m_nNext];}return oOusted;
};
GF_SlidingWindow.prototype._hasJustFilled = function(){return this.m_bFilled==false&&this.m_nNext==0;
};
GF_SlidingWindow.prototype.add = function(A){var oOusted=this.oldest();
this.changeWindow(A,oOusted);if(this._hasJustFilled()){this.windowFilled();}return oOusted;
};
GF_SlidingWindow.prototype.changeWindow = function(B,A){this.m_pBuffer[this.m_nNext]=B;this.m_nNext=(this.m_nNext+1)%this.m_nMaxsize;};
GF_SlidingWindow.prototype.windowFilled = function(){this.m_bFilled=true;};
GF_SlidingWindow.prototype.iterate = function(A){var end=this.m_nMaxsize;
if(this.m_bFilled==false){end=this.m_nNext-1;}for(var i=0;i<end;++i){var j=i;
if(this.m_bFilled==true){j=(this.m_nNext+i)%this.m_nMaxsize;}A(this.m_pBuffer[j]);}};
GF_SlidingWindow.prototype.toString = function(){var result=["{sidingwindow start="];
result.push(this.m_nNext);result.push(" values=[");result.push(this.m_pBuffer.join(","));result.push("] }");return result.join("");
};
GF_SlidingWindow.prototype.getLength = function(){return this.m_bFilled ? this.m_nMaxsize : this.m_nNext;
};
var SL4B_DebugLevel=function(){};
if(false){function SL4B_DebugLevel(){}
}SL4B_DebugLevel = new function(){this.CRITICAL="critical";this.ERROR="error";this.NOTIFY="notify";this.WARN="warn";this.INFO="info";this.DEBUG="debug";this.RTTP_FINE="rttp-fine";this.RTTP_FINER="rttp-finer";this.RTTP_FINEST="rttp-finest";this.FINE="fine";this.FINER="finer";this.FINEST="finest";this.const_CRITICAL_INT=0;this.const_ERROR_INT=1;this.const_NOTIFY_INT=2;this.const_WARN_INT=3;this.const_INFO_INT=4;this.const_DEBUG_INT=5;this.const_RTTP_FINE_INT=6;this.const_RTTP_FINER_INT=7;this.const_RTTP_FINEST_INT=8;this.const_FINE_INT=6;this.const_FINER_INT=7;this.const_FINEST_INT=8;this.m_pDebugLevelNames=new Object();this.m_pNumericDebugLevels=new Object();this.addDebugLevel = function(B,A){this.m_pDebugLevelNames[B]=A;this.m_pNumericDebugLevels[A]=B;};
this.getNumericDebugLevel = function(A){var l_nNumericDebugLevel;
if(typeof A=="number"){l_nNumericDebugLevel=A;}else 
if(!isNaN(A)){l_nNumericDebugLevel=parseInt(A);}else 
if(typeof A!="string"||typeof this.m_pNumericDebugLevels[A.toLowerCase()]=="undefined"){throw new SL4B_Exception("Illegal debug level \""+A+"\" specified");
}else 
{l_nNumericDebugLevel=this.m_pNumericDebugLevels[A.toLowerCase()];}return l_nNumericDebugLevel;
};
this.getDebugLevelName = function(A){var l_sDebugLevelName;
if(typeof A=="string"){l_sDebugLevelName=A;}else 
if(typeof A=="number"){l_sDebugLevelName=this.m_pDebugLevelNames[A];}return l_sDebugLevelName;
};
this.addDebugLevel(this.const_CRITICAL_INT,this.CRITICAL);this.addDebugLevel(this.const_ERROR_INT,this.ERROR);this.addDebugLevel(this.const_NOTIFY_INT,this.NOTIFY);this.addDebugLevel(this.const_WARN_INT,this.WARN);this.addDebugLevel(this.const_INFO_INT,this.INFO);this.addDebugLevel(this.const_DEBUG_INT,this.DEBUG);this.addDebugLevel(this.const_RTTP_FINE_INT,this.RTTP_FINE);this.addDebugLevel(this.const_RTTP_FINER_INT,this.RTTP_FINER);this.addDebugLevel(this.const_RTTP_FINEST_INT,this.RTTP_FINEST);this.addDebugLevel(this.const_FINE_INT,this.FINE);this.addDebugLevel(this.const_FINER_INT,this.FINER);this.addDebugLevel(this.const_FINEST_INT,this.FINEST);};
var SL4B_Logger=function(){};
if(false){function SL4B_Logger(){}
}SL4B_Logger = new function(){this.const_HTML="html";this.const_ABOUT_BLANK="about:blank";this.m_hDebugConsole=null;this.m_bDebugConsoleOpening=false;this.m_bDebugConsoleOpened=false;this.m_bClosing=false;this.m_pMessageQueue=new Array();this.m_oSlidingLogMessageWindow=new GF_SlidingWindow(200);this.m_pAlertMessageQueue=new Array();this.m_bAlertDisplayed=false;this.m_nConfiguredDebugLevel=-1;this.m_oBrowserAdapter=null;this.m_pMessageListeners=new Array();this.m_pParameterRegularExpressions=new Array(/\{0\}/g,/\{1\}/g,/\{2\}/g,/\{3\}/g,/\{4\}/g,/\{5\}/g,/\{6\}/g,/\{7\}/g);this.replaceMessageParameters = function(C,A,B){var l_nNumberOfParameters=A.length;
for(var l_nParam=B;l_nParam<l_nNumberOfParameters;++l_nParam){C=C.replace(this.m_pParameterRegularExpressions[(l_nParam-B)],A[l_nParam]);}return C;
};
this.addMessageListener = function(A){if(A==null||typeof A.logMessage!="function"){throw new SL4B_Exception("SL4B_Logger.addMessageListener: specified listener is null or does not implement a logMessage() method");
}this.m_pMessageListeners.push(A);};
this.clearMessageListeners = function(){this.m_pMessageListeners=new Array();};
this.log = function(B,A){this.m_oSlidingLogMessageWindow.add(this.log.arguments);if(typeof (B)=="number"&&this.m_nConfiguredDebugLevel!=-1){if(this.m_nConfiguredDebugLevel>=B){this.printMessage(this.replaceMessageParameters(A,this.log.arguments,2),B);}}else 
{
try {if(this.mustDebug(B)){this.printMessage(this.replaceMessageParameters(A,this.log.arguments,2),B);}}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
}};
this.getRecentLogMessages = function(){var pLogMessages=[];
var oThis=this;
this.m_oSlidingLogMessageWindow.iterate(function(A){var sMsg=SL4B_DebugLevel.getDebugLevelName(A[0])+": "+oThis.replaceMessageParameters(A[1],A,2);
pLogMessages.push(sMsg);});return pLogMessages;
};
this.logConnectionMessage = function(A){arguments[0]=(A ? SL4B_DebugLevel.const_NOTIFY_INT : SL4B_DebugLevel.const_INFO_INT);arguments[1]="[CONNECTION] "+arguments[1];this.log.apply(this,arguments);};
this.alert = function(A){var l_sFormattedMessage=this.replaceMessageParameters(A,this.alert.arguments,1);
this.printMessage(l_sFormattedMessage);
try {if(this.mustDebug(SL4B_DebugLevel.NOTIFY)){this.synchronizedAlert(l_sFormattedMessage);}}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
};
this.synchronizedAlert = function(A){this.m_pAlertMessageQueue.push(A);if(!this.m_bAlertDisplayed){this.m_bAlertDisplayed=true;while(this.m_pAlertMessageQueue.length>0){alert(this.m_pAlertMessageQueue.shift());}this.m_bAlertDisplayed=false;}};
this.printMessage = function(B,A){A=(A===undefined ? SL4B_DebugLevel.INFO : A);var l_sFormattedMessage=SL_HK.createDateStamp()+" - "+SL4B_DebugLevel.getDebugLevelName(A)+":   "+B;
this.m_pMessageQueue.push(l_sFormattedMessage);if(this.m_oBrowserAdapter==null){this.m_oBrowserAdapter=SL4B_Accessor.getBrowserAdapter();}if(this.m_oBrowserAdapter!=null){this.m_oBrowserAdapter.dump(l_sFormattedMessage+"\n");}for(var l_nListener=0,l_nLength=this.m_pMessageListeners.length;l_nListener<l_nLength;++l_nListener){this.m_pMessageListeners[l_nListener].logMessage(B,A);}
try {if(this.m_bDebugConsoleOpened){this.printMessagesToDebugConsole();}}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
};
this.printMessagesToDebugConsole = function(){while(this.m_pMessageQueue.length>0){var l_sNextMessage=this.m_pMessageQueue.shift();
this.printMessageToDebugConsole(l_sNextMessage);}};
this.printMessageToDebugConsole = function(A){if(this.m_hDebugConsole!=null){
try {this.m_hDebugConsole.GF_LogMessage(A);}catch(e){}
}};
this.useHtmlDebugWindow = function(){return (SL4B_Accessor.getConfiguration().getDebugWindowType()==this.const_HTML);
};
this.openDebugConsoleOnStartUp = function(A){if((A&&this.useHtmlDebugWindow())||(!A&&!this.useHtmlDebugWindow())){if(this.mustDebug(SL4B_DebugLevel.WARN)){this.openDebugConsole();}}};
this.getDebugWindowName = function(){return "_sl4b_debug_"+SL4B_Accessor.getConfiguration().getFrameId();
};
this.openDebugConsole = function(){if(!this.m_bDebugConsoleOpening&&!this.m_bClosing){this.m_bDebugConsoleOpening=true;var l_sDomain=SL4B_Accessor.getConfiguration().getCommonDomain();
var l_sDebugWindowName=this.getDebugWindowName();
var l_sDebugWindowParameters="height=400,width=600,status=no,toolbar=no,menubar=no,location=no,resizable=yes,scrollbars=yes";
if(this.useHtmlDebugWindow()){var l_sUrl=SL4B_ScriptLoader.getRootUrl()+"sl4b/logger/log-window.html?level="+SL4B_Accessor.getConfiguration().getDebugLevel()+((l_sDomain!=null) ? "&domain="+l_sDomain : "");
this.m_hDebugConsole=window.open(l_sUrl,l_sDebugWindowName,l_sDebugWindowParameters);}else 
{this.m_hDebugConsole=window.open("",l_sDebugWindowName,l_sDebugWindowParameters);var l_sHtml="<html><head><title>SL4B Debug Log [Debug level "+SL4B_StringEncoder.encodeValue(SL4B_Accessor.getConfiguration().getDebugLevel())+"]</title>";
l_sHtml+="<style type=\"text/css\"> body {font-family:Verdana;background-color:Black;color:#00ff00;} table {font-size:10px;}</style></head>";l_sHtml+="<table width='100%'><tbody id=\"tblMessageLog\" cellpadding=\"0\" cellspacing=\"0\"></tbody></table>";l_sHtml+="<scr"+"ipt type=\"text/javascript\" src=\""+SL4B_ScriptLoader.getRootUrl()+"sl4b/logger/log-window.js\"></scr"+"ipt>";l_sHtml+="</body></html>";
try {var l_oDocument=this.m_hDebugConsole.document;
l_oDocument.open();l_oDocument.write(l_sHtml);l_oDocument.close();}catch(e){SL4B_Logger.alert("Your browser appears to have a popup blocker enabled which is preventing the SL4B debug console window from opening.\nPlease disable the popup blocker for this web site to view the console.");}
}}};
this.closeDebugConsole = function(){if(this.m_hDebugConsole!=null){this.m_bClosing=true;this.m_hDebugConsole.close();}};
this.debugConsoleOpened = function(){this.m_bDebugConsoleOpened=true;this.printMessageToDebugConsole("Debug Console for frame \""+SL4B_Accessor.getConfiguration().getFrameId()+"\"");this.printMessagesToDebugConsole();SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"Logger.debugConsoleOpened: Adding logger as listener for close event.");
try {SL4B_WindowEventHandler.addListener(this);}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
};
this.debugConsoleClosed = function(){this.m_bDebugConsoleOpened=false;this.m_hDebugConsole=null;};
this.mustDebug = function(A){return (this.getConfiguredDebugLevel()>=SL4B_DebugLevel.getNumericDebugLevel(A));
};
this.getConfiguredDebugLevel = function(){if(this.m_nConfiguredDebugLevel==-1){
try {this.m_nConfiguredDebugLevel=SL4B_DebugLevel.getNumericDebugLevel(SL4B_Accessor.getConfiguration().getDebugLevel());}catch(e){this.m_nConfiguredDebugLevel=SL4B_DebugLevel.getNumericDebugLevel(SL4B_DebugLevel.ERROR);}
}return this.m_nConfiguredDebugLevel;
};
this.onUnload = function(A){if(A!=null&&typeof A!="undefined"&&!(A.ctrlKey&&A.altKey)){
try {if(this.m_hDebugConsole){this.m_hDebugConsole.close();}}catch(e){}
}};
};
SL_HK = new function(){this.m_pMonths=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");this.m_pZeroPadding=new Array("","0","00","000");this.createDateStamp = function(){var l_oNow=new Date();
var l_nTimezoneOffset=l_oNow.getTimezoneOffset();
var l_nAbsoluteTimezoneOffset=Math.abs(l_nTimezoneOffset);
var l_sOffsetSign=(l_nTimezoneOffset<=0) ? "+" : "-";
var l_sOffsetHours=this.padZeros(Math.floor(Math.abs(l_nAbsoluteTimezoneOffset)/60),2);
var l_sOffsetMinutes=this.padZeros(l_nAbsoluteTimezoneOffset%60,2);
return this.m_pMonths[l_oNow.getMonth()]+" "+this.padZeros(l_oNow.getDate(),2)+" "+this.padZeros(l_oNow.getHours(),2)+":"+this.padZeros(l_oNow.getMinutes(),2)+":"+this.padZeros(l_oNow.getSeconds(),2)+"."+this.padZeros(l_oNow.getMilliseconds(),3)+" "+l_sOffsetSign+l_sOffsetHours+l_sOffsetMinutes;
};
this.padZeros = function(B,A){var l_nValueLength=(B+"").length;
var l_nDifference=A-l_nValueLength;
return this.m_pZeroPadding[l_nDifference]+B;
};
};
var SL4B_LogMessageListener=function(){};
if(false){function SL4B_LogMessageListener(){}
}SL4B_LogMessageListener = function(){};
SL4B_LogMessageListener.prototype.logMessage = function(A){};
var SL4B_ConnectionMethod=function(){};
if(false){function SL4B_ConnectionMethod(){}
}SL4B_ConnectionMethod = function(D,C,A,B){this.m_sName=D;this.m_sConnectionClass=A;this.m_nRTTPType=C;this.m_bIsPolling=B;};
SL4B_ConnectionMethod.AllMethods={};SL4B_ConnectionMethod.prototype.createConnection = function(B,A){var oClass=window[this.m_sConnectionClass];
var oInstance=new oClass(B,A);
return oInstance;
};
SL4B_ConnectionMethod.prototype.isStreaming = function(){return !this.m_bIsPolling;
};
SL4B_ConnectionMethod.prototype.isPolling = function(){return this.m_bIsPolling;
};
SL4B_ConnectionMethod.prototype.getRTTPType = function(){return this.m_nRTTPType;
};
SL4B_ConnectionMethod.prototype.toString = function(){return this.m_sName;
};
SL4B_ConnectionMethod.XHR_STREAMING=new SL4B_ConnectionMethod("XHR Streaming",2,"SL4B_Type2Connection",false);SL4B_ConnectionMethod.POLLING=new SL4B_ConnectionMethod("Polling",3,"SL4B_Type3Connection",true);SL4B_ConnectionMethod.MULTIPART_REPLACE=new SL4B_ConnectionMethod("XHR Multipart",4,"SL4B_Type4Connection",false);SL4B_ConnectionMethod.FOREVER_FRAME=new SL4B_ConnectionMethod("Forever Frame",5,"SL4B_Type5Connection",false);SL4B_ConnectionMethod.HTML_FILE=new SL4B_ConnectionMethod("HTML File",5,"SL4B_Type6Connection",false);SL4B_ConnectionMethod.AllMethods[2]=SL4B_ConnectionMethod.XHR_STREAMING;SL4B_ConnectionMethod.AllMethods[3]=SL4B_ConnectionMethod.POLLING;SL4B_ConnectionMethod.AllMethods[4]=SL4B_ConnectionMethod.MULTIPART_REPLACE;SL4B_ConnectionMethod.AllMethods[5]=SL4B_ConnectionMethod.FOREVER_FRAME;SL4B_ConnectionMethod.AllMethods[6]=SL4B_ConnectionMethod.HTML_FILE;SL4B_Browser={};SL4B_Browser.UNKNOWN="UNKNOWN";SL4B_Browser.MSIE="MSIE";SL4B_Browser.SAFARI="Safari";SL4B_Browser.FIREFOX="Firefox";SL4B_Browser.CHROME="Chrome";SL4B_Browser.AllBrowsers=[];SL4B_Browser.AllBrowsers.push(SL4B_Browser.MSIE);SL4B_Browser.AllBrowsers.push(SL4B_Browser.SAFARI);SL4B_Browser.AllBrowsers.push(SL4B_Browser.FIREFOX);SL4B_Browser.AllBrowsers.push(SL4B_Browser.CHROME);SL4B_Browser.isKnownBrowser = function(A){for(var i=0,len=SL4B_Browser.AllBrowsers.length;i<len;++i){if(SL4B_Browser.AllBrowsers[i]===A){return true;
}}return false;
};
var SL4B_AbstractBrowserAdapter=function(){};
if(false){function SL4B_AbstractBrowserAdapter(){}
}SL4B_AbstractBrowserAdapter.prototype.isFirefox = function(){throw new SL4B_Error("isFirefox method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.isInternetExplorer = function(){throw new SL4B_Error("isInternetExplorer method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.getBrowserVersion = function(){throw new SL4B_Error("getBrowserVersion method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.getElementById = function(A){return document.getElementById(A);
};
SL4B_AbstractBrowserAdapter.prototype.getFrameWindow = function(A){throw new SL4B_Error("getFrameWindow method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.getPollingConnectionTypes = function(){throw new SL4B_Error("getPollingConnectionTypes method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.getStreamingConnectionTypes = function(){throw new SL4B_Error("getStreamingConnectionTypes method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.addEventListener = function(A,C,B){throw new SL4B_Error("addEventListener method not implemented");
};
SL4B_AbstractBrowserAdapter.prototype.dump = function(A){};
SL4B_AbstractBrowserAdapter.prototype.convertExceptionToString = function(A){var l_sValue=null;
if(typeof A.getClass!="undefined"){l_sValue=A.getClass()+": "+A.getMessage();}else 
if(typeof A.stack!="undefined"){l_sValue=A.name+": "+A.message+" ("+A.fileName+" [line "+A.lineNumber+"])";}else 
if(typeof A.description!="undefined"){l_sValue=A.name+": "+A.message;}else 
if(typeof A.toString!="undefined"){l_sValue=A.toString();}else 
{l_sValue=A+"";}return l_sValue;
};
var SL4B_BrowserAdapter=function(){};
if(false){function SL4B_BrowserAdapter(){}
}SL4B_BrowserAdapter = function(){this.bIsIE=false;this.bIsChrome=false;this.bIsSafari=false;this.bIsFirefox=false;this.oBrowser=SL4B_Browser.UNKNOWN;this.sBrowserVersion=SL4B_BrowserAdapter.VALUE_NOT_KNOWN;this._detectBrowsers(navigator);if(this.isInternetExplorer()==true){if(window.ActiveXObject){
try {this.m_oTracer.name="SL4B";}catch(e){}
}}};
SL4B_BrowserAdapter.prototype = new SL4B_AbstractBrowserAdapter;SL4B_BrowserAdapter.VALUE_NOT_KNOWN="UNKNOWN";SL4B_BrowserAdapter.prototype._resetBrowserDetection = function(){this.bIsIE=false;this.bIsChrome=false;this.bIsSafari=false;this.bIsFirefox=false;this.oBrowser=SL4B_Browser.UNKNOWN;this.sBrowserVersion=SL4B_BrowserAdapter.VALUE_NOT_KNOWN;};
SL4B_BrowserAdapter.prototype._detectBrowsers = function(A){this.bIsIE=(A.userAgent.toLowerCase().match(/msie/)!=null);this.bIsChrome=(A.userAgent.toLowerCase().match(/chrome/)!=null);if(this.bIsChrome==false){this.bIsSafari=(A.userAgent.toLowerCase().match(/safari/)!=null);this.bIsFirefox=(A.userAgent.toLowerCase().match(/firefox/)!=null);}this.oBrowser=this.getBrowser();this.sBrowserVersion=this._getBrowserVersion(A);};
SL4B_BrowserAdapter.prototype._getBrowserVersion = function(A){var sVersion=SL4B_Browser.UNKNOWN;
if(this.isInternetExplorer()==true){var l_sFullDescription=A.userAgent;
var l_nStartPos=l_sFullDescription.indexOf(this.getBrowser().toString()+" ");
sVersion=l_sFullDescription.substring(l_nStartPos+5,l_sFullDescription.indexOf(";",l_nStartPos));sVersion=sVersion.toLowerCase();}else 
if(this.isSafari()==true){var l_sFullDescription=A.userAgent;
var oRegMatch=new RegExp("(Version\\/)([\\d\\.]*)");
var oMatch=l_sFullDescription.match(oRegMatch);
if(oMatch!=null&&oMatch.length==3){sVersion=oMatch[2];}}else 
if(this.isFirefox()==true||this.isChrome()==true){sVersion=A.vendorSub;if(!sVersion||sVersion==""){var l_sFullDescription=A.userAgent;
var oRegMatch=new RegExp("("+this.getBrowser()+"\\/)([\\d\\.]*)");
var oMatch=l_sFullDescription.match(oRegMatch);
if(oMatch!=null&&oMatch.length==3){sVersion=oMatch[2];}}}return sVersion;
};
SL4B_BrowserAdapter.prototype.getBrowser = function(){if(this.oBrowser==SL4B_Browser.UNKNOWN){if(this.isInternetExplorer()==true){this.oBrowser=SL4B_Browser.MSIE;}else 
if(this.isSafari()==true){this.oBrowser=SL4B_Browser.SAFARI;}else 
if(this.isFirefox()==true){this.oBrowser=SL4B_Browser.FIREFOX;}else 
if(this.isChrome()==true){this.oBrowser=SL4B_Browser.CHROME;}}return this.oBrowser;
};
SL4B_BrowserAdapter.prototype.isFirefox = function(){return this.bIsFirefox;
};
SL4B_BrowserAdapter.prototype.isSafari = function(){return this.bIsSafari;
};
SL4B_BrowserAdapter.prototype.isInternetExplorer = function(){return this.bIsIE;
};
SL4B_BrowserAdapter.prototype.isChrome = function(){return this.bIsChrome;
};
SL4B_BrowserAdapter.prototype.getBrowserVersion = function(){return this.sBrowserVersion;
};
SL4B_BrowserAdapter.prototype.addEventListener = function(A,C,B){if(A.addEventListener){A.addEventListener(C,B,false);}else 
if(A.attachEvent){A.attachEvent("on"+C,B);}else 
{throw new SL4B_Error("addEventListener failed");
}};
SL4B_BrowserAdapter.prototype.dump = function(A){if(window.console&&window.console.log){window.console.log(A);}else 
if(this.isInternetExplorer()==true){if(this.m_oTracer){this.m_oTracer.trace(A.substr(0,256));}}else 
if(dump){dump(A);}else 
{throw new SL4B_Error("dump failed");
}};
SL4B_BrowserAdapter.prototype.getFrameWindow = function(A){var oIFrameElement=null;
if(this.isInternetExplorer()==true){oIFrameElement=document.frames[A];oIFrameElement=((typeof oIFrameElement=="undefined") ? null : oIFrameElement);}else 
{oIFrameElement=this.getElementById(A);oIFrameElement=((oIFrameElement==null) ? null : oIFrameElement.contentWindow);}return oIFrameElement;
};
SL4B_BrowserAdapter.prototype.getPollingConnectionTypes = function(){return [SL4B_ConnectionMethod.POLLING];
};
SL4B_BrowserAdapter.prototype.getStreamingConnectionTypes = function(){var l_pStreamingConnectionTypes=[SL4B_ConnectionMethod.FOREVER_FRAME];
if(this.isInternetExplorer()==true){l_pStreamingConnectionTypes=[SL4B_ConnectionMethod.HTML_FILE,SL4B_ConnectionMethod.FOREVER_FRAME];}else 
if(this.isFirefox()==true){l_pStreamingConnectionTypes=[SL4B_ConnectionMethod.MULTIPART_REPLACE,SL4B_ConnectionMethod.FOREVER_FRAME];}return l_pStreamingConnectionTypes;
};
SL4B_Accessor.setBrowserAdapter(new SL4B_BrowserAdapter());var SL4B_FrameRegistrarAccessor = new function(){this.m_oFrameRegistrar=null;this.setCommonContainerDomain = function(A){SL4B_Accessor.getLogger().log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SL4B_FrameRegistrarAccessor.setCommonContainerDomain: domain \"{0}\"",A);var l_sContainerFrameLocation=SL4B_Accessor.getConfiguration().getContainerFrameLocation();
var l_oContainerFrame=eval(l_sContainerFrameLocation);
if(window!=l_oContainerFrame){
try {l_oContainerFrame.document.domain=A;SL4B_Accessor.getLogger().log(SL4B_DebugLevel.const_INFO_INT,"SL4B_FrameRegistrarAccessor.setCommonContainerDomain: container frame domain set to \"{0}\"",A);}catch(e){SL4B_Accessor.getLogger().log(SL4B_DebugLevel.const_INFO_INT,"SL4B_FrameRegistrarAccessor.setCommonContainerDomain: failed to set container frame domain to \"{0}\"",A);}
}else 
{SL4B_Accessor.getLogger().log(SL4B_DebugLevel.const_INFO_INT,"SL4B_FrameRegistrarAccessor.setCommonContainerDomain: container frame domain was not set, this page is the container frame");}};
this.getFrameRegistrar = function(){if(this.m_oFrameRegistrar==null){var l_sContainerFrameLocation=SL4B_Accessor.getConfiguration().getContainerFrameLocation();
var l_oContainerFrame=eval(l_sContainerFrameLocation);
if(typeof l_oContainerFrame.SL4B_FrameRegistrar=="undefined"){l_oContainerFrame.SL4B_FrameRegistrar=new SL_KS();}this.m_oFrameRegistrar=l_oContainerFrame.SL4B_FrameRegistrar;}return this.m_oFrameRegistrar;
};
this.setMasterFrame = function(A){this.getFrameRegistrar().setMasterFrame(A);};
this.removeMasterFrame = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"FrameRegistrarAccessor.removeMasterFrame");this.getFrameRegistrar().removeMasterFrame();};
this.registerSlaveFrame = function(B,A){this.getFrameRegistrar().registerSlaveFrame(B,A);};
this.deregisterSlaveFrame = function(A){this.getFrameRegistrar().deregisterSlaveFrame(A);};
};
function SL_KS(){this.m_oMasterFrameRttpProvider=null;this.m_pRegisteredSlaveFrames=new Object();this.setMasterFrame = function(A){this.m_oMasterFrameRttpProvider=A;for(l_sFrameId in this.m_pRegisteredSlaveFrames){var l_oSlave=this.m_pRegisteredSlaveFrames[l_sFrameId];
l_oSlave.masterRegistered(this.m_oMasterFrameRttpProvider);}};
this.removeMasterFrame = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"FrameRegistrarAccessor.removeMasterFrame");this.m_oMasterFrameRttpProvider=null;for(l_sFrameId in this.m_pRegisteredSlaveFrames){var l_oSlave=this.m_pRegisteredSlaveFrames[l_sFrameId];
l_oSlave.masterClosing();}};
this.registerSlaveFrame = function(B,A){this.m_pRegisteredSlaveFrames[B]=A;if(this.m_oMasterFrameRttpProvider!=null){A.masterRegistered(this.m_oMasterFrameRttpProvider);}};
this.deregisterSlaveFrame = function(A){delete (this.m_pRegisteredSlaveFrames[A]);};
}
if(false){function SL4B_RttpUtils(){}
}SL4B_RttpUtils = function(){};
SL4B_RttpUtils.prototype.createFieldListForContainer = function(A,C,D,B){if(A===null||A===undefined){A="default";}var l_sCombinedFieldList="ctrid="+A;
if(D!==undefined&&B!==undefined){l_sCombinedFieldList+=",ctrstart="+D+",ctrend="+B;}if(C&&C!=""){l_sCombinedFieldList+=","+C;}return l_sCombinedFieldList;
};
SL4B_RttpUtils.prototype.getListener = function(A){var l_sListener;
if(A==null||typeof A=="undefined"){throw new SL4B_Exception("Subscriber cannot be null or undefined");
}else 
if(typeof A=="object"&&A.getIdentifier!==undefined){l_sListener=A.getIdentifier();}else 
if(typeof A=="string"){l_sListener=A;}else 
{throw new SL4B_Exception("Illegal Subscriber \""+A+"\" defined");
}return l_sListener;
};
SL4B_RttpUtils=new SL4B_RttpUtils();var SL4B_AbstractRttpProvider=function(){};
if(false){function SL4B_AbstractRttpProvider(){}
}SL4B_AbstractRttpProvider = function(){this.m_pConnectionListeners=new Array();this.m_oLiberatorConfiguration=null;this.m_fOnBeforeCloseEventHandler=null;};
SL4B_AbstractRttpProvider.prototype.const_OK_CONNECTION_EVENT = "connectionOk";SL4B_AbstractRttpProvider.prototype.const_RECONNECTION_OK_CONNECTION_EVENT = "reconnectionOk";SL4B_AbstractRttpProvider.prototype.const_WARNING_CONNECTION_EVENT = "connectionWarning";SL4B_AbstractRttpProvider.prototype.const_ERROR_CONNECTION_EVENT = "connectionError";SL4B_AbstractRttpProvider.prototype.const_INFO_CONNECTION_EVENT = "connectionInfo";SL4B_AbstractRttpProvider.prototype.const_ATTEMPT_CONNECTION_EVENT = "connectionAttempt";SL4B_AbstractRttpProvider.prototype.const_FILE_DOWNLOAD_ERROR_CONNECTION_EVENT = "fileDownloadError";SL4B_AbstractRttpProvider.prototype.const_LOGIN_OK_CONNECTION_EVENT = "loginOk";SL4B_AbstractRttpProvider.prototype.const_LOGIN_ERROR_CONNECTION_EVENT = "loginError";SL4B_AbstractRttpProvider.prototype.const_CREDENTIALS_RETRIEVED_CONNECTION_EVENT = "credentialsRetrieved";SL4B_AbstractRttpProvider.prototype.const_CREDENTIALS_PROVIDER_SESSION_ERROR_CONNECTION_EVENT = "credentialsProviderSessionError";SL4B_AbstractRttpProvider.prototype.const_MESSAGE_CONNECTION_EVENT = "message";SL4B_AbstractRttpProvider.prototype.const_SOURCE_MESSAGE_CONNECTION_EVENT = "sourceMessage";SL4B_AbstractRttpProvider.prototype.const_SERVICE_MESSAGE_CONNECTION_EVENT = "serviceMessage";SL4B_AbstractRttpProvider.prototype.const_SESSION_EJECTED_CONNECTION_EVENT = "sessionEjected";SL4B_AbstractRttpProvider.prototype.const_STATISTICS_CONNECTION_EVENT = "statistics";SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER=" ";SL4B_AbstractRttpProvider.prototype.getListener = SL_AM;SL4B_AbstractRttpProvider.prototype.internalInitialise = SL_MD;SL4B_AbstractRttpProvider.prototype.initialise = function(){throw new SL4B_Error("initialise method not implemented");
};
SL4B_AbstractRttpProvider.prototype.internalStop = SL_PY;SL4B_AbstractRttpProvider.prototype.stop = SL_CW;SL4B_AbstractRttpProvider.prototype.register = SL_IQ;SL4B_AbstractRttpProvider.prototype.registerSlave = SL_AD;SL4B_AbstractRttpProvider.prototype.deregisterSlave = SL_EH;SL4B_AbstractRttpProvider.prototype.getLiberatorConfiguration = function(){return this.m_oLiberatorConfiguration;
};
SL4B_AbstractRttpProvider.prototype.connect = function(){throw new SL4B_Error("connect method not implemented");
};
SL4B_AbstractRttpProvider.prototype.reconnect = function(){throw new SL4B_Error("reconnect method not implemented");
};
SL4B_AbstractRttpProvider.prototype.connected = function(){
try {SL4B_Accessor.getCredentialsProvider().getCredentials(this);}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
};
SL4B_AbstractRttpProvider.prototype.login = function(A,B){throw new SL4B_Error("login method not implemented");
};
SL4B_AbstractRttpProvider.prototype.loggedIn = SL_PJ;SL4B_AbstractRttpProvider.prototype.credentialsRetrieved = SL_LP;SL4B_AbstractRttpProvider.prototype.getObject = function(C,B,A){throw new SL4B_Error("getObject method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getObjects = function(C,A,B){throw new SL4B_Error("getObjects method not implemented");
};
SL4B_AbstractRttpProvider.prototype.removeObject = function(C,B,A){throw new SL4B_Error("removeObject method not implemented");
};
SL4B_AbstractRttpProvider.prototype.removeObjects = function(C,A,B){throw new SL4B_Error("removeObjects method not implemented");
};
SL4B_AbstractRttpProvider.prototype.removeSubscriber = function(A){throw new SL4B_Error("removeSubscriber method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getFilteredObject = function(E,C,B,D,A){this.getObject(E,C,this.createFieldListWithFilter(B,D,A));};
SL4B_AbstractRttpProvider.prototype.getFilteredObjects = function(E,A,C,D,B){this.getObjects(E,A,this.createFieldListWithFilter(C,D,B));};
SL4B_AbstractRttpProvider.prototype.removeFilteredObject = function(E,C,B,D,A){this.removeObject(E,C,this.createFieldListWithFilter(B,D,A));};
SL4B_AbstractRttpProvider.prototype.removeFilteredObjects = function(E,A,C,D,B){this.removeObjects(E,A,this.createFieldListWithFilter(C,D,B));};
SL4B_AbstractRttpProvider.prototype.createFieldListWithFilter = function(B,C,A){if(typeof C=="undefined"||C==null){C=true;}var l_sCombinedFieldList=(C ? "filter=" : "imagefilter=")+B;
if(A&&A!=""){l_sCombinedFieldList+=","+A;}return l_sCombinedFieldList;
};
SL4B_AbstractRttpProvider.prototype.createFieldListForAutoDirectory = function(B,C,A){var l_sCombinedFieldList="auto=1,monitor=1";
if(B&&B!=""){l_sCombinedFieldList+=","+this.createFieldListWithFilter(B,C,A);}else 
if(A&&A!=""){l_sCombinedFieldList+=","+A;}return l_sCombinedFieldList;
};
SL4B_AbstractRttpProvider.prototype.createFieldListForContainer = function(A,C,D,B){return SL4B_RttpUtils.createFieldListForContainer(A,C,D,B);
};
SL4B_AbstractRttpProvider.prototype.getFilteredNewsHeadline = function(C,B,A){this.getFilteredObject(C,B,A,true,A);};
SL4B_AbstractRttpProvider.prototype.getFilteredNewsHeadlines = function(C,A,B){this.getFilteredObjects(C,A,B,true,B);};
SL4B_AbstractRttpProvider.prototype.removeFilteredNewsHeadline = function(C,B,A){this.removeFilteredObject(C,B,A,true,A);};
SL4B_AbstractRttpProvider.prototype.removeFilteredNewsHeadlines = function(C,A,B){this.removeFilteredObjects(C,A,B,true,B);};
SL4B_AbstractRttpProvider.prototype.getAutoDirectory = function(E,D,A,B,C){throw new SL4B_Error("getAutoDirectory method not implemented");
};
SL4B_AbstractRttpProvider.prototype.removeAutoDirectory = function(E,D,A,B,C){throw new SL4B_Error("removeAutoDirectory method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getContainer = function(E,A,C,D,B){throw new SL4B_Error("getContainer method not implemented");
};
SL4B_AbstractRttpProvider.prototype.setContainerWindow = function(B,C,A){throw new SL4B_Error("setContainerWindow method not implemented");
};
SL4B_AbstractRttpProvider.prototype.clearContainerWindow = function(A){throw new SL4B_Error("clearContainerWindow method not implemented");
};
SL4B_AbstractRttpProvider.prototype.removeContainer = function(B,A){throw new SL4B_Error("removeContainer method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getObjectType = function(B,A){throw new SL4B_Error("getObjectType method not implemented");
};
SL4B_AbstractRttpProvider.prototype.setThrottleObject = function(A,B){throw new SL4B_Error("setThrottleObject method not implemented");
};
SL4B_AbstractRttpProvider.prototype.setThrottleObjects = function(A,B){throw new SL4B_Error("setThrottleObjects method not implemented");
};
SL4B_AbstractRttpProvider.prototype.setGlobalThrottle = function(A){throw new SL4B_Error("setGlobalThrottle method not implemented");
};
SL4B_AbstractRttpProvider.prototype.disableWTStatsTimeout = function(A){throw new SL4B_Error("disableWTStatsTimeout method not implemented");
};
SL4B_AbstractRttpProvider.prototype.clearObjectListeners = function(B,A){throw new SL4B_Error("clearObjectListeners method not implemented");
};
SL4B_AbstractRttpProvider.prototype.blockObjectListeners = function(B,A){throw new SL4B_Error("blockObjectListeners method not implemented");
};
SL4B_AbstractRttpProvider.prototype.unblockObjectListeners = function(B,A){throw new SL4B_Error("unblockObjectListeners method not implemented");
};
SL4B_AbstractRttpProvider.prototype.createObject = function(A,B){throw new SL4B_Error("createObject method not implemented");
};
SL4B_AbstractRttpProvider.prototype.contribObject = function(C,A,B){throw new SL4B_Error("contribObject method not implemented");
};
SL4B_AbstractRttpProvider.prototype.deleteObject = function(A){throw new SL4B_Error("deleteObject method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getFieldNames = function(){throw new SL4B_Error("getFieldNames method not implemented");
};
SL4B_AbstractRttpProvider.prototype.logout = function(){throw new SL4B_Error("logout method not implemented");
};
SL4B_AbstractRttpProvider.prototype.debug = function(B,A){throw new SL4B_Error("debug method not implemented");
};
SL4B_AbstractRttpProvider.prototype.setDebugLevel = function(A){throw new SL4B_Error("setDebugLevel method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getVersion = function(){throw new SL4B_Error("getVersion method not implemented");
};
SL4B_AbstractRttpProvider.prototype.getVersionInfo = function(){throw new SL4B_Error("getVersionInfo method not implemented");
};
SL4B_AbstractRttpProvider.prototype.addConnectionListener = SL_FH;SL4B_AbstractRttpProvider.prototype.removeConnectionListener = SL_FB;SL4B_AbstractRttpProvider.prototype.notifyConnectionListeners = SL_NB;SL4B_AbstractRttpProvider.prototype.onUnload = SL_OE;function SL_AM(A){return SL4B_RttpUtils.getListener(A);
}
function SL_MD(){this.initialise();this.register();
try {SL4B_WindowEventHandler.addListener(this);}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
if(!SL4B_Accessor.getConfiguration().isNoBrowserStatus()){this.addConnectionListener(new SL_DX());}}
function SL_PY(){this.stop();if(this.m_fOnBeforeCloseEventHandler!=null){this.m_fOnBeforeCloseEventHandler();}}
function SL_CW(){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractRttpProvider.stop");this.logout();
try {SL4B_FrameRegistrarAccessor.removeMasterFrame();}catch(e){}
}
function SL_IQ(){
try {SL4B_FrameRegistrarAccessor.setMasterFrame(this);}catch(e){}
SL4B_SubscriptionManagerAccessor.addSubscriptionManager(SL4B_SubscriptionManager);}
function SL_AD(B,A,C){SL4B_SubscriptionManagerAccessor.addSubscriptionManager(C);}
function SL_EH(B,A,C){SL4B_SubscriptionManagerAccessor.removeSubscriptionManager(C);}
function SL_PJ(){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_LOGIN_OK_CONNECTION_EVENT));SL4B_SubscriptionManagerAccessor.ready();}
function SL_LP(){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_CREDENTIALS_RETRIEVED_CONNECTION_EVENT,SL4B_Accessor.getCredentialsProvider().getUsername()));}
function SL_FH(A){this.m_pConnectionListeners.push(A);}
function SL_FB(A){var l_nMatchIndex=-1;
for(var l_nListener=0,l_nLength=this.m_pConnectionListeners.length;l_nListener<l_nLength;++l_nListener){if(this.m_pConnectionListeners[l_nListener]==A){l_nMatchIndex=l_nListener;break;
}}if(l_nMatchIndex!=-1){this.m_pConnectionListeners.splice(l_nMatchIndex,1);}return (l_nMatchIndex!=-1);
}
function SL_NB(A){var l_pArguments=SL_NB.arguments;
var l_aCopy=this.m_pConnectionListeners.slice();
for(var l_nListener=0,l_nLength=l_aCopy.length;l_nListener<l_nLength;++l_nListener){
try {switch(A){
case this.const_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].connectionError(l_pArguments[1]);break;
case this.const_WARNING_CONNECTION_EVENT:l_aCopy[l_nListener].connectionWarning(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
case this.const_INFO_CONNECTION_EVENT:l_aCopy[l_nListener].connectionInfo(l_pArguments[1]);break;
case this.const_ATTEMPT_CONNECTION_EVENT:l_aCopy[l_nListener].connectionAttempt(l_pArguments[1],l_pArguments[2]);break;
case this.const_OK_CONNECTION_EVENT:l_aCopy[l_nListener].connectionOk(l_pArguments[1],l_pArguments[2],l_pArguments[3]);break;
case this.const_RECONNECTION_OK_CONNECTION_EVENT:l_aCopy[l_nListener].reconnectionOk();break;
case this.const_FILE_DOWNLOAD_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].fileDownloadError(l_pArguments[1],l_pArguments[2]);break;
case this.const_LOGIN_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].loginError(l_pArguments[1]);break;
case this.const_LOGIN_OK_CONNECTION_EVENT:l_aCopy[l_nListener].loginOk();break;
case this.const_CREDENTIALS_RETRIEVED_CONNECTION_EVENT:l_aCopy[l_nListener].credentialsRetrieved(l_pArguments[1]);break;
case this.const_MESSAGE_CONNECTION_EVENT:l_aCopy[l_nListener].message(l_pArguments[1],l_pArguments[2]);break;
case this.const_SERVICE_MESSAGE_CONNECTION_EVENT:l_aCopy[l_nListener].serviceMessage(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
case this.const_SESSION_EJECTED_CONNECTION_EVENT:l_aCopy[l_nListener].sessionEjected(l_pArguments[1],l_pArguments[2]);break;
case this.const_SOURCE_MESSAGE_CONNECTION_EVENT:l_aCopy[l_nListener].sourceMessage(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
case this.const_STATISTICS_CONNECTION_EVENT:l_aCopy[l_nListener].statistics(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4],l_pArguments[5]);break;
case this.const_CREDENTIALS_PROVIDER_SESSION_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].credentialsProviderSessionError(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
default :SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractRttpProvider.notifyConnectionListeners: "+"Received an unknown connection event '"+A+"'. Ignoring event.");}}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractRttpProvider.notifyConnectionListeners: Exception thrown by a listener whilst processing a \"{0}\" event; exception was {1}",A,SL4B_Accessor.getBrowserAdapter().convertExceptionToString(e));}
}}
function SL_OE(A){SL4B_Accessor.getRttpProvider().internalStop();}
var SL4B_ConnectionListener=function(){};
if(false){function SL4B_ConnectionListener(){}
}SL4B_ConnectionListener = function(){};
SL4B_ConnectionListener.prototype.connectionWarning = function(C,D,B,A){};
SL4B_ConnectionListener.prototype.connectionInfo = function(A){};
SL4B_ConnectionListener.prototype.connectionAttempt = function(B,A){this.connectionInfo("Trying connection type "+A);};
SL4B_ConnectionListener.prototype.connectionOk = function(C,A,B){};
SL4B_ConnectionListener.prototype.reconnectionOk = function(){};
SL4B_ConnectionListener.prototype.fileDownloadError = function(B,A){};
SL4B_ConnectionListener.prototype.loginOk = function(){};
SL4B_ConnectionListener.prototype.loginError = function(A){};
SL4B_ConnectionListener.prototype.credentialsRetrieved = function(A){};
SL4B_ConnectionListener.prototype.credentialsProviderSessionError = function(A,D,C,B){};
SL4B_ConnectionListener.prototype.message = function(A,B){};
SL4B_ConnectionListener.prototype.connectionError = function(A){};
SL4B_ConnectionListener.prototype.serviceMessage = function(A,D,B,C){};
SL4B_ConnectionListener.prototype.sessionEjected = function(A,B){};
SL4B_ConnectionListener.prototype.sourceMessage = function(A,C,D,B){};
SL4B_ConnectionListener.prototype.statistics = function(A,D,E,B,C){};
var SL4B_ConnectionWarningReason=function(){};
if(false){function SL4B_ConnectionWarningReason(){}
}SL4B_ConnectionWarningReason = new function(){this.CONNECTION_FAILED="Connection failed";this.LIBERATOR_UNAVAILABLE="Liberator unavailable";this.CONNECTION_LOST="Connection lost";};
var SL4B_ThrottleLevel=function(){};
if(false){function SL4B_ThrottleLevel(){}
}SL4B_ThrottleLevel = new function(){this.MINIMUM="min";this.DOWN="down";this.UP="up";this.MAXIMUM="max";this.STOP="stop";this.START="start";this.DEFAULT="def";this.isValid = function(A){return A==this.UP||A==this.DOWN||A==this.DEFAULT||A==this.MINIMUM||A==this.MAXIMUM||A==this.STOP||A==this.START;
};
};
var SL4B_ObjectType=function(){};
if(false){function SL4B_ObjectType(){}
}SL4B_ObjectType = new function(){this.DIRECTORY="220";this.PAGE="221";this.RECORD="222";this.NEWS_HEADLINE="223";this.NEWS_STORY="224";this.CHAT="227";this.CONTAINER="228";this.AUTO_DIRECTORY="229";this.m_pObjectTypeToNameMap=new Object();this.m_pObjectTypeToNameMap[this.DIRECTORY]="directory";this.m_pObjectTypeToNameMap[this.PAGE]="page";this.m_pObjectTypeToNameMap[this.RECORD]="record";this.m_pObjectTypeToNameMap[this.NEWS_HEADLINE]="news headline";this.m_pObjectTypeToNameMap[this.NEWS_STORY]="news story";this.m_pObjectTypeToNameMap[this.CHAT]="chat";this.m_pObjectTypeToNameMap[this.CONTAINER]="container";this.m_pObjectTypeToNameMap[this.AUTO_DIRECTORY]="auto directory";this.getName = function(A){var l_sName=this.m_pObjectTypeToNameMap[A];
return ((typeof l_sName=="undefined") ? null : l_sName);
};
};
var SL4B_FileType=function(){};
if(false){function SL4B_FileType(){}
}SL4B_FileType = new function(){this.URL_CHECK="URL check";this.APPLET_CHECK="Applet check";this.RTTP_APPLET="RTTP applet";};
var SL4B_ContributionFieldData=function(){};
if(false){function SL4B_ContributionFieldData(){}
}SL4B_ContributionFieldData = function(){this.m_pFieldNameAndValues=new Array();};
SL4B_ContributionFieldData.prototype.addField = function(B,A){this.m_pFieldNameAndValues.push(new GF_Field(B,A));};
SL4B_ContributionFieldData.prototype.size = function(){return this.m_pFieldNameAndValues.length;
};
SL4B_ContributionFieldData.prototype.getField = function(A){if(A>=this.m_pFieldNameAndValues.length||A<0){throw new SL4B_Exception("getField: specified field index \""+A+"\" is out of bounds");
}return this.m_pFieldNameAndValues[A];
};
SL4B_ContributionFieldData.prototype.toString = function(){return this.m_pFieldNameAndValues.join(" ");
};
function GF_Field(B,A){this.m_sName=B;this.m_sValue=A;}
GF_Field.prototype.toString = function(){return "["+this.m_sName+"="+this.m_sValue+"]";
};
function SL_DX(){this.showStatus = function(A){window.status=A;};
}
SL_DX.prototype = new SL4B_ConnectionListener;SL_DX.prototype.connectionWarning = function(A){this.showStatus("Connection Warning: "+A);};
SL_DX.prototype.connectionInfo = function(A){this.showStatus("Connection Information: "+A);};
SL_DX.prototype.connectionOk = function(C,A,B){this.showStatus("Connection OK: "+C+", "+A+", "+B);};
SL_DX.prototype.reconnectionOk = function(C,A,B){this.showStatus("Reconnection OK");};
SL_DX.prototype.fileDownloadError = function(B,A){this.showStatus("File Download Error: "+B+", "+A);};
SL_DX.prototype.loginError = function(A){this.showStatus("Login Error: "+A);};
SL_DX.prototype.loginOk = function(){this.showStatus("Login Ok");};
SL_DX.prototype.message = function(A,B){this.showStatus("Message :"+A+", "+B);};
SL_DX.prototype.connectionError = function(){this.showStatus("Connection Error: connection lost");};
SL_DX.prototype.serviceMessage = function(A,D,B,C){};
SL_DX.prototype.sessionEjected = function(A,B){this.showStatus("Session Ejected: "+A+", "+B);};
SL_DX.prototype.sourceMessage = function(A,C,D,B){};
SL_DX.prototype.statistics = function(A,D,E,B,C){};
function SL4B_LogConnectionListener(A){this.m_oLogger=A;this.m_mSourceRttpCodeToDescriptionMap={511.0:"is up", 512.0:"is down"};this.m_mServiceRttpCodeToDescriptionMap={515.0:"up, all DataSources are up", 516.0:"down, one or more required DataSources are down", 517.0:"limited, one or more non-required DataSources are down"};}
SL4B_LogConnectionListener.prototype = new SL4B_ConnectionListener;SL4B_LogConnectionListener.prototype.connectionAttempt = function(A,B){this.m_oLogger.logConnectionMessage(true,"Attempting a type {0} connection to Liberator {1}",B,A);};
SL4B_LogConnectionListener.prototype.connectionInfo = function(A){this.m_oLogger.logConnectionMessage(false,"Connection information \"{0}\"",A);};
SL4B_LogConnectionListener.prototype.connectionWarning = function(B,D,A,C){var sLogDescription;
if(D===SL4B_ConnectionWarningReason.CONNECTION_FAILED){sLogDescription="Failed to establish type {0} connection to Liberator {1} - {2}";}else 
if(D===SL4B_ConnectionWarningReason.CONNECTION_LOST){sLogDescription="Lost type {0} connection to Liberator {1} - {2}";}else 
if(D===SL4B_ConnectionWarningReason.LIBERATOR_UNAVAILABLE){sLogDescription="Type {0} connection to Liberator {1} failed due to url-check.gif download failure";}else 
{sLogDescription="Unknown connection issue with type {0} connection to Liberator {1} - {2}";}this.m_oLogger.logConnectionMessage(true,sLogDescription,C,A,B);};
SL4B_LogConnectionListener.prototype.connectionError = function(A){this.m_oLogger.logConnectionMessage(true,"Connection error: {0}",A);};
SL4B_LogConnectionListener.prototype.connectionOk = function(A,B,C){this.m_oLogger.logConnectionMessage(true,"Successfully established type {0} connection to {1}",B,A);};
SL4B_LogConnectionListener.prototype.credentialsRetrieved = function(A){this.m_oLogger.logConnectionMessage(true,"Credentials retrieved for user {0}",A);};
SL4B_LogConnectionListener.prototype.loginOk = function(){this.m_oLogger.logConnectionMessage(true,"Log in successful");};
SL4B_LogConnectionListener.prototype.reconnectionOk = function(){this.m_oLogger.logConnectionMessage(true,"Log in has successfully reconnected to the previous session");};
SL4B_LogConnectionListener.prototype.loginError = function(A){this.m_oLogger.logConnectionMessage(true,"Log in failed - {0}",A);};
SL4B_LogConnectionListener.prototype.sessionEjected = function(B,A){this.m_oLogger.logConnectionMessage(true,"User session ejected by the server - {0}",A);};
SL4B_LogConnectionListener.prototype.message = function(B,A){this.m_oLogger.logConnectionMessage(false,"Generic message \"{0}\" received from Liberator - {1}",B,A);};
SL4B_LogConnectionListener.prototype.serviceMessage = function(B,D,C,A){this.m_oLogger.logConnectionMessage(false,"Data service \"{0}\" is {1}",D,this.m_mServiceRttpCodeToDescriptionMap[B]);};
SL4B_LogConnectionListener.prototype.sourceMessage = function(D,C,B,A){this.m_oLogger.logConnectionMessage(false,"DataSource \"{0}\" {1}",B,this.m_mSourceRttpCodeToDescriptionMap[D]||A);};
SL4B_LogConnectionListener.prototype.fileDownloadError = function(A,B){this.m_oLogger.logConnectionMessage(false,"Failed to load file {0}",B);};
SL4B_LogConnectionListener.prototype.statistics = function(C,D,E,A,B){};
var SL4B_ContainerKey=function(){this.m_nId=SL4B_ContainerKey.g_nNextId++;this.getId = function(){return this.m_nId;
};
this.toString = function(){return this.m_nId+"";
};
};
SL4B_ContainerKey.g_nNextId=0;var SL4B_ContainerRequestData=function(A,E,B,D,F,C){this.m_sSubscriberId=A;this.m_sContainerId=E;this.m_sContainerName=B;this.m_sFieldList=D;this.m_nWindowStart=F;this.m_nWindowEnd=C;};
SL4B_ContainerRequestData.prototype.getSubscriberId = function(){return this.m_sSubscriberId;
};
SL4B_ContainerRequestData.prototype.getContainerId = function(){return this.m_sContainerId;
};
SL4B_ContainerRequestData.prototype.getContainerName = function(){return this.m_sContainerName;
};
SL4B_ContainerRequestData.prototype.getFieldList = function(){return this.m_sFieldList;
};
SL4B_ContainerRequestData.prototype.getWindowStart = function(){return this.m_nWindowStart;
};
SL4B_ContainerRequestData.prototype.getWindowEnd = function(){return this.m_nWindowEnd;
};
SL4B_ContainerRequestData.prototype.setWindowStart = function(A){this.m_nWindowStart=A;};
SL4B_ContainerRequestData.prototype.setWindowEnd = function(A){this.m_nWindowEnd=A;};
SL4B_ContainerRequestData.prototype.toString = function(){return "{ContainerRequestData "+this.m_sSubscriberId+" "+this.m_sContainerId+" "+this.m_sContainerName+" "+this.m_sFieldList+" "+this.m_nWindowStart+","+this.m_nWindowEnd+" }";
};
SL4B_ContainerRequestData.prototype.clone = function(){return new SL4B_ContainerRequestData(this.m_sSubscriberId,this.m_sContainerId,this.m_sContainerName,this.m_sFieldList,this.m_nWindowStart,this.m_nWindowEnd);
};
var SL4B_AbstractSubscriber=function(){};
if(false){function SL4B_AbstractSubscriber(){}
}SL4B_AbstractSubscriber = function(){};
SL4B_AbstractSubscriber.prototype.m_sListenerId = null;SL4B_AbstractSubscriber.prototype.m_pMultiUpdateQueue = null;SL4B_AbstractSubscriber.prototype.initialise = SL_AU;SL4B_AbstractSubscriber.prototype.getIdentifier = function(){return SL4B_SubscriptionManager.getListenerPrefix()+this.m_sListenerId;
};
SL4B_AbstractSubscriber.prototype.getLocalIdentifier = function(){return SL4B_SubscriptionManager.getLocalListenerPrefix()+this.m_sListenerId;
};
SL4B_AbstractSubscriber.prototype.ready = function(){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractSubscriber.ready invoked but not overridden");};
SL4B_AbstractSubscriber.prototype.WTChat = SL_JC;SL4B_AbstractSubscriber.prototype.WTContribOk = SL_FQ;SL4B_AbstractSubscriber.prototype.WTContribFailed = SL_KJ;SL4B_AbstractSubscriber.prototype.WTDirUpdated = SL_HN;SL4B_AbstractSubscriber.prototype.WTFieldDeleted = SL_CT;SL4B_AbstractSubscriber.prototype.WTType2Clear = SL_RK;SL4B_AbstractSubscriber.prototype.WTType3Clear = SL_BR;SL4B_AbstractSubscriber.prototype.WTNewsUpdated = SL_NH;SL4B_AbstractSubscriber.prototype.WTObjectDeleted = SL_IJ;SL4B_AbstractSubscriber.prototype.WTObjectInfo = SL_EJ;SL4B_AbstractSubscriber.prototype.WTObjectNotFound = SL_GZ;SL4B_AbstractSubscriber.prototype.WTObjectNotStale = SL_AL;SL4B_AbstractSubscriber.prototype.WTObjectReadDenied = SL_JT;SL4B_AbstractSubscriber.prototype.WTObjectStale = SL_QK;SL4B_AbstractSubscriber.prototype.WTObjectStatus = SL_AQ;SL4B_AbstractSubscriber.prototype.WTObjectType = SL_OX;SL4B_AbstractSubscriber.prototype.WTObjectUnavailable = SL_AG;SL4B_AbstractSubscriber.prototype.WTObjectUpdated = SL_KO;SL4B_AbstractSubscriber.prototype.WTObjectWriteDenied = SL_IU;SL4B_AbstractSubscriber.prototype.WTPageUpdated = SL_CO;SL4B_AbstractSubscriber.prototype.WTRecordMultiUpdated = SL_HW;SL4B_AbstractSubscriber.prototype.WTRecordUpdated = SL_DO;SL4B_AbstractSubscriber.prototype.WTStoryReset = SL_MZ;SL4B_AbstractSubscriber.prototype.WTStoryUpdated = SL_MP;SL4B_AbstractSubscriber.prototype.WTStructureChange = SL_CN;SL4B_AbstractSubscriber.prototype.WTStructureMultiChange = SL_BL;SL4B_AbstractSubscriber.prototype.WTPermissionUpdated = SL_DU;SL4B_AbstractSubscriber.prototype.WTPermissionDeleted = SL_KV;SL4B_AbstractSubscriber.prototype.dequeueNextMultiUpdate = SL_PF;SL4B_AbstractSubscriber.prototype.chat = function(C,B,D,A,E){this.methodNotImplemented("chat");};
SL4B_AbstractSubscriber.prototype.contribOk = function(A){this.methodNotImplemented("contribOk");};
SL4B_AbstractSubscriber.prototype.contribFailed = function(A,C,B){this.methodNotImplemented("contribFailed");};
SL4B_AbstractSubscriber.prototype.directoryUpdated = function(D,C,A,B){this.methodNotImplemented("directoryUpdated");};
SL4B_AbstractSubscriber.prototype.directoryMultiUpdated = function(A,B){this.methodNotImplemented("recordMultiUpdated");};
SL4B_AbstractSubscriber.prototype.fieldDeleted = function(A,C,B){this.methodNotImplemented("fieldDeleted");};
SL4B_AbstractSubscriber.prototype.type2Clear = function(A){this.methodNotImplemented("type2Clear");};
SL4B_AbstractSubscriber.prototype.type3Clear = function(A){this.methodNotImplemented("type3Clear");};
SL4B_AbstractSubscriber.prototype.newsUpdated = function(A,D,C,B){this.methodNotImplemented("newsUpdated");};
SL4B_AbstractSubscriber.prototype.objectDeleted = function(A){this.methodNotImplemented("objectDeleted");};
SL4B_AbstractSubscriber.prototype.objectInfo = function(C,B,D,A){this.methodNotImplemented("objectInfo");};
SL4B_AbstractSubscriber.prototype.objectNotFound = function(A){this.methodNotImplemented("objectNotFound");};
SL4B_AbstractSubscriber.prototype.objectNotStale = function(A,B){this.methodNotImplemented("objectNotStale");};
SL4B_AbstractSubscriber.prototype.objectReadDenied = function(A,B){this.methodNotImplemented("objectReadDenied");};
SL4B_AbstractSubscriber.prototype.objectStale = function(A,B){this.methodNotImplemented("objectStale");};
SL4B_AbstractSubscriber.prototype.objectStatus = function(D,B,A,C){this.methodNotImplemented("objectStatus");};
SL4B_AbstractSubscriber.prototype.objectType = function(C,B,A){this.methodNotImplemented("objectType");};
SL4B_AbstractSubscriber.prototype.objectUnavailable = function(A){this.methodNotImplemented("objectUnavailable");};
SL4B_AbstractSubscriber.prototype.objectUpdated = function(A){this.methodNotImplemented("objectUpdated");};
SL4B_AbstractSubscriber.prototype.objectWriteDenied = function(A,B){this.methodNotImplemented("objectWriteDenied");};
SL4B_AbstractSubscriber.prototype.pageUpdated = function(E,D,B,A,C){this.methodNotImplemented("pageUpdated");};
SL4B_AbstractSubscriber.prototype.recordMultiUpdated = function(A,B,C){for(var l_nCount=0,l_nSize=B.size();l_nCount<l_nSize;l_nCount++){SL4B_MethodInvocationProxy.invoke(this,"recordUpdated",[A,B.getFieldName(l_nCount),B.getFieldValue(l_nCount)]);}};
SL4B_AbstractSubscriber.prototype.recordUpdated = function(B,C,A){this.methodNotImplemented("recordUpdated");};
SL4B_AbstractSubscriber.prototype.storyReset = function(A){this.methodNotImplemented("storyReset");};
SL4B_AbstractSubscriber.prototype.storyUpdated = function(B,A){this.methodNotImplemented("storyUpdated");};
SL4B_AbstractSubscriber.prototype.structureChange = function(A,C,D,B){this.methodNotImplemented("structureChange");};
SL4B_AbstractSubscriber.prototype.structureMultiChange = function(B,A,D,C){this.methodNotImplemented("structureChange");};
SL4B_AbstractSubscriber.prototype.permissionUpdated = function(A,B,C){this.methodNotImplemented("permissionUpdated");};
SL4B_AbstractSubscriber.prototype.permissionDeleted = function(A,B){this.methodNotImplemented("permissionDeleted");};
SL4B_AbstractSubscriber.prototype.methodNotImplemented = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractSubscriber.{0} invoked but not overridden",A);};
function SL_AU(){this.m_sListenerId=SL4B_SubscriptionManager.addSubscriber(this);this.m_pMultiUpdateQueue=new Array();if(SL4B_SubscriptionManager.isReady()){C_CallbackQueue.addCallback(new Array(this,"ready"));}}
function SL_JC(C,B,D,A,E){C_CallbackQueue.addCallback(new Array(this,"chat",C,B,D,A,E));}
function SL_FQ(A){C_CallbackQueue.addCallback(new Array(this,"contribOk",A));}
function SL_KJ(A,C,B){C_CallbackQueue.addCallback(new Array(this,"contribFailed",A,C,B));}
function SL_HN(D,C,A,B){C_CallbackQueue.addCallback(new Array(this,"directoryUpdated",D,C,A,B));}
function SL_CT(A,C,B){C_CallbackQueue.addCallback(new Array(this,"fieldDeleted",A,C,B));}
function SL_RK(A){C_CallbackQueue.addCallback(new Array(this,"type2Clear",A));}
function SL_BR(A){C_CallbackQueue.addCallback(new Array(this,"type3Clear",A));}
function SL_NH(A,D,C,B){C_CallbackQueue.addCallback(new Array(this,"newsUpdated",A,D,C,B));}
function SL_IJ(A){C_CallbackQueue.addCallback(new Array(this,"objectDeleted",A));}
function SL_EJ(C,B,D,A){C_CallbackQueue.addCallback(new Array(this,"objectInfo",C,B,D,A));}
function SL_GZ(A){C_CallbackQueue.addCallback(new Array(this,"objectNotFound",A));}
function SL_AL(A,B){C_CallbackQueue.addCallback(new Array(this,"objectNotStale",A,B));}
function SL_JT(A,B){C_CallbackQueue.addCallback(new Array(this,"objectReadDenied",A,B));}
function SL_QK(A,B){C_CallbackQueue.addCallback(new Array(this,"objectStale",A,B));}
function SL_AQ(D,B,A,C){C_CallbackQueue.addCallback(new Array(this,"objectStatus",D,B,A,C));}
function SL_OX(C,B,A){C_CallbackQueue.addCallback(new Array(this,"objectType",C,B,A));}
function SL_AG(A){C_CallbackQueue.addCallback(new Array(this,"objectUnavailable",A));}
function SL_KO(A){C_CallbackQueue.addCallback(new Array(this,"objectUpdated",A));}
function SL_IU(A,B){C_CallbackQueue.addCallback(new Array(this,"objectWriteDenied",A,B));}
function SL_CO(E,D,B,A,C){C_CallbackQueue.addCallback(new Array(this,"pageUpdated",E,D,B,A,C));}
function SL_HW(A,B){this.m_pMultiUpdateQueue.push(new SL_HI(A,B,SL_HI.const_RECORD_UPDATE_TYPE,null));C_CallbackQueue.addCallback(new Array(this,"dequeueNextMultiUpdate"));}
function SL_DO(B,C,A){C_CallbackQueue.addCallback(new Array(this,"recordUpdated",B,C,A));}
function SL_MZ(A){C_CallbackQueue.addCallback(new Array(this,"storyReset",A));}
function SL_MP(B,A){C_CallbackQueue.addCallback(new Array(this,"storyUpdated",B,A));}
function SL_CN(A,C,D,B){C_CallbackQueue.addCallback(new Array(this,"structureChange",A,C,D,B));}
function SL_BL(B,A,D,C){this.m_pMultiUpdateQueue.push(new SL_HI(B,null,SL_HI.const_STRUCTURE_CHANGE_TYPE,new Array(A,D,C)));C_CallbackQueue.addCallback(new Array(this,"dequeueNextMultiUpdate"));}
function SL_DU(A,B,C){this.m_pMultiUpdateQueue.push(new SL_HI(A,C,SL_HI.const_PERMISSION_UPDATE_TYPE,new Array(B)));C_CallbackQueue.addCallback(new Array(this,"dequeueNextMultiUpdate"));}
function SL_KV(A,B){C_CallbackQueue.addCallback(new Array(this,"permissionDeleted",A,((!B) ? null : B)));}
function SL_PF(){var l_oMultiUpdate=this.m_pMultiUpdateQueue.shift();
if(l_oMultiUpdate!=null){if(l_oMultiUpdate.m_nType==SL_HI.const_RECORD_UPDATE_TYPE){this.recordMultiUpdated(l_oMultiUpdate.m_sObjectName,l_oMultiUpdate.m_oFieldData);}else 
if(l_oMultiUpdate.m_nType==SL_HI.const_PERMISSION_UPDATE_TYPE){this.permissionUpdated(l_oMultiUpdate.m_sObjectName,l_oMultiUpdate.m_pExtraData[0],l_oMultiUpdate.m_oFieldData);}else 
if(l_oMultiUpdate.m_nType==SL_HI.const_STRUCTURE_CHANGE_TYPE){this.structureMultiChange(l_oMultiUpdate.m_sObjectName,l_oMultiUpdate.m_pExtraData[0],l_oMultiUpdate.m_pExtraData[1],l_oMultiUpdate.m_pExtraData[2]);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"AbstractSubscriber.dequeueNextMultiUpdate: unknown update type: {0}.",l_oMultiUpdate.m_nType);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"AbstractSubscriber.dequeueNextMultiUpdate: method invoked with no more multi updates left in the queue.");}}
function SL_HI(C,D,B,A){this.m_sObjectName=C;this.m_oFieldData=D;this.m_nType=B;this.m_pExtraData=A;}
SL_HI.const_RECORD_UPDATE_TYPE=1;SL_HI.const_PERMISSION_UPDATE_TYPE=2;SL_HI.const_STRUCTURE_CHANGE_TYPE=3;var SL4B_RecordFieldData=function(){};
if(false){function SL4B_RecordFieldData(){}
}SL4B_RecordFieldData = function(){this.m_pFieldNames=new Array();this.m_mFieldNameToValue={};this.m_oField=new GF_Field();};
SL4B_RecordFieldData.prototype.size = function(){return this.m_pFieldNames.length;
};
SL4B_RecordFieldData.prototype.getField = function(A){var sFieldName=this.m_pFieldNames[A];
this.m_oField.m_sName=sFieldName;this.m_oField.m_sValue=this.m_mFieldNameToValue[sFieldName];return this.m_oField;
};
SL4B_RecordFieldData.prototype.getFieldMap = function(){return this.m_mFieldNameToValue;
};
SL4B_RecordFieldData.prototype.getFieldName = function(A){return this.m_pFieldNames[A];
};
SL4B_RecordFieldData.prototype.getFieldValue = function(A){var sFieldName=this.m_pFieldNames[A];
return this.m_mFieldNameToValue[sFieldName];
};
SL4B_RecordFieldData.prototype.add = function(B,A){this.m_pFieldNames.push(B);this.m_mFieldNameToValue[B]=A;};
var SL4B_SubscriptionManager = new function(){this.m_nUniqueId=0;this.m_bIsReady=false;this.m_pSubscribers=new Array();this.m_sId=null;this.m_sListenerPrefix=null;this.getSubscribers = function(){return this.m_pSubscribers;
};
this.getSubscriber = function(A){return this.m_pSubscribers[A];
};
this.addSubscriber = function(A){var l_nUniqueId=this.getUniqueId();
this.m_pSubscribers[l_nUniqueId]=A;return "getSubscriber("+l_nUniqueId+")";
};
this.getId = function(){if(this.m_sId==null){this.m_sId=SL4B_Accessor.getConfiguration().getFrameId();}return this.m_sId;
};
this.getListenerPrefix = function(){if(this.m_sListenerPrefix==null){this.m_sListenerPrefix="SL4B_SubscriptionManagerAccessor.getSubscriptionManager(\""+this.getId()+"\").";}return this.m_sListenerPrefix;
};
this.getLocalListenerPrefix = function(){return "SL4B_SubscriptionManager.";
};
this.getUniqueId = function(){return this.m_nUniqueId++;
};
this.ready = function(){if(!this.m_bIsReady){this.m_bIsReady=true;for(var l_nSubscriberId=0;l_nSubscriberId<this.m_pSubscribers.length;++l_nSubscriberId){SL4B_MethodInvocationProxy.invoke(this.m_pSubscribers[l_nSubscriberId],"ready",[]);}}};
this.isReady = function(){return this.m_bIsReady;
};
};
function SL_QP(){}
SL_QP.prototype = new SL4B_AbstractSubscriber;SL_QP.prototype.getSubscriber = function(A){return this;
};
SL_QP.prototype.ready = function(){};
SL_QP.prototype.WTChat = function(C,B,D,A,E){};
SL_QP.prototype.WTContribOk = function(A){};
SL_QP.prototype.WTContribFailed = function(A,B){};
SL_QP.prototype.WTdirUpdated = function(D,C,A,B){};
SL_QP.prototype.WTDirMultiUpdated = function(A,B){};
SL_QP.prototype.WTFieldDeleted = function(A,C,B){};
SL_QP.prototype.WTType2Clear = function(A){};
SL_QP.prototype.WTType3Clear = function(A){};
SL_QP.prototype.WTNewsUpdated = function(A,D,C,B){};
SL_QP.prototype.WTObjectDeleted = function(A){};
SL_QP.prototype.WTObjectInfo = function(C,B,D,A){};
SL_QP.prototype.WTObjectNotFound = function(A){};
SL_QP.prototype.WTObjectNotStale = function(A,B){};
SL_QP.prototype.WTObjectReadDenied = function(A,B){};
SL_QP.prototype.WTObjectStale = function(A,B){};
SL_QP.prototype.WTObjectStatus = function(D,B,A,C){};
SL_QP.prototype.WTObjectType = function(C,B,A){};
SL_QP.prototype.WTObjectUnavailable = function(A){};
SL_QP.prototype.WTObjectUpdated = function(A){};
SL_QP.prototype.WTObjectWriteDenied = function(A,B){};
SL_QP.prototype.WTPageUpdated = function(E,D,B,A,C){};
SL_QP.prototype.WTRecordMultiUpdated = function(A,B){};
SL_QP.prototype.WTRecordUpdated = function(B,C,A){};
SL_QP.prototype.WTStoryReset = function(A){};
SL_QP.prototype.WTStoryUpdated = function(B,A){};
SL_QP.prototype.WTStructureChange = function(A,C,D,B){};
SL_QP.prototype.WTPermissionUpdated = function(B,A,C){};
SL_QP.prototype.WTPermissionDeleted = function(B,A){};
var SL4B_SubscriptionManagerAccessor = new function(){this.m_bIsReady=false;this.m_pSubscriptionManagers=new Object();this.m_oNullSubscriptionManager=new SL_QP();this.getSubscriptionManager = function(A){var l_oSubscriptionManager=this.m_pSubscriptionManagers[A];
if(typeof l_oSubscriptionManager=="undefined"){SL4B_Logger.log(SL4B_DebugLevel.WARN,"AbstractSubscriber.getSubscriptionManager: No subscription manager has been registered with the id \"{0}\". Using null subscription manager.",A);l_oSubscriptionManager=this.m_oNullSubscriptionManager;}return l_oSubscriptionManager;
};
this.addSubscriptionManager = function(A){if(typeof this.m_pSubscriptionManagers[A.getId()]!="undefined"){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"AbstractSubscriber.addSubscriptionManager: A subscription manager with the identifier \"{0}\" has already been registered",A.getId());}else 
{this.m_pSubscriptionManagers[A.getId()]=A;if(this.m_bIsReady){A.ready();}}};
this.removeSubscriptionManager = function(A){delete (this.m_pSubscriptionManagers[A.getId()]);};
this.ready = function(){if(!this.m_bIsReady){this.m_bIsReady=true;for(l_sManagerId in this.m_pSubscriptionManagers){this.m_pSubscriptionManagers[l_sManagerId].ready();}}};
};
var SL4B_ObjectStatus=function(){};
if(false){function SL4B_ObjectStatus(){}
}SL4B_ObjectStatus = new function(){this.OK=3;this.STALE=1;this.LIMITED=5;this.REMOVED=2;this.INFO=0;this.m_pStatuses=new Array(this.OK,this.STALE,this.LIMITED,this.REMOVED,this.INFO);this.RTTP_STATUS_CODE_BASELINE=415;this.getObjectStatusFromRttpCode = function(A){var l_nArrayIndex=A-this.RTTP_STATUS_CODE_BASELINE;
if(l_nArrayIndex>=0&&l_nArrayIndex<this.m_pStatuses.length){return this.m_pStatuses[l_nArrayIndex];
}else 
{throw new SL4B_Exception("Invalid RTTP status code. Code was "+A);
}};
};
var SL4B_ChatStatus=function(){};
if(false){function SL4B_ChatStatus(){}
}SL4B_ChatStatus = new function(){this.MESSAGE=0;this.USER_SUBSCRIBED=1;this.USER_UNSUBSCRIBED=2;this.SUBSCRIBED=3;};
var SL4B_ContainerOrderChange=function(){};
if(false){function SL4B_ContainerOrderChange(){}
}SL4B_ContainerOrderChange = function(A,C,B){this.m_sObjectName=A;this.m_nObjectId=C;this.m_nPosition=B;};
SL4B_ContainerOrderChange.prototype.getObjectName = function(){return this.m_sObjectName;
};
SL4B_ContainerOrderChange.prototype.getObjectId = function(){return this.m_nObjectId;
};
SL4B_ContainerOrderChange.prototype.getPosition = function(){return this.m_nPosition;
};
var SL4B_ContainerStructureChange=function(){};
if(false){function SL4B_ContainerStructureChange(){}
}SL4B_ContainerStructureChange = function(B,C,A){this.m_sObjectName=B;this.m_sObjectType=C;this.m_bAdded=A;};
SL4B_ContainerStructureChange.prototype.getObjectName = function(){return this.m_sObjectName;
};
SL4B_ContainerStructureChange.prototype.getObjectType = function(){return this.m_sObjectType;
};
SL4B_ContainerStructureChange.prototype.getAdded = function(){return this.m_bAdded;
};
var SL4B_ExceptionHandler=function(){};
if(false){function SL4B_ExceptionHandler(){}
}SL4B_ExceptionHandler = function(){};
SL4B_ExceptionHandler.prototype.processError = SL_IS;SL4B_ExceptionHandler.prototype.processException = SL_IT;function SL_IS(A){throw (A);
}
function SL_IT(A){throw (A);
}
var SL4B_SilentExceptionHandler=function(){};
if(false){function SL4B_SilentExceptionHandler(){}
}SL4B_SilentExceptionHandler = function(){};
SL4B_SilentExceptionHandler.prototype.processError = SL_FM;SL4B_SilentExceptionHandler.prototype.processException = SL_FF;function SL_FM(A){SL4B_Logger.log(SL4B_DebugLevel.const_CRITICAL_INT,A.toString());}
function SL_FF(A){SL4B_Logger.log(SL4B_DebugLevel.const_CRITICAL_INT,A.toString());}
function SL_LJ(){SL4B_Accessor.setExceptionHandler(new SL4B_ExceptionHandler());}
C_CallbackQueue = new function(){this.m_pQueue=new Array();this.m_nCallbackBatchFrequency=0;this.m_nMaximumCallbacksInBatch=5000;this.start = function(){var l_oConfiguration=SL4B_Accessor.getConfiguration();
this.m_nCallbackBatchFrequency=l_oConfiguration.getCallbackBatchFrequency();if(this.m_nCallbackBatchFrequency>0){this.m_nMaximumCallbacksInBatch=l_oConfiguration.getMaximumCallbackBatchSize();setTimeout("C_CallbackQueue.processCallbackBatch();",this.m_nCallbackBatchFrequency);}};
this.addCallback = function(A){if(this.m_nCallbackBatchFrequency>0){this.m_pQueue.push(A);}else 
{this.invokeCallback(A);}};
this.processCallbackBatch = function(){var l_nBatchStartTime=(new Date()).valueOf();
var l_nNumberOfUpdatesProcessed=0;
while(this.m_pQueue.length>0&&l_nNumberOfUpdatesProcessed<this.m_nMaximumCallbacksInBatch){++l_nNumberOfUpdatesProcessed;var l_pCallback=this.m_pQueue.shift();
this.invokeCallback(l_pCallback);}var l_nTimeTaken=(new Date()).valueOf()-l_nBatchStartTime;
setTimeout("C_CallbackQueue.processCallbackBatch();",Math.max(0,this.m_nCallbackBatchFrequency-l_nTimeTaken));};
this.invokeCallback = function(A){if(!A||typeof A!="object"||typeof A.length!="number"){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"CallbackQueue.invokeCallback: Error processing callback \"{0}\"; Specified callback parameter is not an array",((A&&typeof A.join=="function") ? A.join() : A));}else 
if(A.length<2){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"CallbackQueue.invokeCallback: Error processing callback \"{0}\"; Unexpected number of callback arguments ({1})",((A&&typeof A.join=="function") ? A.join() : A),A.length);}else 
{var l_oCallbackObject=A.shift();
var l_sCallbackMethod=A.shift();
SL4B_MethodInvocationProxy.invoke(l_oCallbackObject,l_sCallbackMethod,A);}};
};
var SL4B_XmlResponseRetriever=function(){};
if(false){function SL4B_XmlResponseRetriever(){}
}SL4B_XmlResponseRetriever = new function(){this.getXmlDocumentElement = function(A){var l_oDocElement=null;

try {l_oDocElement=A.responseXML.documentElement;}catch(e){if(e.match(/Permission/)&&A.responseText&&document.implementation.createDocument){var l_oParser=new DOMParser();
var l_oDomDoc=l_oParser.parseFromString(A.responseText,"text/xml");
l_oDocElement=l_oDomDoc.documentElement;}}
return l_oDocElement;
};
};
var SL4B_JsUnit = new function(){this.isUnobfuscated = function(){var l_sObfuscatedFunction=eval("typeof(IS_UNOBFUSCATED)");
return l_sObfuscatedFunction!="undefined";
};
};
var SL_MJ = new function(){return true;
};
GF_CommonDomainExtractor = new function(){this.m_bDomainSet=false;this.m_sCommonDomain=null;this.getCommonDomain=SL_AO;this.getLiberatorUrl=SL_OD;this.determineCommonDomain=SL_NM;this.getCommonDomainForDifferentPort=SL_QL;this.getDocumentDomain=SL_IF;};
function SL_AO(){if(!this.m_bDomainSet){this.m_sCommonDomain=this.determineCommonDomain(this.getDocumentDomain(),window.location.href);this.m_bDomainSet=true;}return this.m_sCommonDomain;
}
function SL_OD(){var l_sUrl=SL4B_Accessor.getConfiguration().getJsContainerUrl();
if(l_sUrl==null){l_sUrl=SL4B_Accessor.getConfiguration().getServerUrl();}return l_sUrl;
}
function SL_NM(A,B){var l_oLiberatorDomainMatch=this.getLiberatorUrl().match(/https?:\/\/([^\/:]+)/);
if(l_oLiberatorDomainMatch==null){SL4B_Logger.logConnectionMessage(true,"CommonDomainExtractor.determineCommonDomain: Relative url to Liberator detected - document.domain will not be set");return null;
}else 
if(A==l_oLiberatorDomainMatch[1]){if(SL4B_Accessor.getBrowserAdapter().isFirefox()){var l_pLibPortMatch=this.getLiberatorUrl().match(/^https?:\/\/([^:]+)(:)?(\d+)/);
if(B==null){B="http://localhost:80/";}var l_pServerPortMatch=B.match(/^https?:\/\/([^:]+)(:)?(\d+)/);
if((l_pLibPortMatch!=null)){if((l_pServerPortMatch!=null&&l_pLibPortMatch[3]!=l_pServerPortMatch[3])||(l_pServerPortMatch==null&&l_pLibPortMatch[3]!="80")){return this.getCommonDomainForDifferentPort(A);
}}else 
if(l_pServerPortMatch!=null&&l_pServerPortMatch[3]!="80"){return this.getCommonDomainForDifferentPort(A);
}}SL4B_Logger.logConnectionMessage(true,"JavaScriptRttpProvider.determineCommonDomain: Web page and Liberator share the same domain ({0}) - document.domain will not be set",A);return null;
}var l_pWebPageDomainParts=A.split(".");
var l_pLiberatorDomainParts=l_oLiberatorDomainMatch[1].split(".");
var l_nWebPageIndex=l_pWebPageDomainParts.length-1;
var l_nLiberatorIndex=l_pLiberatorDomainParts.length-1;
if(l_nWebPageIndex<1||l_nLiberatorIndex<1){SL4B_Logger.logConnectionMessage(true,"JavaScriptRttpProvider.determineCommonDomain: Web page and Liberator do not share the common domain (web page domain = {0}, liberator domain = {1})",A,l_oLiberatorDomainMatch[1]);throw new SL4B_Exception("determineCommonDomain [1]: web page and Liberator do not share a common domain, connection to Liberator cannot be established");
}for(var l_nMatchingParts=0;l_nWebPageIndex>=0&&l_nLiberatorIndex>=0;--l_nWebPageIndex, --l_nLiberatorIndex){if(l_pWebPageDomainParts[l_nWebPageIndex]==l_pLiberatorDomainParts[l_nLiberatorIndex]){++l_nMatchingParts;}else 
{break;
}}if(l_nMatchingParts<2){SL4B_Logger.logConnectionMessage(true,"CommonDomainExtractor.determineCommonDomain: Web page and Liberator do not share the common domain (web page domain = {0}, liberator domain = {1})",A,l_oLiberatorDomainMatch[1]);throw new SL4B_Exception("determineCommonDomain [2]: web page and Liberator do not share a common domain, connection to Liberator cannot be established");
}var l_pCommonDomain=l_pWebPageDomainParts.splice(l_pWebPageDomainParts.length-l_nMatchingParts,l_nMatchingParts);
var l_sCommonDomain=l_pCommonDomain.join(".");
SL4B_Logger.logConnectionMessage(true,"CommonDomainExtractor.determineCommonDomain: document.domain will be set to {0}",l_sCommonDomain);return l_sCommonDomain;
}
function SL_QL(A){SL4B_Logger.logConnectionMessage(true,"CommonDomainExtractor.getCommonDomainForDifferentPorts: web page and Liberator share the same domain ({0}), but their ports differ and domain needs to be changed.",A);var l_sCommonDomain=A.substring(A.indexOf(".")+1);
SL4B_Logger.logConnectionMessage(true,"CommonDomainExtractor.getCommonDomainForDifferentPorts: document.domain will be set to {0}.",l_sCommonDomain);return l_sCommonDomain;
}
function SL_IF(){return document.domain;
}
var SL4B_Capabilities=function(){};
if(false){function SL4B_Capabilities(){}
}SL4B_Capabilities = function(){this.m_nRttpVersion=2;this.m_oCapabilities={};this.m_oCapabilities["HttpBodyLength"]=65536;this.m_oCapabilities["HttpRequestLineLength"]=128;};
SL4B_Capabilities.prototype.getRttpVersion = function(){return this.m_nRttpVersion;
};
SL4B_Capabilities.prototype.setRttpVersion = function(A){this.m_nRttpVersion=A;};
SL4B_Capabilities.prototype.getHttpBodyLength = function(){return this.m_oCapabilities["HttpBodyLength"];
};
SL4B_Capabilities.prototype.getHttpRequestLineLength = function(){var sMaxGetLength=SL4B_Accessor.getConfiguration().getMaxGetLength();
if(sMaxGetLength===null){return this.m_oCapabilities["HttpRequestLineLength"]+"";
}else 
{return Math.min(this.m_oCapabilities["HttpRequestLineLength"],sMaxGetLength)+"";
}};
SL4B_Capabilities.prototype.toString = function(){var s="";
for(key in this.m_oCapabilities){s+=key+"="+this.m_oCapabilities[key]+", ";}return s;
};
SL4B_Capabilities.prototype.add = function(A,B){this.m_oCapabilities[A]=B;return B;
};
function SL4B_Capabilities_scriptLoaded(){SL4B_Accessor.setCapabilities(new SL4B_Capabilities());}
SL4B_Capabilities_scriptLoaded();var SL4B_Statistics=function(){};
if(false){function SL4B_Statistics(){}
}SL4B_Statistics = function(){this.m_nClockOffset=0;this.m_nLatency=0;this.m_nAverageLatency=0;};
SL4B_Statistics.prototype.getClockOffset = function(){return this.m_nClockOffset;
};
SL4B_Statistics.prototype.setClockOffset = function(A){this.m_nClockOffset=A;};
SL4B_Statistics.prototype.getLatency = function(){return this.m_nLatency;
};
SL4B_Statistics.prototype.setLatency = function(A){this.m_nLatency=A;};
SL4B_Statistics.prototype.getAverageLatency = function(){return this.m_nAverageLatency;
};
SL4B_Statistics.prototype.getResponseQueueStatistics = function(){return SL4B_ConnectionProxy.getInstance().getResponseQueueStatistics();
};
SL4B_Statistics.prototype.addResponseQueueStatisticsListener = function(A){return SL4B_ConnectionProxy.getInstance().addResponseQueueStatisticsListener(A);
};
SL4B_Statistics.prototype.setAverageLatency = function(A){this.m_nAverageLatency=A;};
function SL4B_Statistics_scriptLoaded(){SL4B_Accessor.setStatistics(new SL4B_Statistics());}
SL4B_Statistics_scriptLoaded();var SL4B_ResponseQueueStatistics=function(){this.m_nQueuedMessageCount=0;this.m_pQueuedBatches=[];this.m_nProcessedMessageCount=0;};
if(false){function SL4B_ResponseQueueStatistics(){}
}SL4B_ResponseQueueStatistics.prototype.addMessageBatch = function(A){this.m_nQueuedMessageCount+=A;this.m_pQueuedBatches[this.m_pQueuedBatches.length]=this._createMessageBatchInfo(A);};
SL4B_ResponseQueueStatistics.prototype._createMessageBatchInfo = function(A){var oCurrentTime=this._getTime();
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SL4B_ResponseQueueStatistics._createMessageBatchInfo(): creating batch info ({0}, {1})",A,oCurrentTime.getTime());return {numberOfMessages:A, batchQueuedTime:oCurrentTime, batchStartedTime:null};
};
SL4B_ResponseQueueStatistics.prototype._getTime = function(){return new Date();
};
SL4B_ResponseQueueStatistics.prototype.setMessageBatchStarted = function(){var oNow=this._getTime();
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SL4B_ResponseQueueStatistics.setMessageBatchStarted(): starting batch ({0}, {1}) at {2}",this.m_pQueuedBatches[0].numberOfMessages,this.m_pQueuedBatches[0].batchQueuedTime.getTime(),oNow.getTime());this.m_pQueuedBatches[0].batchStartedTime=oNow;};
SL4B_ResponseQueueStatistics.prototype.setMessageBatchEnded = function(){var oQueuedBatch=this.m_pQueuedBatches.shift();
if(oQueuedBatch){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SL4B_ResponseQueueStatistics.setMessageBatchEnded(): finishing batch ({0}, {1})",oQueuedBatch.numberOfMessages,oQueuedBatch.batchQueuedTime.getTime());}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SL4B_ResponseQueueStatistics.setMessageBatchEnded(): Queued batches has been emptied during message processing.");}};
SL4B_ResponseQueueStatistics.prototype.reset = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SL4B_ResponseQueueStatistics.reset()");this.m_nQueuedMessageCount=0;this.m_pQueuedBatches=[];};
SL4B_ResponseQueueStatistics.prototype.incrementProcessedMessageCount = function(){--this.m_nQueuedMessageCount;++this.m_nProcessedMessageCount;};
SL4B_ResponseQueueStatistics.prototype.getQueuedMessageCount = function(){return this.m_nQueuedMessageCount;
};
SL4B_ResponseQueueStatistics.prototype.getProcessedMessageCount = function(){return this.m_nProcessedMessageCount;
};
SL4B_ResponseQueueStatistics.prototype.getQueuedBatchCount = function(){return this.m_pQueuedBatches.length;
};
SL4B_ResponseQueueStatistics.prototype.getTimeOldestBatchWasQueued = function(){if(this.m_pQueuedBatches.length===0){return null;
}return this.m_pQueuedBatches[0].batchQueuedTime;
};
SL4B_ResponseQueueStatistics.prototype.getTimeOldestBatchBeganExecution = function(){if(this.m_pQueuedBatches.length===0){return null;
}return this.m_pQueuedBatches[0].batchStartedTime;
};
SL4B_ResponseQueueStatistics.prototype.toString = function(){return "SL4B_ResponseQueueStatistics: batchCount="+this.m_pQueuedBatches.length+", queuedMessageCount="+this.m_nQueuedMessageCount+", processedMessageCount="+this.m_nProcessedMessageCount;
};
var SL4B_ResponseQueueStatisticsListener=function(){};
if(false){function SL4B_ResponseQueueStatisticsListener(){}
}SL4B_ResponseQueueStatisticsListener.prototype.onBatchQueued = function(A){};
SL4B_ResponseQueueStatisticsListener.prototype.onBeforeBatchProcessed = function(A){};
SL4B_ResponseQueueStatisticsListener.prototype.onAfterBatchProcessed = function(A){};
var SL4B_Configuration=function(){};
if(false){function SL4B_Configuration(){}
}SL4B_Configuration = function(){this.m_oIndexScript=SL4B_ScriptLoader.getIndexScript();this.m_bUsingFile=false;this.m_bFileAttributeSet=false;this.m_DEFAULT_JAVA_CONNECTION_METHODS=new Array(SL4B_ConnectionMethod.JAVAHTTP,SL4B_ConnectionMethod.JAVAPOLLING);this.m_pBrowserStreamingConnectionMethodOverrides={};this.m_pBrowserPollingConnectionMethodOverrides={};this.m_pDefaultAttributes=new Object();this._getDefaultServerUrl = function(B,A){var l_sDefaultServerUrl;
var l_oMatch=B.match(/(^https?:\/\/[^\/]+\/)/);
if(l_oMatch){l_sDefaultServerUrl=l_oMatch[0];}else 
{l_sDefaultServerUrl="/";}return l_sDefaultServerUrl;
};
this.m_pDefaultAttributes["appletjar"]="applet.jar";this.m_pDefaultAttributes["user"]="demouser";this.m_pDefaultAttributes["password"]="demopass";this.m_pDefaultAttributes["credentialsprovider"]=SL4B_ScriptLoader.const_STANDARD_CREDENTIALS_PROVIDER;this.m_pDefaultAttributes["rttpprovider"]=SL4B_ScriptLoader.const_JAVASCRIPT_RTTP_PROVIDER;this.m_pDefaultAttributes["appletchecktimeout"]=15000;this.m_pDefaultAttributes["rttpapplettimeout"]=120000;this.m_pDefaultAttributes["debug"]=SL4B_DebugLevel.ERROR;this.m_pDefaultAttributes["suppressexceptions"]="true";this.m_pDefaultAttributes["rttpdebuglevel"]=SL4B_DebugLevel.CRITICAL;this.m_pDefaultAttributes["debugwindowtype"]=SL4B_Logger.const_HTML;this.m_pDefaultAttributes["applicationid"]=null;this.m_pDefaultAttributes["discarddelay"]=10;this.m_pDefaultAttributes["jvmfileurl"]="http://www.caplin.com/products/jvm-list.js";this.m_pDefaultAttributes["jvmfiledownloadtimeout"]=10;this.m_pDefaultAttributes["logoutdelay"]=1;this.m_pDefaultAttributes["objectnamedelimiter"]=" ";this.m_pDefaultAttributes["statsinterval"]=5;this.m_pDefaultAttributes["statsreset"]=5000;this.m_pDefaultAttributes["statstimeout"]=30000;this.m_pDefaultAttributes["useconfig"]="server_config.js";this.m_pDefaultAttributes["updatebatchfreq"]=250;this.m_pDefaultAttributes["maxupdatebatchsize"]=5000;this.m_pDefaultAttributes["gcfreq"]=200;this.m_pDefaultAttributes["jscontainerpath"]="sl4b/javascript-rttp-provider";this.m_pDefaultAttributes["appletpath"]="applet";this.m_pDefaultAttributes["type3pollperiod"]=1000;this.m_pDefaultAttributes["type5reconnectcount"]=10000;this.m_pDefaultAttributes["type5padlength"]=1024*4;this.m_pDefaultAttributes["maxgetlength"]=null;this.m_pDefaultAttributes["connectiontimeout"]=15000;this.m_pDefaultAttributes["noopinterval"]=5000;this.m_pDefaultAttributes["nooptimeout"]=5000;this.m_pDefaultAttributes["logintimeout"]=10000;this.m_pDefaultAttributes["service"]=null;this.m_pDefaultAttributes["keymasterurl"]=null;this.m_pDefaultAttributes["keymasterattempts"]=3;this.m_pDefaultAttributes["keymasterconnectiontimeout"]=10000;this.m_pDefaultAttributes["keymasterkeepaliveinterval"]=30000;this.m_pDefaultAttributes["keymasterxhrurl"]=null;this.m_pDefaultAttributes["commondomain"]=null;this.m_pDefaultAttributes["enableautoloading"]=true;this.m_pDefaultAttributes["yieldbeforemessageprocessing"]=false;this.m_pDefaultAttributes["enablelatency"]=false;this.m_pDefaultAttributes["clocksyncbatchsize"]=5;this.m_pDefaultAttributes["clocksyncspacing"]=1000;this.m_pDefaultAttributes["clocksyncperiod"]=60000;this.m_pDefaultAttributes["clocksyncstrategy"]="GF_BatchingClockSyncStrategy";this.m_pDefaultAttributes["slidingsyncsize"]=12;this.m_pDefaultAttributes["slidingsyncspacing"]=5000;this.m_pDefaultAttributes["slidingsyncinitialspacing"]=500;this.m_pDefaultAttributes["timestampfield"]="INITIAL_TIMESTAMP";this.m_pDefaultAttributes["disablepolling"]=false;this.m_pDefaultAttributes["disablestreaming"]=false;this.m_pDefaultAttributes["flashtime"]=1000;this.m_pDefaultAttributes["bg"]=null;this.m_pDefaultAttributes["bgchange"]='rel';this.m_pDefaultAttributes["bgdn"]='red';this.m_pDefaultAttributes["bgeq"]='green';this.m_pDefaultAttributes["bgup"]='blue';this.m_pDefaultAttributes["fg"]=null;this.m_pDefaultAttributes["fgchange"]=null;this.m_pDefaultAttributes["fgdn"]='red';this.m_pDefaultAttributes["fgeq"]='black';this.m_pDefaultAttributes["fgflash"]='white';this.m_pDefaultAttributes["fgup"]='blue';this.m_pDefaultAttributes["plus"]=null;this.m_pDefaultAttributes["fractionhandling"]=null;this.m_pDefaultAttributes["gfxup"]=null;this.m_pDefaultAttributes["gfxdn"]=null;this.m_pDefaultAttributes["gfxeq"]=null;this.m_pDefaultAttributes["isencoded"]=0;this.m_pDefaultAttributes["todp"]=0;this.m_pDefaultAttributes["round"]='default';this.m_pDefaultAttributes["addcommas"]=0;this.m_pDefaultAttributes["tosf"]=null;this.m_pDefaultAttributes["serverurl"]=this._getDefaultServerUrl(this.m_oIndexScript.src,window.location.href);};
SL4B_Configuration.prototype.getScriptTagAttribute = SL_AC;SL4B_Configuration.prototype.getIntegerScriptTagAttribute = SL_DL;SL4B_Configuration.prototype.getPositiveIntegerScriptTagAttribute = SL_OV;SL4B_Configuration.prototype.getIntegerScriptTagAttributeInMilliseconds = SL_KW;SL4B_Configuration.prototype.unaryScriptTagAttributeExists = function(A){return (this.getScriptTagAttribute(A)!=null);
};
SL4B_Configuration.prototype.setAttribute = function(B,A){this.m_bFileAttributeSet=true;this.m_pDefaultAttributes[B.toLowerCase()]=A;};
SL4B_Configuration.prototype.getAttribute = function(A){A=A.toLowerCase();return ((typeof this.m_pDefaultAttributes[A]=="undefined") ? null : this.m_pDefaultAttributes[A]);
};
SL4B_Configuration.prototype.getAppletPath = function(){var l_sValue=this.m_oIndexScript.getAttribute("appletpath");
if(l_sValue==null){l_sValue=this.getAttribute("appletpath");}return l_sValue.replace(/(^\/)/,"").replace(/\/$/,"");
};
SL4B_Configuration.prototype.getAppletUrl = function(){var l_sValue=this.m_oIndexScript.getAttribute("appleturl");
if(l_sValue==null){l_sValue=this.getAttribute("appleturl");}return ((l_sValue==null) ? null : l_sValue.replace(/\/$/,""));
};
SL4B_Configuration.prototype.getJsContainerPath = function(){var l_sValue=this.m_oIndexScript.getAttribute("jscontainerpath");
if(l_sValue==null){l_sValue=this.getAttribute("jscontainerpath");}return l_sValue.replace(/(^\/)/,"").replace(/\/$/,"");
};
SL4B_Configuration.prototype.getJsContainerUrl = function(){var l_sValue=this.m_oIndexScript.getAttribute("jscontainerurl");
if(l_sValue==null){l_sValue=this.getAttribute("jscontainerurl");}return ((l_sValue==null) ? null : l_sValue.replace(/\/$/,""));
};
SL4B_Configuration.prototype.getServerUrl = function(){var l_sServerUrl=this.getScriptTagAttribute("serverurl");
if(l_sServerUrl.match(/\/$/)==null){l_sServerUrl+="/";}return l_sServerUrl;
};
SL4B_Configuration.prototype.getAppletJarName = function(){return this.getScriptTagAttribute("appletjar");
};
SL4B_Configuration.prototype.getUsername = function(){return this.getScriptTagAttribute("user");
};
SL4B_Configuration.prototype.getPassword = function(){return this.getScriptTagAttribute("password");
};
SL4B_Configuration.prototype.includeRtsl = function(){return this.unaryScriptTagAttributeExists("includertsl");
};
SL4B_Configuration.prototype.includeRtml = function(){return this.unaryScriptTagAttributeExists("includertml");
};
SL4B_Configuration.prototype.isMasterFrame = function(){return !this.unaryScriptTagAttributeExists("usemasterframe");
};
SL4B_Configuration.prototype.isMultiSource = function(){return this.unaryScriptTagAttributeExists("multisource");
};
SL4B_Configuration.prototype.getService = function(){return this.getScriptTagAttribute("service");
};
SL4B_Configuration.prototype.getKeyMasterConnectionTimeout = function(){return this.getScriptTagAttribute("keymasterconnectiontimeout");
};
SL4B_Configuration.prototype.getKeyMasterKeepAliveInterval = function(){return this.getScriptTagAttribute("keymasterkeepaliveinterval");
};
SL4B_Configuration.prototype.isEnableLatency = function(){return this.getScriptTagAttribute("enablelatency");
};
SL4B_Configuration.prototype.isPollingDisabled = function(){return this.getScriptTagAttribute("disablepolling");
};
SL4B_Configuration.prototype.isStreamingDisabled = function(){return this.getScriptTagAttribute("disablestreaming");
};
SL4B_Configuration.prototype.getClockSyncStrategy = function(){return this.getScriptTagAttribute("clocksyncstrategy");
};
SL4B_Configuration.prototype.getSlidingSyncSize = function(){return this.getScriptTagAttribute("slidingsyncsize");
};
SL4B_Configuration.prototype.getSlidingSyncSpacing = function(){return this.getScriptTagAttribute("slidingsyncspacing");
};
SL4B_Configuration.prototype.getSlidingSyncInitialSpacing = function(){return this.getScriptTagAttribute("slidingsyncinitialspacing");
};
SL4B_Configuration.prototype.getClocksyncBatchSize = function(){return this.getScriptTagAttribute("clocksyncbatchsize");
};
SL4B_Configuration.prototype.getClocksyncSpacing = function(){return this.getScriptTagAttribute("clocksyncspacing");
};
SL4B_Configuration.prototype.getClocksyncPeriod = function(){return this.getScriptTagAttribute("clocksyncperiod");
};
SL4B_Configuration.prototype.getTimestampField = function(){return this.getScriptTagAttribute("timestampfield");
};
SL4B_Configuration.prototype.getFrameId = function(){var l_sId;
if(this.isMasterFrame()){l_sId="master";}else 
{l_sId=this.getScriptTagAttribute("frameid");if(l_sId==null){l_sId=this.getFrameLocation();if(l_sId==null){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"Configuration.getFrameId: The slave frame did not have a id defined on it. This identifier is required for the master/slave functionality to work.");}}}return l_sId;
};
SL4B_Configuration.prototype.getFrameLocation = function(){return this.getScriptTagAttribute("thisframe");
};
SL4B_Configuration.prototype.getMasterFrameLocation = function(){return this.getScriptTagAttribute("usemasterframe");
};
SL4B_Configuration.prototype.getCredentialsProvider = function(){if(this.getKeyMasterUrl()==null||this.getKeyMasterUrl()==""){return this.getScriptTagAttribute("credentialsprovider");
}else 
{return SL4B_ScriptLoader.const_KEYMASTER_CREDENTIALS_PROVIDER;
}};
SL4B_Configuration.prototype.getParameterFromQueryString = function(A){var l_sDebugLevel=null;

try {var l_oNextWindow;

do{l_oNextWindow=(l_oNextWindow) ? l_oNextWindow.parent : window;l_sDebugLevel=this.getParameterFromProvidedQueryString(l_oNextWindow.location.href,A);}while((!l_sDebugLevel)&&(l_oNextWindow.parent!=l_oNextWindow));}catch(e){}
return l_sDebugLevel;
};
SL4B_Configuration.prototype.getParameterFromProvidedQueryString = function(B,A){var l_oMatches=B.match(new RegExp("[?&]"+A+"=([^&#]+)"));
return (l_oMatches) ? l_oMatches[1] : null;
};
SL4B_Configuration.prototype.getDebugLevel = function(){var l_sDebugLevel=this.getParameterFromQueryString("debug");
return (l_sDebugLevel) ? l_sDebugLevel : this.getScriptTagAttribute("debug");
};
SL4B_Configuration.prototype.isSuppressExceptions = function(){var l_sSuppressExceptions=this.getParameterFromQueryString("suppressexceptions");
return (((l_sSuppressExceptions) ? l_sSuppressExceptions : this.getScriptTagAttribute("suppressexceptions"))==="true");
};
SL4B_Configuration.prototype.getRttpDebugLevel = function(){var l_sDebugLevel=this.getParameterFromQueryString("rttpdebuglevel");
return (l_sDebugLevel) ? l_sDebugLevel : this.getScriptTagAttribute("rttpdebuglevel");
};
SL4B_Configuration.prototype.getAppletCheckTimeout = function(){return this.getIntegerScriptTagAttribute("appletchecktimeout");
};
SL4B_Configuration.prototype.getRttpAppletTimeout = function(){return this.getIntegerScriptTagAttribute("rttpapplettimeout");
};
SL4B_Configuration.prototype.includeFlash = SL_JR;SL4B_Configuration.prototype.getRttpProvider = SL_NF;SL4B_Configuration.prototype.getDebugWindowType = SL_CZ;SL4B_Configuration.prototype.isAutoLoadingEnabled = SL_NK;SL4B_Configuration.prototype.yieldBeforeMessageProcessing = SL_LE;SL4B_Configuration.prototype.getCommonDomain = SL_PK;SL4B_Configuration.prototype.loadConfigurationFile = SL_AX;SL4B_Configuration.prototype.loaded = SL_QO;SL4B_Configuration.prototype.getConnectionMethods = SL_PB;SL4B_Configuration.prototype.setPollingConnectionMethods = SL_OP;SL4B_Configuration.prototype.setStreamingConnectionMethods = SL_GG;SL4B_Configuration.prototype.getPollingConnectionMethods = SL_CM;SL4B_Configuration.prototype.getStreamingConnectionMethods = SL_QT;SL4B_Configuration.prototype.getType3PollPeriod = SL_PO;SL4B_Configuration.prototype.getType5ReconnectCount = SL_GQ;SL4B_Configuration.prototype.getType5PadLength = SL_FC;SL4B_Configuration.prototype.getConnectionTimeout = SL_HX;SL4B_Configuration.prototype.getNOOPInterval = SL_HQ;SL4B_Configuration.prototype.getNOOPTimeout = SL_EW;SL4B_Configuration.prototype.getLoginTimeout = SL_LY;SL4B_Configuration.prototype.getMaxGetLength = SL_PS;SL4B_Configuration.prototype.getApplicationId = function(){var l_sClientApplicationId=this.getScriptTagAttribute("applicationid");
return "SL4B"+((l_sClientApplicationId==null||l_sClientApplicationId=="") ? "" : ":"+l_sClientApplicationId);
};
SL4B_Configuration.prototype.getDiscardDelay = function(){return this.getIntegerScriptTagAttribute("discarddelay");
};
SL4B_Configuration.prototype.getJvmFileUrl = function(){return this.getScriptTagAttribute("jvmfileurl");
};
SL4B_Configuration.prototype.getJvmFileDownloadTimeout = function(){return this.getIntegerScriptTagAttribute("jvmfiledownloadtimeout");
};
SL4B_Configuration.prototype.getLogoutDelay = function(){return this.getIntegerScriptTagAttribute("logoutdelay");
};
SL4B_Configuration.prototype.getObjectNameDelimiter = function(){return this.getScriptTagAttribute("objectnamedelimiter");
};
SL4B_Configuration.prototype.getStatsInterval = function(){return this.getIntegerScriptTagAttributeInMilliseconds("statsinterval");
};
SL4B_Configuration.prototype.getStatsReset = function(){return this.getIntegerScriptTagAttributeInMilliseconds("statsreset");
};
SL4B_Configuration.prototype.getStatsTimeout = function(){return this.getIntegerScriptTagAttributeInMilliseconds("statstimeout");
};
SL4B_Configuration.prototype.getKeyMasterUrl = function(){return this.getScriptTagAttribute("keymasterurl");
};
SL4B_Configuration.prototype.getKeyMasterAttempts = function(){return this.getIntegerScriptTagAttribute("keymasterattempts");
};
SL4B_Configuration.prototype.getKeyMasterXHRUrl = function(){return this.getScriptTagAttribute("keymasterxhrurl");
};
SL4B_Configuration.prototype.getUseConfig = function(){return this.getScriptTagAttribute("useconfig");
};
SL4B_Configuration.prototype.getGarbageCollectionFrequency = function(){return this.getPositiveIntegerScriptTagAttribute("gcfreq");
};
SL4B_Configuration.prototype.getMicrosoftGarbageCollectionFrequency = function(){return this.getPositiveIntegerScriptTagAttribute("gcfreqms");
};
SL4B_Configuration.prototype.getSunGarbageCollectionFrequency = function(){return this.getPositiveIntegerScriptTagAttribute("gcfreqsun");
};
SL4B_Configuration.prototype.getCallbackBatchFrequency = function(){return ((this.getRttpProvider()==SL4B_ScriptLoader.const_JAVASCRIPT_RTTP_PROVIDER) ? 0 : this.getIntegerScriptTagAttribute("updatebatchfreq"));
};
SL4B_Configuration.prototype.getMaximumCallbackBatchSize = function(){return this.getPositiveIntegerScriptTagAttribute("maxupdatebatchsize");
};
SL4B_Configuration.prototype.isNoStaleNotify = function(){return this.unaryScriptTagAttributeExists("nostalenotify");
};
SL4B_Configuration.prototype.isNoBrowserStatus = function(){return this.unaryScriptTagAttributeExists("nobrowserstatus");
};
SL4B_Configuration.prototype.isNoStats = function(){return this.unaryScriptTagAttributeExists("nostats");
};
SL4B_Configuration.prototype.isPortlet = function(){return this.unaryScriptTagAttributeExists("portlet");
};
SL4B_Configuration.prototype.isDisableJvmDownload = function(){return this.unaryScriptTagAttributeExists("disablejvmdownload");
};
SL4B_Configuration.prototype.isMultiUpdates = function(){return this.unaryScriptTagAttributeExists("multiupdates");
};
SL4B_Configuration.prototype.isUseStaticHtmlFailoverContainers = function(){return this.unaryScriptTagAttributeExists("usestatichtmlfailovercontainers");
};
SL4B_Configuration.prototype.isDirectEnable = function(){return this.unaryScriptTagAttributeExists("directEnable");
};
SL4B_Configuration.prototype.isHttpEnable = function(){return this.unaryScriptTagAttributeExists("httpEnable");
};
SL4B_Configuration.prototype.isRefreshEnable = function(){return this.unaryScriptTagAttributeExists("refreshEnable");
};
SL4B_Configuration.prototype.getContainerFrameLocation = function(){var l_sCommonContainerFrame=this.getScriptTagAttribute("containerframelocation");
if(l_sCommonContainerFrame==null){var l_sMasterFrameLocation=this.getMasterFrameLocation();
if(l_sMasterFrameLocation!=null&&l_sMasterFrameLocation!=""){var l_oMatch=l_sMasterFrameLocation.match(/(((window)|(self)|(parent)|(top)|(opener))(\.|$))*/);
if(l_oMatch!=null&&l_oMatch[0]!=""){l_sCommonContainerFrame=l_oMatch[0].replace(/\.$/,"");}else 
{l_sCommonContainerFrame="top";}}else 
{l_sCommonContainerFrame="top";}}return l_sCommonContainerFrame;
};
function SL_AC(A){A=A.toLowerCase();var l_sValue=this.m_oIndexScript.getAttribute(A);
if(l_sValue==null){l_sValue=this.getAttribute(A);}return l_sValue;
}
function SL_DL(A){A=A.toLowerCase();var l_nIntegerValue=this.getAttribute(A);
var l_sValue=this.m_oIndexScript.getAttribute(A);
if(this.checkInteger(l_sValue)==true){l_nIntegerValue=parseInt(l_sValue);}return l_nIntegerValue;
}
SL4B_Configuration.prototype.checkInteger = function(A){var isValid=false;
if(A!==null&&!isNaN(A)){var l_nTestValue=parseInt(A,10);
if(l_nTestValue>=0){isValid=true;}}return isValid;
};
function SL_OV(A){A=A.toLowerCase();var l_nPositiveIntegerValue=this.getAttribute(A);
var l_sValue=this.m_oIndexScript.getAttribute(A);
if(this.checkPositiveInteger(l_sValue)==true){l_nPositiveIntegerValue=parseInt(l_sValue);}return l_nPositiveIntegerValue;
}
SL4B_Configuration.prototype.checkPositiveInteger = function(A){var isValid=false;
if(this.checkInteger(A)==true&&parseInt(A)>0){isValid=true;}return isValid;
};
function SL_KW(A){A=A.toLowerCase();var l_nAttributeValue=this.getIntegerScriptTagAttribute(A);
if(l_nAttributeValue==null){l_nAttributeValue=this.getAttribute(A);}else 
if(l_nAttributeValue<500){l_nAttributeValue=l_nAttributeValue*1000;}return l_nAttributeValue;
}
function SL_JR(){return (this.includeRtml()||this.unaryScriptTagAttributeExists("enableflash"));
}
function SL_OP(A,B){if(!SL4B_Browser.isKnownBrowser(A)){throw new SL4B_Error("Configuration method setPollingConnectionMethods called with invalid SL4B_Browser parameter: "+A);
}if(B==null){delete this.m_pBrowserPollingConnectionMethodOverrides[A];}else 
{var l_pConnectionMethods=this.m_pBrowserPollingConnectionMethodOverrides[A];
if(l_pConnectionMethods==null){l_pConnectionMethods=[];this.m_pBrowserPollingConnectionMethodOverrides[A.toString()]=l_pConnectionMethods;}for(var i=0;i<B.length;i++){var l_oConnectionMethod=B[i];
if(!(l_oConnectionMethod instanceof SL4B_ConnectionMethod)){throw new SL4B_Error("Configuration method setPollingConnectionMethods called with invalid SL4B_ConnectionMethod parameter: "+l_oConnectionMethod);
}if(!l_oConnectionMethod.isPolling()){throw new SL4B_Error("Configuration method setPollingConnectionMethods called with non-polling SL4B_ConnectionMethod parameter: "+l_oConnectionMethod);
}l_pConnectionMethods.push(l_oConnectionMethod);}}}
function SL_CM(){if(this.isPollingDisabled()){return [];
}else 
{var l_oBrowser=SL4B_Accessor.getBrowserAdapter().getBrowser();
var l_pPolling=this.m_pBrowserPollingConnectionMethodOverrides[l_oBrowser.toString()];
if(l_pPolling==null){l_pPolling=SL4B_Accessor.getBrowserAdapter().getPollingConnectionTypes();}return l_pPolling;
}}
function SL_GG(A,B){if(!SL4B_Browser.isKnownBrowser(A)){throw new SL4B_Error("Configuration method setStreamingConnectionMethods called with invalid SL4B_Browser parameter: "+A);
}if(B==null){delete this.m_pBrowserStreamingConnectionMethodOverrides[A];}else 
{var l_pConnectionMethods=this.m_pBrowserStreamingConnectionMethodOverrides[A];
if(l_pConnectionMethods==null){l_pConnectionMethods=[];this.m_pBrowserStreamingConnectionMethodOverrides[A.toString()]=l_pConnectionMethods;}for(var i=0;i<B.length;i++){var l_oConnectionMethod=B[i];
if(!(l_oConnectionMethod instanceof SL4B_ConnectionMethod)){throw new SL4B_Error("Configuration method setStreamingConnectionMethods called with invalid SL4B_ConnectionMethod parameter: "+l_oConnectionMethod);
}if(!l_oConnectionMethod.isStreaming()){throw new SL4B_Error("Configuration method setStreamingConnectionMethods called with non-streaming SL4B_ConnectionMethod parameter: "+l_oConnectionMethod);
}l_pConnectionMethods.push(l_oConnectionMethod);}}}
function SL_QT(){if(this.isStreamingDisabled()){return [];
}else 
{var l_oBrowser=SL4B_Accessor.getBrowserAdapter().getBrowser();
var l_pStreaming=this.m_pBrowserStreamingConnectionMethodOverrides[l_oBrowser.toString()];
if(l_pStreaming==null){l_pStreaming=SL4B_Accessor.getBrowserAdapter().getStreamingConnectionTypes();}return l_pStreaming;
}}
function SL_PB(){var l_sConnectionTypes=this.getScriptTagAttribute("connectiontypes");
var l_oConnectionMethods=[];
if(l_sConnectionTypes!=null){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"The Configuration attribute 'connectiontypes' has been deprecated, "+"use the methods SL4B_Configuration.SetPollingConnectionMethods() and SL4B_Configuration.SetStreamingConnectionMethods() "+" to change the default connection methods.");var l_pTypes=l_sConnectionTypes.split(",");
for(var i=0;i<l_pTypes.length;i++){var l_nType=l_pTypes[i];
if(SL4B_ConnectionMethod.AllMethods[l_nType]==null){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"Configuration attribute 'connectiontypes' contains invalid connection type: "+l_nType);}else 
{l_oConnectionMethods.push(SL4B_ConnectionMethod.AllMethods[l_nType]);}}}else 
{if(this.isDirectEnable()||this.isHttpEnable()||this.isRefreshEnable()){if(this.isRefreshEnable()){l_oConnectionMethods.push(SL4B_ConnectionMethod.POLLING);}else 
{l_oConnectionMethods.push(SL4B_ConnectionMethod.FOREVER_FRAME);l_oConnectionMethods.push(SL4B_ConnectionMethod.POLLING);}}}return l_oConnectionMethods;
}
function SL_PO(){return this.getIntegerScriptTagAttribute("type3pollperiod");
}
function SL_GQ(){return this.getIntegerScriptTagAttribute("type5reconnectcount");
}
function SL_FC(){return this.getIntegerScriptTagAttribute("type5padlength");
}
function SL_HX(){return this.getPositiveIntegerScriptTagAttribute("connectiontimeout");
}
function SL_HQ(){return this.getPositiveIntegerScriptTagAttribute("noopinterval");
}
function SL_EW(){return this.getPositiveIntegerScriptTagAttribute("nooptimeout");
}
function SL_LY(){return this.getPositiveIntegerScriptTagAttribute("logintimeout");
}
function SL_PS(){return this.getIntegerScriptTagAttribute("maxgetlength");
}
function SL_NF(){return this.getScriptTagAttribute("rttpprovider").toLowerCase();
}
function SL_CZ(){return this.getScriptTagAttribute("debugwindowtype");
}
function SL_NK(){var l_vEnableAutoLoading=this.getScriptTagAttribute("enableautoloading");
if(typeof l_vEnableAutoLoading=="string"){l_vEnableAutoLoading=(l_vEnableAutoLoading.toLowerCase()=="true");}return l_vEnableAutoLoading;
}
function SL_LE(){var l_vYield=this.getScriptTagAttribute("yieldbeforemessageprocessing");
if(typeof l_vYield=="string"){l_vYield=(l_vYield.toLowerCase()=="true");}return l_vYield;
}
function SL_PK(){var l_sCommonDomain=this.getScriptTagAttribute("commondomain");
if(l_sCommonDomain==null){l_sCommonDomain=GF_CommonDomainExtractor.getCommonDomain();}return l_sCommonDomain;
}
function SL_AX(){var l_sConfigurationFileUrl=this.getScriptTagAttribute("configurationfile");
if(l_sConfigurationFileUrl!=null){this.m_bUsingFile=true;SL4B_ScriptLoader.loadScript(l_sConfigurationFileUrl);SL4B_ScriptLoader.loadSl4bScript("configuration/configuration-file-loaded.js");}else 
{this.loaded();}}
function SL_QO(){if(this.m_bUsingFile&&!this.m_bFileAttributeSet){SL4B_Accessor.getLogger().log(SL4B_DebugLevel.const_WARN_INT,"Configuration.loaded: Specified configuration file was empty. There may have been an error loading the file!");}SL4B_Accessor.getLogger().printMessage(SL4B_Version.getVersionInfo());SL4B_Accessor.getLogger().printMessage("SL4B running in browser: "+navigator.userAgent);var l_pMethodNamesToIgnoreSet=new Object();
l_pMethodNamesToIgnoreSet["getIntegerScriptTagAttributeInMilliseconds"]=true;l_pMethodNamesToIgnoreSet["getPositiveIntegerScriptTagAttribute"]=true;l_pMethodNamesToIgnoreSet["getIntegerScriptTagAttribute"]=true;l_pMethodNamesToIgnoreSet["getScriptTagAttribute"]=true;l_pMethodNamesToIgnoreSet["getAttribute"]=true;l_pMethodNamesToIgnoreSet["getParameterFromProvidedQueryString"]=true;l_pMethodNamesToIgnoreSet["getParameterFromQueryString"]=true;var l_oConfigurationMethodRegExp=/(^get)|(^is)|(^include)/;
var l_pMethodNames=new Array();
for(l_sMethod in this){if(l_sMethod.match(l_oConfigurationMethodRegExp)&&!l_pMethodNamesToIgnoreSet[l_sMethod]&&typeof this[l_sMethod]=="function"){l_pMethodNames.push(l_sMethod);}}l_pMethodNames.sort();for(var l_nMethod=0,l_nLength=l_pMethodNames.length;l_nMethod<l_nLength;++l_nMethod){var l_sMethod=l_pMethodNames[l_nMethod];
SL4B_Accessor.getLogger().printMessage("SL4B configuration ["+l_sMethod+"()]: "+this[l_sMethod]());}SL4B_Accessor.getLogger().printMessage("SL4B configuration [yieldBeforeMessageProcessing()]: "+this.yieldBeforeMessageProcessing());SL4B_ScriptLoader.loadConfiguredScripts(this);}
function SL_JV(){
try {SL4B_Accessor.setConfiguration(new SL4B_Configuration());}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
SL4B_Accessor.getConfiguration().loadConfigurationFile();SL4B_Accessor.getCapabilities().add("HttpRequestLineLength",SL4B_Accessor.getConfiguration().getMaxGetLength());}
var SL4B_MethodInvocationProxy=function(){};
if(false){function SL4B_MethodInvocationProxy(){}
}SL4B_MethodInvocationProxy = function(){if(SL4B_Accessor.getConfiguration().isSuppressExceptions()===true&&!SL4B_JsUnit.isUnobfuscated()){SL4B_MethodInvocationProxy.prototype.invoke = SL4B_MethodInvocationProxy.prototype._invokeWithTryCatch;}else 
{SL4B_MethodInvocationProxy.prototype.invoke = SL4B_MethodInvocationProxy.prototype._invoke;}};
SL4B_MethodInvocationProxy.prototype.invoke = function(B,A,D,C){throw new SL4B_Error("MethodInvocationProxy.invoke: method not implemented");
};
SL4B_MethodInvocationProxy.prototype._invoke = function(B,A,C){B[A].call(B,C[0],C[1],C[2],C[3],C[4],C[5],C[6],C[7],C[8],C[9]);};
SL4B_MethodInvocationProxy.prototype._invokeWithTryCatch = function(B,A,D,C){
try {this._invoke(B,A,D);}catch(e){if(C!=null){C(e);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"MethodInvocationProxy._invokeWithTryCatch: Error processing callback for object \"{0}\" (method: \"{1}\", parameters: \"{2}\"; Unexpected exception ({3})",B,A,D.join(),SL4B_Accessor.getBrowserAdapter().convertExceptionToString(e));}}
};
function SL_HC(){SL4B_MethodInvocationProxy=new SL4B_MethodInvocationProxy();}
var SL4B_AbstractCredentialsProvider=function(){};
if(false){function SL4B_AbstractCredentialsProvider(){}
}SL4B_AbstractCredentialsProvider = function(){};
SL4B_AbstractCredentialsProvider.prototype.getCredentials = function(A){throw new SL4B_Error("getCredentials method not implemented");
};
SL4B_AbstractCredentialsProvider.prototype.getUsername = function(){throw new SL4B_Error("getUsername method not implemented");
};
var SL4B_StandardCredentialsProvider=function(){};
if(false){function SL4B_StandardCredentialsProvider(){}
}SL4B_StandardCredentialsProvider = function(){};
SL4B_StandardCredentialsProvider.prototype = new SL4B_AbstractCredentialsProvider;SL4B_StandardCredentialsProvider.prototype.getCredentials = SL_BH;SL4B_StandardCredentialsProvider.prototype.getUsername = SL_MF;function SL_BH(A){var l_oConfiguration=SL4B_Accessor.getConfiguration();
A.login(l_oConfiguration.getUsername(),l_oConfiguration.getPassword());}
function SL_MF(){return SL4B_Accessor.getConfiguration().getUsername();
}
function SL_RB(){SL4B_Accessor.setCredentialsProvider(new SL4B_StandardCredentialsProvider());}
C_DynamicIFrameLoader = new function(){document.write("<div id=\"iframeloader\"></div>");var l_oIFrameIdentifierToElementMap=new Object();
var l_oIFrameIdentifierToTimeoutMap=new Object();
this.loadIFrame = function(C,D,B,A){if(typeof B.scriptLoadTimeout!="function"){throw new SL4B_Exception("C_DynamicIFrameLoader.loadIFrame: l_oErrorCallback parameter must implement scriptLoadTimeout() ");
}D+=((D.indexOf("?")==-1) ? "?" : "&")+"time="+(new Date()).valueOf();var l_sCommonDomain=SL4B_Accessor.getConfiguration().getCommonDomain();
if(l_sCommonDomain!=null){D+="&"+SL4B_JavaScriptRttpProviderConstants.const_DOMAIN_PARAMETER+"="+l_sCommonDomain;}var l_oIFrameElement=l_oIFrameIdentifierToElementMap[C];
if(typeof l_oIFrameElement!="undefined"){document.getElementById("iframeloader").removeChild(l_oIFrameElement);}SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Creating IFRAME for {0} at URL {1} with a timeout of {2}ms",C,D,A);l_oIFrameElement=document.createElement('iframe');l_oIFrameElement.src=D;l_oIFrameElement.style.display="none";l_oIFrameIdentifierToElementMap[C]=l_oIFrameElement;document.getElementById("iframeloader").appendChild(l_oIFrameElement);var self=this;
var l_nTimeout=setTimeout(function(){self.checkLoaded(C,B);},A);
l_oIFrameIdentifierToTimeoutMap[C]=l_nTimeout;};
this.checkLoaded = function(B,A){var l_nTimeout=l_oIFrameIdentifierToTimeoutMap[B];
if(typeof l_nTimeout!="undefined"){this.clearIFrame(B);A.scriptLoadTimeout(B);}};
this.iframeLoaded = function(A){var l_nTimeout=l_oIFrameIdentifierToTimeoutMap[A];
if(typeof l_nTimeout!="undefined"){clearTimeout(l_nTimeout);this.clearIFrame(A);}};
this.clearIFrame = function(A){var l_oIFrameElement=l_oIFrameIdentifierToElementMap[A];
if(typeof l_oIFrameElement!="undefined"){document.getElementById("iframeloader").removeChild(l_oIFrameElement);}delete (l_oIFrameIdentifierToElementMap[A]);delete (l_oIFrameIdentifierToTimeoutMap[A]);};
};
var SL4B_KeymasterIFrameManager=function(){};
if(false){function SL4B_KeymasterIFrameManager(){}
}SL4B_KeymasterIFrameManager = function(A,B){this.m_sKeyMasterUrl=B;this.m_sLastLoadedUrl="";this.m_oListener=A;this.nKeepAliveTimer=null;SL4B_Logger.logConnectionMessage(true,"Using deprecated iframe loading method to access keymaster. Use XHRKeymaster instead of StandardKeyMaster : {0}",this.m_sKeyMasterUrl);};
SL4B_KeymasterIFrameManager.prototype.getCredentials = function(A){SL4B_Logger.logConnectionMessage(true,"KeyMasterCredentialsProvider.getCredentials: Requesting credentials");var sUserName=SL4B_KeymasterIFrameManager.escapeParameter(SL4B_Accessor.getConfiguration().getUsername());
var nConnectionTimeout=SL4B_Accessor.getConfiguration().getKeyMasterConnectionTimeout();
var l_sSeparator=((this.m_sKeyMasterUrl.indexOf("?")!=-1) ? "&" : "?");
this.m_sLastLoadedUrl=this.m_sKeyMasterUrl+l_sSeparator+"type=html&sourceid="+SL4B_KeymasterIFrameManager.escapeParameter(A)+"&username="+sUserName;SL4B_Logger.logConnectionMessage(true,"SL4B_KeyMaster.requestToken: Credentials being requested from {0}",this.m_sLastLoadedUrl);C_DynamicIFrameLoader.loadIFrame("keymaster",this.m_sLastLoadedUrl,this,nConnectionTimeout);};
SL4B_KeymasterIFrameManager.prototype.startKeepAlive = function(C,A,B){if(this.nKeepAliveTimer==null){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"KeyMaster: Starting keep-alive polling");var oThis=this;
this.nKeepAliveTimer=setInterval(function(){oThis.sendKeepAlive();},A);}};
SL4B_KeymasterIFrameManager.prototype.stopKeepAlive = function(){if(this.nKeepAliveTimer!=null){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"KeyMaster: Stopping keep-alive polling");clearInterval(this.nKeepAliveTimer);this.nKeepAliveTimer=null;}};
SL4B_KeymasterIFrameManager.prototype.sendKeepAlive = function(){var l_sUrl="";
var l_oMatch=this.m_sKeyMasterUrl.match(/((^|\/)servlet\/)/);
if(l_oMatch!=null){l_sUrl=this.m_sKeyMasterUrl.replace(/((^|\/)servlet\/.*)/,l_oMatch[2]+"poll.jsp");}else 
{l_sUrl=this.m_sKeyMasterUrl.replace(/[^\/]+$/,"poll.jsp");}SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"KeyMaster: Sending session keep-alive at URL {0}",l_sUrl);C_DynamicIFrameLoader.loadIFrame("keymaster-poll",l_sUrl,this,SL4B_Accessor.getConfiguration().getKeyMasterConnectionTimeout());};
SL4B_KeymasterIFrameManager.prototype.scriptLoadTimeout = function(A){if(A=="keymaster"){this.m_oListener.failed("Could not load keymaster script",this.m_sLastLoadedUrl,null,0);}else 
if(A=="keymaster-poll"){var l_sUrl="";
var l_oMatch=this.m_sKeyMasterUrl.match(/((^|\/)servlet\/)/);
if(l_oMatch!=null){l_sUrl=this.m_sKeyMasterUrl.replace(/((^|\/)servlet\/.*)/,l_oMatch[2]+"poll.jsp");}else 
{l_sUrl=this.m_sKeyMasterUrl.replace(/[^\/]+$/,"poll.jsp");}this.m_oListener.keepAliveFailure("Keep-alive polling timed out.",l_sUrl,null,0);}};
SL4B_KeymasterIFrameManager.escapeParameter = function(A){return escape(A).replace(/[.]/g,"%2E").replace(/@/g,"%40");
};
function SigGen_Signature(B,A,C){
try {C_DynamicIFrameLoader.iframeLoaded("keymaster");SL4B_Accessor.getCredentialsProvider().success(A,C);}catch(e){SL4B_Logger.logConnectionMessage(true,"SigGen_Signature: failed to retrieve SL4B_CredentialsProvider "+e.message);SL4B_Accessor.getExceptionHandler().processException(e);}
}
function SigGen_AuthenticationFailed(B,A){
try {C_DynamicIFrameLoader.iframeLoaded("keymaster");SL4B_Accessor.getCredentialsProvider().failed(A,SL4B_Accessor.getCredentialsProvider().m_oRequestManager.m_sLastLoadedUrl,null,200);}catch(e){SL4B_Logger.logConnectionMessage(true,"SigGen_AuthenticationFailed: failed to retrieve SL4B_CredentialsProvider "+e.message);SL4B_Accessor.getExceptionHandler().processException(e);}
}
function SigGen_KeepAliveLoaded(){C_DynamicIFrameLoader.iframeLoaded("keymaster-poll");SL4B_Accessor.getCredentialsProvider().keepAliveSuccess();}
var SL4B_KeymasterXHRManager=function(){};
if(false){function SL4B_KeymasterXHRManager(A,B){}
}SL4B_KeymasterXHRManager = function(A,B){this.m_sKeyMasterUrl=B;var sCommonDomain=SL4B_Accessor.getConfiguration().getCommonDomain();
if(sCommonDomain!=null){this.m_sKeyMasterUrl=SL4B_KeymasterXHRManager.appendParameter(this.m_sKeyMasterUrl,"domain",sCommonDomain);}this.m_oListener=A;this.storedRequests=[];this.iFrameLoaded=false;var oThis=this;
this._iframeLoadedFunction = function(){oThis.xhrIframeLoaded();};
var keymasterIframe=document.createElement("div");
keymasterIframe.id='keymaster';document.body.appendChild(keymasterIframe);};
SL4B_KeymasterXHRManager.prototype.getCredentials = function(A){var oListener=this.m_oListener;
var oThis=this;
var loadCredentials=function(){var sUserName=SL4B_KeymasterIFrameManager.escapeParameter(SL4B_Accessor.getConfiguration().getUsername());
var nConnectionTimeout=SL4B_Accessor.getConfiguration().getKeyMasterConnectionTimeout();
SL4B_Logger.logConnectionMessage(true,"KeyMasterCredentialsProvider.getCredentials: Requesting credentials");oThis.m_oEmbeddedKeyMaster.requestToken(oListener,A,sUserName,nConnectionTimeout);};
this.removeFunctionFromQueue("load credentials");this.withIFrameLoaded(loadCredentials,"load credentials");};
SL4B_KeymasterXHRManager.prototype.startKeepAlive = function(C,A,B){var oThis=this;
this.withIFrameLoaded(function(){oThis.m_oEmbeddedKeyMaster.startKeepAlive(C,A,B);},"start keep alive");};
SL4B_KeymasterXHRManager.prototype.stopKeepAlive = function(){var oThis=this;
this.withIFrameLoaded(function(){oThis.m_oEmbeddedKeyMaster.stopKeepAlive();},"stop keep alive");};
SL4B_KeymasterXHRManager.prototype.withIFrameLoaded = function(B,A){if(this.m_oEmbeddedKeyMaster!=null){B();}else 
{SL4B_Logger.logConnectionMessage(true,"KeyMasterCredentialsProvider.getCredentials: {0} waiting for iframe to load.",A);B.tag=A;this.storedRequests.push(B);}if(this.iFrameLoaded==false){this.iFrameLoaded=true;this.loadXhrIframe();}};
SL4B_KeymasterXHRManager.prototype.loadXhrIframe = function(){var oThis=this;
this.m_nIFrameLoadingTimeout=null;this.m_oIFrameContainer=document.getElementById('keymaster');this.m_oIFrame=document.createElement('iframe');this.m_oIFrame.src=this.m_sKeyMasterUrl;this.m_oIFrame.style.display="none";if(this.m_oIFrame.addEventListener!=null){this.m_oIFrame.addEventListener("load",this._iframeLoadedFunction,false);}else 
{this.m_oIFrame.attachEvent("onload",this._iframeLoadedFunction);}this.m_nIFrameLoadingTimeout=setTimeout(function(){oThis.xhrIframeLoadingTimedOut();},SL4B_Accessor.getConfiguration().getKeyMasterConnectionTimeout());SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"SL4B_KeyMasterCredentialsProvider: Loading initial KeyMaster page");this.m_oIFrameContainer.appendChild(this.m_oIFrame);};
SL4B_KeymasterXHRManager.prototype.processStoredRequests = function(){for(var i=0;i<this.storedRequests.length;++i){this.storedRequests[i]();}};
SL4B_KeymasterXHRManager.prototype.removeFunctionFromQueue = function(A){for(var i=this.storedRequests.length-1;i>=0;--i){if(this.storedRequests[i].tag==A){this.storedRequests.splice(i,1);}}};
SL4B_KeymasterXHRManager.prototype.xhrIframeLoaded = function(){if(this.m_nIFrameLoadingTimeout!=null){clearTimeout(this.m_nIFrameLoadingTimeout);}
try {this.m_oEmbeddedKeyMaster=this.m_oIFrame.contentWindow.KeyMaster;if(this.m_oEmbeddedKeyMaster==null||this.m_oIFrame.contentWindow.KeyMasterListener==null){var iframeDoc=this.m_oIFrame.contentWindow.document;
var contentType=null;
if(iframeDoc.contentType==null){contentType=iframeDoc.mimeType;}else 
{contentType=iframeDoc.contentType;}var sContents=iframeDoc.documentElement.innerHTML;
SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"SL4B_KeyMasterCredentialsProvider: *** Bad Keymaster page");this._reset();this.m_oListener.failed("Unexpected initial KeyMaster page.  Type='"+contentType+"'",this.m_sKeyMasterUrl,sContents,200);return;
}}catch(e){this._reset();var errMsg="Error accessing initial KeyMaster page: "+e.message+" The page probably did not set document.domain";
this.m_oListener.failed(errMsg,this.m_sKeyMasterUrl,null,200);return;
}
SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"SL4B_KeyMasterCredentialsProvider: Initial KeyMaster page loaded");this.processStoredRequests();};
SL4B_KeymasterXHRManager.prototype._reset = function(){if(this.m_oIFrame){this._deleteIframe();}this.m_oEmbeddedKeyMaster=undefined;this.iFrameLoaded=false;this.storedRequests=[];};
SL4B_KeymasterXHRManager.prototype._deleteIframe = function(){if(this.m_oIFrame.removeEventListener!=null){this.m_oIFrame.removeEventListener("load",this._iframeLoadedFunction,false);}else 
if(this.m_oIFrame.detachEvent!=null){this.m_oIFrame.detachEvent("onload",this._iframeLoadedFunction);}this.m_oIFrameContainer.removeChild(this.m_oIFrame);};
SL4B_KeymasterXHRManager.prototype.xhrIframeLoadingTimedOut = function(){this._reset();SL4B_Logger.logConnectionMessage(true,"SL4B_KeyMasterCredentialsProvider: Could not load initial KeyMaster page: Timeout");this.m_oListener.failed("Could not load initial KeyMaster page: Timeout after "+SL4B_Accessor.getConfiguration().getKeyMasterConnectionTimeout()+"ms",this.m_sKeyMasterUrl,null,0);};
SL4B_KeymasterXHRManager.appendParameter = function(A,C,B){if(A==null||C==null){return A;
}if(B==null){B="";}var sAppendChar="?";
if(A.indexOf("?")==A.length-1){sAppendChar="";}else 
if(A.indexOf("?")>=0){sAppendChar="&";}A+=sAppendChar+C+"="+B;return A;
};
var SL4B_KeyMasterCredentialsProvider=function(){};
if(false){function SL4B_KeyMasterCredentialsProvider(){}
}SL4B_KeyMasterCredentialsProvider = function(){this.m_sSourceId="default";this.m_oRequestManager=null;this.m_sUserName="";this.m_oRttpProvider=null;this.reconnectAttempt=0;this.doneBackwardsCompatibleCheck=false;this.storedRequests=[];this.m_sKeyMasterToken=null;this.iFrameLoaded=false;if(SL4B_Accessor.getConfiguration().getKeyMasterUrl()==null){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"SL4B_KeyMasterCredentialsProvider: KeyMaster URL has not been defined");}};
SL4B_KeyMasterCredentialsProvider.prototype = new SL4B_AbstractCredentialsProvider;SL4B_KeyMasterCredentialsProvider.prototype.getCredentials = SL_RF;SL4B_KeyMasterCredentialsProvider.prototype.getKeyMasterToken = SL_IB;SL4B_KeyMasterCredentialsProvider.prototype.getUsername = SL_GN;SL4B_KeyMasterCredentialsProvider.prototype.stopKeepAlive = function(){if(this.m_oRequestManager==null){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"SL4B_KeyMasterCredentialsProvider.stopKeepAlive: KeyMaster URL was not been defined.  Unable to stop keepalive.");return;
}this.m_oRequestManager.stopKeepAlive();};
SL4B_KeyMasterCredentialsProvider.prototype.startKeepAlive = function(){if(this.m_oRequestManager==null){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"SL4B_KeyMasterCredentialsProvider.startKeepAlive: KeyMaster URL was not been defined.  Unable to start keepalive.");return;
}var l_nKeepAliveInterval=SL4B_Accessor.getConfiguration().getKeyMasterKeepAliveInterval();
if(l_nKeepAliveInterval>0){var oThis=this;
this.m_oRequestManager.startKeepAlive({success:function(){oThis.keepAliveSuccess();}, failed:function(B,A,C,D){oThis.keepAliveFailure(B,A,C,D);}, timedOut:function(A,B){oThis.keepAliveTimedOut(A,B);}},l_nKeepAliveInterval,SL4B_Accessor.getConfiguration().getKeyMasterConnectionTimeout());}};
SL4B_KeyMasterCredentialsProvider.prototype._internalGetCredentials = function(){var sKeyMasterUrl=SL4B_Accessor.getConfiguration().getKeyMasterUrl();
var sXhrKeymaster=SL4B_Accessor.getConfiguration().getKeyMasterXHRUrl();
if(this.doneBackwardsCompatibleCheck==false){this.doneBackwardsCompatibleCheck=true;if(sXhrKeymaster==null){if(sKeyMasterUrl!=null){this.m_oRequestManager=new SL4B_KeymasterIFrameManager(this,sKeyMasterUrl);}else 
{}}else 
if(this.usingFirefoxAndForeverFrame()==true){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"SL4B_KeyMasterCredentialsProvider: Firefox and Forever Frame detected");if(sKeyMasterUrl!=null){this.m_oRequestManager=new SL4B_KeymasterIFrameManager(this,sKeyMasterUrl);}else 
{}}else 
{this.m_oRequestManager=new SL4B_KeymasterXHRManager(this,sXhrKeymaster);}}if(this.m_oRequestManager==null){this.logConnectionError("KeyMaster error - KeyMaster URL has not been defined.");return;
}this.m_sUserName="";this.stopKeepAlive();this.m_oRequestManager.getCredentials(this.m_sSourceId);};
function SL_RF(A){this.m_oRttpProvider=A;this.reconnectAttempt=0;this._internalGetCredentials();}
function SL_IB(){return this.m_sKeyMasterToken;
}
function SL_GN(){return this.m_sUserName;
}
SL4B_KeyMasterCredentialsProvider.prototype.logConnectionError = function(A){C_CallbackQueue.addCallback(new Array(this.m_oRttpProvider,"notifyConnectionListeners",this.m_oRttpProvider.const_LOGIN_ERROR_CONNECTION_EVENT,A));};
SL4B_KeyMasterCredentialsProvider.prototype.usingFirefoxAndForeverFrame = function(){var result=false;
if(SL4B_Accessor.getBrowserAdapter().isFirefox()){var connections=this.m_oRttpProvider.getLiberatorConfiguration().getAllConnectionData();
for(var i=0;i<connections.length;++i){if(connections[i].getMethod()==SL4B_ConnectionMethod.FOREVER_FRAME){result=true;break;
}}}return result;
};
SL4B_KeyMasterCredentialsProvider.prototype.success = function(B,A){this.m_sUserName=B;this.m_sKeyMasterToken=A;C_CallbackQueue.addCallback(new Array(this.m_oRttpProvider,"notifyConnectionListeners",this.m_oRttpProvider.const_INFO_CONNECTION_EVENT,"KeyMaster authentication success: Attempting Liberator login... "));window.setTimeout("SL4B_Accessor.getRttpProvider().login('"+this.m_sUserName+"','"+A+"')",0);this.startKeepAlive();};
SL4B_KeyMasterCredentialsProvider.prototype.failed = function(D,A,B,C){this.m_sKeyMasterToken=null;var message="KeyMaster error - "+D;
if(A!=null){message+=" when loading "+A;}if(C!=200&&C!=null&&C!=0){message+=" (code:"+C+")";}if(B!=null&&B.length>0){message+=" response="+B;}SL4B_Logger.logConnectionMessage(true,"KeyMasterCredentialsProvider.failed: {0}",message);var maximumRetries=SL4B_Accessor.getConfiguration().getKeyMasterAttempts();
var bRetry=++this.reconnectAttempt<maximumRetries;
var bRetriable=C==0||C==404||C>=500;
if(bRetry&&bRetriable){SL4B_Logger.logConnectionMessage(true,"KeyMasterCredentialsProvider: Retrying Keymaster");this._internalGetCredentials();}else 
{this.logConnectionError(message);}};
SL4B_KeyMasterCredentialsProvider.prototype.timedOut = function(A,B){this.failed("Timed out after "+B+"ms",A,"",0);};
SL4B_KeyMasterCredentialsProvider.prototype.keepAliveSuccess = function(){SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"Keymaster server session alive");};
SL4B_KeyMasterCredentialsProvider.prototype.keepAliveFailure = function(B,A,C,D){SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"Keymaster polling failed to access {0}: {1} code={2} {3}",A,B,D,C);C_CallbackQueue.addCallback(new Array(this.m_oRttpProvider,"notifyConnectionListeners",this.m_oRttpProvider.const_CREDENTIALS_PROVIDER_SESSION_ERROR_CONNECTION_EVENT,"Keymaster polling failed: "+B,A,C,D));};
SL4B_KeyMasterCredentialsProvider.prototype.keepAliveTimedOut = function(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"Keymaster polling timed out after {0} contacting {1}",B,A);C_CallbackQueue.addCallback(new Array(this.m_oRttpProvider,"notifyConnectionListeners",this.m_oRttpProvider.const_CREDENTIALS_PROVIDER_SESSION_ERROR_CONNECTION_EVENT,"Keymaster polling timed out after "+B+"ms",A,null,null));};
function SL_CU(){SL4B_Accessor.setCredentialsProvider(new SL4B_KeyMasterCredentialsProvider());}
var SL4B_LiberatorConfiguration=function(){};
if(false){function SL4B_LiberatorConfiguration(){}
}SL4B_LiberatorConfiguration = function(){this.m_nCurrentConnection=-1;this.m_nSuccessfulConnection=-1;this.m_nIgnoreConnection=-1;this.m_pConnectionDatas=new Array();};
SL4B_LiberatorConfiguration.prototype.initialise = function(){this.m_nCurrentConnection=-1;this.m_nSuccessfulConnection=-1;this.m_nIgnoreConnection=-1;this.m_pConnectionDatas=new Array();};
SL4B_LiberatorConfiguration.prototype.addConnection = function(A){this.m_pConnectionDatas.push(A);};
SL4B_LiberatorConfiguration.prototype.getNextConnection = function(){var l_oConfigurationData=null;
if(this.m_nSuccessfulConnection!=-1){l_oConfigurationData=this.m_pConnectionDatas[this.m_nSuccessfulConnection];this.m_nIgnoreConnection=this.m_nSuccessfulConnection;this.m_nSuccessfulConnection=-1;this.m_nCurrentConnection=-1;}else 
{++this.m_nCurrentConnection;if(this.m_nCurrentConnection==this.m_nIgnoreConnection){++this.m_nCurrentConnection;}if(this.m_nCurrentConnection<this.m_pConnectionDatas.length){l_oConfigurationData=this.m_pConnectionDatas[this.m_nCurrentConnection];}}return l_oConfigurationData;
};
SL4B_LiberatorConfiguration.prototype.peekAtNextConnection = function(){var l_oConfigurationData=null;
if(this.m_nSuccessfulConnection!=-1){l_oConfigurationData=this.m_pConnectionDatas[this.m_nSuccessfulConnection];}else 
{var l_nCurrentConnection=this.m_nCurrentConnection+1;
if(l_nCurrentConnection==this.m_nIgnoreConnection){++l_nCurrentConnection;}if(l_nCurrentConnection<this.m_pConnectionDatas.length){l_oConfigurationData=this.m_pConnectionDatas[l_nCurrentConnection];}}return l_oConfigurationData;
};
SL4B_LiberatorConfiguration.prototype.getAllConnectionData = function(){return this.m_pConnectionDatas;
};
SL4B_LiberatorConfiguration.prototype.resetConnections = function(){this.m_nCurrentConnection=-1;this.m_nSuccessfulConnection=-1;this.m_nIgnoreConnection=-1;};
SL4B_LiberatorConfiguration.prototype.connectionOk = function(){this.m_nSuccessfulConnection=this.m_nCurrentConnection;};
SL4B_LiberatorConfiguration.prototype.toString = function(){var l_sValue="LiberatorConfiguration:\n";
for(var l_nCount=0;l_nCount<this.m_pConnectionDatas.length;l_nCount++){var l_oConnectionData=this.m_pConnectionDatas[l_nCount];
l_sValue+=l_oConnectionData.toString()+"\n";}return l_sValue;
};
SL4B_LiberatorConfiguration.prototype.toSimpleString = function(){var l_sValue="";
for(var l_nCount=0;l_nCount<this.m_pConnectionDatas.length;l_nCount++){var l_oConnectionData=this.m_pConnectionDatas[l_nCount];
l_sValue+=l_oConnectionData.m_sProtocol+" ";l_sValue+=l_oConnectionData.m_sAddress+" ";l_sValue+=l_oConnectionData.m_sPort+" ";l_sValue+=l_oConnectionData.m_oMethod+", ";}return l_sValue;
};
var SL4B_SimpleLiberatorConfiguration=function(){};
if(false){function SL4B_SimpleLiberatorConfiguration(){}
}SL4B_SimpleLiberatorConfiguration = function(){this.initialise();var l_oConfiguration=SL4B_Accessor.getConfiguration();
var l_sServerUrl=l_oConfiguration.getServerUrl();
var l_sProtocol=null;
var l_sAddress=null;
var l_sPort=null;
if(l_sServerUrl.match(/^http/)){l_sProtocol=l_sServerUrl.match(/^(https?)/)[1];l_sAddress=l_sServerUrl.match(/^https?:\/\/([^:\/]+)/)[1];var l_oMatch=l_sServerUrl.match(/:(\d+)/);
l_sPort=((l_oMatch==null) ? null : l_oMatch[1]);}var l_pMethods=l_oConfiguration.getConnectionMethods();
if(l_pMethods.length==0){var l_pStreamingConnectionMethods=l_oConfiguration.getStreamingConnectionMethods();
if(l_pStreamingConnectionMethods.length!=0){l_pMethods.push(l_pStreamingConnectionMethods[0]);}var l_pPollingConnectionMethods=l_oConfiguration.getPollingConnectionMethods();
if(l_pPollingConnectionMethods.length!=0){l_pMethods.push(l_pPollingConnectionMethods[0]);}}for(var l_oMethod=0,l_nLength=l_pMethods.length;l_oMethod<l_nLength;++l_oMethod){var l_oConnectionMethod=l_pMethods[l_oMethod];
this.addConnection(new SL4B_ConnectionData(l_sProtocol,l_sAddress,l_sPort,l_oConnectionMethod));}};
SL4B_SimpleLiberatorConfiguration.prototype = new SL4B_LiberatorConfiguration;var SL4B_ConnectionData=function(){};
if(false){function SL4B_ConnectionData(){}
}SL4B_ConnectionData = function(D,A,B,C){this.m_sProtocol=D;this.m_sAddress=A;this.m_sPort=B;this.m_oMethod=C;this.getProtocol = function(){return this.m_sProtocol;
};
this.getAddress = function(){return this.m_sAddress;
};
this.getPort = function(){return this.m_sPort;
};
this.getMethod = function(){return this.m_oMethod;
};
this.toString = function(){var l_sValue="ConnectionData(";
l_sValue+="Protocol = "+this.m_sProtocol+", ";l_sValue+="Address = "+this.m_sAddress+", ";l_sValue+="Port = "+this.m_sPort+", ";l_sValue+="Method = "+this.m_oMethod+")";return l_sValue;
};
};
SL4B_ConnectionData.prototype.getServerUrl = function(){var l_sServerUrl="";
if(this.m_sProtocol!=null){l_sServerUrl=this.m_sProtocol+"://"+this.m_sAddress+((this.m_sPort!=null) ? ":"+this.m_sPort : "");}else 
{l_sServerUrl=SL4B_Accessor.getConfiguration().getServerUrl().replace(/\/$/,"");}return l_sServerUrl;
};
function GF_RttpCommandQueue(){this.m_pQueuedCommands=new Array();}
GF_RttpCommandQueue.prototype.sendNext = GF_RttpCommandQueue_SendNext;GF_RttpCommandQueue.prototype.queueCommand = GF_RttpCommandQueue_QueueCommand;GF_RttpCommandQueue.prototype.checkArguments = GF_RttpCommandQueue_CheckArguments;GF_RttpCommandQueue.prototype.isEmpty = function(){return (this.m_pQueuedCommands.length==0);
};
GF_RttpCommandQueue.prototype.getObject = function(C,B,A){this.queueCommand(SL_EX.const_GET_OBJECT,C,B,A);};
GF_RttpCommandQueue.prototype.getObjects = function(C,A,B){this.queueCommand(SL_EX.const_GET_OBJECTS,C,A,B);};
GF_RttpCommandQueue.prototype.removeObject = function(C,B,A){this.queueCommand(SL_EX.const_REMOVE_OBJECT,C,B,A);};
GF_RttpCommandQueue.prototype.removeObjects = function(C,A,B){this.queueCommand(SL_EX.const_REMOVE_OBJECTS,C,A,B);};
GF_RttpCommandQueue.prototype.getObjectType = function(B,A){this.queueCommand(SL_EX.const_GET_OBJECT_TYPE,B,A);};
GF_RttpCommandQueue.prototype.setThrottleObject = function(A,B){this.queueCommand(SL_EX.const_SET_THROTTLE_OBJECT,A,B);};
GF_RttpCommandQueue.prototype.setThrottleObjects = function(A,B){this.queueCommand(SL_EX.const_SET_THROTTLE_OBJECTS,A,B);};
GF_RttpCommandQueue.prototype.setGlobalThrottle = function(A){this.queueCommand(SL_EX.const_SET_GLOBAL_THROTTLE,A);};
GF_RttpCommandQueue.prototype.disableWTStatsTimeout = function(A){this.queueCommand(SL_EX.const_DISABLE_WTSTATS_TIMEOUT,A);};
GF_RttpCommandQueue.prototype.clearObjectListeners = function(B,A){this.queueCommand(SL_EX.const_CLEAR_OBJECT_LISTENERS,B,A);};
GF_RttpCommandQueue.prototype.blockObjectListeners = function(B,A){this.queueCommand(SL_EX.const_BLOCK_OBJECT_LISTENERS,B,A);};
GF_RttpCommandQueue.prototype.unblockObjectListeners = function(B,A){this.queueCommand(SL_EX.const_UNBLOCK_OBJECT_LISTENERS,B,A);};
GF_RttpCommandQueue.prototype.createObject = function(A,B){this.queueCommand(SL_EX.const_CREATE_OBJECT,A,B);};
GF_RttpCommandQueue.prototype.contribObject = function(C,A,B){this.queueCommand(SL_EX.const_CONTRIB_OBJECT,C,A,B);};
GF_RttpCommandQueue.prototype.deleteObject = function(A){this.queueCommand(SL_EX.const_DELETE_OBJECT,A);};
GF_RttpCommandQueue.prototype.getFieldNames = function(){this.queueCommand(SL_EX.const_GET_FIELD_NAMES);};
GF_RttpCommandQueue.prototype.logout = function(){this.queueCommand(SL_EX.const_LOGOUT);};
GF_RttpCommandQueue.prototype.debug = function(B,A){this.queueCommand(SL_EX.const_DEBUG,B,A);};
GF_RttpCommandQueue.prototype.setDebugLevel = function(A){this.queueCommand(SL_EX.const_SET_DEBUG_LEVEL,A);};
GF_RttpCommandQueue.prototype.getVersion = function(){this.queueCommand(SL_EX.const_GET_VERSION);};
GF_RttpCommandQueue.prototype.getVersionInfo = function(){this.queueCommand(SL_EX.const_GET_VERSION_INFO);};
GF_RttpCommandQueue.prototype.addConnectionListener = function(A){this.queueCommand(SL_EX.const_ADD_CONNECTION_LISTENER,A);};
GF_RttpCommandQueue.prototype.removeConnectionListener = function(A){this.queueCommand(SL_EX.const_REMOVE_CONNECTION_LISTENER,A);};
GF_RttpCommandQueue.prototype.removeSubscriber = function(A){this.queueCommand(SL_EX.const_REMOVE_SUBSCRIBER,A);};
GF_RttpCommandQueue.prototype.getContainer = function(E,A,C,D,B){this.queueCommand(SL_EX.const_GET_CONTAINER,E,A,C,D,B);};
GF_RttpCommandQueue.prototype.setContainerWindow = function(B,C,A){this.queueCommand(SL_EX.const_SET_CONTAINER_WINDOW,B,C,A);};
GF_RttpCommandQueue.prototype.clearContainerWindow = function(A){this.queueCommand(SL_EX.const_CLEAR_CONTAINER,A);};
GF_RttpCommandQueue.prototype.removeContainer = function(B,A){this.queueCommand(SL_EX.const_REMOVE_CONTAINER,B,A);};
GF_RttpCommandQueue.prototype.getAutoDirectory = function(E,D,A,B,C){this.queueCommand(SL_EX.const_GET_AUTO_DIRECTORY,E,D,A,B,C);};
GF_RttpCommandQueue.prototype.removeAutoDirectory = function(E,D,A,B,C){this.queueCommand(SL_EX.const_REMOVE_AUTO_DIRECTORY,E,D,A,B,C);};
function GF_RttpCommandQueue_SendNext(C,A,B){var l_oNextCommand=this.m_pQueuedCommands.shift();
var l_nCommandType=l_oNextCommand.m_nCommandType;
var l_pArguments=l_oNextCommand.m_pArguments;
switch(l_nCommandType){
case SL_EX.const_GET_OBJECT:if(this.checkArguments(l_pArguments,3)){C.getObject(l_pArguments[1],l_pArguments[2],l_pArguments[3]);}break;
case SL_EX.const_GET_OBJECTS:if(this.checkArguments(l_pArguments,3)){C.getObjects(l_pArguments[1],l_pArguments[2],l_pArguments[3]);}break;
case SL_EX.const_REMOVE_OBJECT:if(this.checkArguments(l_pArguments,3)){C.removeObject(l_pArguments[1],l_pArguments[2],l_pArguments[3]);}break;
case SL_EX.const_GET_OBJECT_TYPE:if(this.checkArguments(l_pArguments,2)){C.getObjectType(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_SET_THROTTLE_OBJECT:if(this.checkArguments(l_pArguments,2)){C.setThrottleObject(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_SET_THROTTLE_OBJECTS:if(this.checkArguments(l_pArguments,2)){C.setThrottleObjects(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_SET_GLOBAL_THROTTLE:if(this.checkArguments(l_pArguments,1)){C.setGlobalThrottle(l_pArguments[1]);}break;
case SL_EX.const_DISABLE_WTSTATS_TIMEOUT:if(this.checkArguments(l_pArguments,1)){C.disableWTStatsTimeout(l_pArguments[1]);}break;
case SL_EX.const_CLEAR_OBJECT_LISTENERS:if(this.checkArguments(l_pArguments,2)){C.clearObjectListeners(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_BLOCK_OBJECT_LISTENERS:if(this.checkArguments(l_pArguments,2)){C.blockObjectListeners(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_UNBLOCK_OBJECT_LISTENERS:if(this.checkArguments(l_pArguments,2)){C.unblockObjectListeners(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_CREATE_OBJECT:if(this.checkArguments(l_pArguments,2)){C.createObject(l_pArguments[1],l_pArguments[2]);}break;
case SL_EX.const_CONTRIB_OBJECT:if(this.checkArguments(l_pArguments,3)){C.contribObject(l_pArguments[1],l_pArguments[2],l_pArguments[3]);}break;
case SL_EX.const_DELETE_OBJECT:if(this.checkArguments(l_pArguments,1)){C.deleteObject(l_pArguments[1]);}break;
case SL_EX.const_GET_FIELD_NAMES:if(this.checkArguments(l_pArguments,0)){C.getFieldNames();}break;
case SL_EX.const_LOGOUT:if(this.checkArguments(l_pArguments,0)){C.logout();}break;
case SL_EX.const_DEBUG:if(this.checkArguments(l_pArguments,0)){C.debug();}break;
case SL_EX.const_SET_DEBUG_LEVEL:if(this.checkArguments(l_pArguments,1)){C.setDebugLevel(l_pArguments[1]);}break;
case SL_EX.const_GET_VERSION:if(this.checkArguments(l_pArguments,0)){C.getVersion();}break;
case SL_EX.const_GET_VERSION_INFO:if(this.checkArguments(l_pArguments,0)){C.getVersionInfo();}break;
case SL_EX.const_ADD_CONNECTION_LISTENER:if(this.checkArguments(l_pArguments,1)){C.addConnectionListener(l_pArguments[1]);}break;
case SL_EX.const_REMOVE_CONNECTION_LISTENER:if(this.checkArguments(l_pArguments,1)){C.removeConnectionListener(l_pArguments[1]);}break;
case SL_EX.const_GET_CONTAINER:var l_oContainerKey=null;
if(this.checkArguments(l_pArguments,5)){l_oContainerKey=C.getContainer(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4],l_pArguments[5]);}else 
if(this.checkArguments(l_pArguments,3)){l_oContainerKey=C.getContainer(l_pArguments[1],l_pArguments[2],l_pArguments[3]);}var oObj=A.shift();
B[oObj]=l_oContainerKey;break;
case SL_EX.const_REMOVE_CONTAINER:if(this.checkArguments(l_pArguments,2)){var l_oContainerKey=this.getContainerKeyFromContainerKeyMap(l_pArguments[1],B);
C.removeContainer(l_pArguments[1],l_oContainerKey);}break;
case SL_EX.const_CLEAR_CONTAINER:if(this.checkArguments(l_pArguments,1)){var l_oContainerKey=this.getContainerKeyFromContainerKeyMap(l_pArguments[1],B);
C.clearContainerWindow(l_oContainerKey);}break;
case SL_EX.const_SET_CONTAINER_WINDOW:if(this.checkArguments(l_pArguments,3)){var l_oContainerKey=this.getContainerKeyFromContainerKeyMap(l_pArguments[1],B);
C.setContainerWindow(l_oContainerKey,l_pArguments[2],l_pArguments[3]);}break;
case SL_EX.const_REMOVE_SUBSCRIBER:if(this.checkArguments(l_pArguments,1)){C.removeSubscriber(l_pArguments[1]);}break;
case SL_EX.const_GET_AUTO_DIRECTORY:if(this.checkArguments(l_pArguments,5)){C.getAutoDirectory(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4],l_pArguments[5]);}break;
case SL_EX.const_REMOVE_AUTO_DIRECTORY:if(this.checkArguments(l_pArguments,5)){C.removeAutoDirectory(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4],l_pArguments[5]);}break;
default :SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"RttpCommandQueue.sendNext: unknown command ({0}) - {1}",l_nCommandType,l_oNextCommand);break;
}}
GF_RttpCommandQueue.prototype.getContainerKeyFromContainerKeyMap = function(A,B){if(B[A]!=null){A=B[A];}return A;
};
function GF_RttpCommandQueue_QueueCommand(A){this.m_pQueuedCommands.push(new SL_GU(A,GF_RttpCommandQueue_QueueCommand.arguments));}
function GF_RttpCommandQueue_CheckArguments(B,A){return B.length>A;
}
function SL_GU(A,B){this.m_nCommandType=A;this.m_pArguments=B;}
SL_EX = new function(){this.const_GET_OBJECT=1;this.const_GET_OBJECTS=2;this.const_REMOVE_OBJECT=3;this.const_REMOVE_OBJECTS=4;this.const_GET_OBJECT_TYPE=5;this.const_SET_THROTTLE_OBJECT=6;this.const_SET_THROTTLE_OBJECTS=7;this.const_SET_GLOBAL_THROTTLE=8;this.const_DISABLE_WTSTATS_TIMEOUT=9;this.const_CLEAR_OBJECT_LISTENERS=10;this.const_BLOCK_OBJECT_LISTENERS=11;this.const_UNBLOCK_OBJECT_LISTENERS=12;this.const_CREATE_OBJECT=13;this.const_CONTRIB_OBJECT=14;this.const_DELETE_OBJECT=15;this.const_GET_FIELD_NAMES=16;this.const_LOGOUT=17;this.const_DEBUG=18;this.const_SET_DEBUG_LEVEL=19;this.const_GET_VERSION=20;this.const_GET_VERSION_INFO=21;this.const_ADD_CONNECTION_LISTENER=22;this.const_REMOVE_CONNECTION_LISTENER=23;this.const_GET_CONTAINER=24;this.const_REMOVE_CONTAINER=25;this.const_REMOVE_SUBSCRIBER=26;this.const_SET_CONTAINER_WINDOW=27;this.const_CLEAR_CONTAINER_WINDOW=28;this.const_SET_CONTAINER_WINDOW=29;this.const_CLEAR_CONTAINER=30;this.const_GET_AUTO_DIRECTORY=31;this.const_REMOVE_AUTO_DIRECTORY=32;};
var SL4B_SlaveFrameRttpProvider=function(){};
if(false){function SL4B_SlaveFrameRttpProvider(){}
}SL4B_SlaveFrameRttpProvider = function(){SL4B_AbstractRttpProvider.apply(this);this.m_oMasterFrameRttpProvider=null;this.m_oRttpCommandQueue=new GF_RttpCommandQueue();this.m_bMasterRefresh=false;};
SL4B_SlaveFrameRttpProvider.prototype = new SL4B_AbstractRttpProvider;SL4B_SlaveFrameRttpProvider.prototype.register = SL_OY;SL4B_SlaveFrameRttpProvider.prototype.masterRegistered = SL_KE;SL4B_SlaveFrameRttpProvider.prototype.masterClosing = SL_HB;SL4B_SlaveFrameRttpProvider.prototype.connect = function(){};
SL4B_SlaveFrameRttpProvider.prototype.login = function(A,B){};
SL4B_SlaveFrameRttpProvider.prototype.reconnect = function(){};
SL4B_SlaveFrameRttpProvider.prototype.getObject = SL_EA;SL4B_SlaveFrameRttpProvider.prototype.getObjects = SL_OG;SL4B_SlaveFrameRttpProvider.prototype.removeObject = SL_NO;SL4B_SlaveFrameRttpProvider.prototype.removeObjects = SL_ER;SL4B_SlaveFrameRttpProvider.prototype.removeSubscriber = SL_GC;SL4B_SlaveFrameRttpProvider.prototype.getObjectType = SL_PV;SL4B_SlaveFrameRttpProvider.prototype.setThrottleObject = SL_IV;SL4B_SlaveFrameRttpProvider.prototype.setThrottleObjects = SL_PT;SL4B_SlaveFrameRttpProvider.prototype.setGlobalThrottle = SL_QW;SL4B_SlaveFrameRttpProvider.prototype.createObject = SL_GK;SL4B_SlaveFrameRttpProvider.prototype.contribObject = SL_CJ;SL4B_SlaveFrameRttpProvider.prototype.deleteObject = SL_DQ;SL4B_SlaveFrameRttpProvider.prototype.getFieldNames = SL_HG;SL4B_SlaveFrameRttpProvider.prototype.logout = function(){};
SL4B_SlaveFrameRttpProvider.prototype.initialise = function(){};
SL4B_SlaveFrameRttpProvider.prototype.stop = SL_DK;SL4B_SlaveFrameRttpProvider.prototype.disableWTStatsTimeout = function(A){this.m_oMasterFrameRttpProvider.disableWTStatsTimeout(A);};
SL4B_SlaveFrameRttpProvider.prototype.clearObjectListeners = function(B,A){this.m_oMasterFrameRttpProvider.clearObjectListeners(B,A);};
SL4B_SlaveFrameRttpProvider.prototype.blockObjectListeners = function(B,A){this.m_oMasterFrameRttpProvider.blockObjectListeners(B,A);};
SL4B_SlaveFrameRttpProvider.prototype.unblockObjectListeners = function(B,A){this.m_oMasterFrameRttpProvider.unblockObjectListeners(B,A);};
SL4B_SlaveFrameRttpProvider.prototype.debug = function(B,A){this.m_oMasterFrameRttpProvider.debug(B,A);};
SL4B_SlaveFrameRttpProvider.prototype.setDebugLevel = function(A){return this.m_oMasterFrameRttpProvider.setDebugLevel(A);
};
SL4B_SlaveFrameRttpProvider.prototype.getVersion = function(){return this.m_oMasterFrameRttpProvider.getVersion()+"-"+this.m_oMasterFrameRttpProvider.getBuildVersion();
};
SL4B_SlaveFrameRttpProvider.prototype.getVersionInfo = function(){return this.m_oMasterFrameRttpProvider.getVersionInfo();
};
function SL_EA(C,B,A){if(this.m_oMasterFrameRttpProvider!=null){this.m_oMasterFrameRttpProvider.getObject(C,B,A);}else 
{this.m_oRttpCommandQueue.getObject(C,B,A);}}
function SL_OG(C,A,B){this.m_oMasterFrameRttpProvider.getObjects(C,A,B);}
function SL_NO(C,B,A){this.m_oMasterFrameRttpProvider.removeObject(C,B,A);}
function SL_ER(C,A,B){this.m_oMasterFrameRttpProvider.removeObjects(C,A,B);}
function SL_GC(A){if(this.m_oMasterFrameRttpProvider!=null){this.m_oMasterFrameRttpProvider.removeSubscriber(A);}}
function SL_PV(B,A){this.m_oMasterFrameRttpProvider.getObjectType(B,A);}
function SL_IV(A,B){this.m_oMasterFrameRttpProvider.setThrottleObject(A,B);}
function SL_PT(A,B){this.m_oMasterFrameRttpProvider.setThrottleObject(A,B);}
function SL_QW(A){this.m_oMasterFrameRttpProvider.setGlobalThrottle(A);}
function SL_GK(A,B){return this.m_oMasterFrameRttpProvider.createObject(A,B);
}
function SL_CJ(C,A,B){this.m_oMasterFrameRttpProvider.contribObject(C,A,B);}
function SL_DQ(A){return this.m_oMasterFrameRttpProvider.deleteObject(A);
}
function SL_HG(){return this.m_oMasterFrameRttpProvider.getFieldNames();
}
function SL_OY(){setTimeout("SL4B_FrameRegistrarAccessor.registerSlaveFrame(SL4B_Accessor.getConfiguration().getFrameId(), SL4B_Accessor.getRttpProvider())",0);}
function SL_DK(){SL4B_FrameRegistrarAccessor.deregisterSlaveFrame(SL4B_Accessor.getConfiguration().getFrameId());if(this.m_oMasterFrameRttpProvider!=null){this.m_oMasterFrameRttpProvider.deregisterSlave(SL4B_Accessor.getConfiguration().getFrameId(),this,SL4B_SubscriptionManager);}for(var i=0;i<SL4B_SubscriptionManager.m_pSubscribers.length;i++){this.removeSubscriber(SL4B_SubscriptionManager.m_pSubscribers[i]);}}
function SL_KE(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SlaveFrameRttpProvider.masterRegistered: {0}",A);this.m_oMasterFrameRttpProvider=A;A.registerSlave(SL4B_Accessor.getConfiguration().getFrameId(),this,SL4B_SubscriptionManager);if(this.m_bMasterRefresh==true){window.location.replace(window.location.href);}}
function SL_HB(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"SlaveFrameRttpProvider.masterClosing");this.m_oMasterFrameRttpProvider=null;this.m_bMasterRefresh=true;}
var SL4B_MultiSourceRttpProvider=function(){};
var SL4B_FailoverAlgorithm=function(){};
if(false){function SL4B_FailoverAlgorithm(){}
}SL4B_FailoverAlgorithm = function(){this.nextLiberatorConfiguration = function(){};
this.setConnected = function(){};
};
var SL4B_ZunAlgorithm=function(){};
if(false){function SL4B_ZunAlgorithm(){}
}SL4B_ZunAlgorithm = function(){this.initialise = function(A){this.m_oFailoverConfiguration=new SL4B_FailoverConfiguration();this.m_oFailoverConfiguration.load(A);this.m_oCurrentServer=null;this.m_oConnectedServer=null;this.m_bReset=true;this.m_bFirstPass=true;this.m_sAlgorithm=this.m_oFailoverConfiguration.getAlgorithm();var l_oConfiguration=SL4B_Accessor.getConfiguration();
var l_sServerUrl=document.location.toString();
this.m_sProtocol="http";if(l_sServerUrl.match(/^http/)){this.m_sProtocol=l_sServerUrl.match(/^(https?)/)[1];}};
this.setAlgorithm = function(A){this.m_sAlgorithm=A;};
this.setServerWeights = function(A){SL4B_Failover_Log("SL4B_ZunAlgorithm.setServerWeights");var l_nWeight=0;
for(var i=0;i<A.length;i++){var l_oServer=A[i];
if(!l_oServer.isTried()){l_oServer.setWeightStart(l_nWeight);l_nWeight+=l_oServer.getWeight();l_oServer.setWeightEnd(l_nWeight);}}return l_nWeight;
};
this.clearTries = function(A,B){SL4B_Failover_Log("SL4B_ZunAlgorithm.clearTries");for(var i=0;i<A.length;i++){var l_oServer=A[i];
if(l_oServer==B){l_oServer.setTried(true);}else 
{l_oServer.setTried(false);}}};
this.chooseRandomServer = function(A){SL4B_Failover_Log("SL4B_ZunAlgorithm.chooseRandomServer");var l_nWeightMax=this.setServerWeights(A);
var l_nRandom=this.random(l_nWeightMax);
for(var i=0;i<A.length;i++){var l_oServer=A[i];
if(!l_oServer.isTried()){SL4B_Failover_Log("\t"+l_oServer.getAddress()+" "+l_oServer.getWeightStart()+" "+l_oServer.getWeightEnd()+" "+l_nRandom);if(l_oServer.getWeightStart()<=l_nRandom&&l_nRandom<l_oServer.getWeightEnd()){SL4B_Failover_Log("\t\tchosen");return l_oServer;
}}}return null;
};
this.random = function(A){SL4B_Failover_Log("SL4B_ZunAlgorithm.random");return l_nValue=Math.random()*100000%A;
};
this.chooseRandomPrimaryServer = function(){SL4B_Failover_Log("SL4B_ZunAlgorithm.chooseRandomPrimaryServer");return this.chooseRandomServer(this.m_oFailoverConfiguration.getPrimaryServers());
};
this.chooseRandomBackupServer = function(){SL4B_Failover_Log("SL4B_ZunAlgorithm.chooseRandomBackupServer");return this.chooseRandomServer(this.m_oFailoverConfiguration.getBackupServers());
};
this.addFirstMatchingConnectionMethod = function(C,B,A){for(var i=0;i<A.length;i++){var l_oConnectionMethod=A[i];
var l_pConnections=B.getConnections();
for(var j=0;j<l_pConnections.length;j++){var failoverServerConnection=l_pConnections[j];
if(failoverServerConnection.getType()==l_oConnectionMethod.getRTTPType()&&failoverServerConnection.getProtocol()==this.m_sProtocol){var l_sPort=B.getPorts()[this.m_sProtocol];
if(l_sPort==null){l_sPort=((this.m_sProtocol=="http") ? "80" : "443");}var l_oConnection=new SL4B_ConnectionData(this.m_sProtocol,B.getAddress(),l_sPort,l_oConnectionMethod);
C.addConnection(l_oConnection);return;
}}}};
this.nextLiberatorConfiguration = function(){SL4B_Failover_Log("SL4B_ZunAlgorithm.nextServer");if(this.m_bReset==true){if(this.m_oCurrentServer!=this.m_oConnectedServer){this.m_oCurrentServer=null;}this.clearTries(this.m_oFailoverConfiguration.getPrimaryServers(),this.m_oCurrentServer);this.clearTries(this.m_oFailoverConfiguration.getBackupServers(),this.m_oCurrentServer);this.m_bReset=false;this.m_bFirstPass=true;this.m_oConnectedServer=null;}var l_oServer=null;
var l_oLiberatorConfiguration=null;
switch(this.m_sAlgorithm){
case "Z":l_oServer=this.nextZServer();break;
case "U":l_oServer=this.nextUServer();break;
case "N":l_oServer=this.nextNServer();break;
}if(l_oServer!=null){l_oServer.setTried(true);this.m_oCurrentServer=l_oServer;l_oLiberatorConfiguration=new SL4B_LiberatorConfiguration();l_oLiberatorConfiguration.initialise();var l_oConfiguration=SL4B_Accessor.getConfiguration();
this.addFirstMatchingConnectionMethod(l_oLiberatorConfiguration,l_oServer,l_oConfiguration.getStreamingConnectionMethods());this.addFirstMatchingConnectionMethod(l_oLiberatorConfiguration,l_oServer,l_oConfiguration.getPollingConnectionMethods());}else 
{this.m_bReset=true;}return l_oLiberatorConfiguration;
};
this.nextZServer = function(){SL4B_Failover_Log("SL4B_ZunAlgorithm.nextZServer");var l_oServer=null;
l_oServer=this.chooseRandomPrimaryServer();if(l_oServer!=null){return l_oServer;
}l_oServer=this.chooseRandomBackupServer();if(l_oServer!=null){return l_oServer;
}return null;
};
this.nextUServer = function(){SL4B_Failover_Log("SL4B_ZunAlgorithm.nextUServer");var l_oServer=null;
if(this.m_bFirstPass==true){this.m_bFirstPass=false;l_oServer=this.chooseRandomPrimaryServer();if(l_oServer!=null){return l_oServer;
}}if(!this.m_oCurrentServer.isBackup()){l_oServer=this.m_oCurrentServer.getPairedServer();if(l_oServer!=null&&l_oServer.isTried()==false){return l_oServer;
}}l_oServer=this.chooseRandomBackupServer();if(l_oServer!=null){return l_oServer;
}l_oServer=this.chooseRandomPrimaryServer();if(l_oServer!=null){return l_oServer;
}return null;
};
this.nextNServer = function(){SL4B_Failover_Log("SL4B_ZunAlgorithm.nextUServer");var l_oServer=null;
if(this.m_bFirstPass==true){this.m_bFirstPass=false;l_oServer=this.chooseRandomPrimaryServer();if(l_oServer!=null){return l_oServer;
}}if(this.m_oCurrentServer!=null&&!this.m_oCurrentServer.isBackup()){l_oServer=this.m_oCurrentServer.getPairedServer();if(l_oServer!=null){return l_oServer;
}}l_oServer=this.chooseRandomPrimaryServer();if(l_oServer!=null){return l_oServer;
}l_oServer=this.chooseRandomBackupServer();if(l_oServer!=null){return l_oServer;
}return null;
};
this.setConnected = function(){this.m_oConnectedServer=this.m_oCurrentServer;this.m_bReset=true;};
};
function SL_JI(){SL4B_ZunAlgorithm.prototype = new SL4B_FailoverAlgorithm;}
var SL4B_Failover_Log=function(A){};
var SL4B_FailoverConfiguration=function(){this.m_sName="";this.m_sFailOverAlgorithm="Z";this.m_pPrimaryServers=new Array();this.m_pBackupServers=new Array();this.getName = function(){return this.m_sName;
};
this.getAlgorithm = function(){return this.m_sFailOverAlgorithm;
};
this.getPrimaryServers = function(){return this.m_pPrimaryServers;
};
this.getBackupServers = function(){return this.m_pBackupServers;
};
this.load = function(A){l_oXmlHttpRequest=null;
try {if(typeof XMLHttpRequest!='undefined'){l_oXmlHttpRequest=new XMLHttpRequest();}else 
{
try {l_oXmlHttpRequest=new ActiveXObject("Msxml2.XMLHTTP");}catch(e){l_oXmlHttpRequest=new ActiveXObject("Microsoft.XMLHTTP");}
}l_oXmlHttpRequest.open("GET",A,false);l_oXmlHttpRequest.send(null);if(l_oXmlHttpRequest.status==200){SL4B_Failover_Log("SL4B_FailoverConfiguration: Loaded file "+A+", status="+l_oXmlHttpRequest.status+" message: "+l_oXmlHttpRequest.statusText);var l_oDocElement=SL4B_XmlResponseRetriever.getXmlDocumentElement(l_oXmlHttpRequest);
if(l_oDocElement==null){SL4B_Logger.log(SL4B_DebugLevel.const_CRITICAL_INT,"Error parsing XML configuration ("+A+"): "+e.toString());SL4B_Failover_Log("SL4B_FailoverConfiguration: Error parsing XML configuration ("+A+"): "+e.message);throw new SL4B_Exception("SL4B_FailoverConfiguration: Error parsing XML configuration ("+A+"): "+e.message);
}this.parseRttpService(l_oDocElement);if(this.m_pPrimaryServers.length==0&&this.m_pBackupServers.length==0){SL4B_Logger.log(SL4B_DebugLevel.const_CRITICAL_INT,"SL4B_FailoverConfiguration: Error in file "+A+", no primary or backup servers found!");throw new SL4B_Exception("SL4B_FailoverConfiguration: Error in file "+A+", no primary or backup servers found!");
}SL4B_Failover_Log(this.toString());}else 
{SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to load file "+A+", status="+l_oXmlHttpRequest.status+" message: "+l_oXmlHttpRequest.statusText);throw new SL4B_Exception("SL4B_FailoverConfiguration: Failed to load file "+A+", status="+l_oXmlHttpRequest.status+" message: "+l_oXmlHttpRequest.statusText);
}}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_CRITICAL_INT,e.toString());SL4B_Failover_Log("SL4B_FailoverConfiguration: Exception: "+e.message);throw (e);
}
};
this.parseRttpService = function(A){SL4B_Failover_Log("\tparseRttpService "+A.tagName);
try {var l_pChildren=A.childNodes;
for(var i=0;i<l_pChildren.length;i++){var l_oChild=l_pChildren[i];
if(l_oChild.tagName=="name"){this.m_sName=l_oChild.firstChild.nodeValue;}else 
if(l_oChild.tagName=="failoveralgorithm"){this.m_sFailOverAlgorithm=l_oChild.firstChild.nodeValue;}else 
if(l_oChild.tagName=="rttpsite"){this.parseRttpSite(l_oChild);}}}catch(e){SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to parse rttpservice");throw (e);
}
};
this.parseRttpSite = function(A){SL4B_Failover_Log("\tparseRttpSite "+A.tagName);
try {var l_pChildren=A.childNodes;
for(var i=0;i<l_pChildren.length;i++){var l_oChild=l_pChildren[i];
if(l_oChild.tagName=="serverpair"){this.parseServerPair(l_oChild);}else 
if(l_oChild.tagName=="primaryserver"){var l_oServer=new SL4B_FailoverServer();
l_oServer.parseServer(l_oChild);this.m_pPrimaryServers.push(l_oServer);}else 
if(l_oChild.tagName=="backupserver"){var l_oServer=new SL4B_FailoverServer();
l_oServer.parseServer(l_oChild);this.m_pBackupServers.push(l_oServer);}}}catch(e){SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to parse RttpSite");throw (e);
}
};
this.parseServerPair = function(A){
try {SL4B_Failover_Log("\tparseServerPair "+A.tagName);var l_pChildren=A.childNodes;
var l_oPrimaryServer=null;
var l_oBackupServer=null;
for(var i=0;i<l_pChildren.length;i++){var l_oChild=l_pChildren[i];
if(l_oChild.tagName=="primaryserver"){l_oPrimaryServer=new SL4B_FailoverServer();l_oPrimaryServer.parseServer(l_oChild);this.m_pPrimaryServers.push(l_oPrimaryServer);}else 
if(l_oChild.tagName=="backupserver"){l_oBackupServer=new SL4B_FailoverServer();l_oBackupServer.parseServer(l_oChild);this.m_pBackupServers.push(l_oBackupServer);}}l_oPrimaryServer.setPairedServer(l_oBackupServer,false);l_oBackupServer.setPairedServer(l_oPrimaryServer,true);}catch(e){SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to parse ServerPair");throw (e);
}
};
this.toString = function(){var l_sValue="";
l_sValue+="Name = "+this.m_sName+", ";l_sValue+="\nFailOverAlgorithm = "+this.m_sFailOverAlgorithm+", ";l_sValue+="\nPrimary Servers:";for(var i=0;i<this.m_pPrimaryServers.length;i++){l_sValue+=this.m_pPrimaryServers[i].toString();}l_sValue+="\nBackup Servers:";for(var i=0;i<this.m_pBackupServers.length;i++){l_sValue+=this.m_pBackupServers[i].toString();}return l_sValue;
};
};
var SL4B_FailoverServer=function(){this.m_sAddress=null;this.m_sName=null;this.m_pConnections=new Array();this.m_pPorts=new Object();this.m_nWeight=1;this.m_oPairedServer=null;this.m_bBackup=false;this.m_bTried=false;this.m_nWeightStart=0;this.m_nWeightEnd=0;this.getName = function(){return this.m_sName;
};
this.getAddress = function(){return this.m_sAddress;
};
this.getConnections = function(){return this.m_pConnections;
};
this.getPorts = function(){return this.m_pPorts;
};
this.getPairedServer = function(){return this.m_oPairedServer;
};
this.setPairedServer = function(B,A){this.m_oPairedServer=B;this.m_bBackup=A;};
this.isBackup = function(){return this.m_bBackup;
};
this.getWeight = function(){return this.m_nWeight;
};
this.getWeightStart = function(){return this.m_nWeightStart;
};
this.getWeightEnd = function(){return this.m_nWeightEnd;
};
this.setWeightStart = function(A){this.m_nWeightStart=A;};
this.setWeightEnd = function(A){this.m_nWeightEnd=A;};
this.isTried = function(){return this.m_bTried;
};
this.setTried = function(A){this.m_bTried=A;};
this.parseServer = function(A){
try {SL4B_Failover_Log("\tparseServer "+A.tagName);var l_pChildren=A.childNodes;
for(var i=0;i<l_pChildren.length;i++){var l_oChild=l_pChildren[i];
if(l_oChild.tagName=="address"){this.m_sAddress=l_oChild.firstChild.nodeValue;}else 
if(l_oChild.tagName=="name"){this.m_sName=l_oChild.firstChild.nodeValue;}else 
if(l_oChild.tagName=="connections"){this.parseConnections(l_oChild);}else 
if(l_oChild.tagName=="ports"){this.parsePorts(l_oChild);}else 
if(l_oChild.tagName=="weight"){this.m_nWeight=parseInt(l_oChild.firstChild.nodeValue);}}}catch(e){SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to parse Server");throw (e);
}
};
this.parseConnections = function(A){SL4B_Failover_Log("\tparseConnections "+A.tagName);
try {var l_oServerConnection=null;
var l_pChildren=A.childNodes;
for(var i=0;i<l_pChildren.length;i++){var l_oChild=l_pChildren[i];
var l_sTagName=l_oChild.tagName;
if(l_sTagName=="type3"){this.addConnectionType(3,l_oChild.firstChild.nodeValue.toLowerCase());}else 
if(l_sTagName=="type4"){this.addConnectionType(4,l_oChild.firstChild.nodeValue.toLowerCase());}else 
if(l_sTagName=="type5"){this.addConnectionType(5,l_oChild.firstChild.nodeValue.toLowerCase());}else 
{SL4B_Failover_Log("SL4B_FailoverConfiguration: Unknown connection type");}}}catch(e){SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to parse Connections");throw (e);
}
};
this.addConnectionType = function(A,B){l_oServerConnection=new SL4B_FailoverServerConnection(A,B);this.m_pConnections.push(l_oServerConnection);};
this.parsePorts = function(A){SL4B_Failover_Log("\tparsePorts "+A.tagName);
try {var l_pChildren=A.childNodes;
for(var i=0;i<l_pChildren.length;i++){var l_oChild=l_pChildren[i];
if(l_oChild.tagName=="http"){this.m_pPorts[l_oChild.tagName]=l_oChild.firstChild.nodeValue;}else 
if(l_oChild.tagName=="https"){this.m_pPorts[l_oChild.tagName]=l_oChild.firstChild.nodeValue;}else 
if(l_oChild.tagName=="direct"){this.m_pPorts[l_oChild.tagName]=l_oChild.firstChild.nodeValue;}}}catch(e){SL4B_Failover_Log("SL4B_FailoverConfiguration: Failed to parse Ports");throw (e);
}
};
this.toString = function(){var l_sValue="";
l_sValue+="\n\tAddress = "+this.m_sAddress;l_sValue+="\n\tName = "+this.m_sName;l_sValue+="\n\tWeight = "+this.m_nWeight;if(this.m_oPairedServer!=null){l_sValue+="\n\tPairedServer = "+this.m_oPairedServer.m_sAddress;}l_sValue+="\n\tConnections:";for(var i=0;i<this.m_pConnections.length;i++){l_sValue+=this.m_pConnections[i].toString();}l_sValue+="\n\tPorts:";for(sKey in this.m_pPorts){var sValue=this.m_pPorts[sKey];
l_sValue+="\n\t\t"+sKey+"="+sValue;}return l_sValue;
};
};
var SL4B_FailoverServerConnection=function(B,A){this.m_nType=5;if(B!=null){this.m_nType=B;}this.m_sProtocol="http";if(A!=null){this.m_sProtocol=A;}this.getType = function(){return this.m_nType;
};
this.getProtocol = function(){return this.m_sProtocol;
};
this.toString = function(){var l_sValue="";
l_sValue+="\n\t\tConnection:";l_sValue+="\n\t\t\tType = "+this.m_nType;l_sValue+="\n\t\t\tProtocol = "+this.m_sProtocol;return l_sValue;
};
};
var SL4B_FailoverRttpProvider=function(){};
if(false){function SL4B_FailoverRttpProvider(){}
}SL4B_FailoverRttpProvider = function(){SL4B_AbstractRttpProvider.apply(this);this.m_oBaseRttpProvider=null;this.m_oRttpCommandQueue=new GF_RttpCommandQueue();this.m_bProviderReady=false;this.m_bConnectionListenerAdded=false;this.m_oConnectionListener=new SL_ME(this);this.m_oContainerKeyMap=new Object();this.m_oProxyKeyArray=new Array();this.m_bAttemptReconnections=true;this.m_bConnectionLost=false;var l_sUrl=SL4B_Accessor.getConfiguration().getService();
this.m_oFailoverAlgorithm=new SL4B_ZunAlgorithm();this.m_oFailoverAlgorithm.initialise(l_sUrl);this.setUnderlyingRttpProvider = function(A){if(this.m_oBaseRttpProvider!=null){this.m_oBaseRttpProvider.removeConnectionListener(this.m_oConnectionListener);}SL4B_Accessor.setUnderlyingRttpProvider(A);this.m_oBaseRttpProvider=A;this.m_oConnectionListener.setRttpProvider(A);this.m_oBaseRttpProvider.addConnectionListener(this.m_oConnectionListener);A.initialise();};
this.processQueuedCommands = function(){this.m_bProviderReady=true;while(!this.m_oRttpCommandQueue.isEmpty()){this.m_oRttpCommandQueue.sendNext(this.m_oBaseRttpProvider,this.m_oProxyKeyArray,this.m_oContainerKeyMap);}};
this.nextRttpProvider = function(){var l_bAnotherServerIsAvailable=true;
this.m_bProviderReady=false;var l_oLiberatorConfiguration=this.m_oFailoverAlgorithm.nextLiberatorConfiguration();
while(l_oLiberatorConfiguration==null){l_bAnotherServerIsAvailable=false;C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_INFO_CONNECTION_EVENT,"Failover cycle complete, recycling"));SL4B_Failover_Log("**** no next liberator configuration, restarting sequence *****");l_oLiberatorConfiguration=this.m_oFailoverAlgorithm.nextLiberatorConfiguration();}C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_INFO_CONNECTION_EVENT,"Failover trying: "+l_oLiberatorConfiguration.toSimpleString()));var l_oRttpProvider=this.createRttpProvider(l_oLiberatorConfiguration);
this.setUnderlyingRttpProvider(l_oRttpProvider);return l_bAnotherServerIsAvailable;
};
this.createRttpProvider = function(A){return SL4B_Accessor.getRttpProviderFactory().createRttpProvider(A);
};
this.isFailoverProvider=true;this.initialise();};
function SL_ME(B){this.m_pConnectionListeners=new Array();this.m_oFailoverProvider=B;this.m_oRttpProvider=null;this.setRttpProvider = function(A){this.m_oRttpProvider=A;};
}
SL_ME.prototype = new SL4B_ConnectionListener;SL_ME.prototype.addConnectionListener = function(A){this.m_pConnectionListeners.push(A);};
SL_ME.prototype.removeConnectionListener = function(A){var l_nMatchIndex=-1;
for(var l_nListener=0,l_nLength=this.m_pConnectionListeners.length;l_nListener<l_nLength;++l_nListener){if(this.m_pConnectionListeners[l_nListener]==A){l_nMatchIndex=l_nListener;break;
}}if(l_nMatchIndex!=-1){this.m_pConnectionListeners.splice(l_nMatchIndex,1);}return (l_nMatchIndex!=-1);
};
SL_ME.prototype.notifyConnectionListeners = function(A,B){for(var l_nListener=0,l_nLength=this.m_pConnectionListeners.length;l_nListener<l_nLength;++l_nListener){if(B.length>0&&B[0]===undefined){B=[];}this.m_pConnectionListeners[l_nListener][A].apply(this.m_pConnectionListeners[l_nListener],B);}};
SL_ME.prototype.connectionAttempt = function(B,A){this.notifyConnectionListeners("connectionAttempt",[B,A]);};
SL_ME.prototype.connectionWarning = function(C,D,B,A){this.notifyConnectionListeners("connectionWarning",[C,D,B,A]);};
SL_ME.prototype.connectionError = function(A){if(this.m_oFailoverProvider.m_bAttemptReconnections){var l_bIsAnotherServerAvailable=this.m_oFailoverProvider.nextRttpProvider();
if(!l_bIsAnotherServerAvailable){this.m_oFailoverProvider.m_bConnectionLost=true;this.notifyConnectionListeners("connectionError",[A]);}this.m_oFailoverProvider.onLoad(null);}};
SL_ME.prototype.connectionInfo = function(A){this.notifyConnectionListeners("connectionInfo",[A]);};
SL_ME.prototype.connectionOk = function(C,A,B){this.notifyConnectionListeners("connectionOk",[C,A,B]);};
SL_ME.prototype.reconnectionOk = function(C,A,B){this.notifyConnectionListeners("reconnectionOk",[C,A,B]);};
SL_ME.prototype.fileDownloadError = function(B,A){this.notifyConnectionListeners("fileDownloadError",[B,A]);};
SL_ME.prototype.credentialsRetrieved = function(A){this.notifyConnectionListeners("credentialsRetrieved",[A]);};
SL_ME.prototype.loginError = function(A){this.notifyConnectionListeners("loginError",[A]);};
SL_ME.prototype.credentialsProviderSessionError = function(A,D,C,B){this.notifyConnectionListeners("credentialsProviderSessionError",[A,D,C,B]);};
SL_ME.prototype.loginOk = function(){this.notifyConnectionListeners("loginOk",[]);setTimeout("SL4B_Accessor.getRttpProvider().processQueuedCommands()",0);};
SL_ME.prototype.message = function(A,B){this.notifyConnectionListeners("message",[A,B]);};
SL_ME.prototype.serviceMessage = function(A,D,B,C){this.notifyConnectionListeners("serviceMessage",[A,D,B,C]);};
SL_ME.prototype.sessionEjected = function(A,B){this.notifyConnectionListeners("sessionEjected",[A,B]);};
SL_ME.prototype.sourceMessage = function(A,C,D,B){this.notifyConnectionListeners("sourceMessage",[A,C,D,B]);};
SL_ME.prototype.statistics = function(A,D,E,B,C){this.notifyConnectionListeners("statistics",[A,D,E,B,C]);};
SL4B_FailoverRttpProvider.prototype = new SL4B_AbstractRttpProvider;SL4B_FailoverRttpProvider.prototype.super_internalInitialise = SL4B_AbstractRttpProvider.prototype.internalInitialise;SL4B_FailoverRttpProvider.prototype.super_register = SL4B_AbstractRttpProvider.prototype.register;SL4B_FailoverRttpProvider.prototype.internalInitialise = function(){if(this.m_oBaseRttpProvider==null){this.super_internalInitialise();this.nextRttpProvider();}else 
{this.m_oBaseRttpProvider.internalInitialise();}};
SL4B_FailoverRttpProvider.prototype.initialise = function(){if(!this.m_bConnectionListenerAdded){this.m_bConnectionListenerAdded=true;SL4B_AbstractRttpProvider.prototype.addConnectionListener.apply(this,[this.m_oConnectionListener]);}if(this.m_oBaseRttpProvider!=null){this.m_oBaseRttpProvider.initialise();}};
SL4B_FailoverRttpProvider.prototype.onLoad = function(A){if(this.m_oBaseRttpProvider!=null&&this.m_bAttemptReconnections){this.m_bConnectionLost=false;this.m_oBaseRttpProvider.onLoad(A);}};
SL4B_FailoverRttpProvider.prototype.internalStop = function(){this.m_oBaseRttpProvider.internalStop();};
SL4B_FailoverRttpProvider.prototype.stop = function(){this.m_bAttemptReconnections=false;this.m_oBaseRttpProvider.stop();if(this.m_bConnectionLost===false){this.m_bConnectionLost=true;this.m_oConnectionListener.notifyConnectionListeners("connectionError",["Connection stopped"]);}};
SL4B_FailoverRttpProvider.prototype.addConnectionListener = function(A){this.m_oConnectionListener.addConnectionListener(A);};
SL4B_FailoverRttpProvider.prototype.removeConnectionListener = function(A){return this.m_oConnectionListener.removeConnectionListener(A);
};
SL4B_FailoverRttpProvider.prototype.loggedIn = function(){this.m_oBaseRttpProvider.loggedIn();};
SL4B_FailoverRttpProvider.prototype.register = function(){if(this.m_oBaseRttpProvider==null){this.super_register();}else 
{this.m_oBaseRttpProvider.register();}};
SL4B_FailoverRttpProvider.prototype.registerSlave = function(B,A,C){this.m_oBaseRttpProvider.registerSlave(B,A,C);};
SL4B_FailoverRttpProvider.prototype.deregisterSlave = function(B,A,C){this.m_oBaseRttpProvider.deregisterSlave(B,A,C);};
SL4B_FailoverRttpProvider.prototype.connect = function(){this.m_oBaseRttpProvider.connect();};
SL4B_FailoverRttpProvider.prototype.reconnect = function(){this.m_bAttemptReconnections=true;this.m_oBaseRttpProvider.reconnect();};
SL4B_FailoverRttpProvider.prototype.connected = function(){this.m_oBaseRttpProvider.connected();};
SL4B_FailoverRttpProvider.prototype.login = function(A,B){this.m_oBaseRttpProvider.login(A,B);};
SL4B_FailoverRttpProvider.prototype.loggedIn = function(){this.m_oBaseRttpProvider.loggedIn();};
SL4B_FailoverRttpProvider.prototype.getObject = function(C,B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getObject(C,B,A);}else 
{this.m_oRttpCommandQueue.getObject(C,B,A);}};
SL4B_FailoverRttpProvider.prototype.getObjects = function(C,A,B){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getObjects(C,A,B);}else 
{this.m_oRttpCommandQueue.getObjects(C,A,B);}};
SL4B_FailoverRttpProvider.prototype.removeObject = function(C,B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.removeObject(C,B,A);}else 
{this.m_oRttpCommandQueue.removeObject(C,B,A);}};
SL4B_FailoverRttpProvider.prototype.removeObjects = function(C,A,B){if(this.m_bProviderReady){this.m_oBaseRttpProvider.removeObjects(C,A,B);}else 
{this.m_oRttpCommandQueue.removeObjects(C,A,B);}};
SL4B_FailoverRttpProvider.prototype.getContainer = function(E,A,C,D,B){if(this.m_bProviderReady){return this.m_oBaseRttpProvider.getContainer(E,A,C,D,B);
}else 
{var l_oProxyContainerKey=new SL4B_ContainerKey();
this.m_oProxyKeyArray.push(l_oProxyContainerKey);this.m_oRttpCommandQueue.getContainer(E,A,C,D,B);return l_oProxyContainerKey;
}};
SL4B_FailoverRttpProvider.prototype.setContainerWindow = function(B,C,A){if(this.m_bProviderReady){if(this.m_oContainerKeyMap[B]!=null){B=this.m_oContainerKeyMap[B];}this.m_oBaseRttpProvider.setContainerWindow(B,C,A);}else 
{this.m_oRttpCommandQueue.setContainerWindow(B,C,A);}};
SL4B_FailoverRttpProvider.prototype.clearContainerWindow = function(A){if(this.m_bProviderReady){if(this.m_oContainerKeyMap[A]!=null){A=this.m_oContainerKeyMap[A];}this.m_oBaseRttpProvider.clearContainerWindow(A);}else 
{this.m_oRttpCommandQueue.clearContainerWindow(A);}};
SL4B_FailoverRttpProvider.prototype.removeContainer = function(B,A){if(this.m_bProviderReady){if(this.m_oContainerKeyMap[A]!=null){A=this.m_oContainerKeyMap[A];}this.m_oBaseRttpProvider.removeContainer(B,A);}else 
{this.m_oRttpCommandQueue.removeContainer(B,A);}};
SL4B_FailoverRttpProvider.prototype.getAutoDirectory = function(E,D,A,B,C){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getAutoDirectory(E,D,A,B,C);}else 
{this.m_oRttpCommandQueue.getAutoDirectory(E,D,A,B,C);}};
SL4B_FailoverRttpProvider.prototype.removeAutoDirectory = function(E,D,A,B,C){if(this.m_bProviderReady){this.m_oBaseRttpProvider.removeAutoDirectory(E,D,A,B,C);}else 
{this.m_oRttpCommandQueue.removeAutoDirectory(E,D,A,B,C);}};
SL4B_FailoverRttpProvider.prototype.getObjectType = function(B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getObjectType(B,A);}else 
{this.m_oRttpCommandQueue.getObjectType(B,A);}};
SL4B_FailoverRttpProvider.prototype.setThrottleObject = function(A,B){if(this.m_bProviderReady){this.m_oBaseRttpProvider.setThrottleObject(A,B);}else 
{this.m_oRttpCommandQueue.setThrottleObject(A,B);}};
SL4B_FailoverRttpProvider.prototype.setThrottleObjects = function(A,B){if(this.m_bProviderReady){this.m_oBaseRttpProvider.setThrottleObjects(A,B);}else 
{this.m_oRttpCommandQueue.setThrottleObjects(A,B);}};
SL4B_FailoverRttpProvider.prototype.setGlobalThrottle = function(A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.setGlobalThrottle(A);}else 
{this.m_oRttpCommandQueue.setGlobalThrottle(A);}};
SL4B_FailoverRttpProvider.prototype.disableWTStatsTimeout = function(A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.disableWTStatsTimeout(A);}else 
{this.m_oRttpCommandQueue.disableWTStatsTimeout(A);}};
SL4B_FailoverRttpProvider.prototype.clearObjectListeners = function(B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.clearObjectListeners(B,A);}else 
{this.m_oRttpCommandQueue.clearObjectListeners(B,A);}};
SL4B_FailoverRttpProvider.prototype.blockObjectListeners = function(B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.blockObjectListeners(B,A);}else 
{this.m_oRttpCommandQueue.blockObjectListeners(B,A);}};
SL4B_FailoverRttpProvider.prototype.unblockObjectListeners = function(B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.unblockObjectListeners(B,A);}else 
{this.m_oRttpCommandQueue.unblockObjectListeners(B,A);}};
SL4B_FailoverRttpProvider.prototype.createObject = function(A,B){if(this.m_bProviderReady){this.m_oBaseRttpProvider.createObject(A,B);}else 
{this.m_oRttpCommandQueue.createObject(A,B);}};
SL4B_FailoverRttpProvider.prototype.contribObject = function(C,A,B){if(this.m_bProviderReady){this.m_oBaseRttpProvider.contribObject(C,A,B);}else 
{this.m_oRttpCommandQueue.contribObject(C,A,B);}};
SL4B_FailoverRttpProvider.prototype.deleteObject = function(A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.deleteObject(A);}else 
{this.m_oRttpCommandQueue.deleteObject(A);}};
SL4B_FailoverRttpProvider.prototype.removeSubscriber = function(A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.removeSubscriber(A);}else 
{this.m_oRttpCommandQueue.removeSubscriber(A);}};
SL4B_FailoverRttpProvider.prototype.getFieldNames = function(){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getFieldNames();}else 
{this.m_oRttpCommandQueue.getFieldNames();}};
SL4B_FailoverRttpProvider.prototype.logout = function(){if(this.m_bProviderReady){this.m_oBaseRttpProvider.logout();}else 
{this.m_oRttpCommandQueue.logout();}};
SL4B_FailoverRttpProvider.prototype.debug = function(B,A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.debug(B,A);}else 
{this.m_oRttpCommandQueue.debug(B,A);}};
SL4B_FailoverRttpProvider.prototype.setDebugLevel = function(A){if(this.m_bProviderReady){this.m_oBaseRttpProvider.setDebugLevel(A);}else 
{this.m_oRttpCommandQueue.setDebugLevel(A);}};
SL4B_FailoverRttpProvider.prototype.getVersion = function(){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getVersion();}else 
{this.m_oRttpCommandQueue.getVersion();}};
SL4B_FailoverRttpProvider.prototype.getVersionInfo = function(){if(this.m_bProviderReady){this.m_oBaseRttpProvider.getVersionInfo();}else 
{this.m_oRttpCommandQueue.getVersionInfo();}};
SL4B_FailoverRttpProvider.prototype.onUnload = function(){this.m_oBaseRttpProvider.onUnload();};
var bURLValid=false;
var SL4B_AbstractJavaRttpProvider=function(){};
if(false){function SL4B_AbstractJavaRttpProvider(){}
}SL4B_AbstractJavaRttpProvider = function(){SL4B_AbstractRttpProvider.apply(this);this.m_sAppletDirectoryUrl=null;};
SL4B_AbstractJavaRttpProvider.prototype = new SL4B_AbstractRttpProvider;SL4B_AbstractJavaRttpProvider.prototype.connect = SL_FS;SL4B_AbstractJavaRttpProvider.prototype.login = SL_FI;SL4B_AbstractJavaRttpProvider.prototype.reconnect = SL_DW;SL4B_AbstractJavaRttpProvider.prototype.getObject = function(C,B,A){this.m_oRttpApplet.getObject(this.getListener(C),B,this.validateFieldList(A));};
SL4B_AbstractJavaRttpProvider.prototype.getObjects = function(C,A,B){this.m_oRttpApplet.getObjects(this.getListener(C),A,this.validateFieldList(B));};
SL4B_AbstractJavaRttpProvider.prototype.removeObject = function(C,B,A){this.m_oRttpApplet.removeObject(this.getListener(C),B,this.validateFieldList(A));};
SL4B_AbstractJavaRttpProvider.prototype.removeObjects = function(C,A,B){this.m_oRttpApplet.removeObjects(this.getListener(C),A,this.validateFieldList(B));};
SL4B_AbstractJavaRttpProvider.prototype.getObjectType = function(B,A){this.m_oRttpApplet.getObjectType(this.getListener(B),A);};
SL4B_AbstractJavaRttpProvider.prototype.setThrottleObject = function(A,B){this.m_oRttpApplet.setThrottleObject(A,B);};
SL4B_AbstractJavaRttpProvider.prototype.setThrottleObjects = function(A,B){this.m_oRttpApplet.setThrottleObjects(A,B);};
SL4B_AbstractJavaRttpProvider.prototype.setGlobalThrottle = function(A){this.m_oRttpApplet.setGlobalThrottle(A);};
SL4B_AbstractJavaRttpProvider.prototype.disableWTStatsTimeout = function(A){this.m_oRttpApplet.disableWTStatsTimeout(A);};
SL4B_AbstractJavaRttpProvider.prototype.clearObjectListeners = SL_MM;SL4B_AbstractJavaRttpProvider.prototype.blockObjectListeners = SL_DD;SL4B_AbstractJavaRttpProvider.prototype.unblockObjectListeners = SL_DA;SL4B_AbstractJavaRttpProvider.prototype.createObject = function(A,B){return this.m_oRttpApplet.createObject(A,B);
};
SL4B_AbstractJavaRttpProvider.prototype.contribObject = SL_EU;SL4B_AbstractJavaRttpProvider.prototype.deleteObject = function(A){return this.m_oRttpApplet.deleteObject(A);
};
SL4B_AbstractJavaRttpProvider.prototype.getFieldNames = function(){return this.m_oRttpApplet.getFieldNames();
};
SL4B_AbstractJavaRttpProvider.prototype.logout = function(){this.m_oRttpApplet.logout();};
SL4B_AbstractJavaRttpProvider.prototype.setDebugLevel = function(A){return this.m_oRttpApplet.setDebugLevel(A);
};
SL4B_AbstractJavaRttpProvider.prototype.getVersion = function(){return this.m_oRttpApplet.getVersion()+"-"+this.m_oRttpApplet.getBuildVersion();
};
SL4B_AbstractJavaRttpProvider.prototype.getVersionInfo = function(){return this.m_oRttpApplet.getVersionInfo();
};
SL4B_AbstractJavaRttpProvider.prototype.debug = function(B,A){if(typeof A=="undefined"){this.m_oRttpApplet.debug(B);}else 
{this.m_oRttpApplet.debug(B,A);}};
SL4B_AbstractJavaRttpProvider.prototype.m_oRttpApplet = null;SL4B_AbstractJavaRttpProvider.prototype.m_nAppletCheckTimeoutHandle = null;SL4B_AbstractJavaRttpProvider.prototype.m_nRttpAppletTimeoutHandle = null;SL4B_AbstractJavaRttpProvider.prototype.m_pUpdateQueue = new Array();SL4B_AbstractJavaRttpProvider.prototype.m_bConnectionEstablished = false;SL4B_AbstractJavaRttpProvider.prototype.const_ALL_FIELDS = 0;SL4B_AbstractJavaRttpProvider.prototype.getRttpAppletId = function(){return "appRttpApplet";
};
SL4B_AbstractJavaRttpProvider.prototype.createParameterHtml = function(B,A){return "<param name=\""+B+"\" value=\""+A+"\"></param>";
};
SL4B_AbstractJavaRttpProvider.prototype.validateFieldList = function(A){return ((A==null||typeof A=="undefined") ? this.const_ALL_FIELDS : A);
};
SL4B_AbstractJavaRttpProvider.prototype.setRttpApplet = SL_FV;SL4B_AbstractJavaRttpProvider.prototype.getAppletParameterHtml = SL_GJ;SL4B_AbstractJavaRttpProvider.prototype.writeAppletToDocument = SL_MS;SL4B_AbstractJavaRttpProvider.prototype.startAppletCheckTimeout = SL_JX;SL4B_AbstractJavaRttpProvider.prototype.startRttpAppletTimeout = SL_IA;SL4B_AbstractJavaRttpProvider.prototype.appletCheckDownloadComplete = SL_NJ;SL4B_AbstractJavaRttpProvider.prototype.rttpAppletDownloadComplete = SL_JH;SL4B_AbstractJavaRttpProvider.prototype.urlCheckDownloadFailed = SL_DG;SL4B_AbstractJavaRttpProvider.prototype.appletCheckDownloadFailed = SL_RA;SL4B_AbstractJavaRttpProvider.prototype.rttpAppletDownloadFailed = SL_KP;SL4B_AbstractJavaRttpProvider.prototype.queueUpdates = SL_GD;SL4B_AbstractJavaRttpProvider.prototype.dequeueUpdates = SL_OW;SL4B_AbstractJavaRttpProvider.prototype.WTConnectionError = SL_FO;SL4B_AbstractJavaRttpProvider.prototype.WTConnectionInfo = SL_AA;SL4B_AbstractJavaRttpProvider.prototype.WTConnectionOk = SL_BV;SL4B_AbstractJavaRttpProvider.prototype.WTMessage = SL_FY;SL4B_AbstractJavaRttpProvider.prototype.WTReconnect = SL_JB;SL4B_AbstractJavaRttpProvider.prototype.WTServiceMessage = SL_GY;SL4B_AbstractJavaRttpProvider.prototype.WTSessionEjected = SL_GF;SL4B_AbstractJavaRttpProvider.prototype.WTSourceMessage = SL_KG;SL4B_AbstractJavaRttpProvider.prototype.WTStats = SL_AT;function SL_FS(){this.m_oRttpApplet.addStatsListener('SL4B_Accessor.getRttpProvider()');this.m_oRttpApplet.addConnectionListener("SL4B_Accessor.getRttpProvider()");this.m_oRttpApplet.addReconnectListener('SL4B_Accessor.getRttpProvider()');this.m_oRttpApplet.addMessagesListener('SL4B_Accessor.getRttpProvider()');this.m_oRttpApplet.connect(false);}
function SL_DW(){this.m_oRttpApplet.reconnect(false);}
function SL_FI(A,B){this.credentialsRetrieved();var l_sLoginResponse=this.m_oRttpApplet.login(A,B);
if(typeof l_sLoginResponse!="undefined"&&l_sLoginResponse!=null&&l_sLoginResponse!=""){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_LOGIN_ERROR_CONNECTION_EVENT,l_sLoginResponse));}else 
{this.loggedIn();}}
function SL_MM(B,A){if(typeof A=="undefined"){this.m_oRttpApplet.clearObjectListeners(this.getListener(B));}else 
{this.m_oRttpApplet.clearObjectListeners(this.getListener(B),A);}}
function SL_DD(B,A){if(typeof A=="undefined"){this.m_oRttpApplet.blockObjectListeners(this.getListener(B));}else 
{this.m_oRttpApplet.blockObjectListeners(this.getListener(B),A);}}
function SL_DA(B,A){if(typeof A=="undefined"){this.m_oRttpApplet.unblockObjectListeners(this.getListener(B));}else 
{this.m_oRttpApplet.unblockObjectListeners(this.getListener(B),A);}}
function SL_EU(C,A,B){for(var l_nFieldIndex=0,l_nLength=B.size();l_nFieldIndex<l_nLength;++l_nFieldIndex){var l_oField=B.getField(l_nFieldIndex);
if(l_nFieldIndex==(l_nLength-1)){this.m_oRttpApplet.contribObject(A,l_oField.m_sName,l_oField.m_sValue,this.getListener(C));}else 
{this.m_oRttpApplet.contribObject(A,l_oField.m_sName,l_oField.m_sValue,null);}}}
function SL_FV(A){this.m_oRttpApplet=A;this.connect();}
function SL_GJ(){var l_oConfiguration=SL4B_Accessor.getConfiguration();
var l_sHtml="";
l_sHtml+=this.createParameterHtml('scriptable','true');l_sHtml+=this.createParameterHtml('loaded.callback','1');var l_sDirectPort=null;
var l_sDirectEnable='0';
var l_sHttpEnable='0';
var l_sRefreshEnable='0';
var l_oConnectionData;
while((l_oConnectionData=this.m_oLiberatorConfiguration.getNextConnection())!=null){switch(l_oConnectionData.m_oMethod){
case SL4B_ConnectionMethod.JAVADIRECT:l_sDirectEnable='1';l_sDirectPort=l_oConnectionData.m_sPort;break;
case SL4B_ConnectionMethod.JAVAHTTP:l_sHttpEnable='1';break;
case SL4B_ConnectionMethod.JAVAPOLLING:l_sRefreshEnable='1';break;
}}l_sHtml+=this.createParameterHtml('rttp.direct.enable',l_sDirectEnable);l_sHtml+=this.createParameterHtml('rttp.http.enable',l_sHttpEnable);l_sHtml+=this.createParameterHtml('rttp.refresh.enable',l_sRefreshEnable);if(l_sDirectPort!=null){l_sHtml+=this.createParameterHtml('rttp.server.port',l_sDirectPort);}l_sHtml+=this.createParameterHtml('rttp.cookie.enable','1');l_sHtml+=this.createParameterHtml('rttp.response.dequeue.timeout','120000');l_sHtml+=this.createParameterHtml('rttp.debuglevel',l_oConfiguration.getRttpDebugLevel());if(l_oConfiguration.isMultiUpdates()){l_sHtml+=this.createParameterHtml('record.updates','2');}else 
{l_sHtml+=this.createParameterHtml('record.updates','1');}if(l_oConfiguration.getApplicationId()!=null){l_sHtml+=this.createParameterHtml('rttp.applicationid',l_oConfiguration.getApplicationId());}if(l_oConfiguration.getObjectNameDelimiter()!=SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER){l_sHtml+=this.createParameterHtml('objectname.delimiter',l_oConfiguration.getObjectNameDelimiter());}if(l_oConfiguration.isNoStaleNotify()!=null){l_sHtml+=this.createParameterHtml('notify.stale',l_oConfiguration.isNoStaleNotify());}if(l_oConfiguration.getGarbageCollectionFrequency()!=null){l_sHtml+=this.createParameterHtml('rttp.gc.force',l_oConfiguration.getGarbageCollectionFrequency());}if(l_oConfiguration.getMicrosoftGarbageCollectionFrequency()!=null){l_sHtml+=this.createParameterHtml('rttp.gc.force.microsoft',l_oConfiguration.getMicrosoftGarbageCollectionFrequency());}if(l_oConfiguration.getSunGarbageCollectionFrequency()!=null){l_sHtml+=this.createParameterHtml('rttp.gc.force.sun',l_oConfiguration.getSunGarbageCollectionFrequency());}if(l_oConfiguration.getType3PollPeriod()!=null){l_sHtml+=this.createParameterHtml('rttp.refresh.time',l_oConfiguration.getType3PollPeriod());}l_sHtml+=this.createParameterHtml('discard.delay',l_oConfiguration.getDiscardDelay());l_sHtml+=this.createParameterHtml('logout.delay',l_oConfiguration.getLogoutDelay());l_sHtml+=this.createParameterHtml('stats.interval',l_oConfiguration.getStatsInterval());l_sHtml+=this.createParameterHtml('stats.reset',l_oConfiguration.getStatsReset());l_sHtml+=this.createParameterHtml('stats.timeout',l_oConfiguration.getStatsTimeout());return l_sHtml;
}
function SL_MS(A){var l_sHtmlToWrite="<div style=\"height:0px;width:0px;overflow:hidden;\">";
l_sHtmlToWrite+=A;l_sHtmlToWrite+="</div>";document.write(l_sHtmlToWrite);}
function SL_JX(){this.m_nAppletCheckTimeoutHandle=setTimeout("SL4B_Accessor.getRttpProvider().appletCheckDownloadFailed()",SL4B_Accessor.getConfiguration().getAppletCheckTimeout());}
function SL_IA(){this.m_nRttpAppletTimeoutHandle=setTimeout("SL4B_Accessor.getRttpProvider().rttpAppletDownloadFailed()",SL4B_Accessor.getConfiguration().getRttpAppletTimeout());}
function SL_NJ(){if(this.m_nAppletCheckTimeoutHandle!==null){clearTimeout(this.m_nAppletCheckTimeoutHandle);this.m_nAppletCheckTimeoutHandle=null;}}
function SL_JH(){if(this.m_nRttpAppletTimeoutHandle!==null){clearTimeout(this.m_nRttpAppletTimeoutHandle);this.m_nRttpAppletTimeoutHandle=null;}var l_oApplet=SL4B_Accessor.getBrowserAdapter().getElementById(this.getRttpAppletId());
this.setRttpApplet(l_oApplet);}
function SL_DG(){this.notifyConnectionListeners(this.const_FILE_DOWNLOAD_ERROR_CONNECTION_EVENT,SL4B_FileType.URL_CHECK,this.m_sAppletDirectoryUrl+"/urlcheck.js");}
function SL_RA(){if(this.m_nAppletCheckTimeoutHandle!==null){this.m_nAppletCheckTimeoutHandle=null;this.notifyConnectionListeners(this.const_FILE_DOWNLOAD_ERROR_CONNECTION_EVENT,SL4B_FileType.APPLET_CHECK,this.m_sAppletDirectoryUrl+"/AppletCheck.class");}}
function SL_KP(){if(this.m_nRttpAppletTimeoutHandle!==null){this.m_nRttpAppletTimeoutHandle=null;var l_oConfiguration=SL4B_Accessor.getConfiguration();
this.notifyConnectionListeners(this.const_FILE_DOWNLOAD_ERROR_CONNECTION_EVENT,SL4B_FileType.RTTP_APPLET,this.m_sAppletDirectoryUrl+l_oConfiguration.getAppletJarName());}}
function SL_GD(A){this.m_pUpdateQueue.push(A);setTimeout("SL4B_Accessor.getRttpProvider().dequeueUpdates()",0);}
function SL_OW(){var l_oQueue=this.m_pUpdateQueue.shift();
l_oQueue.doAllUpdates();}
function SL_FO(A){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_WARNING_CONNECTION_EVENT,A));}
function SL_AA(A){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_INFO_CONNECTION_EVENT,A));}
function SL_BV(C,A,B){if(!this.m_bConnectionEstablished){this.m_bConnectionEstablished=true;setTimeout("SL4B_Accessor.getRttpProvider().connected();",0);}C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_OK_CONNECTION_EVENT,C,A,B));}
function SL_FY(A,B){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_MESSAGE_CONNECTION_EVENT,A,B));}
function SL_JB(){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_ERROR_CONNECTION_EVENT));}
function SL_GY(A,D,B,C){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_SERVICE_MESSAGE_CONNECTION_EVENT,A,D,B,C));}
function SL_GF(A,B){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_SESSION_EJECTED_CONNECTION_EVENT,A,B));}
function SL_KG(A,C,D,B){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_SOURCE_MESSAGE_CONNECTION_EVENT,A,C,D,B));}
function SL_AT(A,D,E,B,C){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_STATISTICS_CONNECTION_EVENT,A,D,E,B,C));}
function WTAppletLoaded(){setTimeout("SL4B_Accessor.getRttpProvider().rttpAppletDownloadComplete()",0);}
function WTWrapper(){eval(arguments[0]+"."+arguments[1]+"(arguments[2], arguments[3])");}
function WTQueue(A){SL4B_Accessor.getRttpProvider().queueUpdates(A);}
function AppletCheckLoaded(){setTimeout("SL4B_Accessor.getRttpProvider().appletCheckDownloadComplete()",0);}
var SL4B_AppletRttpProvider=function(){};
if(false){function SL4B_AppletRttpProvider(){}
}SL4B_AppletRttpProvider = function(A){this.m_oLiberatorConfiguration=A;var l_sAppletUrl=SL4B_Accessor.getConfiguration().getAppletUrl();
if(l_sAppletUrl==null){var l_oConnectionData=this.m_oLiberatorConfiguration.peekAtNextConnection();
l_sAppletUrl=((l_oConnectionData==null) ? "" : l_oConnectionData.getServerUrl())+"/"+SL4B_Accessor.getConfiguration().getAppletPath();}this.m_sAppletDirectoryUrl=l_sAppletUrl;};
SL4B_AppletRttpProvider.prototype = new SL4B_AbstractJavaRttpProvider;SL4B_AppletRttpProvider.prototype.initialise = SL_KB;SL4B_AppletRttpProvider.prototype.loadUrlCheck = SL_GT;SL4B_AppletRttpProvider.prototype.loadAppletCheck = SL_OB;SL4B_AppletRttpProvider.prototype.loadRttpApplet = SL_KN;function SL_KB(){this.loadUrlCheck();this.loadAppletCheck();this.loadRttpApplet();}
function SL_GT(){SL4B_ScriptLoader.loadScript(this.m_sAppletDirectoryUrl+"/urlcheck.js?"+(new Date()).valueOf());SL4B_ScriptLoader.loadSl4bScript("applet-rttp-provider/js-check-file-loaded.js");}
function SL_OB(){var l_sHtml="<applet width=\"0\" height=\"0\"";
l_sHtml+="codebase=\""+this.m_sAppletDirectoryUrl+"\" ";l_sHtml+="code=\"AppletCheck.class\" ";l_sHtml+="mayscript=\"mayscript\" ";l_sHtml+="></applet>";this.startAppletCheckTimeout();this.writeAppletToDocument(l_sHtml);}
function SL_KN(){var l_oConfiguration=SL4B_Accessor.getConfiguration();
var l_sHtml="<applet id=\""+this.getRttpAppletId()+"\" width=\"0\" height=\"0\" ";
l_sHtml+="codebase=\""+this.m_sAppletDirectoryUrl+"\" ";if(SL4B_Accessor.getBrowserAdapter().isFirefox()){l_sHtml+="code=\"com.rttp.applet.FirefoxRTTPApplet.class\" ";}else 
{l_sHtml+="code=\"com.rttp.applet.RTTPApplet.class\" ";}l_sHtml+="archive=\""+l_oConfiguration.getAppletJarName()+"\" ";l_sHtml+="mayscript=\"mayscript\" ";l_sHtml+=">";l_sHtml+=this.getAppletParameterHtml();l_sHtml+="</applet>";this.startRttpAppletTimeout();this.writeAppletToDocument(l_sHtml);}
var SL4B_AbstractObjectRttpProvider=function(){};
if(false){function SL4B_AbstractObjectRttpProvider(){}
}SL4B_AbstractObjectRttpProvider = function(A){SL4B_AbstractRttpProvider.apply(this);this.m_oLiberatorConfiguration=A;};
function SL_GI(){SL4B_AbstractObjectRttpProvider.prototype = new SL4B_AbstractRttpProvider;}
var SL4B_JavaScriptRttpProviderConstants = new function(){this.const_TYPE_PARAMETER="type";this.const_DOMAIN_PARAMETER="domain";this.const_URL_PARAMETER="url";this.const_UNIQUEID_PARAMETER="uniqueid";this.const_MAX_GET_LENGTH_PARAMETER="maxget";this.const_INIT_PARAMETER="init";this.const_TYPE4_PARAMETER="type4";this.const_REQUEST_TYPE="request";this.const_RESPONSE_TYPE="response";};
var SL4B_RttpCodes = new function(){this.const_REQUEST_ACK=0;this.const_CONNECT_OK=1;this.const_FIELD_MAP=50;this.const_SESSION_EJECTED=90;this.const_LOGIN_OK=101;this.const_RECON_OK=111;this.const_RESP_UNKNOWN=200;this.const_DIRECTORY_RESP=220;this.const_PAGE_RESP=221;this.const_RECORD_RESP=222;this.const_NEWS_RESP=223;this.const_STORY_RESP=224;this.const_CHAT_RESP=227;this.const_CONT_RESP=228;this.const_AUTODIR_RESP=229;this.const_PERM_RESP=230;this.const_CONTRIB_OK=301;this.const_DISCARD_OK=302;this.const_CREATE_OK=303;this.const_DELETE_OK=304;this.const_NOOP_OK=305;this.const_LOGOUT_OK=306;this.const_THROTTLE_OK=307;this.const_SYNC_OK=309;this.const_CONTRIB_WAIT=311;this.const_CONTRIB_OK_DELAY=351;this.const_OBJECT_UPDATES=400;this.const_STATUS_OK=415;this.const_STATUS_STALE=416;this.const_STATUS_LIMITED=417;this.const_STATUS_REMOVED=418;this.const_STATUS_INFO=419;this.const_DIR_UPD=420;this.const_PAGE_UPD=421;this.const_REC1_UPD=422;this.const_NEWS_UPD=423;this.const_STORY_UPD=424;this.const_REC2_UPD=425;this.const_REC3_UPD=426;this.const_CHAT_UPD=427;this.const_CONT_UPD=428;this.const_AUTODIR_UPD=429;this.const_PERM_UPD=430;this.const_PERM_IMG=450;this.const_PERM_CLR=470;this.const_REC1_IMG=472;this.const_NEWS_IMG=473;this.const_STORY_IMG=474;this.const_REC2_IMG=475;this.const_REC3_IMG=476;this.const_CONT_IMG=478;this.const_AUTODIR_IMG=479;this.const_REC1_CLR=482;this.const_NEWS_CLR=463;this.const_REC2_CLR=485;this.const_REC3_CLR=486;this.const_PERM_DEL=490;this.const_REC1_DEL=492;this.const_REC2_DEL=495;this.const_REC3_DEL=496;this.const_MISC_HEARTBEAT=501;this.const_INIT_HEARTBEAT=502;this.const_SOURCE_UP=511;this.const_SOURCE_DOWN=512;this.const_SOURCE_WARN=513;this.const_SERVICE_OK=515;this.const_SERVICE_DOWN=516;this.const_SERVICE_LIMITED=517;this.const_STATUS_MSG=520;this.const_WARNING_MSG=530;this.const_ERROR_MSG=540;this.const_NOT_FOUND_DELAY=550;this.const_READ_DENY_DELAY=560;this.const_WRITE_DENY_DELAY=570;this.const_UNAVAILABLE_DELAY=580;this.const_INVALID_PARAMETERS=581;this.const_DELETED_DELAY=590;this.const_NOT_FOUND=600;this.const_READ_DENY=610;this.const_WRITE_DENY=620;this.const_UNAVAILABLE=630;this.const_INVALID_PARAMETERS_DELAY=631;this.const_CONTRIB_FAILED=650;this.const_THROTTLE_FAILED=660;this.const_THROTTLE_UP_FAILED=661;this.const_THROTTLE_DOWN_FAILED=662;this.const_THROTTLE_MIN_FAILED=663;this.const_THROTTLE_MAX_FAILED=664;this.const_THROTTLE_STOP_FAILED=665;this.const_THROTTLE_START_FAILED=666;this.const_THROTTLE_DEF_FAILED=667;this.const_THROTTLE_NL_FAILED=668;this.const_LOGIN_FAILURES=700;this.const_INVALID_USER=701;this.const_INVALID_PASS=702;this.const_INVALID_IP=703;this.const_ACCT_EXPIRED=704;this.const_ALREADY_LOGGED_IN=705;this.const_LICENSE_SITE=711;this.const_LICENSE_USER=712;this.const_GOTO_URL=721;this.const_AUTH_ERROR_STR=731;this.const_NOT_LOGGED_IN=800;this.const_REQUEST_ERROR=810;this.const_INVALID_REQUEST=811;this.const_SERVER_ERROR=820;this.const_INVALID_SESSION_ID=832;this.const_MULTI_RESPONSE=900;this.isResponseCode = function(A){return ((A>=this.const_LOGIN_OK&&A<this.const_CONTRIB_OK_DELAY)||(A>=this.const_NOT_FOUND&&A<this.const_LOGIN_FAILURES)||(A>=this.const_NOT_LOGGED_IN&&A<this.const_MULTI_RESPONSE));
};
this.isImageCode = function(A){return ((A>=this.const_DIRECTORY_RESP&&A<this.const_CONTRIB_OK)||(A>=this.const_REC1_IMG&&A<=this.const_AUTODIR_IMG)||(A>=this.const_PERM_IMG&&A<this.const_PERM_CLR));
};
this.isEventCode = function(A){return ((A>=this.const_CONTRIB_OK_DELAY&&A<this.const_MISC_HEARTBEAT)||(A>=this.const_NOT_FOUND_DELAY&&A<this.const_NOT_FOUND));
};
this.isFinalEventCode = function(A){return ((A>=this.const_CONTRIB_OK_DELAY&&A<this.const_OBJECT_UPDATES)||(A>=this.const_NOT_FOUND_DELAY&&A<this.const_NOT_FOUND));
};
};
var GF_Base64Decoder=function(){};
if(false){function GF_Base64Decoder(){}
}GF_Base64Decoder = function(){this.m_mBase64CharacterToBase10ValueMap={};this.m_nTwoDigitBase64Limit=4096;var sBase64Encoding="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_";
for(var nDecodedValue=0,nLength=sBase64Encoding.length;nDecodedValue<nLength;++nDecodedValue){this.m_mBase64CharacterToBase10ValueMap[sBase64Encoding.charAt(nDecodedValue)]=nDecodedValue;}};
GF_Base64Decoder.prototype.decodeRttpCode = function(A){return this._decodeTwoDigitBase64Value(A);
};
GF_Base64Decoder.prototype.decodeSequenceNumber = function(A){return this._decodeTwoDigitBase64Value(A);
};
GF_Base64Decoder.prototype.decodeNextExpectedSequenceNumber = function(A){if(A===null||A.length===0){return 0;
}var nNextSequenceNumber=this.decodeSequenceNumber(A)+1;
if(nNextSequenceNumber<this.m_nTwoDigitBase64Limit){return nNextSequenceNumber;
}return 0;
};
GF_Base64Decoder.prototype._decodeTwoDigitBase64Value = function(A){if(A.length!==2){this._throwIllegalEncodingException(A);}var n64s=this.m_mBase64CharacterToBase10ValueMap[A.charAt(0)];
var nUnits=this.m_mBase64CharacterToBase10ValueMap[A.charAt(1)];
if(n64s===undefined||nUnits===undefined){this._throwIllegalEncodingException(A);}return (n64s*64)+nUnits;
};
GF_Base64Decoder.prototype._throwIllegalEncodingException = function(A){throw new SL4B_Exception("Illegal base 64 encoded value \""+A+"\"");
};
GF_Base64Decoder=new GF_Base64Decoder();var SL4B_RequestRecord=function(){};
if(false){function SL4B_RequestRecord(){}
}SL4B_RequestRecord = function(A,C,B,E,D){this.sMessage=A;this.oOriginalMessage=C;this.oListener=B;this.bHighPriority=E;this.oContext=D;this.sObjectName="";this.mParameters={};this.pFields=[];if(this.sMessage!=null){var pParms=A.split(/[;,]/);
var sRequest=pParms.shift();
this.sObjectName=sRequest.split(" ")[1];for(var i=0;i<pParms.length;i++){var pKeyval=pParms[i].split("=");
if(pKeyval.length>1){this.mParameters[pKeyval[0]]=pKeyval[1];}else 
{this.pFields.push(pKeyval[0]);}}}};
SL4B_RequestRecord.prototype.getObjectName = function(){return this.sObjectName;
};
SL4B_RequestRecord.prototype.getParameters = function(){return this.mParameters;
};
SL4B_RequestRecord.prototype.getFields = function(){return this.pFields;
};
SL4B_RequestRecord.prototype.getFilterContent = function(A){var result={};
if(A!==null&&A!==undefined&&A.length>0){var filterStart=A.indexOf(';');
if(filterStart>=0){var filterMsg=A.substring(filterStart+1);
while(filterMsg!=""){filterMsg=this.getNextNameValuePair(filterMsg,result);}}}return result;
};
SL4B_RequestRecord.prototype.getMessage = function(){return this.sMessage;
};
SL4B_RequestRecord.prototype.getOriginalMessage = function(){return this.oOriginalMessage;
};
SL4B_RequestRecord.prototype.getListener = function(){return this.oListener;
};
SL4B_RequestRecord.prototype.isHighPriority = function(){return this.bHighPriority;
};
SL4B_RequestRecord.prototype.getContext = function(){return this.oContext;
};
SL4B_RequestRecord.prototype.toString = function(){return "{RequestRecord: "+this.sMessage+" "+this.oOriginalMessage+" "+this.oListener+" "+this.bHighPriority+" "+this.oContext+"}";
};
var SL4B_ManagedConnection=function(){};
if(false){function SL4B_ManagedConnection(){}
}SL4B_ManagedConnection = function(){this.CLASS_NAME="SL4B_ManagedConnection";this.m_pRequestQueue=new Array();this.m_pPriorityRequestQueue=new Array();this.m_pResponseQueue=new Array();this.m_mObjectNumberToRequestRecord=new Object();this.m_oSystemEventReceiverRecord=null;this.m_oObjectNumberMap=new SL4B_ObjectNumberMap(this);this.m_oConnectionManager=null;this.m_sSessionId=null;};
SL4B_ManagedConnection.MESSAGES={REQUEST_CONFLICT:"{0}: Conflict between message listeners for object number {1}. Two different listeners have been registered to process the message.", UNEXPECTED_RESPONSE:"{0}: Received response when none were expected.  message={1}", UNKNOWN_OBJECT_NUMBER:"{0}: Received update for an unknown object number.  message={1}", IGNORING_RESPONSE_QUEUE:"{0}: ignoring expected response queue queue for message={1}", RESPONSE_QUEUED:"{0}: queued expected response for message={1}", RESPONSE_DEQUEUED:"{0}: dequeued reponse for message={1}, response={2}", ADDED_OBJECT_NUMBER_EVENT_LISTENER:"{0}: Added event listener for object number {1}", REMOVED_OBJECT_NUMBER_EVENT_LISTENER:"{0}: Removed event listener for object number {1}", CLEARING_STATE:"{0}: Clearing state.", INCOMING_MESSAGES_EXPECTED_AFTER_LOGIN:"{0}: The expected incoming should be empty immediately after receiving a login, but instead has {1} messages.  First message is '{2}'", QUEUED_HIGH_PRIORITY_MESSAGE:"{0}: Queued high priority message {1}", QUEUED_MESSAGE:"{0}: Queued message {1}", SESSION_ID_NULL_FOR_HIGH_PRIORITY_MESSAGE:"{0}: Session id is null, cannot send high priority message {1} at the moment", SESSION_ID_NULL_FOR_MESSAGE:"{0}: Session id is null, cannot send message {1} at the moment", DONT_SEND_NEXT_MESSAGE:"{0}: Didn't send next message - {1}"};SL4B_ManagedConnection.prototype._$setConnectionManager = function(A){this.m_oConnectionManager=A;};
SL4B_ManagedConnection.prototype.sendMessage = function(A,B,C){this._sendPriorityMessage(A,B,false,C);};
SL4B_ManagedConnection.prototype.setSystemEventReceiver = function(A){this.m_oSystemEventReceiverRecord=new SL4B_RequestRecord(null,null,A,false,null);};
SL4B_ManagedConnection.prototype._setSessionId = function(A){this.m_sSessionId=A;SL4B_Logger.logConnectionMessage(true,"Session Id: {0}",this.m_sSessionId);};
SL4B_ManagedConnection.prototype._getSessionId = function(){return this.m_sSessionId;
};
SL4B_ManagedConnection.prototype._hasSessionId = function(){return this.m_sSessionId!==null;
};
SL4B_ManagedConnection.prototype.receiveMessage = function(A){var oNormalisedMessage=A;
var oMsgRecord=null;
if(SL4B_RttpCodes.isResponseCode(oNormalisedMessage.getRttpCode())){oMsgRecord=this._getNextResponseListener(oNormalisedMessage);}else 
{oMsgRecord=this._getEventListener(oNormalisedMessage);}if(oMsgRecord){this.m_oObjectNumberMap._setMsgRecord(oMsgRecord);oMsgRecord.getListener().receiveMessage(A,oMsgRecord,this.m_oObjectNumberMap);}};
SL4B_ManagedConnection.prototype._getEventListener = function(A){var oListener=null;
var nObjectNumber=A.getObjectNumber();
var oMsgRecord=null;
if(nObjectNumber!==null){oMsgRecord=this.m_mObjectNumberToRequestRecord[nObjectNumber];if(oMsgRecord===undefined){this._log(SL4B_DebugLevel.const_ERROR_INT,SL4B_ManagedConnection.MESSAGES.UNKNOWN_OBJECT_NUMBER,"_getEventListener",A);return null;
}else 
{if(SL4B_RttpCodes.isFinalEventCode(A.getRttpCode())){this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.REMOVED_OBJECT_NUMBER_EVENT_LISTENER,"_getEventListener",nObjectNumber);delete this.m_mObjectNumberToRequestRecord[nObjectNumber];}}}else 
{oMsgRecord=this.m_oSystemEventReceiverRecord;}return oMsgRecord;
};
SL4B_ManagedConnection.prototype.getRequestRecord = function(A){return this.m_mObjectNumberToRequestRecord[A];
};
SL4B_ManagedConnection.prototype._getNextResponseListener = function(A){var oListener=null;
var oMsgRecord=null;
var nObjectNumber=A.getObjectNumber();
if(this.m_pResponseQueue.length>0){oMsgRecord=this.m_pResponseQueue.shift();this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.RESPONSE_DEQUEUED,"_getNextResponseListener",oMsgRecord,A.toString());oListener=oMsgRecord.getListener();if(nObjectNumber!==null){this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.ADDED_OBJECT_NUMBER_EVENT_LISTENER,"_getNextResponseListener",nObjectNumber);var oOrigRecord=this.m_mObjectNumberToRequestRecord[nObjectNumber];
if(oOrigRecord!==undefined&&oOrigRecord.getListener()!==oMsgRecord.getListener()){this._log(SL4B_DebugLevel.const_WARN_INT,SL4B_ManagedConnection.MESSAGES.REQUEST_CONFLICT,"_getNextResponseListener",nObjectNumber);}else 
{this.m_mObjectNumberToRequestRecord[nObjectNumber]=oMsgRecord;}}}else 
{this._log(SL4B_DebugLevel.const_ERROR_INT,SL4B_ManagedConnection.MESSAGES.UNEXPECTED_RESPONSE,"_getNextResponseListener",A);this._triggerReconnect("Received response when none was expected",true);return null;
}return oMsgRecord;
};
SL4B_ManagedConnection.prototype._triggerReconnect = function(A,B){SL4B_Accessor.getUnderlyingRttpProvider().createConnectionLost(A,B);};
SL4B_ManagedConnection.prototype._$isFullReconnectRequired = function(){var bFullReconnect=false;
for(var i=0,nLength=this.m_pResponseQueue.length;i<nLength;++i){if(this.m_pResponseQueue[i].getMessage().match(/^REQUEST|^DISCARD|^CREATE|^DELETE|^CONTRIB|^THROTTLE|^GLOBAL_THROTTLE|^LOGIN/)){bFullReconnect=true;break;
}}return bFullReconnect;
};
SL4B_ManagedConnection.prototype.clearResponseQueue = function(){this._log(SL4B_DebugLevel.const_RTTP_FINER_INT,SL4B_ManagedConnection.MESSAGES.CLEARING_STATE,"clearResponseQueue");this.m_pResponseQueue=new Array();};
SL4B_ManagedConnection.prototype.clear = function(){this._log(SL4B_DebugLevel.const_RTTP_FINER_INT,SL4B_ManagedConnection.MESSAGES.CLEARING_STATE,"clear");this.m_pRequestQueue=new Array();this.m_pPriorityRequestQueue=new Array();if(this.m_pResponseQueue.length>0){this._log(SL4B_DebugLevel.const_WARN_INT,SL4B_ManagedConnection.MESSAGES.INCOMING_MESSAGES_EXPECTED_AFTER_LOGIN,"clear",this.m_pResponseQueue.length,this.m_pResponseQueue[0]);}this.m_pResponseQueue=new Array();this.m_mObjectNumberToRequestRecord=new Object();};
SL4B_ManagedConnection.prototype._sendPriorityMessage = function(A,B,D,C){if(B==null){throw new SL4B_Exception("SL4B_ManagedConnection._sendPriorityMessage: Listener may not be null or undefined.");
}if(B.receiveMessage==null){throw new SL4B_Exception("SL4B_ManagedConnection._sendPriorityMessage: Listener must implement receiveMessage.");
}var oMsgRecord=new SL4B_RequestRecord(A,null,B,D,C);
if(D){this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.QUEUED_HIGH_PRIORITY_MESSAGE,"_sendPriorityMessage",A);this.m_pPriorityRequestQueue.push(oMsgRecord);}else 
{this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.QUEUED_MESSAGE,"_sendPriorityMessage",A);this.m_pRequestQueue.push(oMsgRecord);}this._sendNextRttpMessage();};
SL4B_ManagedConnection.prototype._sendNextRttpMessage = function(){if(this.m_oConnectionManager.readyToRequest()&&this._hasMessages()){if(this.m_sSessionId!==null){var oMsgRecord=this._dequeueMessage();
if(oMsgRecord===null){this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.DONT_SEND_NEXT_MESSAGE,"_sendNextRttpMessage","not logged in");return;
}this.m_oConnectionManager.makingRequest();if(oMsgRecord.getListener()!==SL4B_ManagedConnection.NO_RESPONSE_EXPECTED_MESSAGE_RECEIVER){this._addResponses(oMsgRecord);}else 
{this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.IGNORING_RESPONSE_QUEUE,"_sendNextRttpMessage",oMsgRecord);}var sMsg=oMsgRecord.getMessage();
if(sMsg=="SYNC"){sMsg=this.m_oConnectionManager.getConnectionProxy().getNextSyncMessage();}this._sendRttpMessage(sMsg);}else 
{if(this.m_pPriorityRequestQueue.length>0){this._log(SL4B_DebugLevel.const_ERROR_INT,SL4B_ManagedConnection.MESSAGES.SESSION_ID_NULL_FOR_HIGH_PRIORITY_MESSAGE,"_sendNextRttpMessage",this.m_pPriorityRequestQueue[0]);}else 
{this._log(SL4B_DebugLevel.const_ERROR_INT,SL4B_ManagedConnection.MESSAGES.SESSION_ID_NULL_FOR_MESSAGE,"_sendNextRttpMessage",this.m_pRequestQueue[0]);}}}else 
{var sMessage;
if(!this._hasMessages()){sMessage="no messages remaining in queue";}else 
{sMessage="an acknowledgement for the last message has not been received";}this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.DONT_SEND_NEXT_MESSAGE,"_sendNextRttpMessage",sMessage);}};
SL4B_ManagedConnection.prototype._sendRttpMessage = function(A){var l_sFullRttpMessage=this.m_sSessionId+((A=="") ? "" : (" "+A));
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"> {0}",l_sFullRttpMessage);this.m_oConnectionManager.getConnectionProxy().send(GF_RequestEncoder.encodeUrl(l_sFullRttpMessage));};
SL4B_ManagedConnection.prototype._addResponse = function(A){this._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.RESPONSE_QUEUED,"_addResponse",A);this.m_pResponseQueue.push(A);};
SL4B_ManagedConnection.prototype._addResponses = function(A){var sMsg=A.getMessage();
var nEndOfCommand=sMsg.indexOf(" ");
if(nEndOfCommand>0){var sCommand=sMsg.substring(0,nEndOfCommand);
if(this._mayHaveMultipleObjects(sCommand)){var pObjects=sMsg.substring(nEndOfCommand+1).split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
var start=0;
if(pObjects[0].substr(0,1)==";"){start=1;}for(var i=start,len=pObjects.length;i<len;i++){var oSyntheticRequest=new SL4B_RequestRecord(sCommand+" "+pObjects[i],A,A.getListener(),A.isHighPriority(),A.getContext());
this._addResponse(oSyntheticRequest);}}else 
{this._addResponse(A);}}else 
{this._addResponse(A);}};
SL4B_ManagedConnection.prototype._mayHaveMultipleObjects = function(A){return A=="THROTTLE"||A=="REQUEST"||A=="DISCARD";
};
SL4B_ManagedConnection.prototype._dequeueMessage = function(){var oMsgRecord=null;
if(this.m_pPriorityRequestQueue.length>0){oMsgRecord=this.m_pPriorityRequestQueue.shift();}else 
if(this.m_oConnectionManager.isLoggedIn()){oMsgRecord=this.m_pRequestQueue.shift();}return oMsgRecord;
};
SL4B_ManagedConnection.prototype._hasMessages = function(){return this.m_pPriorityRequestQueue.length>0||this.m_pRequestQueue.length>0;
};
SL4B_ManagedConnection.prototype._log = function(B,A){arguments[1]="SL4B_ManagedConnection."+arguments[1];SL4B_Logger.log.apply(SL4B_Logger,arguments);};
SL4B_ManagedConnection.NULL_MESSAGE_RECEIVER = function(){};
SL4B_ManagedConnection.NULL_MESSAGE_RECEIVER = new function(){this.receiveMessage = function(){};
};
SL4B_ManagedConnection.NO_RESPONSE_EXPECTED_MESSAGE_RECEIVER = function(){};
SL4B_ManagedConnection.NO_RESPONSE_EXPECTED_MESSAGE_RECEIVER = new function(){this.receiveMessage = function(){};
};
function SL4B_ObjectNumberMap(A){this.m_oManagedConnection=A;this.m_oMsgRecord=null;}
SL4B_ObjectNumberMap.prototype._setMsgRecord = function(A){this.m_oMsgRecord=A;};
SL4B_ObjectNumberMap.prototype.addObjectNumber = function(A){this.m_oManagedConnection._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.ADDED_OBJECT_NUMBER_EVENT_LISTENER,"SL4B_ObjectNumberMap.addObjectNumber",A);this.m_oManagedConnection.m_mObjectNumberToRequestRecord[A]=this.m_oMsgRecord;};
SL4B_ObjectNumberMap.prototype.removeObjectNumber = function(A){this.m_oManagedConnection._log(SL4B_DebugLevel.const_RTTP_FINEST_INT,SL4B_ManagedConnection.MESSAGES.REMOVED_OBJECT_NUMBER_EVENT_LISTENER,"SL4B_ObjectNumberMap.removeObjectNumber",A);delete this.m_oManagedConnection.m_mObjectNumberToRequestRecord[A];};
document.write("<div id='SL4B_URL_CHECK' style='height: 1px; width: 1px; display: none'></div>");function GF_IFrameLoader(A){this.m_sFrameId=A;this.m_eContainerDiv=null;}
GF_IFrameLoader.prototype.createImage = function(){return document.createElement("IMG");
};
GF_IFrameLoader.prototype.getContainerDiv = function(){if(this.m_eContainerDiv==null){this.m_eContainerDiv=document.getElementById('SL4B_URL_CHECK');}return this.m_eContainerDiv;
};
GF_IFrameLoader.prototype.loadUrl = function(C,A,B){if(typeof (B.liberatorUnavailable)!='function'){throw new SL4B_Exception("Handler parameter must have a liberatorUnavailable function");
}var oCheckDiv=this.getContainerDiv();
var sTestImageUrl=A+"/url-check.gif?"+((new Date()).valueOf());
var sFrameId=this.m_sFrameId;
var eImg=this.createImage();
var bImgRemoved=false;
eImg.onload = function(){if(bImgRemoved==false){oCheckDiv.removeChild(eImg);clearTimeout(nTimeoutId);bImgRemoved=true;SL4B_Logger.logConnectionMessage(true,"LiberatorUrlCheck.onLoad[{0}]: Liberator available, loading {1}",sFrameId,C);var l_oFrameWindow=SL4B_Accessor.getBrowserAdapter().getFrameWindow(sFrameId);
l_oFrameWindow.location.replace(C);}};
eImg.onerror = function(){if(bImgRemoved==false){oCheckDiv.removeChild(eImg);clearTimeout(nTimeoutId);bImgRemoved=true;SL4B_Logger.logConnectionMessage(true,"LiberatorUrlCheck.onerror[{0}]: Liberator not available, when trying to load {1}",sFrameId,C);B.liberatorUnavailable();}};
SL4B_Logger.logConnectionMessage(true,"LiberatorUrlCheck.testLiberatorIsAvailable [{0}]: Checking Liberator availability: {1}",sFrameId,sTestImageUrl);var nTimeoutId=setTimeout(eImg.onerror,10000);
oCheckDiv.appendChild(eImg);eImg.src=sTestImageUrl;};
function C_LiberatorUrlCheck(){this.m_pFrameIdToLiberatorUrlCheckMap={};}
C_LiberatorUrlCheck.prototype.createLiberatorUrlCheck = function(A){this.m_pFrameIdToLiberatorUrlCheckMap[A]=new GF_IFrameLoader(A);};
C_LiberatorUrlCheck.prototype.getLiberatorUrlCheck = function(A){return this.m_pFrameIdToLiberatorUrlCheckMap[A];
};
C_LiberatorUrlCheck=new C_LiberatorUrlCheck();var SL4B_AbstractConnection=function(){};
if(false){function SL4B_AbstractConnection(){}
}SL4B_AbstractConnection = function(){this.CLASS_NAME="SL4B_AbstractConnection";this.m_oRttpProvider=null;this.m_sUrlPrefix="";this.m_oResponseHttpRequest=null;this.m_sResponseUniqueId=null;this.m_sRequestUniqueId=null;this.m_oRequestHttpRequest=null;this.m_oMessageReceiver=null;this.m_sLastSequenceNumber="";this.m_oRttpMessage=null;this.m_bConnectionStopped=false;this.m_oResponseQueueStatistics=this._createResponseQueueStatistics();this.m_pResponseQueueStatisticsListeners=[];this.m_pPendingWork=[];this.m_oConnectionManager=null;};
SL4B_AbstractConnection.prototype._createResponseQueueStatistics = function(){return new SL4B_ResponseQueueStatistics();
};
SL4B_AbstractConnection.prototype._$setConnectionManager = function(A){this.m_oConnectionManager=A;};
SL4B_AbstractConnection.prototype.initialise = function(A,B){this.m_oRttpProvider=A;this.m_sUrlPrefix=B;this.m_oResponseHttpRequest=null;this.m_oRequestHttpRequest=null;this.m_oRttpMessage=new SL4B_RttpMessage();this.m_oMessageReceiver=null;};
SL4B_AbstractConnection.prototype.getResponseQueueStatistics = function(){return this.m_oResponseQueueStatistics;
};
SL4B_AbstractConnection.prototype.toString = function(){return "AbstractConnection(url = "+this.m_sUrlPrefix+")";
};
SL4B_AbstractConnection.prototype.connect = function(){throw new SL4B_Error("connect method not implemented");
};
SL4B_AbstractConnection.prototype.send = SL_IR;SL4B_AbstractConnection.prototype.setRequestHttpRequest = SL_JE;SL4B_AbstractConnection.prototype.setResponseHttpRequest = SL_MA;SL4B_AbstractConnection.prototype.getLastSequenceNumber = function(){return this.m_sLastSequenceNumber;
};
SL4B_AbstractConnection.prototype.start = function(){throw new SL4B_Error("start method not implemented");
};
SL4B_AbstractConnection.prototype.stop = function(){this.m_bConnectionStopped=true;this._clearAllPendingTimeouts();};
SL4B_AbstractConnection.prototype.setMessageReceiver = SL_QC;SL4B_AbstractConnection.prototype.parseRttpMessage = SL_OK;SL4B_AbstractConnection.prototype.createChannel = SL_PP;SL4B_AbstractConnection.prototype.createStandardRequestChannel = SL_KZ;SL4B_AbstractConnection.prototype.createStandardResponseChannel = SL_HY;SL4B_AbstractConnection.prototype.getResponseUniqueId = SL_PW;SL4B_AbstractConnection.prototype.getRequestUniqueId = SL_OM;function SL_PW(){return this.m_sResponseUniqueId;
}
function SL_OM(){return this.m_sRequestUniqueId;
}
function SL_IR(A){if(!this.m_bConnectionStopped){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"AbstractConnection.send({0}?{1})",this.m_sUrlPrefix,A);
try {this.m_oRequestHttpRequest.send(this.m_sUrlPrefix+"?"+A);}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractConnection.send: failed to send \"{0}\" due to exception {1}",A,e);}
}}
function SL_MA(A){this.m_oResponseHttpRequest=A;}
function SL_JE(A){this.m_oRequestHttpRequest=A;}
function SL_QC(A){if(A!==null&&typeof A.receiveMessage!="function"){throw new SL4B_Exception("Specified listener does not define the receiveMessage method");
}this.m_oMessageReceiver=A;}
SL4B_AbstractConnection.prototype._yieldThenProcessRttpMessageBlock = function(A){this.m_oResponseQueueStatistics.addMessageBatch(A.length);this._notifyResponseQueueStatisticsListeners("onBatchQueued");var oThis=this;
var nTimeoutId=setTimeout(function(){if(oThis.m_pPendingWork.length>0){var oWorkPackage=oThis.m_pPendingWork.shift();
oThis._processRttpMessageBlock(oWorkPackage.work);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"*** worker expected messages to process : [{0}]",A.join(","));}},0,"SL4B-message-loop");
this.m_pPendingWork.push({timeoutId:nTimeoutId, work:A, toString:function(){return "{id: "+this.timeoutId+" messages=["+this.work.join(",")+"]}";
}});};
SL4B_AbstractConnection.prototype._processRttpMessageBlockImmediately = function(A){this.m_oResponseQueueStatistics.addMessageBatch(A.length);this._notifyResponseQueueStatisticsListeners("onBatchQueued");this._processRttpMessageBlock(A);};
SL4B_AbstractConnection.prototype.processRttpMessageBlock = function(A){if(SL4B_Accessor.getConfiguration().yieldBeforeMessageProcessing()){this.processRttpMessageBlock=this._yieldThenProcessRttpMessageBlock;}else 
{this.processRttpMessageBlock=this._processRttpMessageBlockImmediately;}this.processRttpMessageBlock(A);};
SL4B_AbstractConnection.prototype._clearAllPendingTimeouts = function(){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"SL4B_AbstractConnection._clearAllPendingTimeouts");while(this.m_pPendingWork.length>0){var workPackage=this.m_pPendingWork.shift();
clearTimeout(workPackage.timeoutId);}this.m_oResponseQueueStatistics.reset();};
SL4B_AbstractConnection.prototype._processRttpMessageBlock = function(A){if(this.m_oResponseQueueStatistics.getQueuedBatchCount()<1){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"SL4B_AbstractConnection._processRttpMessageBlock: queued batch count is out of sync, initiating full reconnect ({0})",this.m_oResponseQueueStatistics);this.m_oRttpProvider.createConnectionLost("Queued batch count is out of sync",true);}else 
{this.m_oResponseQueueStatistics.setMessageBatchStarted();this._notifyResponseQueueStatisticsListeners("onBeforeBatchProcessed");for(var i=0,nLength=A.length;i<nLength;++i){SL4B_MethodInvocationProxy.invoke(this,"parseRttpMessage",[A[i]]);this.m_oResponseQueueStatistics.incrementProcessedMessageCount();}this.m_oResponseQueueStatistics.setMessageBatchEnded();this._notifyResponseQueueStatisticsListeners("onAfterBatchProcessed");this.messageBlockComplete();}};
SL4B_AbstractConnection.prototype.messageBlockComplete = function(){};
SL4B_AbstractConnection.prototype.addResponseQueueStatisticsListener = function(A){this.m_pResponseQueueStatisticsListeners.push(A);};
SL4B_AbstractConnection.prototype._notifyResponseQueueStatisticsListeners = function(A){for(var i=0,nLength=this.m_pResponseQueueStatisticsListeners.length;i<nLength;++i){var oListener=this.m_pResponseQueueStatisticsListeners[i];
SL4B_MethodInvocationProxy.invoke(oListener,A,[this.m_oResponseQueueStatistics]);}};
SL4B_AbstractConnection.prototype.processInvalidServerResponse = function(B,A){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractConnection.processInvalidServerResponse: Bad response code {0} received from Liberator. Response text was {1}",A,B);if(A==404){this.m_oRttpProvider.createConnectionLost("Resource not found response from Liberator: probable Session Timeout.",false);}else 
{this.m_oRttpProvider.createConnectionLost("Invalid response from Liberator, code "+A+", response '"+B+"'.",false);}};
function SL_OK(A){if(!this.m_bConnectionStopped){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"AbstractConnection.parseRttpMessage({0})",A);var l_pMessageLines=A.split("\n");
for(var l_nLine=0,l_nSize=l_pMessageLines.length;l_nLine<l_nSize;++l_nLine){if(l_pMessageLines[l_nLine]!=""){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"< {0}",l_pMessageLines[l_nLine]);if(l_pMessageLines[l_nLine].substr(0,2)=="4r"){
try {SL4B_ConnectionProxy.getInstance().receiveSync(A);}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
}else 
{var l_bMessageSet=false;

try {l_nLine=this.m_oRttpMessage.setMessage(l_pMessageLines,l_nLine);l_bMessageSet=true;}catch(e){SL4B_Accessor.getExceptionHandler().processException(e);}
if(this.m_oRttpMessage.isMessageComplete()&&l_bMessageSet){if(this.m_oMessageReceiver!==null){SL4B_MethodInvocationProxy.invoke(this.m_oMessageReceiver,"receiveMessage",[this.m_oRttpMessage]);}if(this.m_oRttpMessage.m_sSequenceNumber!=null){this.m_sLastSequenceNumber=this.m_oRttpMessage.m_sSequenceNumber;}}}}}}}
function SL_PP(B,A){C_CallbackQueue.addCallback(new Array(SL4B_Accessor.getUnderlyingRttpProvider(),"notifyConnectionListeners",this.m_oRttpProvider.const_INFO_CONNECTION_EVENT,"Establishing "+B.replace(/^frm/,"").toLowerCase()+" channel (URL: "+A+")"));var l_sUniqueId=(new Date()).valueOf();
var l_sCommonDomain=SL4B_Accessor.getConfiguration().getCommonDomain();
if(l_sCommonDomain!=null){A+="&"+SL4B_JavaScriptRttpProviderConstants.const_DOMAIN_PARAMETER+"="+l_sCommonDomain;}A+="&"+SL4B_JavaScriptRttpProviderConstants.const_UNIQUEID_PARAMETER+"="+l_sUniqueId;A+="&"+SL4B_JavaScriptRttpProviderConstants.const_MAX_GET_LENGTH_PARAMETER+"="+SL4B_Accessor.getConfiguration().getMaxGetLength();C_LiberatorUrlCheck.getLiberatorUrlCheck(B).loadUrl(A,this.m_oRttpProvider.getJsContainerUrl(),this);return l_sUniqueId;
}
SL4B_AbstractConnection.prototype.liberatorUnavailable = function(){if(this.m_bConnectionStopped==false){this.m_bConnectionStopped=true;this.m_oConnectionManager.liberatorUnavailable();}};
function SL_KZ(){var l_sUrlPrefix=this.m_oRttpProvider.getJsContainerUrl()+"/";
var l_sRequestFrameUrl=l_sUrlPrefix+SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_URL;
l_sRequestFrameUrl+="&"+SL4B_JavaScriptRttpProviderConstants.const_INIT_PARAMETER+"=true";this.m_sRequestUniqueId=this.createChannel(SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_ID,l_sRequestFrameUrl);}
function SL_HY(){var l_sUrlPrefix=this.m_oRttpProvider.getJsContainerUrl()+"/";
var l_sResponseFrameUrl=l_sUrlPrefix+SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_URL;
l_sResponseFrameUrl+="&"+SL4B_JavaScriptRttpProviderConstants.const_INIT_PARAMETER+"=true";this.m_sResponseUniqueId=this.createChannel(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID,l_sResponseFrameUrl);}
var SL4B_CacheEntry=function(){};
if(false){function SL4B_CacheEntry(){}
}SL4B_CacheEntry = function(A){this.m_sObjectKey=A;this.m_pFieldList=new Object();this.m_bAllFields=false;this.m_oObjectStatus=GF_CachedObjectStatus.const_SUBSCRIBING;this.m_nReferenceCount=0;};
SL4B_CacheEntry.prototype.addFields = SL4B_CacheEntry_AddFields;function SL4B_CacheEntry_AddFields(A){var l_sFieldsToRequest=null;
if(!this.m_bAllFields){if(A==""||A==null||typeof A=="undefined"){this.m_bAllFields=true;l_sFieldsToRequest="";}else 
{var l_pFields=A.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){if(typeof this.m_pFieldList[l_pFields[l_nField]]=="undefined"){this.m_pFieldList[l_pFields[l_nField]]=true;if(l_sFieldsToRequest==null){l_sFieldsToRequest=l_pFields[l_nField];}else 
{l_sFieldsToRequest+=SL4B_ObjectCache.const_FIELD_NAME_DELIMITER+l_pFields[l_nField];}}}}}return l_sFieldsToRequest;
}
SL4B_CacheEntry.prototype.setObjectStatus = function(B,A,C){this.m_oObjectStatus=new GF_CachedObjectStatus(B,A,C);};
SL4B_CacheEntry.prototype.getObjectStatus = function(){return this.m_oObjectStatus;
};
SL4B_CacheEntry.prototype.sendCurrentObjectStatus = function(C,A,B){C.objectStatusForListener(A,this.m_oObjectStatus.m_nType,this.m_oObjectStatus.m_nCode,this.m_oObjectStatus.m_sMessage,B);};
SL4B_CacheEntry.prototype.resetFields = function(){this.m_pFieldList=new Object();this.m_bAllFields=false;};
SL4B_CacheEntry.prototype.incrementReferenceCount = function(){this.m_nReferenceCount++;};
SL4B_CacheEntry.prototype.decrementReferenceCount = function(){this.m_nReferenceCount--;};
SL4B_CacheEntry.prototype.hasReferences = function(){return (this.m_nReferenceCount>0);
};
var GF_ClockSyncStrategy=function(){this.m_nClockOffset=null;};
if(false){function GF_ClockSyncStrategy(){}
}GF_ClockSyncStrategy.prototype.startClockSync = function(){};
GF_ClockSyncStrategy.prototype.stopClockSync = function(){};
GF_ClockSyncStrategy.prototype.getNextSyncMessage = function(A){};
GF_ClockSyncStrategy.prototype.receiveSync = function(A){};
GF_ClockSyncStrategy.prototype.getServerTime = function(A){if(this.m_nClockOffset==null){return null;
}return parseInt(A,10)+this.m_nClockOffset;
};
GF_ClockSyncStrategy.prototype.getClientTime = function(A){if(this.m_nClockOffset==null){return null;
}return A-this.m_nClockOffset;
};
GF_ClockSyncStrategy.prototype._$setClockOffset = function(A){this.m_nClockOffset=A;SL4B_Accessor.getStatistics().setClockOffset(this.m_nClockOffset);};
GF_ClockSyncStrategy.prototype._$getClockOffset = function(){return this.m_nClockOffset;
};
var GF_SlidingClockSyncStrategy=function(A){if(A==null){throw new SL4B_Exception("GF_SlidingClockSyncStrategy: oManagedConnection cannot be null.");
}this.m_oManagedConnection=A;this.m_pSyncTimesWindow=[];this.m_nIndex=0;this.m_bWindowFilled=false;var oConfiguration=SL4B_Accessor.getConfiguration();
this.m_nSlidingWindowSize=oConfiguration.getSlidingSyncSize();this.m_nSyncSpacingTime=oConfiguration.getSlidingSyncSpacing();this.m_nFastSyncSpacingTime=oConfiguration.getSlidingSyncInitialSpacing();this.m_nSyncTimeoutId=null;this.m_nT1=null;this.m_oBestTime=null;};
if(false){function GF_SlidingClockSyncStrategy(){}
}GF_SlidingClockSyncStrategy.prototype = new GF_ClockSyncStrategy();GF_SlidingClockSyncStrategy.prototype.startClockSync = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ClockOffset = {0}",this._$getClockOffset());this._sendSyncPlaceHolder();};
GF_SlidingClockSyncStrategy.prototype.stopClockSync = function(){if(this.m_nSyncTimeoutId!=null){clearTimeout(this.m_nSyncTimeoutId);this.m_nSyncTimeoutId=null;}};
GF_SlidingClockSyncStrategy.prototype._sendSyncPlaceHolder = function(){this.m_oManagedConnection.sendMessage("SYNC",SL4B_ManagedConnection.NO_RESPONSE_EXPECTED_MESSAGE_RECEIVER);};
GF_SlidingClockSyncStrategy.prototype._getTime = function(){return new Date().getTime();
};
GF_SlidingClockSyncStrategy.prototype.getNextSyncMessage = function(A){var nLatencyToSend=Math.ceil(A);
if(isNaN(nLatencyToSend)){nLatencyToSend=-1;}var nClockOffset=Math.ceil(this._$getClockOffset());
if(nClockOffset===null){nClockOffset=0;}this.m_nT1=this._getTime();var sMessage="SYNC "+this.m_nT1+" "+nClockOffset+" "+nLatencyToSend;
return sMessage;
};
GF_SlidingClockSyncStrategy.prototype.receiveSync = function(A){var oCurrentRoundTrip=this._extractRoundTripFromMessage(A);
var nSpacing=this.m_nSyncSpacingTime;
if(this.m_bWindowFilled==false){nSpacing=this.m_nFastSyncSpacingTime;}var self=this;
var nTimeout=Math.max(nSpacing-oCurrentRoundTrip.roundTrip,0);
var nSyncTimeoutId=setTimeout(function(){self._sendSyncPlaceHolder();},nTimeout);
this.m_nSyncTimeoutId=nSyncTimeoutId;if(oCurrentRoundTrip!==null){if(oCurrentRoundTrip.roundTrip>=0){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"GF_SlidingClockSyncStrategy.receiveSync(): Sync received: Round trip time {0}",oCurrentRoundTrip.roundTrip);this._processSyncRoundTrip(oCurrentRoundTrip);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"GF_SlidingClockSyncStrategy.receiveSync(): Invalid sync message {0}",A);}};
GF_SlidingClockSyncStrategy.prototype._extractRoundTripFromMessage = function(A){var pTokens=A.split(" ");
if(pTokens.length==4){var nT4=SL4B_Accessor.getStatistics().getResponseQueueStatistics().getTimeOldestBatchWasQueued().getTime();
var nRoundTrip=nT4-this.m_nT1;
var nT3=parseInt(pTokens[2],10);
var nT2MinusT1=parseInt(pTokens[3],10);
var nClockOffset=(nT2MinusT1-(nT4-nT3))/2;
if(nRoundTrip<0){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"GF_SlidingClockSyncStrategy._extractRoundTripFromMessage(): incorrect round trip time {0} t1={1} t4={2}",nRoundTrip,this.m_nT1,nT4);}return {roundTrip:nRoundTrip, offset:nClockOffset};
}return null;
};
GF_SlidingClockSyncStrategy.prototype._isThisTheBestRoundTrip = function(A){return this.m_oBestTime==null||A.roundTrip<=this.m_oBestTime.roundTrip;
};
GF_SlidingClockSyncStrategy.prototype._areWeRemovingTheBestStoredRoundTrip = function(){return this.m_bWindowFilled&&this.m_pSyncTimesWindow[this.m_nIndex].roundTrip==this.m_oBestTime.roundTrip;
};
GF_SlidingClockSyncStrategy.prototype._findBestRemainingRoundTrip = function(A){var oBestRoundTrip=A;
for(var i=0;i<(this.m_nSlidingWindowSize-1);++i){var j=(this.m_nIndex+i+1)%this.m_nSlidingWindowSize;
if(this.m_pSyncTimesWindow[j].roundTrip<oBestRoundTrip.roundTrip){oBestRoundTrip=this.m_pSyncTimesWindow[j];}}return oBestRoundTrip;
};
GF_SlidingClockSyncStrategy.prototype._processSyncRoundTrip = function(A){if(this._isThisTheBestRoundTrip(A)){this.m_oBestTime=A;if(this.m_bWindowFilled==true){this._$setClockOffset(this.m_oBestTime.offset);}}else 
{if(this._areWeRemovingTheBestStoredRoundTrip()){this.m_oBestTime=this._findBestRemainingRoundTrip(A);this._$setClockOffset(this.m_oBestTime.offset);}}this.m_pSyncTimesWindow[this.m_nIndex]=A;this.m_nIndex=(this.m_nIndex+1)%this.m_nSlidingWindowSize;if(this.m_bWindowFilled===false&&this.m_nIndex==0){this.m_bWindowFilled=true;this._$setClockOffset(this.m_oBestTime.offset);}};
var GF_BatchingClockSyncStrategy=function(A){if(A==null){throw new SL4B_Exception("GF_BatchingClockSyncStrategy: oManagedConnection cannot be null.");
}this.m_oManagedConnection=A;this.m_nSyncTimeoutId=-1;this.m_nT1=0;this.m_nBestRoundTrip=9999999;this.m_nBestClockOffset=null;this.m_nBatchCount=0;};
if(false){function GF_BatchingClockSyncStrategy(){}
}GF_BatchingClockSyncStrategy.prototype = new GF_ClockSyncStrategy();GF_BatchingClockSyncStrategy.prototype.startClockSync = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"GF_BatchingClockSyncStrategy.startClockSync()");this.m_nBatchCount=0;this.m_nBestRoundTrip=9999999;SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ClockOffset = {0}",this._$getClockOffset());this._sendSyncPlaceHolder();};
GF_BatchingClockSyncStrategy.prototype.stopClockSync = function(){if(this.m_nSyncTimeoutId!=-1){clearTimeout(this.m_nSyncTimeoutId);this.m_nSyncTimeoutId=-1;}};
GF_BatchingClockSyncStrategy.prototype._sendSyncPlaceHolder = function(){this.m_oManagedConnection.sendMessage("SYNC",SL4B_ManagedConnection.NO_RESPONSE_EXPECTED_MESSAGE_RECEIVER);};
GF_BatchingClockSyncStrategy.prototype._getTime = function(){return new Date().getTime();
};
GF_BatchingClockSyncStrategy.prototype.getNextSyncMessage = function(A){var nLatencyToSend=Math.ceil(A);
if(isNaN(nLatencyToSend)){nLatencyToSend=-1;}this.m_nBatchCount++;var self=this;
if(this.m_nBatchCount<SL4B_Accessor.getConfiguration().getClocksyncBatchSize()){this.m_nSyncTimeoutId=setTimeout(function(){return self._sendSyncPlaceHolder();
},SL4B_Accessor.getConfiguration().getClocksyncSpacing());}else 
{this.m_nSyncTimeoutId=setTimeout(function(){return self.startClockSync();
},SL4B_Accessor.getConfiguration().getClocksyncPeriod());}var l_nClockOffset=Math.ceil(this._$getClockOffset());
if(l_nClockOffset===null){l_nClockOffset=0;}this.m_nT1=this._getTime();var l_sMessage="SYNC "+this.m_nT1+" "+l_nClockOffset+" "+nLatencyToSend;
return l_sMessage;
};
GF_BatchingClockSyncStrategy.prototype.receiveSync = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"GF_BatchingClockSyncStrategy.receiveSync({0})",A);var l_nT4=SL4B_Accessor.getStatistics().getResponseQueueStatistics().getTimeOldestBatchWasQueued().getTime();
var l_nRoundtrip=l_nT4-this.m_nT1;
if(l_nRoundtrip<this.m_nBestRoundTrip){this.m_nBestRoundTrip=l_nRoundtrip;var l_pTokens=A.split(" ");
if(l_pTokens.length==4){var l_nT3=parseInt(l_pTokens[2],10);
var l_nT2MinusT1=parseInt(l_pTokens[3],10);
this.m_nBestClockOffset=(l_nT2MinusT1-(l_nT4-l_nT3))/2;}}if(this.m_nBatchCount==SL4B_Accessor.getConfiguration().getClocksyncBatchSize()){this._$setClockOffset(this.m_nBestClockOffset);}};
var GF_SlidingStatisticsWindow=function(A){GF_SlidingWindow.call(this,A);};
if(false){function GF_SlidingStatisticsWindow(){}
}GF_SlidingStatisticsWindow.prototype = SL_AZ(GF_SlidingWindow);GF_SlidingStatisticsWindow.prototype.clear = function(){GF_SlidingWindow.prototype.clear.call(this);this.m_nMin=NaN;this.m_nMax=NaN;this.m_nTotal=0;this.m_nSquaredTotal=0;};
GF_SlidingStatisticsWindow.prototype.changeWindow = function(B,A){GF_SlidingWindow.prototype.changeWindow.call(this,B,A);if(A==undefined){A=NaN;}this._updateMinMax(B,A);this._updateTotal(B,A);};
GF_SlidingStatisticsWindow.prototype._updateMinMaxBySearching = function(B){var min=B;
var max=B;
this.iterate(function(A){min=Math.min(min,A);max=Math.max(max,A);});this.m_nMin=min;this.m_nMax=max;};
GF_SlidingStatisticsWindow.prototype._updateMinMax = function(B,A){var minmaxsearch=false;
if((this.m_nMin<B)==false){this.m_nMin=B;}else 
if(this.m_nMin==A){minmaxsearch=true;}if((this.m_nMax>B)==false){this.m_nMax=B;}else 
if(this.m_nMax==A){minmaxsearch=true;}if(minmaxsearch==true){this._updateMinMaxBySearching(B);}};
GF_SlidingStatisticsWindow.prototype._updateTotal = function(B,A){var outgoingValueAsNumber=isNaN(A) ? 0 : A;
this.m_nTotal=this.m_nTotal-outgoingValueAsNumber+B;this.m_nSquaredTotal=this.m_nSquaredTotal-outgoingValueAsNumber*outgoingValueAsNumber+B*B;};
GF_SlidingStatisticsWindow.prototype.toString = function(){var result=["{ values=["];
result.push(this.m_pBuffer.join(","));result.push("] n=");result.push(this.getLength());result.push(" total=");result.push(this.getTotal());result.push(" mean=");result.push(this.getMean());result.push(" min=");result.push(this.m_nMin);result.push(" max=");result.push(this.m_nMax);result.push(" var=");result.push(this.getVariance());result.push(" std=");result.push(this.getStandardDeviation());result.push(" std%=");result.push(this.getStandardDeviationPercentage());result.push(" }");return result.join("");
};
GF_SlidingStatisticsWindow.prototype.getLength = function(){return this.m_bFilled ? this.m_nMaxsize : this.m_nNext;
};
GF_SlidingStatisticsWindow.prototype.getTotal = function(){return this.m_nTotal;
};
GF_SlidingStatisticsWindow.prototype.getMean = function(){return this.getTotal()/this.getLength();
};
GF_SlidingStatisticsWindow.prototype.getMin = function(){return this.m_nMin;
};
GF_SlidingStatisticsWindow.prototype.getMax = function(){return this.m_nMax;
};
GF_SlidingStatisticsWindow.prototype.getVariance = function(){var mean=this.getMean();
var n=this.getLength();
return mean*mean-(2*mean*this.m_nTotal-this.m_nSquaredTotal)/n;
};
GF_SlidingStatisticsWindow.prototype.getStandardDeviation = function(){return Math.sqrt(this.getVariance());
};
GF_SlidingStatisticsWindow.prototype.getStandardDeviationPercentage = function(){return Math.sqrt(this.getVariance())*100/this.getMean();
};
var GF_LatencyCalculator=function(A){this.m_oClockSyncStrategy=A;var nWindowSize=10;
var oConfiguration=SL4B_Accessor.getConfiguration();
if(oConfiguration.getClockSyncStrategy()=="GF_SlidingStatisticsWindow"){nWindowSize=oConfiguration.getSlidingSyncSize();}else 
{nWindowSize=Math.floor(oConfiguration.getClocksyncPeriod()/1000);}this.m_oStatistics=new GF_SlidingStatisticsWindow(nWindowSize);this.m_nLatency=-1;};
if(false){function GF_LatencyCalculator(){}
}GF_LatencyCalculator.prototype.getAverageLatency = function(){return this.m_oStatistics.getMean();
};
GF_LatencyCalculator.prototype.getLatency = function(){return this.m_nLatency;
};
GF_LatencyCalculator.prototype.recordLatency = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionProxy.recordLatency({0})",A);var nComparableServerTimeStamp=this.m_oClockSyncStrategy.getClientTime(A);
if(nComparableServerTimeStamp!=null){var nBatchTime=SL4B_Accessor.getStatistics().getResponseQueueStatistics().getTimeOldestBatchWasQueued().getTime();
this.m_nLatency=Math.max(0,(nBatchTime-nComparableServerTimeStamp));this.m_oStatistics.add(this.m_nLatency);SL4B_Accessor.getStatistics().setLatency(this.m_nLatency);SL4B_Accessor.getStatistics().setAverageLatency(this.m_oStatistics.getMean());SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Latency: {0}",this.m_nLatency);}};
var SL4B_ConnectionProxy=function(){};
if(false){function SL4B_ConnectionProxy(){}
}SL4B_ConnectionProxy = function(){this.CLASS_NAME="SL4B_ConnectionProxy";this.m_sConnectionState=SL4B_ConnectionProxy.const_CONNECTION_STATE_INITIALISING;this.m_oConnection=null;this.m_oMessageReceiver=null;this.m_pResponseQueueStatisticsListeners=[];this.m_oClockSyncStrategy=null;this.m_oLatencyCalculator=null;this.m_bOldMethodCallWarningLogged=false;};
SL4B_ConnectionProxy.prototype = new SL4B_AbstractConnection;SL4B_ConnectionProxy.prototype.sendSync = function(A){this.m_oClockSyncStrategy.startClockSync();};
SL4B_ConnectionProxy.prototype.getNextSyncMessage = function(){return this.m_oClockSyncStrategy.getNextSyncMessage(this.m_oLatencyCalculator.getAverageLatency());
};
SL4B_ConnectionProxy.prototype.stopClockSync = function(){this.m_oClockSyncStrategy.stopClockSync();};
SL4B_ConnectionProxy.prototype.receiveSync = function(A){this.m_oClockSyncStrategy.receiveSync(A);};
SL4B_ConnectionProxy.prototype.recordLatency = function(A){this.m_oLatencyCalculator.recordLatency(A);};
SL4B_ConnectionProxy.const_CONNECTION_STATE_INITIALISING="initialising";SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTING="connecting";SL4B_ConnectionProxy.const_CONNECTION_STATE_RECONNECTING="reconnecting";SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTED="connected";SL4B_ConnectionProxy.const_CONNECTION_STATE_DISCONNECTED="disconnected";SL4B_ConnectionProxy.m_oInstance=new SL4B_ConnectionProxy();SL4B_ConnectionProxy.getInstance = function(){return SL4B_ConnectionProxy.m_oInstance;
};
SL4B_ConnectionProxy.prototype.initialise = function(){};
SL4B_ConnectionProxy.prototype.verifyConnection = function(){if(this.m_oConnection==null){throw new SL4B_Exception("A connection has not been set");
}};
SL4B_ConnectionProxy.prototype.getConnection = function(){return this.m_oConnection;
};
SL4B_ConnectionProxy.prototype.isDisconnected = function(){return (this.m_sConnectionState==SL4B_ConnectionProxy.const_CONNECTION_STATE_INITIALISING||this.m_sConnectionState==SL4B_ConnectionProxy.const_CONNECTION_STATE_DISCONNECTED);
};
SL4B_ConnectionProxy.prototype.connect = SL_BG;SL4B_ConnectionProxy.prototype.send = SL_EO;SL4B_ConnectionProxy.prototype.setRequestHttpRequest = SL_OO;SL4B_ConnectionProxy.prototype.setResponseHttpRequest = SL_LH;SL4B_ConnectionProxy.prototype.start = SL_OR;SL4B_ConnectionProxy.prototype.stop = SL_CK;SL4B_ConnectionProxy.prototype.setMessageReceiver = SL_DJ;SL4B_ConnectionProxy.prototype.setConnection = SL_MH;SL4B_ConnectionProxy.prototype.parseRttpMessage = SL_DC;SL4B_ConnectionProxy.prototype.getResponseUniqueId = SL_HP;SL4B_ConnectionProxy.prototype.getRequestUniqueId = SL_KC;function SL_HP(){this.verifyConnection();return this.m_oConnection.getResponseUniqueId();
}
function SL_KC(){this.verifyConnection();return this.m_oConnection.getRequestUniqueId();
}
SL4B_ConnectionProxy.prototype.getConnectionState = function(){return this.m_sConnectionState;
};
SL4B_ConnectionProxy.prototype.setConnectionState = function(A){this.m_sConnectionState=A;};
function SL_BG(){SL4B_Logger.logConnectionMessage(false,"ConnectionProxy.connect()");this.verifyConnection();this.m_oConnection.connect();}
function SL_EO(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionProxy.send({0})",A);this.verifyConnection();this.m_oConnection.send(A);}
function SL_OO(B,A){
try {SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ConnectionProxy.setRequestHttpRequest({0}) - {1}",A,this.getRequestUniqueId());if(A==this.getRequestUniqueId()){this.verifyConnection();this.m_oConnection.setRequestHttpRequest(B);this.m_oConnection.m_oRttpProvider.requestHttpRequestReady();}}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ConnectionProxy.setRequestHttpRequest: exception caught: {0}",e);}
}
function SL_LH(B,A){
try {SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ConnectionProxy.setResponseHttpRequest({0}) - {1}",A,this.getResponseUniqueId());if(A==this.getResponseUniqueId()){this.verifyConnection();this.m_oConnection.setResponseHttpRequest(B);this.m_oConnection.m_oRttpProvider.responseHttpRequestReady();}}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ConnectionProxy.setResponseHttpRequest: exception caught: {0}",e);}
}
function SL_OR(){SL4B_Logger.logConnectionMessage(false,"ConnectionProxy.start()");this.verifyConnection();this.m_oConnection.start();}
function SL_CK(){this.verifyConnection();this.setConnectionState(SL4B_ConnectionProxy.const_CONNECTION_STATE_DISCONNECTED);this.m_oConnection.stop();this.stopClockSync();}
function SL_DJ(A){if(A!==null&&typeof A.receiveMessage!="function"){throw new SL4B_Exception("Specified listener does not define the receiveMessage method");
}this.m_oMessageReceiver=A;if(this.m_oConnection!=null){this.m_oConnection.setMessageReceiver(A);}}
function SL_MH(A)
{
	if(this.m_oConnection!=null)
	{
		this.m_oConnection.stop();
		this.stopClockSync();
	}
	SL4B_Logger.logConnectionMessage(false,"ConnectionProxy.setConnection: {0}",A);
	this.m_oConnection=A;
	this.m_oConnection.setMessageReceiver(this.m_oMessageReceiver);
	this._addExistingResponseQueueStatisticsListenerToNewConnection(A);
	var sClockSyncStrategyClass=SL4B_Accessor.getConfiguration().getClockSyncStrategy();
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ConnectionProxy.setConnection: Creating clock sync strategy {0}",sClockSyncStrategyClass);var ClockSyncStrategyClass=null;
var oException=null;

try {ClockSyncStrategyClass=eval(sClockSyncStrategyClass);}catch(e){oException=e;}
if(ClockSyncStrategyClass==null||typeof (ClockSyncStrategyClass)!="function"){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ConnectionProxy.setConnection: Problem creating clock sync strategy {0} : {1}",sClockSyncStrategyClass,oException);SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ConnectionProxy.setConnection: Using default clock sync strategy GF_BatchingClockSyncStrategy");ClockSyncStrategyClass=GF_BatchingClockSyncStrategy;}this.m_oClockSyncStrategy=new ClockSyncStrategyClass(A.m_oRttpProvider.getManagedConnection());this.m_oLatencyCalculator=new GF_LatencyCalculator(this.m_oClockSyncStrategy);}
function SL_DC(A){if(!this.m_bOldMethodCallWarningLogged){this.m_bOldMethodCallWarningLogged=true;SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ConnectionProxy.parseRttpMessage: old API method was invoked, SL4B version on the Liberator is out of date");}if(A!=''){this.processRttpMessageBlock(A.split("\n"));}}
SL4B_ConnectionProxy.prototype.getResponseQueueStatistics = function(){this.verifyConnection();return this.m_oConnection.getResponseQueueStatistics();
};
SL4B_ConnectionProxy.prototype.addResponseQueueStatisticsListener = function(A){this.m_pResponseQueueStatisticsListeners.push(A);if(this.m_oConnection!==null){this.m_oConnection.addResponseQueueStatisticsListener(A);}};
SL4B_ConnectionProxy.prototype._addExistingResponseQueueStatisticsListenerToNewConnection = function(A){for(var i=0,nLength=this.m_pResponseQueueStatisticsListeners.length;i<nLength;++i){var oListener=this.m_pResponseQueueStatisticsListeners[i];
A.addResponseQueueStatisticsListener(oListener);}};
SL4B_ConnectionProxy.prototype.processInvalidServerResponse = function(B,A){if(this.m_sConnectionState!=SL4B_ConnectionProxy.const_CONNECTION_STATE_DISCONNECTED){if(this.m_oConnection!=null){this.m_oConnection.processInvalidServerResponse(B,A);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ConnectionProxy.processInvalidServerResponse: Invalid server response \"{0}\" received, but underlying connection is null",B);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ConnectionProxy.processInvalidServerResponse: Unexpected server response \"{0}\" received while disconnected.",B);}};
SL4B_ConnectionProxy.prototype.processRttpMessageBlock = function(A){if(A.length==1&&A[0]==""){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ConnectionProxy.processRttpMessageBlock: Empty mesasge block received.");}else 
{if(this.m_oConnection!=null){this.m_oConnection.processRttpMessageBlock(A);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ConnectionProxy.processRttpMessageBlock: RTTP message block size \"{0}\" received, but underlying connection is null",A.length);}}};
var SL4B_ObjectCache=function(){};
if(false){function SL4B_ObjectCache(){}
}SL4B_ObjectCache = function(B,A){this.CLASS_NAME="SL4B_ObjectCache";this.m_oRttpProvider=B;this.m_oSubscriptionManager=A;A.setObjectCache(this);this.m_pObjects=new Object();this.m_pObjectDataCache=new Object();this.m_pObjectDataCacheType2=new Object();this.m_pObjectDataCacheType3=new Object();this.m_pObjectNumberToObjectKeyMap=new Object();this.m_pDirectoryCache=new Object();this.m_pStoryCache=new Object();this.m_mChatCache=new Object();this.m_bIsFireFox1_0=SL4B_Accessor.getBrowserAdapter().isFirefox()&&SL4B_Accessor.getBrowserAdapter().getBrowserVersion().indexOf("1.0")==0;this.m_nMaxRequestDiscardLength=800;this.m_pContainerCache=new Object();this.m_pNewsHeadlineCache=new Object();this.m_pPermissionCache=new Object();};
SL4B_ObjectCache.const_FIELD_NAME_DELIMITER=",";SL4B_ObjectCache.const_OBJECT_NAME_AND_FIELD_LIST_DELIMITER=";";SL4B_ObjectCache.const_BLANK_STRING="";SL4B_ObjectCache.SUBJECT_DELETED="deleted";SL4B_ObjectCache.SUBJECT_ADDED="added";SL4B_ObjectCache.prototype.receiveMessage = SL_PZ;SL4B_ObjectCache.prototype.processRttpMessage = SL4B_ObjectCache.prototype.receiveMessage;SL4B_ObjectCache.prototype.requestObject = SL_EC;SL4B_ObjectCache.prototype.sendCachedFields = SL_DS;SL4B_ObjectCache.prototype.requestObjects = SL_EI;SL4B_ObjectCache.prototype.discardObject = SL_HJ;SL4B_ObjectCache.prototype.discardObjects = SL_NZ;SL4B_ObjectCache.prototype.cacheObject = SL_IZ;SL4B_ObjectCache.prototype.cacheType1Record = SL_DM;SL4B_ObjectCache.prototype.cacheType2Record = SL_OJ;SL4B_ObjectCache.prototype.cacheType3Record = SL_PC;SL4B_ObjectCache.prototype.deleteType2RecordLevel = SL_RH;SL4B_ObjectCache.prototype.type2Clear = SL_EV;SL4B_ObjectCache.prototype.type3Clear = SL_PI;SL4B_ObjectCache.prototype.notFound = SL_DZ;SL4B_ObjectCache.prototype.cacheDirectory = SL_AP;SL4B_ObjectCache.prototype.statusUpdated = SL_PX;SL4B_ObjectCache.prototype.sendObjectAction = SL_PL;SL4B_ObjectCache.prototype.createObjectArray = SL_ED;SL4B_ObjectCache.prototype.cacheContainer = SL_RG;SL4B_ObjectCache.prototype.cacheNewsHeadline = SL_DN;SL4B_ObjectCache.prototype.cacheNewsStory = SL_QG;SL4B_ObjectCache.prototype.cachePermission = SL_OF;SL4B_ObjectCache.prototype.clearPermission = SL_LN;SL4B_ObjectCache.prototype.deletePermissionEntry = SL_CC;SL4B_ObjectCache.prototype.parseOrderChanges = SL_IY;SL4B_ObjectCache.prototype.isActive = SL_DR;SL4B_ObjectCache.prototype.clear = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.clear()");this.m_pObjects=new Object();this.m_pObjectDataCache=new Object();this.m_pObjectDataCacheType2=new Object();this.m_pObjectDataCacheType3=new Object();this.m_pObjectNumberToObjectKeyMap=new Object();this.m_pDirectoryCache=new Object();this.m_pStoryCache=new Object();this.m_pNewsHeadlineCache=new Object();this.m_pContainerCache=new Object();this.m_pPermissionCache=new Object();this.m_mChatCache=new Object();};
function SL_PZ(C,A,B){var l_nRttpCode=C.getRttpCode();
switch(l_nRttpCode){
case SL4B_RttpCodes.const_RECORD_RESP:case SL4B_RttpCodes.const_RESP_UNKNOWN:case SL4B_RttpCodes.const_REC1_UPD:case SL4B_RttpCodes.const_REC1_IMG:case SL4B_RttpCodes.const_REC2_UPD:case SL4B_RttpCodes.const_REC2_IMG:case SL4B_RttpCodes.const_REC2_CLR:case SL4B_RttpCodes.const_REC2_DEL:case SL4B_RttpCodes.const_REC3_UPD:case SL4B_RttpCodes.const_REC3_IMG:case SL4B_RttpCodes.const_REC3_CLR:case SL4B_RttpCodes.const_REC3_DEL:case SL4B_RttpCodes.const_DIRECTORY_RESP:case SL4B_RttpCodes.const_DIR_UPD:case SL4B_RttpCodes.const_CONT_RESP:case SL4B_RttpCodes.const_AUTODIR_RESP:case SL4B_RttpCodes.const_CONT_UPD:case SL4B_RttpCodes.const_AUTODIR_UPD:case SL4B_RttpCodes.const_CONT_IMG:case SL4B_RttpCodes.const_AUTODIR_IMG:case SL4B_RttpCodes.const_NEWS_RESP:case SL4B_RttpCodes.const_NEWS_IMG:case SL4B_RttpCodes.const_NEWS_UPD:case SL4B_RttpCodes.const_STORY_RESP:case SL4B_RttpCodes.const_STORY_UPD:case SL4B_RttpCodes.const_STORY_IMG:case SL4B_RttpCodes.const_PERM_RESP:case SL4B_RttpCodes.const_PERM_IMG:case SL4B_RttpCodes.const_PERM_UPD:case SL4B_RttpCodes.const_PERM_CLR:case SL4B_RttpCodes.const_PERM_DEL:case SL4B_RttpCodes.const_CHAT_RESP:case SL4B_RttpCodes.const_CHAT_UPD:{this.cacheObject(C,A,B);break;
}case SL4B_RttpCodes.const_STATUS_OK:case SL4B_RttpCodes.const_STATUS_STALE:case SL4B_RttpCodes.const_STATUS_LIMITED:case SL4B_RttpCodes.const_STATUS_REMOVED:case SL4B_RttpCodes.const_STATUS_INFO:{this.statusUpdated(C);break;
}case SL4B_RttpCodes.const_NEWS_CLR:{var sObjKey=this.m_pObjectNumberToObjectKeyMap[C.getObjectNumber()];
delete this.m_pNewsHeadlineCache[sObjKey];break;
}case SL4B_RttpCodes.const_DISCARD_OK:{this._discarded(C,A,B);break;
}default :this.notFound(C,A);}}
SL4B_ObjectCache.prototype._discarded = function(B,A,C){this.m_oSubscriptionManager._discarded();};
SL4B_ObjectCache.prototype.sendSubscriptionMessage = function(A,B){this.m_oRttpProvider.getManagedConnection().sendMessage(A,this,B);};
SL4B_ObjectCache.prototype._createObjectKey = function(A,B){return A+B;
};
SL4B_ObjectCache.prototype._extractObjectKeyFromSentMessage = function(A){if(A===null||A.getContext()==null){throw new SL4B_Exception("SL4B_ObjectCache._extractObjectKeyFromSentMessage: context could not be extracted from the specified request ("+oRequest+")");
}var sEncodedObjectName=A.getMessage().match(/^[A-Z]+ ([^;]+)/)[1];
return GF_ResponseDecoder.decodeRttpData(sEncodedObjectName)+A.getContext().filter;
};
function SL_EC(C,B,A,D){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.requestObject({0}, {1}, {2})",C,B,A);var l_sObjectKey=this._createObjectKey(C,B);
this._addCacheEntryIfNotPresent(l_sObjectKey);var l_sFieldsToRequest=this.m_pObjects[l_sObjectKey].addFields(A);
if(l_sFieldsToRequest!=null){var l_sFieldMessage=SL4B_ObjectCache.createFilterAndFieldList(B,A);
this.sendObjectAction("REQUEST",this.createObjectArray(GF_RequestEncoder.encodeRttpData(C),l_sFieldMessage),[C],B);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"\tnothing to request, send cached update");this.sendCachedFields(C,B,A,D);}}
SL4B_ObjectCache.prototype._addCacheEntryIfNotPresent = function(A){var oCacheEntry=this.m_pObjects[A];
if(oCacheEntry===undefined){oCacheEntry=new SL4B_CacheEntry(A);this.m_pObjects[A]=oCacheEntry;}oCacheEntry.incrementReferenceCount();};
SL4B_ObjectCache.prototype._removeCacheEntryIfNoMoreReferences = function(A,B){var oCacheEntry=this.m_pObjects[A];
if(oCacheEntry!==undefined){oCacheEntry.decrementReferenceCount();if(!oCacheEntry.hasReferences()){delete this.m_pObjects[A];}else 
if(B){oCacheEntry.resetFields();}}};
SL4B_ObjectCache.prototype.removeObjectFromCacheIfNoMoreReferences = function(A,B){var sObjectKey=this._createObjectKey(A,B);
this._removeCacheEntryIfNoMoreReferences(sObjectKey,false);};
SL4B_ObjectCache.prototype._getCacheEntryForObjectKey = function(A){return this.m_pObjects[A];
};
SL4B_ObjectCache.buildRTTPRequestMessage = function(C,B,A){var l_sObjectRequestMessage="REQUEST "+GF_RequestEncoder.encodeRttpData(C);
l_sObjectRequestMessage+=SL4B_ObjectCache.createFilterAndFieldList(B,A);return l_sObjectRequestMessage;
};
SL4B_ObjectCache.createFilterAndFieldList = function(B,A){var l_sFilterAndFieldList="";
var l_bFilterSet=false;
if(typeof B=="string"&&B!=""){l_sFilterAndFieldList+=SL4B_ObjectCache.const_OBJECT_NAME_AND_FIELD_LIST_DELIMITER;l_sFilterAndFieldList+=GF_RequestEncoder.encodeFieldList(B,SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);l_bFilterSet=true;}if(typeof A=="string"&&A!=""){if(l_bFilterSet){l_sFilterAndFieldList+=SL4B_ObjectCache.const_FIELD_NAME_DELIMITER;}else 
{l_sFilterAndFieldList+=SL4B_ObjectCache.const_OBJECT_NAME_AND_FIELD_LIST_DELIMITER;}l_sFilterAndFieldList+=GF_RequestEncoder.encodeFieldList(A,SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);}return l_sFilterAndFieldList;
};
function SL_DS(D,A,C,B){var l_sObjectKey=this._createObjectKey(D,A);
var l_oCacheEntry=this.m_pObjects[l_sObjectKey];
if(l_oCacheEntry!==undefined&&l_oCacheEntry!=null){var l_pCacheFieldList=l_oCacheEntry.m_pFieldList;
var l_bCacheAllFields=l_oCacheEntry.m_bAllFields;
var l_bAllFields=false;
if(C==""||C==null||C===undefined){l_bAllFields=true;}if(this.m_pObjectDataCache[l_sObjectKey]!==undefined){var l_oType1RecordCache=this.m_pObjectDataCache[l_sObjectKey];
var l_oRecordFieldData=new SL4B_RecordFieldData();
if(l_bAllFields){for(l_sField in l_oType1RecordCache.m_pFieldCache){var l_sValue=l_oType1RecordCache.m_pFieldCache[l_sField];
l_oRecordFieldData.add(l_sField,l_sValue);}}else 
{var l_pFields=C.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_sField=l_pFields[l_nField];
if(l_bCacheAllFields||l_pCacheFieldList[l_sField]!==undefined){var l_sValue=l_oType1RecordCache.m_pFieldCache[l_sField];
if(l_sValue){l_oRecordFieldData.add(l_sField,l_sValue);}}}}if(l_oRecordFieldData.size()>0){this.m_oSubscriptionManager.recordMultiUpdated(l_sObjectKey,l_oRecordFieldData,true,B);}}if(this.m_pObjectDataCacheType2[l_sObjectKey]!==undefined){var l_oType2RecordCache=this.m_pObjectDataCacheType2[l_sObjectKey];
var l_sLevelField=l_oType2RecordCache.m_sIndexFieldName;
for(l_sLevel in l_oType2RecordCache.m_pLevelCache){var l_oRecordFieldData=new SL4B_RecordFieldData();
var l_pNameValues=l_oType2RecordCache.m_pLevelCache[l_sLevel];
var l_sLevelValue=l_sLevel;
l_oRecordFieldData.add(l_sLevelField,l_sLevelValue);if(l_bAllFields){for(l_sField in l_pNameValues){var l_sValue=l_pNameValues[l_sField];
l_oRecordFieldData.add(l_sField,l_sValue);}}else 
{var l_pFields=C.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_sField=l_pFields[l_nField];
if(l_bCacheAllFields||l_pNameValues[l_sField]!==undefined){var l_sValue=l_pNameValues[l_sField];
l_oRecordFieldData.add(l_sField,l_sValue);}}}if(l_oRecordFieldData.size()>0){this.m_oSubscriptionManager.recordMultiUpdated(l_sObjectKey,l_oRecordFieldData,true,B);}}}if(this.m_pObjectDataCacheType3[l_sObjectKey]!==undefined){var l_oType3RecordCache=this.m_pObjectDataCacheType3[l_sObjectKey];
for(var l_nLevel=0;l_nLevel<l_oType3RecordCache.m_pLevelCache.length;l_nLevel++){var l_oRecordFieldData=new SL4B_RecordFieldData();
var l_pNameValues=l_oType3RecordCache.m_pLevelCache[l_nLevel];
if(l_bAllFields){for(l_sField in l_pNameValues){var l_sValue=l_pNameValues[l_sField];
l_oRecordFieldData.add(l_sField,l_sValue);}}else 
{var l_pFields=C.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_sField=l_pFields[l_nField];
if(l_bCacheAllFields||l_pNameValues[l_sField]!==undefined){var l_sValue=l_pNameValues[l_sField];
l_oRecordFieldData.add(l_sField,l_sValue);}}}if(l_oRecordFieldData.size()>0){this.m_oSubscriptionManager.recordMultiUpdated(l_sObjectKey,l_oRecordFieldData,true,B);}}}if(this.m_pDirectoryCache[l_sObjectKey]!==undefined){var l_oDirCache=this.m_pDirectoryCache[l_sObjectKey];
var l_pListing=l_oDirCache.m_pListing;
for(l_sName in l_pListing){var l_sType=l_pListing[l_sName];
this.m_oSubscriptionManager.dirUpdated(l_sObjectKey,l_sName,l_sType,true,B);}}if(this.m_pContainerCache[l_sObjectKey]!==undefined){var l_oContCache=this.m_pContainerCache[l_sObjectKey];
var l_oObjectNameToObjectTypeMap=l_oContCache.getObjectNameToObjectTypeMap();
var l_pStructureChanges=new Array();
for(l_sName in l_oObjectNameToObjectTypeMap){this.m_oSubscriptionManager.structureChange(l_sObjectKey,l_sName,l_oObjectNameToObjectTypeMap[l_sName],true,B);l_pStructureChanges.push(new SL4B_ContainerStructureChange(l_sName,l_oObjectNameToObjectTypeMap[l_sName],true));}var l_pOrderChanges=new Array();
var l_oOrdering=l_oContCache.m_oOrdering;
for(l_sSubscriptionId in l_oOrdering){l_pOrderChanges.push(new SL4B_ContainerOrderChange(this.m_pObjectNumberToObjectKeyMap[l_sSubscriptionId],l_sSubscriptionId,l_oOrdering[l_sSubscriptionId]));}if(!l_oContCache.isDirectory()){this.m_oSubscriptionManager.structureMultiChange(l_sObjectKey,l_pStructureChanges,l_pOrderChanges,l_pStructureChanges.length);}var l_sProxyListenerId=this.m_oSubscriptionManager.getProxySubscriber(B,l_sObjectKey,"");
if(l_sProxyListenerId!=null){for(l_sName in l_oObjectNameToObjectTypeMap){this.sendCachedFields(l_sName,"","",l_sProxyListenerId);}}}if(this.m_pNewsHeadlineCache[l_sObjectKey]!==undefined){var l_oNewsHeadlineCache=this.m_pNewsHeadlineCache[l_sObjectKey];
var l_nNumberOfHeadlines=l_oNewsHeadlineCache.getSize();
this.m_oSubscriptionManager.objectInfo(l_sObjectKey,SL4B_ObjectType.NEWS_HEADLINE,SL4B_NewsHeadlineCache.const_SIZE_FIELD,l_oNewsHeadlineCache.getSize()+"");for(var l_nHeadline=0;l_nHeadline<l_nNumberOfHeadlines;++l_nHeadline){var l_oHeadline=l_oNewsHeadlineCache.getHeadline(l_nHeadline);
this.m_oSubscriptionManager.newsUpdated(l_sObjectKey,l_oHeadline.m_sStoryCode,l_oHeadline.m_sHeadline,l_oHeadline.m_sDate);}}if(this.m_pStoryCache[l_sObjectKey]!==undefined){var l_oNewsStoryCache=this.m_pStoryCache[l_sObjectKey];
var l_aStoryText=l_oNewsStoryCache.getTextLines();
this.m_oSubscriptionManager.storyUpdated(l_sObjectKey,l_aStoryText);}if(this.m_pPermissionCache[l_sObjectKey]!==undefined){var l_oPermissionCache=this.m_pPermissionCache[l_sObjectKey];
for(l_sKey in l_oPermissionCache.m_pLevelCache){var l_oFieldData=new SL4B_RecordFieldData();
if(l_bAllFields){for(l_sField in l_pNameValues){var l_sValue=l_pNameValues[l_sField];
l_oFieldData.add(l_sField,l_sValue);}}else 
{var l_pFields=C.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_sField=l_pFields[l_nField];
if(l_bCacheAllFields||l_pNameValues[l_sField]!==undefined){var l_sValue=l_pNameValues[l_sField];
l_oFieldData.add(l_sField,l_sValue);}}}if(l_oFieldData.size()>0){this.m_oSubscriptionManager.permissionUpdated(l_sObjectKey,l_sKey,l_oFieldData,B);}}}if(this.m_mChatCache[l_sObjectKey]!==undefined){this.m_mChatCache[l_sObjectKey].sendCachedData(this,B);}if(B!=null){this.m_pObjects[l_sObjectKey].sendCurrentObjectStatus(this.m_oSubscriptionManager,l_sObjectKey,B);}}}
function SL_ED(A,B){var l_pObjectsToReturn=new Array();
if(A!=undefined&&A.length>0){var l_pObjects=A.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
if(SL4B_Accessor.getCapabilities().getRttpVersion()>=2.1){if(l_pObjects.length==1){l_pObjectsToReturn.push(l_pObjects[0]+B);}else 
{if(B!=undefined&&B.length>0){l_pObjectsToReturn.push(B);}for(var l_nObject=0,l_nLength=l_pObjects.length;l_nObject<l_nLength;l_nObject++){l_pObjectsToReturn.push(l_pObjects[l_nObject]);}}}else 
{for(var l_nObject=0,l_nLength=l_pObjects.length;l_nObject<l_nLength;l_nObject++){l_pObjectsToReturn.push(l_pObjects[l_nObject]+B);}}}return l_pObjectsToReturn;
}
function SL_PL(C,B,A,D){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.sendObjectAction({0}, {1})",C,B);if(B.length==0){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ObjectCache.sendObjectAction. Not performing {0} action as there are no subjects to send to Liberator, not sending any messages.",C);return;
}var l_sObjectRequestMessage=C+" "+B.join(" ");
this.sendSubscriptionMessage(l_sObjectRequestMessage,{filter:D});}
function SL_EI(C,A,D,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.requestObjects({0}, {1}, {2})",C,A,D);var l_pObjects=C.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
var l_pObjectsToRequest=new Array();
var l_sObjectRequestList="";
for(var l_nObject=0,l_nLength=l_pObjects.length;l_nObject<l_nLength;++l_nObject){var l_sObjectName=l_pObjects[l_nObject];
var l_sObjectKey=this._createObjectKey(l_sObjectName,A);
this._addCacheEntryIfNotPresent(l_sObjectKey);if(this.m_pObjects[l_sObjectKey].addFields(D)!=null){l_pObjectsToRequest.push(l_sObjectName);l_sObjectRequestList+=((l_sObjectRequestList=="") ? "" : SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER)+GF_RequestEncoder.encodeRttpData(l_sObjectName);}else 
{this.sendCachedFields(l_sObjectName,A,D,B);}}if(l_pObjectsToRequest.length>0){var l_sFieldMessage=SL4B_ObjectCache.createFilterAndFieldList(A,D);
this.sendObjectAction("REQUEST",this.createObjectArray(l_sObjectRequestList,l_sFieldMessage),l_pObjectsToRequest,A);}}
function SL_HJ(B,A){var l_sSendFilter=A;
if(l_sSendFilter!=""){l_sSendFilter=SL4B_ObjectCache.const_OBJECT_NAME_AND_FIELD_LIST_DELIMITER+GF_RequestEncoder.encodeFieldList(l_sSendFilter,SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);}this.sendObjectAction("DISCARD",this.createObjectArray(GF_RequestEncoder.encodeRttpData(B),l_sSendFilter),[B],A);var l_sObjectKey=this._createObjectKey(B,A);
this.clearCacheForObjectKey(l_sObjectKey);}
function SL_NZ(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.discardObjects({0}, {1})",A,B);var l_sSendFilter=B;
if(l_sSendFilter!=""){l_sSendFilter=SL4B_ObjectCache.const_OBJECT_NAME_AND_FIELD_LIST_DELIMITER+GF_RequestEncoder.encodeFieldList(l_sSendFilter,SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);}var l_pObjects=A.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
this.sendObjectAction("DISCARD",this.createObjectArray(A,l_sSendFilter),l_pObjects,B);for(var l_nObject=0,l_nLength=l_pObjects.length;l_nObject<l_nLength;++l_nObject){var l_sObjectName=l_pObjects[l_nObject];
var l_sObjectKey=this._createObjectKey(l_sObjectName,B);
this.clearCacheForObjectKey(l_sObjectKey);}}
function SL_DZ(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.notFound: {0}",A);var l_sObjectKey=null;
var l_sObjectNumber=A.getObjectNumber();
if(l_sObjectNumber!==null){l_sObjectKey=(l_sObjectNumber ? this.m_pObjectNumberToObjectKeyMap[l_sObjectNumber] : A.getMessageContent().split(" ")[0]);}if(B!==null&&l_sObjectKey==null){l_sObjectKey=this._extractObjectKeyFromSentMessage(B);}this.clearCacheForObjectKey(l_sObjectKey);this.m_oSubscriptionManager.clearAllSubscriptions(l_sObjectKey,A.getRttpCode());}
SL4B_ObjectCache.prototype.clearCacheForObjectKey = function(A){if(A!==undefined){this._removeCacheEntryIfNoMoreReferences(A,true);if(this.m_pObjectDataCache[A]!==undefined){delete this.m_pObjectDataCache[A];}if(this.m_pObjectDataCacheType2[A]!==undefined){delete this.m_pObjectDataCacheType2[A];}if(this.m_pObjectDataCacheType3[A]!==undefined){delete this.m_pObjectDataCacheType3[A];}if(this.m_pDirectoryCache[A]!==undefined){delete this.m_pDirectoryCache[A];}if(this.m_pContainerCache[A]!==undefined){delete this.m_pContainerCache[A];}if(this.m_pNewsHeadlineCache[A]!==undefined){delete this.m_pNewsHeadlineCache[A];}if(this.m_pStoryCache[A]!==undefined){delete this.m_pStoryCache[A];}if(this.m_pPermissionCache[A]!==undefined){delete this.m_pPermissionCache[A];}if(this.m_mChatCache[A]!==undefined){delete this.m_mChatCache[A];}}};
SL4B_ObjectCache.prototype.validateResponseMatchesExpectation = function(A,B){if(SL4B_RttpCodes.isResponseCode(A.getRttpCode())){var sReceivedObjectName=A.getMessageContent().match(/([^ ]+)/)[1];
var sSentObjectName=B.getMessage().match(/ ([^;]+)/)[1];
if(sReceivedObjectName!==sSentObjectName&&GF_ResponseDecoder.decodeRttpData(sReceivedObjectName)!==GF_ResponseDecoder.decodeRttpData(sSentObjectName)){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ObjectCache.validateResponseMatchesExpectation: Received a message for {0} when a message for {1} was expected.",sReceivedObjectName,sSentObjectName);return false;
}}return true;
};
function SL_DR(A,B,C){switch(A){
case SL4B_RttpCodes.const_RESP_UNKNOWN:case SL4B_RttpCodes.const_DIRECTORY_RESP:case SL4B_RttpCodes.const_CONT_UPD:case SL4B_RttpCodes.const_CONT_IMG:case SL4B_RttpCodes.const_CONT_RESP:case SL4B_RttpCodes.const_AUTODIR_RESP:case SL4B_RttpCodes.const_AUTODIR_UPD:case SL4B_RttpCodes.const_AUTODIR_IMG:{return true;
}default :{if(C!=null){var mParameters=C.getParameters();
if(mParameters.ctrid!==undefined){oUserRequestData=this.m_oSubscriptionManager.getContainerRequestData(mParameters.ctrid);if(oUserRequestData!==undefined&&(mParameters.ctrstart!=oUserRequestData.getWindowStart()||mParameters.ctrend!=oUserRequestData.getWindowEnd())){var oContainerRequest=C;
if(C.getOriginalMessage()){oContainerRequest=C.getOriginalMessage();}var l_sContainerObjectKey=this._extractObjectKeyFromSentMessage(oContainerRequest);
if(B&&l_sContainerObjectKey&&this.m_pContainerCache[l_sContainerObjectKey]){var l_nObjPosition=this.m_pContainerCache[l_sContainerObjectKey].getOrdering(B);
if(l_nObjPosition>=oUserRequestData.getWindowStart()&&l_nObjPosition<=oUserRequestData.getWindowEnd()){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ObjectCache.cacheObject: Item {0} is from an old request, but it is inside the current window {1} - {2}: processing updates",l_nObjPosition,oUserRequestData.getWindowStart(),oUserRequestData.getWindowEnd());}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ObjectCache.cacheObject: Item {0} is outside the current window {1} - {2}: will not process non container updates",l_nObjPosition,oUserRequestData.getWindowStart(),oUserRequestData.getWindowEnd());return false;
}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ObjectCache.cacheObject: windows don't match - not processing non container updates: expected window start = {0} end = {1} this update for window start = {2}, end = {3}",oUserRequestData.getWindowStart(),oUserRequestData.getWindowEnd(),mParameters.ctrstart,mParameters.ctrend);return false;
}}}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheObject: no request record stored for message {0}",B);}}}return true;
}
function SL_IZ(C,A,B){var oNormalisedRttpMessage=C;
if(this.validateResponseMatchesExpectation(oNormalisedRttpMessage,A)==false){this.m_oRttpProvider.getManagedConnection()._triggerReconnect("incorrect response");return;
}var oUserRequestData;
var l_nRttpCode=oNormalisedRttpMessage.getRttpCode();
var l_sObjectNumber=oNormalisedRttpMessage.getObjectNumber();
var bProcessUpdates=this.isActive(l_nRttpCode,l_sObjectNumber,A);
if(bProcessUpdates==false){return;
}switch(l_nRttpCode){
case SL4B_RttpCodes.const_RECORD_RESP:case SL4B_RttpCodes.const_RESP_UNKNOWN:case SL4B_RttpCodes.const_DIRECTORY_RESP:case SL4B_RttpCodes.const_CONT_RESP:case SL4B_RttpCodes.const_AUTODIR_RESP:case SL4B_RttpCodes.const_NEWS_RESP:case SL4B_RttpCodes.const_STORY_RESP:case SL4B_RttpCodes.const_PERM_RESP:case SL4B_RttpCodes.const_CHAT_RESP:{var l_sObjectKey=this._extractObjectKeyFromSentMessage(A);
this.m_pObjectNumberToObjectKeyMap[l_sObjectNumber]=l_sObjectKey;break;
}}switch(l_nRttpCode){
case SL4B_RttpCodes.const_RECORD_RESP:case SL4B_RttpCodes.const_RESP_UNKNOWN:{var l_nIndex=C.getMessageContent().indexOf(" ");
this.cacheType1Record(C.getObjectNumber(),C.getMessageContent().substr(l_nIndex+1),(l_nRttpCode==SL4B_RttpCodes.const_RESP_UNKNOWN),SL4B_RttpCodes.isImageCode(l_nRttpCode));break;
}case SL4B_RttpCodes.const_REC1_UPD:case SL4B_RttpCodes.const_REC1_IMG:{this.cacheType1Record(C.getObjectNumber(),C.getMessageContent(),false,SL4B_RttpCodes.isImageCode(l_nRttpCode));break;
}case SL4B_RttpCodes.const_REC2_UPD:case SL4B_RttpCodes.const_REC2_IMG:{this.cacheType2Record(C.getObjectNumber(),C.getMessageContent(),SL4B_RttpCodes.isImageCode(l_nRttpCode));break;
}case SL4B_RttpCodes.const_REC2_CLR:{this.type2Clear(C.getObjectNumber());break;
}case SL4B_RttpCodes.const_REC2_DEL:{this.deleteType2RecordLevel(C.getObjectNumber(),C.getMessageContent());break;
}case SL4B_RttpCodes.const_REC3_UPD:case SL4B_RttpCodes.const_REC3_IMG:{this.cacheType3Record(C.getObjectNumber(),C.getMessageContent(),SL4B_RttpCodes.isImageCode(l_nRttpCode));break;
}case SL4B_RttpCodes.const_REC3_CLR:{this.type3Clear(C.getObjectNumber());break;
}case SL4B_RttpCodes.const_DIRECTORY_RESP:case SL4B_RttpCodes.const_DIR_UPD:{this.cacheDirectory(C.getObjectNumber(),C.getMessageContent(),l_nRttpCode);break;
}case SL4B_RttpCodes.const_CONT_RESP:case SL4B_RttpCodes.const_CONT_UPD:case SL4B_RttpCodes.const_CONT_IMG:case SL4B_RttpCodes.const_AUTODIR_RESP:case SL4B_RttpCodes.const_AUTODIR_UPD:case SL4B_RttpCodes.const_AUTODIR_IMG:{this.cacheContainer(C.getObjectNumber(),C.getMessageContent(),l_nRttpCode,B,A);break;
}case SL4B_RttpCodes.const_NEWS_IMG:case SL4B_RttpCodes.const_NEWS_UPD:{this.cacheNewsHeadline(C.getObjectNumber(),C.getMessageContent());break;
}case SL4B_RttpCodes.const_STORY_UPD:case SL4B_RttpCodes.const_STORY_RESP:case SL4B_RttpCodes.const_STORY_IMG:{this.cacheNewsStory(C.getObjectNumber(),C.getMultipleLineContents(),C.getMessageContent());break;
}case SL4B_RttpCodes.const_PERM_IMG:case SL4B_RttpCodes.const_PERM_UPD:{this.cachePermission(C.getObjectNumber(),C.getMessageContent());break;
}case SL4B_RttpCodes.const_PERM_CLR:{this.clearPermission(C.getObjectNumber());break;
}case SL4B_RttpCodes.const_PERM_DEL:{this.deletePermissionEntry(C.getObjectNumber(),C.getMessageContent());break;
}case SL4B_RttpCodes.const_CHAT_RESP:case SL4B_RttpCodes.const_CHAT_UPD:{this.cacheChat(C.getObjectNumber(),C.getMessageContent(),(l_nRttpCode===SL4B_RttpCodes.const_CHAT_RESP));break;
}}}
var g_rePlus=new RegExp("\\+","g");
function SL_DM(A,B,C,D){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.cacheType1Record({0}, {1}, {2}, {3})",A,B,C,D);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){var l_oType1Cache=this.m_pObjectDataCache[l_sObjectKey];
if(l_oType1Cache===undefined){l_oType1Cache=new SL4B_Type1RecordCache();this.m_pObjectDataCache[l_sObjectKey]=l_oType1Cache;}if(!C){var l_oRecordFieldData;
l_oRecordFieldData=this.getFieldDataFromString(l_oType1Cache,B);this.m_oSubscriptionManager.recordMultiUpdated(l_sObjectKey,l_oRecordFieldData,D);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheType1Record: No object name is "+"available that corresponds to the object number {0}",A);}}
SL4B_ObjectCache.prototype.getFieldDataFromString = function(B,A){var l_pFields=A.split(" ");
var l_oRecordFieldData=new SL4B_RecordFieldData();
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_nIndex=l_pFields[l_nField].indexOf("=");
var l_sRawFieldName=l_pFields[l_nField].substring(0,l_nIndex);
var l_sRawFieldValue=l_pFields[l_nField].substring(l_nIndex+1);
this.addType1FieldData(B,l_oRecordFieldData,l_sRawFieldName,l_sRawFieldValue);}return l_oRecordFieldData;
};
SL4B_ObjectCache.prototype.addType1FieldData = function(A,D,C,B){var l_sFieldName=this.m_oRttpProvider.getFieldName(C);
var l_sFieldValue=unescape(B.replace(g_rePlus," "));
A.addField(l_sFieldName,l_sFieldValue);D.add(l_sFieldName,l_sFieldValue);if(SL4B_Accessor.getConfiguration().isEnableLatency()&&l_sFieldName==SL4B_Accessor.getConfiguration().getTimestampField()){SL4B_ConnectionProxy.getInstance().recordLatency(l_sFieldValue);}};
function SL_OJ(A,C,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.cacheType2Record({0}, {1}, {2})",A,C,B);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){var l_pFields=C.split(" ");
var l_nIndex=l_pFields[0].indexOf("=");
var l_sLevelFieldName=this.m_oRttpProvider.getFieldName(l_pFields[0].substring(0,l_nIndex));
var l_sLevelFieldValue=l_pFields[0].substring(l_nIndex+1);
l_sLevelFieldValue=GF_ResponseDecoder.decodeRttpData(l_sLevelFieldValue);if(this.m_pObjectDataCacheType2[l_sObjectKey]===undefined){this.m_pObjectDataCacheType2[l_sObjectKey]=new SL4B_Type2RecordCache();this.m_pObjectDataCacheType2[l_sObjectKey].m_sIndexFieldName=l_sLevelFieldName;}var l_oRecordFieldData=new SL4B_RecordFieldData();
l_oRecordFieldData.add(l_sLevelFieldName,l_sLevelFieldValue);for(var l_nField=1,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){l_nIndex=l_pFields[l_nField].indexOf("=");var l_sFieldName=this.m_oRttpProvider.getFieldName(l_pFields[l_nField].substring(0,l_nIndex));
var l_sFieldValue=l_pFields[l_nField].substring(l_nIndex+1);
if(l_sFieldName!==undefined){var l_sFieldValue=GF_ResponseDecoder.decodeRttpData(l_sFieldValue);
this.m_pObjectDataCacheType2[l_sObjectKey].addField(l_sLevelFieldValue,l_sFieldName,l_sFieldValue);l_oRecordFieldData.add(l_sFieldName,l_sFieldValue);if(SL4B_Accessor.getConfiguration().isEnableLatency()&&l_sFieldName==SL4B_Accessor.getConfiguration().getTimestampField()){SL4B_ConnectionProxy.getInstance().recordLatency(l_sFieldValue);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheType2Record: No field is "+"available that corresponds to the field {0}",l_pFields[l_nField].substring(0,l_nIndex));}}this.m_oSubscriptionManager.recordMultiUpdated(l_sObjectKey,l_oRecordFieldData,B);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheType2Record: No object name is "+"available that corresponds to the object number {0}",A);}}
function SL_EV(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.type2Clear: {0}",A);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){if(this.m_pObjectDataCacheType2[l_sObjectKey]!==undefined){delete this.m_pObjectDataCacheType2[l_sObjectKey];this.m_oSubscriptionManager.type2Clear(l_sObjectKey);}}}
function SL_PC(A,C,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.cacheType3Record: {0}, {1}, {2}",A,C,B);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){if(this.m_pObjectDataCacheType3[l_sObjectKey]===undefined){this.m_pObjectDataCacheType3[l_sObjectKey]=new SL_NL();}var l_pFields=C.split(" ");
var l_oRecordFieldData=new SL4B_RecordFieldData();
var l_pNameValuePairs=new Array();
this.m_pObjectDataCacheType3[l_sObjectKey].m_pLevelCache.push(l_pNameValuePairs);for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){l_nIndex=l_pFields[l_nField].indexOf("=");var l_sFieldName=this.m_oRttpProvider.getFieldName(l_pFields[l_nField].substring(0,l_nIndex));
var l_sFieldValue=l_pFields[l_nField].substring(l_nIndex+1);
if(l_sFieldName!==undefined){var l_sFieldValue=GF_ResponseDecoder.decodeRttpData(l_sFieldValue);
l_pNameValuePairs[l_sFieldName]=l_sFieldValue;l_oRecordFieldData.add(l_sFieldName,l_sFieldValue);if(SL4B_Accessor.getConfiguration().isEnableLatency()&&l_sFieldName==SL4B_Accessor.getConfiguration().getTimestampField()){SL4B_ConnectionProxy.getInstance().recordLatency(l_sFieldValue);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheType3Record: No field is "+"available that corresponds to the field {0}",l_pFields[l_nField].substring(0,l_nIndex));}}this.m_oSubscriptionManager.recordMultiUpdated(l_sObjectKey,l_oRecordFieldData,B);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheType3Record: No object name is "+"available that corresponds to the object number {0}",A);}}
function SL_PI(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.type3Clear({0})",A);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){if(this.m_pObjectDataCacheType3[l_sObjectKey]!==undefined){delete this.m_pObjectDataCacheType3[l_sObjectKey];this.m_oSubscriptionManager.type3Clear(l_sObjectKey);}}}
function SL_RH(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.deleteType2RecordLevel: {0}; {1}",A,B);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){if(this.m_pObjectDataCacheType2[l_sObjectKey]!==undefined){var l_pFields=B.split(" ");
var l_nIndex=l_pFields[0].indexOf("=");
var l_sLevelFieldName=this.m_oRttpProvider.getFieldName(l_pFields[0].substring(0,l_nIndex));
var l_sLevelFieldValue=l_pFields[0].substring(l_nIndex+1);
l_sLevelFieldValue=GF_ResponseDecoder.decodeRttpData(l_sLevelFieldValue);this.m_pObjectDataCacheType2[l_sObjectKey].deleteLevel(l_sLevelFieldValue);this.m_oSubscriptionManager.deleteType2Level(l_sObjectKey,l_sLevelFieldName,l_sLevelFieldValue);}}}
function SL_AP(B,C,A){var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[B];
if(l_sObjectKey!==undefined){var l_oCache=this.m_pDirectoryCache[l_sObjectKey];
if(l_oCache===undefined){l_oCache=new SL4B_DirectoryCache();this.m_pDirectoryCache[l_sObjectKey]=l_oCache;}var l_pDirs=C.split(" ");
var l_nDir=1;
if(A==SL4B_RttpCodes.const_DIR_UPD){l_nDir=0;}for(var l_nLength=l_pDirs.length;l_nDir<l_nLength;++l_nDir){var l_sDirAndType=l_pDirs[l_nDir];
var l_pDirAndType=l_sDirAndType.split(";");
if(l_pDirAndType[1]==0){delete l_oCache.m_pListing[l_pDirAndType[0]];}else 
{l_oCache.m_pListing[l_pDirAndType[0]]=l_pDirAndType[1];}this.m_oSubscriptionManager.dirUpdated(l_sObjectKey,GF_ResponseDecoder.decodeRttpData(l_pDirAndType[0]),l_pDirAndType[1],(l_pDirAndType[1]!=0));}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheDirectory: No object name is "+"available that corresponds to the object number {0}",B);}}
function SL_RG(A,E,C,B,D){var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey===undefined){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheContainer: No object name is "+"available that corresponds to the object number {0}",A);return;
}var l_oCache=this.m_pContainerCache[l_sObjectKey];
if(l_oCache===undefined){l_oCache=new SL4B_ContainerCache();this.m_pContainerCache[l_sObjectKey]=l_oCache;}if(C==SL4B_RttpCodes.const_AUTODIR_RESP||C==SL4B_RttpCodes.const_AUTODIR_IMG){l_oCache.setDirectory(true);}var l_pWords=E.split(" ");
var l_pStructureChanges=new Array();
var l_pOrderChanges=new Array();
var mObjectNamesRemovedFromContainer={};
var l_nPos=0;
var l_bParseOrderFromElements=false;
if(C==SL4B_RttpCodes.const_CONT_RESP||C==SL4B_RttpCodes.const_AUTODIR_RESP||C==SL4B_RttpCodes.const_CONT_IMG||C==SL4B_RttpCodes.const_AUTODIR_IMG){l_bParseOrderFromElements=true;if(C==SL4B_RttpCodes.const_CONT_RESP||C==SL4B_RttpCodes.const_AUTODIR_RESP){l_nPos=2;}var l_oObjectNameToObjectTypeMap=l_oCache.getObjectNameToObjectTypeMap();
for(l_sName in l_oObjectNameToObjectTypeMap){this.m_oSubscriptionManager.structureChange(l_sObjectKey,l_sName,l_oObjectNameToObjectTypeMap[l_sName],false);l_pStructureChanges.push(new SL4B_ContainerStructureChange(l_sName,l_oObjectNameToObjectTypeMap[l_sName],false));B.removeObjectNumber(l_oCache.m_mObjectNameToNumberMap[l_sName]);l_oCache.removeEntry(l_sName);l_oCache.removeOrdering(l_oCache.m_oObjectNameToIdMap[l_sName]);l_oCache.removeFromNameIdMap(l_sName);mObjectNamesRemovedFromContainer[l_sName]=SL4B_ObjectCache.SUBJECT_DELETED;}}var l_nElementPosition=0;
if(C==SL4B_RttpCodes.const_CONT_RESP||C==SL4B_RttpCodes.const_CONT_IMG){var l_nWindowStart;
if(D!==undefined){l_nWindowStart=parseInt(D.getParameters()['ctrstart']);if(l_nWindowStart!==undefined){l_nElementPosition=l_nWindowStart;}}}if(l_nElementPosition>=2147483647){return;
}var l_sOrderingString="";
for(var l_nLength=l_pWords.length;l_nPos<l_nLength;++l_nPos){var l_sWord=l_pWords[l_nPos];
if(l_sWord.match(/^size=/)!=null){var l_pItems=l_sWord.split("=");
l_oCache.setSize(parseInt(l_pItems[1]));}else 
if(l_sWord.match(/^order=/)!=null){var l_pItems=l_sWord.split("=");
l_sOrderingString=l_pItems[1];}else 
if(l_sWord.match(/^.+;.+;.+/)!=null){var l_pItems=l_sWord.split(";");
var l_sName=l_pItems[0];
l_sName=GF_ResponseDecoder.decodeRttpData(l_sName);var l_bAdded=(l_pItems[1]!=0);
var l_sSubscriptionId=l_pItems[l_pItems.length-1];
if(!l_bAdded){l_oCache.removeEntry(l_sName);l_oCache.removeOrdering(l_oCache.m_oObjectNameToIdMap[l_sName]);l_oCache.removeFromNameIdMap(l_sName);B.removeObjectNumber(l_sSubscriptionId);mObjectNamesRemovedFromContainer[l_sName]=SL4B_ObjectCache.SUBJECT_DELETED;}else 
{if(mObjectNamesRemovedFromContainer[l_sName]===undefined){this._addCacheEntryIfNotPresent(l_sName);}this.m_pObjectNumberToObjectKeyMap[l_sSubscriptionId]=l_sName;l_oCache.addEntry(l_sName,l_pItems[1],l_sSubscriptionId);B.addObjectNumber(l_sSubscriptionId);mObjectNamesRemovedFromContainer[l_sName]=SL4B_ObjectCache.SUBJECT_ADDED;}this.m_oSubscriptionManager.structureChange(l_sObjectKey,l_sName,l_pItems[1],l_bAdded);l_pStructureChanges.push(new SL4B_ContainerStructureChange(l_sName,l_pItems[1],l_bAdded));if(l_bParseOrderFromElements){l_pOrderChanges.push(new SL4B_ContainerOrderChange(l_sName,l_sSubscriptionId,l_nElementPosition));l_oCache.addToNameIdMap(l_sName,l_sSubscriptionId);l_oCache.addOrdering(l_sSubscriptionId,l_nElementPosition);}l_nElementPosition++;}}if(l_sOrderingString!=""){l_pOrderChanges=this.parseOrderChanges(l_sOrderingString,l_oCache);}this._dereferenceRemovedContentsInCache(mObjectNamesRemovedFromContainer);if(C==SL4B_RttpCodes.const_CONT_RESP||C==SL4B_RttpCodes.const_CONT_IMG||C==SL4B_RttpCodes.const_CONT_UPD){this.m_oSubscriptionManager.structureMultiChange(l_sObjectKey,l_pStructureChanges,l_pOrderChanges,l_oCache.getSize());}}
SL4B_ObjectCache.prototype._dereferenceRemovedContentsInCache = function(A){for(sDeletedSubject in A){if(A[sDeletedSubject]===SL4B_ObjectCache.SUBJECT_DELETED){this._removeCacheEntryIfNoMoreReferences(sDeletedSubject,false);}}};
function SL_IY(A,B){var l_sParsedItems=new Array();
if(typeof A!="string"||A==null||A.length==0){return l_sParsedItems;
}var l_pOrderItems=A.split(",");
for(var i=0;i<l_pOrderItems.length;i++){var l_pOrderMessage=l_pOrderItems[i].split(":");
if(l_pOrderMessage.length!=2){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.parseOrderChanges: Unable to parse order message: \"{0}\" from \"{1}\"",l_pOrderItems[i],A);break;
}var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[l_pOrderMessage[0]];
if(l_sObjectKey===undefined){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.parseOrderChanges: Unable to parse order message: \"{0}\" from \"{1}\" could not find subscriptionId",l_pOrderItems[i],A);break;
}var order=parseInt(l_pOrderMessage[1]);
l_sParsedItems.push(new SL4B_ContainerOrderChange(l_sObjectKey,l_pOrderMessage[0],order));B.addToNameIdMap(l_sObjectKey,l_pOrderMessage[0]);B.addOrdering(l_pOrderMessage[0],order);}return l_sParsedItems;
}
function SL_DN(A,B){var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){var l_oCache=this.m_pNewsHeadlineCache[l_sObjectKey];
if(l_oCache===undefined||typeof l_oCache.addField=="function"){l_oCache=new SL4B_NewsHeadlineCache();this.m_pNewsHeadlineCache[l_sObjectKey]=l_oCache;}var l_pFields=B.split(" ");
if(l_pFields.length==1){var l_nIndex=l_pFields[0].indexOf("=");
l_sFieldName=l_pFields[0].substring(0,l_nIndex);l_sFieldValue=l_pFields[0].substring(l_nIndex+1);if(l_sFieldName==SL4B_NewsHeadlineCache.const_SIZE_FIELD){this.m_oSubscriptionManager.objectInfo(l_sObjectKey,SL4B_ObjectType.NEWS_HEADLINE,l_sFieldName,l_sFieldValue);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheNewsHeadline: update did not contain the \"size\" field: {0} - {1}",A,B);}}else 
if(l_pFields.length==3){var l_sHeadline;
var l_sCode;
var l_sDate;
var l_bError=false;
for(var l_nField=0;l_nField<3;++l_nField){var l_nIndex=l_pFields[l_nField].indexOf("=");
l_sFieldName=this.m_oRttpProvider.getFieldName(l_pFields[l_nField].substring(0,l_nIndex));l_sFieldValue=l_pFields[l_nField].substring(l_nIndex+1);l_sFieldValue=GF_ResponseDecoder.decodeRttpData(l_sFieldValue);switch(l_sFieldName){
case "headline":l_sHeadline=l_sFieldValue;break;
case "code":l_sCode=l_sFieldValue;break;
case "date":l_sDate=l_sFieldValue;break;
default :l_bError=true;break;
}}if(!l_bError){l_oCache.addHeadline(l_sCode,l_sHeadline,l_sDate);this.m_oSubscriptionManager.newsUpdated(l_sObjectKey,l_sCode,l_sHeadline,l_sDate);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheNewsHeadline: news headline message did not contain the expected fields: {0} - {1}",A,B);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheNewsHeadline: unexpected news headline message received: {0} - {1}",A,B);}}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheNewsHeadline: No object name is available that corresponds to the object number {0}",A);}}
function SL_QG(A,B,C){var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){var l_oStoryCache=this.m_pStoryCache[l_sObjectKey]||this.m_pObjectDataCache[l_sObjectKey];
if(l_oStoryCache===undefined||!l_oStoryCache.isNewsStory){if(l_oStoryCache!==undefined){delete this.m_pObjectDataCache[l_sObjectKey];}l_oStoryCache=new SL4B_NewsStoryCache();this.m_pStoryCache[l_sObjectKey]=l_oStoryCache;}if(C.match(/reset/)){l_oStoryCache.addTextLines(B);}else 
{l_oStoryCache.setTextLines(B);}}var l_aTextLines=l_oStoryCache.getTextLines();
this.m_oSubscriptionManager.storyUpdated(l_sObjectKey,B);}
function SL_OF(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.cachePermission({0}, {1})",A,B);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){var l_oCache=this.m_pPermissionCache[l_sObjectKey];
var l_pFields=null;
if(B==null){l_pFields=new Array();}else 
{l_pFields=B.split(" ");var l_nIndex=l_pFields[0].indexOf("=");
var l_sKeyFieldName=this.m_oRttpProvider.getFieldName(l_pFields[0].substring(0,l_nIndex));
var l_sKeyFieldValue=GF_ResponseDecoder.decodeRttpData(l_pFields[0].substring(l_nIndex+1));
if(l_oCache===undefined){l_oCache=new SL4B_Type2RecordCache();l_oCache.m_sIndexFieldName=l_sKeyFieldValue;this.m_pPermissionCache[l_sObjectKey]=l_oCache;}}var l_oFieldData=new SL4B_RecordFieldData();
for(var l_nField=1,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){l_nIndex=l_pFields[l_nField].indexOf("=");var l_sFieldName=this.m_oRttpProvider.getFieldName(l_pFields[l_nField].substring(0,l_nIndex));
var l_sFieldValue=GF_ResponseDecoder.decodeRttpData(l_pFields[l_nField].substring(l_nIndex+1));
this.m_pPermissionCache[l_sObjectKey].addField(l_sKeyFieldValue,l_sFieldName,l_sFieldValue);l_oFieldData.add(l_sFieldName,l_sFieldValue);}this.m_oSubscriptionManager.permissionUpdated(l_sObjectKey,l_sKeyFieldValue,l_oFieldData);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cachePermission: No object name is available that corresponds to the object number {0}",A);}}
function SL_LN(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.clearPermission: {0}",A);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){if(this.m_pPermissionCache[l_sObjectKey]!==undefined){delete this.m_pPermissionCache[l_sObjectKey];this.m_oSubscriptionManager.deleteAllPermissionEntries(l_sObjectKey);}}}
function SL_CC(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.deletePermissionEntry: {0}; {1}",A,B);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[A];
if(l_sObjectKey!==undefined){if(this.m_pPermissionCache[l_sObjectKey]!==undefined){var l_pFields=B.split(" ");
var l_nIndex=l_pFields[0].indexOf("=");
var l_sKeyFieldName=this.m_oRttpProvider.getFieldName(l_pFields[0].substring(0,l_nIndex));
var l_sKeyFieldValue=GF_ResponseDecoder.decodeRttpData(l_pFields[0].substring(l_nIndex+1));
this.m_pPermissionCache[l_sObjectKey].deleteLevel(l_sKeyFieldValue);this.m_oSubscriptionManager.deletePermissionEntry(l_sObjectKey,l_sKeyFieldValue);}}}
SL4B_ObjectCache.prototype.cacheChat = function(B,C,A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.cacheChat: {0}; {1}",B,C);var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[B];
if(l_sObjectKey!==undefined){var mFields=this._extractFieldsAsMap(C,A);
var oCache=this.m_mChatCache[l_sObjectKey];
if(oCache===undefined){oCache=new GF_ChatCache(l_sObjectKey);this.m_mChatCache[l_sObjectKey]=oCache;}oCache.addToCache(mFields);this._$sendChat(l_sObjectKey,mFields);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.cacheChat: No object name is available that corresponds to the object number {0}",B);}};
SL4B_ObjectCache.prototype._$sendChat = function(A,C,B){this.m_oSubscriptionManager.chat(A,C[GF_ChatFields.TIME]||SL4B_ObjectCache.const_BLANK_STRING,C[GF_ChatFields.USER]||SL4B_ObjectCache.const_BLANK_STRING,C[GF_ChatFields.MESSAGE]||SL4B_ObjectCache.const_BLANK_STRING,parseInt(C[GF_ChatFields.STATUS]||0),B);};
SL4B_ObjectCache.prototype._extractFieldsAsArray = function(B,A){return this._extractFields(B,A,this._addFieldToArray,[]);
};
SL4B_ObjectCache.prototype._addFieldToArray = function(B,A,C){B.push({name:A, value:C});};
SL4B_ObjectCache.prototype._extractFieldsAsMap = function(B,A){return this._extractFields(B,A,this._addFieldToMap,{});
};
SL4B_ObjectCache.prototype._addFieldToMap = function(C,A,B){C[A]=B;};
SL4B_ObjectCache.prototype._extractFields = function(C,A,B,D){var pFieldPairs=C.split(" ");
for(var nField=(A ? 1 : 0),nLength=pFieldPairs.length;nField<nLength;++nField){var nIndex=pFieldPairs[nField].indexOf("=");
if(nIndex>=0){var sFieldName=this.m_oRttpProvider.getFieldName(pFieldPairs[nField].substring(0,nIndex));
var sFieldValue=pFieldPairs[nField].substring(nIndex+1);
B(D,sFieldName,GF_ResponseDecoder.decodeRttpData(sFieldValue));}else 
{this._logParsingError("Illegal field definition found for \""+pFieldPairs[nField]+"\" whilst parsing message body \""+C+"\"");}}return D;
};
SL4B_ObjectCache.prototype._logParsingError = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,A);};
function SL_PX(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectCache.statusUpdated: {0}",A);var l_sObjectNumber=A.getObjectNumber();
var l_sObjectKey=this.m_pObjectNumberToObjectKeyMap[l_sObjectNumber];
var l_pFields=A.getMessageContent().split(" ");
var l_nCode=0;
var l_sMessage="";
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_nIndex=l_pFields[l_nField].indexOf("=");
var l_sFieldName=this.m_oRttpProvider.getFieldName(l_pFields[l_nField].substring(0,l_nIndex));
var l_sFieldValue=GF_ResponseDecoder.decodeRttpData(l_pFields[l_nField].substring(l_nIndex+1));
switch(l_sFieldName){
case "code":l_nCode=parseInt(l_sFieldValue,10);break;
case "status":l_sMessage=l_sFieldValue;break;
}}
try {this.m_oSubscriptionManager.objectStatus(l_sObjectKey,SL4B_ObjectStatus.getObjectStatusFromRttpCode(A.getRttpCode()),l_nCode,l_sMessage);this.m_pObjects[l_sObjectKey].setObjectStatus(SL4B_ObjectStatus.getObjectStatusFromRttpCode(A.getRttpCode()),l_nCode,l_sMessage);}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectCache.statusUpdated: Unable to get status code from SL4B_ObjectStatus.getObjectStatusFromRttpCode for the update: {0}.",A);}
}
SL4B_ObjectCache.prototype.getObjectStatus = function(A){return ((this.m_pObjects[A]!==undefined) ? this.m_pObjects[A].getObjectStatus() : null);
};
GF_ChatFields = new function(){this.STATUS="status";this.USER="user";this.MESSAGE="msg";this.TIME="time";};
var SL4B_ObjectSubscriptionManager=function(){};
if(false){function SL4B_ObjectSubscriptionManager(){}
}SL4B_ObjectSubscriptionManager = function(A){this.CLASS_NAME="SL4B_ObjectSubscriptionManager";this.m_pObjectSubscriptions=new Object();this.m_oObjectCache=null;this.m_oContainerProxySubscribers=new Object();this.m_oContainerObjects=new Object();this.m_oContainerIdToRequestDataMap=new Object();this.m_bStaleStatusSent=false;this.m_oConnectionListener=new LF_ObjectSubscriptionManagerConnectionListener(this);A.addConnectionListener(this.m_oConnectionListener);};
SL4B_ObjectSubscriptionManager.LOGMESSAGES={};SL4B_ObjectSubscriptionManager.LOGMESSAGES.OBJECT_STATUS_WAS_NULL="ObjectStatus was null for key {0}";SL4B_ObjectSubscriptionManager.prototype.isValidObject = function(A){return ((typeof A=="string")&&A!="");
};
SL4B_ObjectSubscriptionManager.prototype.isSubscribed = function(A){return this.m_pObjectSubscriptions[A]!=null;
};
SL4B_ObjectSubscriptionManager.prototype.requestObject = SL_BQ;SL4B_ObjectSubscriptionManager.prototype.requestObjects = SL_NY;SL4B_ObjectSubscriptionManager.prototype.reRequestObjects = SL_BP;SL4B_ObjectSubscriptionManager.prototype.discardObject = SL_DI;SL4B_ObjectSubscriptionManager.prototype.discardObjects = SL_LK;SL4B_ObjectSubscriptionManager.prototype.addObject = SL_LG;SL4B_ObjectSubscriptionManager.prototype.removeObject = SL_QE;SL4B_ObjectSubscriptionManager.prototype.removeSubscriber = SL_CL;SL4B_ObjectSubscriptionManager.prototype.setObjectCache = SL_AK;SL4B_ObjectSubscriptionManager.prototype.recordMultiUpdated = SL_GB;SL4B_ObjectSubscriptionManager.prototype.recordMultiUpdated2 = SL_II;SL4B_ObjectSubscriptionManager.prototype.deleteType2Level = SL_DB;SL4B_ObjectSubscriptionManager.prototype.type2Clear = SL_GE;SL4B_ObjectSubscriptionManager.prototype.type3Clear = SL_DP;SL4B_ObjectSubscriptionManager.prototype.clearAllSubscriptions = SL_JJ;SL4B_ObjectSubscriptionManager.prototype.dirUpdated = SL_EY;SL4B_ObjectSubscriptionManager.prototype.dirMultiUpdated = SL_NX;SL4B_ObjectSubscriptionManager.prototype.newsUpdated = SL_PD;SL4B_ObjectSubscriptionManager.prototype.objectInfo = SL_IC;SL4B_ObjectSubscriptionManager.prototype.storyUpdated = SL_BK;SL4B_ObjectSubscriptionManager.prototype.permissionUpdated = SL_MU;SL4B_ObjectSubscriptionManager.prototype.deleteAllPermissionEntries = SL_FK;SL4B_ObjectSubscriptionManager.prototype.deletePermissionEntry = SL_DV;SL4B_ObjectSubscriptionManager.prototype.objectStatus = SL_MI;SL4B_ObjectSubscriptionManager.prototype.splitFilter = SL_KK;SL4B_ObjectSubscriptionManager.prototype.sendStaleToAll = SL_JP;SL4B_ObjectSubscriptionManager.prototype.sendCurrentObjectStatusToAll = SL_QD;SL4B_ObjectSubscriptionManager.prototype.sendObjectStatusToAll = SL_LZ;SL4B_ObjectSubscriptionManager.prototype.structureChange = SL_LS;SL4B_ObjectSubscriptionManager.prototype.structureChange2 = SL_PR;SL4B_ObjectSubscriptionManager.prototype.structureMultiChange = SL_PE;SL4B_ObjectSubscriptionManager.prototype.structureMultiChange2 = SL_BZ;SL4B_ObjectSubscriptionManager.prototype.registerProxySubscriber = SL_QV;SL4B_ObjectSubscriptionManager.prototype.getProxySubscriber = SL_HZ;SL4B_ObjectSubscriptionManager.prototype.addContainerRequestData = SL_RC;SL4B_ObjectSubscriptionManager.prototype.getContainerRequestData = SL_DE;SL4B_ObjectSubscriptionManager.prototype.getContainer = function(A,B,D,E,C){SL4B_JavaScriptRttpProvider.checkWindowRange(E,C);var l_oListener=SL4B_AbstractRttpProvider.prototype.getListener(A);
var l_oProxyListener=SL4B_AbstractRttpProvider.prototype.getListener(new SL4B_ProxySubscriber(A));
var l_oContainerKey=new SL4B_ContainerKey();
this.addContainerRequestData(l_oListener,l_oContainerKey,B,D,E,C);var l_sCombinedFieldList=SL4B_AbstractRttpProvider.prototype.createFieldListForContainer(l_oContainerKey.getId(),D,E,C);
this.registerProxySubscriber(l_oListener,l_oProxyListener,B,l_sCombinedFieldList);this.requestObject(l_oListener,B,l_sCombinedFieldList);return l_oContainerKey;
};
SL4B_ObjectSubscriptionManager.prototype.setContainerWindow = function(A,C,B){SL4B_JavaScriptRttpProvider.checkWindowRange(C,B);var l_oRequestData=this.getContainerRequestData(A.getId());
var l_sOldCombinedFieldList=SL4B_AbstractRttpProvider.prototype.createFieldListForContainer(A.getId(),l_oRequestData.getFieldList(),l_oRequestData.getWindowStart(),l_oRequestData.getWindowEnd());
var l_oOldFilterAndFieldList=this.splitFilter(l_sOldCombinedFieldList);
this.removeObject(l_oRequestData.getSubscriberId(),l_oRequestData.getContainerName(),l_oOldFilterAndFieldList.m_sFilter,l_oOldFilterAndFieldList.m_sFieldList);l_oRequestData.setWindowStart(C);l_oRequestData.setWindowEnd(B);var l_sCombinedFieldList=SL4B_AbstractRttpProvider.prototype.createFieldListForContainer(A.getId(),l_oRequestData.getFieldList(),C,B);
var l_oFilterAndFieldList=this.splitFilter(l_sCombinedFieldList);
var l_sObjectKey=l_oRequestData.getContainerName()+l_oFilterAndFieldList.m_sFilter;
this.addObject(l_oRequestData.getSubscriberId(),l_oRequestData.getContainerName(),l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList);var l_sObjectRequestMessage=SL4B_ObjectCache.buildRTTPRequestMessage(l_oRequestData.getContainerName(),l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList);
this.m_oObjectCache.sendSubscriptionMessage(l_sObjectRequestMessage,{filter:l_oFilterAndFieldList.m_sFilter});};
function SL_RC(F,D,A,C,E,B){var l_oContainerRequestData=new SL4B_ContainerRequestData(F,D.getId(),A,C,E,B);
this.m_oContainerIdToRequestDataMap[D.getId()]=l_oContainerRequestData;}
function SL_DE(A){return this.m_oContainerIdToRequestDataMap[A];
}
function SL_QV(D,C,A,B){var l_oFilterAndFieldList=this.splitFilter(B);
var l_sObjectKey=A+l_oFilterAndFieldList.m_sFilter;
if(this.m_oContainerProxySubscribers[l_sObjectKey]==null){this.m_oContainerProxySubscribers[l_sObjectKey]=new Object();}this.m_oContainerProxySubscribers[l_sObjectKey][D]=C;}
function SL_HZ(C,A,B){var l_oFilterAndFieldList=this.splitFilter(B);
var l_sObjectKey=A+l_oFilterAndFieldList.m_sFilter;
if(this.m_oContainerProxySubscribers[l_sObjectKey]!=null){return this.m_oContainerProxySubscribers[l_sObjectKey][C];
}return null;
}
function SL_LS(A,C,D,B,E){if(typeof (E)!="undefined"){this.structureChange2(A,C,D,B,E);}else 
{for(l_sListenerId in this.m_pObjectSubscriptions[A]){this.structureChange2(A,C,D,B,l_sListenerId);}}}
function SL_PR(A,C,D,B,E){if(this.m_oContainerProxySubscribers[A]!=null){var l_sProxyListenerId=this.m_oContainerProxySubscribers[A][E];
if(l_sProxyListenerId!=null){if(B){this.addObject(l_sProxyListenerId,C,"","");if(this.m_oContainerObjects[A]==null){this.m_oContainerObjects[A]=new Object();}this.m_oContainerObjects[A][C]=C;}else 
{this.removeObject(l_sProxyListenerId,C,"","");if(this.m_oContainerObjects[A]!=null){delete this.m_oContainerObjects[A][C];}}}var l_oSubscription=this.m_pObjectSubscriptions[A][E];
l_oSubscription.m_oSubscriber.WTStructureChange(l_oSubscription.m_sObjectName,C,D,B);}}
function SL_PE(B,A,D,C,E){if(typeof (E)!="undefined"){this.structureMultiChange2(B,A,D,C,E);}else 
{for(l_sListenerId in this.m_pObjectSubscriptions[B]){this.structureMultiChange2(B,A,D,C,l_sListenerId);}}}
function SL_BZ(B,A,D,C,E){if(this.m_oContainerProxySubscribers[B]!=null){var l_oSubscription=this.m_pObjectSubscriptions[B][E];
l_oSubscription.m_oSubscriber.WTStructureMultiChange(l_oSubscription.m_sObjectName,A,D,C);}}
function SL_BP(){this.m_bStaleStatusSent=false;SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ObjectSubscriptionManager.reRequestObjects()");for(l_sObjectKey in this.m_pObjectSubscriptions){var l_pListenerMap=this.m_pObjectSubscriptions[l_sObjectKey];
for(l_oListenerId in l_pListenerMap){var l_oObjectSubscription=l_pListenerMap[l_oListenerId];
if(!l_oObjectSubscription.m_oSubscriber.m_bIsProxySubscriber){if(l_oObjectSubscription.isSubscribedToAllFields()){this.m_oObjectCache.requestObject(l_oObjectSubscription.m_sObjectName,l_oObjectSubscription.m_sFilter,"");}else 
{for(var l_nFieldList=0,l_nLength=l_oObjectSubscription.m_pFieldLists.length;l_nFieldList<l_nLength;++l_nFieldList){var l_sFieldList=l_oObjectSubscription.m_pFieldLists[l_nFieldList];
this.m_oObjectCache.requestObject(l_oObjectSubscription.m_sObjectName,l_oObjectSubscription.m_sFilter,l_sFieldList.replace(/^,/,"").replace(/,$/,""));}}}}}}
function SL_JP(){if(this.m_bStaleStatusSent===false){this.m_bStaleStatusSent=true;SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ObjectSubscriptionManager.sendStaleToAll()");this.sendObjectStatusToAll(GF_CachedObjectStatus.const_CONNECTION_LOST);}}
function SL_QD(){this.m_bStaleStatusSent=false;SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ObjectSubscriptionManager.sendCurrentObjectStatusToAll()");this.sendObjectStatusToAll(null);}
function SL_LZ(A){for(l_sObjectKey in this.m_pObjectSubscriptions){var l_pListenerMap=this.m_pObjectSubscriptions[l_sObjectKey];
for(l_oListenerId in l_pListenerMap){var l_oObjectSubscription=l_pListenerMap[l_oListenerId];
var l_oObjectStatus=((A===null) ? this.m_oObjectCache.getObjectStatus(l_sObjectKey) : A);
if(l_oObjectStatus!=null){l_oObjectSubscription.m_oSubscriber.WTObjectStatus(l_oObjectSubscription.m_sObjectName,l_oObjectStatus.m_nType,l_oObjectStatus.m_nCode,l_oObjectStatus.m_sMessage);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ObjectSubscriptionManager.sendObjectStatusToAll(): "+SL4B_ObjectSubscriptionManager.LOGMESSAGES.OBJECT_STATUS_WAS_NULL,l_sObjectKey);}}}}
function SL_GL(){this.m_sFilter="";this.m_sFieldList="";}
function SL_KK(A){var l_oReturn=new SL_GL();
var l_pFilter=new Array();
var l_sFilter="";
var l_sNewFieldList=A;
if(A!=null){var l_pNames=["imagefilter=","filter=","auto=","monitor=","ctrid="];
for(l_nName in l_pNames){var l_nFilterPos=l_sNewFieldList.indexOf(l_pNames[l_nName]);
if(l_nFilterPos!=-1){var l_nEndFilterPos=l_sNewFieldList.indexOf(",",l_nFilterPos);
if(l_nEndFilterPos!=-1){l_pFilter.push(l_sNewFieldList.substring(l_nFilterPos,l_nEndFilterPos));}else 
{l_pFilter.push(l_sNewFieldList.substring(l_nFilterPos));}var l_sOldFieldList=l_sNewFieldList;
l_sNewFieldList="";if(l_nFilterPos>0){l_sNewFieldList+=l_sOldFieldList.substring(0,l_nFilterPos);}if(l_nEndFilterPos!=-1&&l_nEndFilterPos<l_sOldFieldList.length){l_sNewFieldList+=l_sOldFieldList.substring(l_nEndFilterPos+1);}if(l_sNewFieldList.substring(l_sNewFieldList.length-1,l_sNewFieldList.length)==","){l_sNewFieldList=l_sNewFieldList.substring(0,l_sNewFieldList.length-1);}}}l_sFilter=l_pFilter.join(",");}else 
{l_sNewFieldList="";}l_oReturn.m_sFieldList=l_sNewFieldList;l_oReturn.m_sFilter=l_sFilter;return l_oReturn;
}
function SL_BQ(C,B,A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.requestObject: {0}, {1}, {2}",C,B,A);var l_oFilterAndFieldList=this.splitFilter(A);
var l_bIsValidObject=this.addObject(C,B,l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList);
if(l_bIsValidObject){this.m_oObjectCache.requestObject(B,l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList,C);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectSubscriptionManager.requestObject: attempt to request illegal object \"{0}\" ignored",B);}}
function SL_NY(C,A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.requestObjects: {0}, {1}, {2}",C,A,B);var l_oFilterAndFieldList=this.splitFilter(B);
var l_sValidatedObjectList="";
var l_pObjectNames=A.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
for(var l_nObject=0,l_nSize=l_pObjectNames.length;l_nObject<l_nSize;++l_nObject){var l_bIsValidObject=this.addObject(C,l_pObjectNames[l_nObject],l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList);
if(l_bIsValidObject){l_sValidatedObjectList+=((l_sValidatedObjectList=="") ? "" : SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER)+l_pObjectNames[l_nObject];}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectSubscriptionManager.requestObjects: attempt to request illegal object \"{0}\" ignored",l_pObjectNames[l_nObject]);}}if(l_sValidatedObjectList!=""){this.m_oObjectCache.requestObjects(l_sValidatedObjectList,l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList,C);}}
function SL_DI(C,B,A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.discardObject: {0}, {1}, {2}",C,B,A);var l_oFilterAndFieldList=this.splitFilter(A);
var l_sObjectKey=B+l_oFilterAndFieldList.m_sFilter;
var l_oContainedObjects=this.m_oContainerObjects[l_sObjectKey];
if(l_oContainedObjects!=null){var nCtridloc=A.indexOf("ctrid=");
if(nCtridloc>=0){var sCtrid=A.substring(nCtridloc+6);
if(sCtrid.indexOf(",")){sCtrid=sCtrid.substring(0,sCtrid.indexOf(","));}SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"ObjectSubscriptionManager.discardObject: ctrid={0}",sCtrid);delete this.m_oContainerIdToRequestDataMap[sCtrid];}var l_sProxyListenerId=this.m_oContainerProxySubscribers[l_sObjectKey][C];
if(l_sProxyListenerId!=null){for(l_sContainedObjectName in l_oContainedObjects){this.removeObject(l_sProxyListenerId,l_sContainedObjectName,"");this.m_oObjectCache.removeObjectFromCacheIfNoMoreReferences(l_sContainedObjectName,"");}}delete this.m_oContainerProxySubscribers[l_sObjectKey][C];}var l_bDiscardFromServer=this.removeObject(C,B,l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList);
if(l_bDiscardFromServer==true){this.m_oObjectCache.discardObject(B,l_oFilterAndFieldList.m_sFilter);delete this.m_oContainerObjects[l_sObjectKey];delete this.m_oContainerProxySubscribers[B];}else 
{this.m_oObjectCache.removeObjectFromCacheIfNoMoreReferences(B,l_oFilterAndFieldList.m_sFilter);}}
SL4B_ObjectSubscriptionManager.prototype._discarded = function(){};
function SL_LK(A,B,C){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.discardObjects: {0}, {1}, {2}",A,B,C);var l_oFilterAndFieldList=this.splitFilter(C);
var l_sValidatedObjectList="";
var l_pObjectNames=B.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
for(var l_nObject=0,l_nSize=l_pObjectNames.length;l_nObject<l_nSize;++l_nObject){var l_sObjectName=l_pObjectNames[l_nObject];
var l_sObjectKey=l_sObjectName+l_oFilterAndFieldList.m_sFilter;
var l_oContainedObjects=this.m_oContainerObjects[l_sObjectKey];
if(l_oContainedObjects!=null){var l_sProxyListenerId=this.m_oContainerProxySubscribers[l_sObjectKey][A];
if(l_sProxyListenerId!=null){for(l_sContainedObjectName in l_oContainedObjects){this.removeObject(l_sProxyListenerId,l_sContainedObjectName,"");}}delete this.m_oContainerProxySubscribers[l_sObjectKey][A];}var l_bDiscardFromServer=this.removeObject(A,l_sObjectName,l_oFilterAndFieldList.m_sFilter,l_oFilterAndFieldList.m_sFieldList);
if(l_bDiscardFromServer==true){l_sValidatedObjectList+=((l_sValidatedObjectList=="") ? "" : SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER)+l_pObjectNames[l_nObject];delete this.m_oContainerObjects[l_sObjectKey];delete this.m_oContainerProxySubscribers[l_sObjectName];}}if(l_sValidatedObjectList!=""){this.m_oObjectCache.discardObjects(l_sValidatedObjectList,l_oFilterAndFieldList.m_sFilter);}}
function SL_LG(D,C,B,A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.addObject: {0}, {1}, {2}, {3}",D,C,B,A);var l_bIsValidObject=this.isValidObject(C);
if(l_bIsValidObject){var l_sObjectKey=C+B;
if(this.m_pObjectSubscriptions[l_sObjectKey]===undefined){this.m_pObjectSubscriptions[l_sObjectKey]=new Object();}if(this.m_pObjectSubscriptions[l_sObjectKey][D]===undefined){this.m_pObjectSubscriptions[l_sObjectKey][D]=new SL4B_ObjectSubscription(D,C,B);}this.m_pObjectSubscriptions[l_sObjectKey][D].addFields(A);}return l_bIsValidObject;
}
function SL_CL(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.removeSubscriber: {0}",A);for(l_sObject in this.m_pObjectSubscriptions){for(l_sCurrListenerId in this.m_pObjectSubscriptions[l_sObject]){if(l_sCurrListenerId==A){this.discardObject(A,l_sObject,SL4B_ObjectSubscription.const_ALL_FIELDS);}}}}
function SL_QE(D,C,B,A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.removeObject: {0}, {1}, {2}",D,C,A);var l_bSendDiscard=this.isValidObject(C);
if(l_bSendDiscard){var l_sObjectKey=C+B;
var l_bCheckForDiscard=false;
if(this.m_pObjectSubscriptions[l_sObjectKey]===undefined){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectSubscriptionManager.removeObject: attempt to remove an object ({0}) that is not currently subscribed to",C);}else 
if(this.m_pObjectSubscriptions[l_sObjectKey][D]===undefined){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ObjectSubscriptionManager.removeObject: attempt to remove an object ({0}) that is not currently subscribed to by the specified listener ({1})",C,D);}else 
{var l_oObjectSubscription=this.m_pObjectSubscriptions[l_sObjectKey][D];
var l_bRemaining=l_oObjectSubscription.removeFields(A);
if(l_bRemaining==false){l_bCheckForDiscard=!l_oObjectSubscription.m_oSubscriber.m_bIsProxySubscriber;delete this.m_pObjectSubscriptions[l_sObjectKey][D];}}if(l_bCheckForDiscard){if(this.m_pObjectSubscriptions[l_sObjectKey]){for(l_oListenerId in this.m_pObjectSubscriptions[l_sObjectKey]){var l_oSubscriber=this.m_pObjectSubscriptions[l_sObjectKey][l_oListenerId].m_oSubscriber;
if(!l_oSubscriber.m_bIsProxySubscriber){l_bSendDiscard=false;break;
}}}}else 
{l_bSendDiscard=false;}}return l_bSendDiscard;
}
function SL_AK(A){this.m_oObjectCache=A;}
function SL_GB(A,C,D,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.recordMultiUpdated: {0}, {1}, {2}",A,C,D);if(typeof (B)!="undefined"){this.recordMultiUpdated2(A,C,D,B);}else 
{for(l_sListenerId in this.m_pObjectSubscriptions[A]){this.recordMultiUpdated2(A,C,D,l_sListenerId);}}}
function SL_II(D,A,C,B){var l_oSubscription=this.m_pObjectSubscriptions[D][B];
var l_bAllFields=l_oSubscription.isSubscribedToAllFields();
var l_oRecordFieldData=null;
if(l_bAllFields){l_oRecordFieldData=A;}else 
{l_oRecordFieldData=new SL4B_RecordFieldData();for(var l_nCount=0,l_nSize=A.size();l_nCount<l_nSize;l_nCount++){var l_sFieldName=A.getFieldName(l_nCount);
if(l_oSubscription.isSubscribedToField(l_sFieldName)){var l_sFieldValue=A.getFieldValue(l_nCount);
l_oRecordFieldData.add(l_sFieldName,l_sFieldValue);}}}if(l_oRecordFieldData.size()!=0){SL4B_MethodInvocationProxy.invoke(l_oSubscription.m_oSubscriber,"recordMultiUpdated",[l_oSubscription.m_sObjectName,l_oRecordFieldData,C]);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.recordMultiUpdated2: didn't invoke record multiupdated, as there were no updated fields {0}",l_oSubscription.m_sObjectName);}}
function SL_DB(B,A,C){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.deleteType2Level: {0}, {1}, {2}",B,A,C);for(l_sListenerId in this.m_pObjectSubscriptions[B]){var l_oSubscription=this.m_pObjectSubscriptions[B][l_sListenerId];
l_oSubscription.m_oSubscriber.WTFieldDeleted(l_oSubscription.m_sObjectName,A,C);}}
function SL_GE(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.type2Clear: {0}",A);for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
l_oSubscription.m_oSubscriber.WTType2Clear(l_oSubscription.m_sObjectName);}}
function SL_DP(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.type3Clear: {0}",A);for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
l_oSubscription.m_oSubscriber.WTType3Clear(l_oSubscription.m_sObjectName);}}
function SL_JJ(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.clearAllSubscriptions: {0}",A);for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
if(B==SL4B_RttpCodes.const_NOT_FOUND_DELAY||B==SL4B_RttpCodes.const_NOT_FOUND){l_oSubscription.m_oSubscriber.WTObjectNotFound(l_oSubscription.m_sObjectName);}else 
if(B==SL4B_RttpCodes.const_READ_DENY_DELAY||B==SL4B_RttpCodes.const_READ_DENY){l_oSubscription.m_oSubscriber.WTObjectReadDenied(l_oSubscription.m_sObjectName);}else 
if((B>SL4B_RttpCodes.const_READ_DENY_DELAY&&B<SL4B_RttpCodes.const_WRITE_DENY_DELAY)||(B>SL4B_RttpCodes.const_READ_DENY&&B<SL4B_RttpCodes.const_WRITE_DENY)){l_oSubscription.m_oSubscriber.WTObjectReadDenied(l_oSubscription.m_sObjectName,(B%10));}else 
if(B==SL4B_RttpCodes.const_WRITE_DENY_DELAY||B==SL4B_RttpCodes.const_WRITE_DENY){l_oSubscription.m_oSubscriber.WTObjectWriteDenied(l_oSubscription.m_sObjectName);}else 
if((B>SL4B_RttpCodes.const_WRITE_DENY_DELAY&&B<SL4B_RttpCodes.const_UNAVAILABLE_DELAY)||(B>SL4B_RttpCodes.const_WRITE_DENY&&B<SL4B_RttpCodes.const_UNAVAILABLE)){l_oSubscription.m_oSubscriber.WTObjectWriteDenied(l_oSubscription.m_sObjectName,(B%10));}else 
if(B==SL4B_RttpCodes.const_UNAVAILABLE_DELAY||B==SL4B_RttpCodes.const_UNAVAILABLE){l_oSubscription.m_oSubscriber.WTObjectUnavailable(l_oSubscription.m_sObjectName);}}}
function SL_EY(C,D,A,B,E){if(typeof (E)!="undefined"){var l_oSubscription=this.m_pObjectSubscriptions[C][E];
l_oSubscription.m_oSubscriber.WTDirUpdated(l_oSubscription.m_sObjectName,D,A,B);}else 
{for(l_sListenerId in this.m_pObjectSubscriptions[C]){var l_oSubscription=this.m_pObjectSubscriptions[C][l_sListenerId];
l_oSubscription.m_oSubscriber.WTDirUpdated(l_oSubscription.m_sObjectName,D,A,B);}}}
function SL_NX(A,B){for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
l_oSubscription.m_oSubscriber.WTDirMultiUpdated(l_oSubscription.m_sObjectName,B);}}
function SL_PD(A,D,C,B){for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
l_oSubscription.m_oSubscriber.WTNewsUpdated(l_oSubscription.m_sObjectName,D,C,B);}}
function SL_IC(B,C,D,A){for(l_sListenerId in this.m_pObjectSubscriptions[B]){var l_oSubscription=this.m_pObjectSubscriptions[B][l_sListenerId];
l_oSubscription.m_oSubscriber.WTObjectInfo(l_oSubscription.m_sObjectName,C,D,A);}}
function SL_BK(B,A){for(l_sListenerId in this.m_pObjectSubscriptions[B]){var l_oSubscription=this.m_pObjectSubscriptions[B][l_sListenerId];
for(var i=0;i<A.length;i++){if(i||A[i]){l_oSubscription.m_oSubscriber.WTStoryUpdated(B,A[i]||"\\n");}}}}
function SL_MU(A,B,C){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.permissionUpdated: {0}, {1}, {2}",A,B,C);for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
var l_bAllFields=l_oSubscription.isSubscribedToAllFields();
var l_oSubscribedFieldData=null;
if(l_bAllFields){l_oSubscribedFieldData=C;}else 
{l_oSubscribedFieldData=new SL4B_RecordFieldData();for(var l_nCount=0,l_nSize=C.size();l_nCount<l_nSize;l_nCount++){var l_sFieldName=C.getFieldName(l_nCount);
var l_sFieldValue=C.getFieldValue(l_nCount);
if(l_oSubscription.isSubscribedToField(l_sFieldName)){l_oSubscribedFieldData.add(l_sFieldName,l_sFieldValue);}}}if(l_oSubscribedFieldData.size()!=0){l_oSubscription.m_oSubscriber.WTPermissionUpdated(l_oSubscription.m_sObjectName,B,l_oSubscribedFieldData);}}}
function SL_FK(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.deleteAllPermissionEntries: {0}",A);for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
l_oSubscription.m_oSubscriber.WTPermissionDeleted(l_oSubscription.m_sObjectName,null);}}
function SL_DV(A,B){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscriptionManager.deleteAllPermissionEntries: {0}, {1}",A,B);for(l_sListenerId in this.m_pObjectSubscriptions[A]){var l_oSubscription=this.m_pObjectSubscriptions[A][l_sListenerId];
l_oSubscription.m_oSubscriber.WTPermissionDeleted(l_oSubscription.m_sObjectName,B);}}
function SL_MI(B,C,A,D){for(l_sListenerId in this.m_pObjectSubscriptions[B]){this.objectStatusForListener(B,C,A,D,l_sListenerId);}}
SL4B_ObjectSubscriptionManager.prototype.objectStatusForListener = function(B,C,A,D,E){var l_oSubscription=this.m_pObjectSubscriptions[B][E];
l_oSubscription.m_oSubscriber.WTObjectStatus(l_oSubscription.m_sObjectName,C,A,D);};
SL4B_ObjectSubscriptionManager.prototype.chat = function(A,C,D,B,E,F){if(F===undefined){for(l_sStoredListenerId in this.m_pObjectSubscriptions[A]){this.chat(A,C,D,B,E,l_sStoredListenerId);}}else 
{var l_oSubscription=this.m_pObjectSubscriptions[A][F];
l_oSubscription.m_oSubscriber.WTChat(l_oSubscription.m_sObjectName,C,D,B,E);}};
SL4B_ObjectSubscriptionManager.prototype._getConnectionManager = function(){return this.m_oConnectionListener;
};
var LF_ObjectSubscriptionManagerConnectionListener=function(A){this.m_oObjectSubscriptionManager=A;};
LF_ObjectSubscriptionManagerConnectionListener.prototype = new SL4B_ConnectionListener;LF_ObjectSubscriptionManagerConnectionListener.prototype.connectionWarning = function(C,D,B,A){this.m_oObjectSubscriptionManager.sendStaleToAll();};
function GF_ActionSubscriptionManager(){this.CLASS_NAME="GF_ActionSubscriptionManager";}
SL4B_ActionSubscriptionManager=GF_ActionSubscriptionManager;GF_ActionSubscriptionManager.prototype.sendActionMessage = SL_KI;GF_ActionSubscriptionManager.prototype.contribObject = SL_RD;GF_ActionSubscriptionManager.prototype.createObject = SL_KT;GF_ActionSubscriptionManager.prototype.deleteObject = SL_QU;GF_ActionSubscriptionManager.prototype.throttleObjects = SL_LU;GF_ActionSubscriptionManager.prototype.throttleGlobal = SL_JZ;function SL_KI(A,B){SL4B_Accessor.getUnderlyingRttpProvider().getManagedConnection().sendMessage(B,A);}
function SL_RD(C,A,B){var l_nLength=B.size();
var pContribMessage=new Array(2+l_nLength);
pContribMessage[0]="CONTRIB ";pContribMessage[1]=GF_RequestEncoder.encodeRttpData(A);for(var l_nField=0;l_nField<l_nLength;++l_nField){var l_oField=B.getField(l_nField);
pContribMessage[2+l_nField]=" "+GF_RequestEncoder.encodeRttpData(l_oField.m_sName)+"="+GF_RequestEncoder.encodeRttpData(l_oField.m_sValue);}var l_oActionSubscription=new SL_BW(C,A,B);
this.sendActionMessage(l_oActionSubscription,pContribMessage.join(""));}
function SL_KT(A,B){var l_sCreationMessage="CREATE "+GF_RequestEncoder.encodeRttpData(A)+";"+B;
this.sendActionMessage(new SL_MC(A,B),l_sCreationMessage);}
function SL_LU(A,B){if(SL4B_ThrottleLevel.isValid(B)===false){throw new SL4B_Exception("'"+B+"' is not a valid throttle level.");
}var l_pObjectNames=A.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
for(var i=0;i<l_pObjectNames.length;i++){l_pObjectNames[i]=GF_RequestEncoder.encodeRttpData(l_pObjectNames[i]);}var l_sThrottleMessage="THROTTLE "+l_pObjectNames.join(";"+B+" ")+";"+B;
this.sendActionMessage(new SL_CY(B,false),l_sThrottleMessage);}
function SL_JZ(A){if(SL4B_ThrottleLevel.isValid(A)===false){throw new SL4B_Exception("'"+A+"' is not a valid throttle level.");
}this.sendActionMessage(new SL_CY(A,true),"GLOBAL_THROTTLE "+A);}
function SL_QU(A){var l_sDeletionMessage="DELETE "+GF_RequestEncoder.encodeRttpData(A);
this.sendActionMessage(new SL_JS(A),l_sDeletionMessage);}
function SL_MW(){}
SL_MW.prototype.receiveMessage = function(A,B){throw new SL4B_Error("AbstractActionSubscription.receiveMessage: method not implemented");
};
function SL_BW(C,A,B){this.m_oSubscriber=eval(C);this.m_sObjectName=A;this.m_oFieldData=B;}
SL_BW.prototype = new SL_MW;SL_BW.prototype.receiveMessage = function(B,A){var l_nRttpCode=B.getRttpCode();
switch(l_nRttpCode){
case SL4B_RttpCodes.const_CONTRIB_OK:case SL4B_RttpCodes.const_CONTRIB_OK_DELAY:this.m_oSubscriber.WTContribOk(this.m_sObjectName);break;
case SL4B_RttpCodes.const_CONTRIB_WAIT:break;
default :var nAuthCode=this.getAuthCode(l_nRttpCode);
if(nAuthCode===undefined){this.m_oSubscriber.WTContribFailed(this.m_sObjectName,this.getFailureDescription(l_nRttpCode));}else 
{this.m_oSubscriber.WTContribFailed(this.m_sObjectName,this.getFailureDescription(l_nRttpCode),nAuthCode);}break;
}};
SL_BW.prototype.getFailureDescription = function(A){var l_sDescription;
switch(A){
case SL4B_RttpCodes.const_NOT_FOUND:case SL4B_RttpCodes.const_NOT_FOUND_DELAY:l_sDescription="Object not found";break;
case SL4B_RttpCodes.const_UNAVAILABLE:case SL4B_RttpCodes.const_UNAVAILABLE_DELAY:l_sDescription="Object unavailable";break;
case SL4B_RttpCodes.const_DELETED_DELAY:case SL4B_RttpCodes.const_CONTRIB_FAILED:default :if((A>=SL4B_RttpCodes.const_READ_DENY_DELAY&&A<SL4B_RttpCodes.const_WRITE_DENY_DELAY)||(A>=SL4B_RttpCodes.const_READ_DENY&&A<SL4B_RttpCodes.const_WRITE_DENY)){l_sDescription="Read denied";}else 
if((A>=SL4B_RttpCodes.const_WRITE_DENY_DELAY&&A<SL4B_RttpCodes.const_UNAVAILABLE_DELAY)||(A>=SL4B_RttpCodes.const_WRITE_DENY&&A<SL4B_RttpCodes.const_UNAVAILABLE)){l_sDescription="Write denied";}else 
{l_sDescription="Unknown failure code ("+A+")";}}return l_sDescription;
};
SL_BW.prototype.getAuthCode = function(A){var l_nAuthCode;
if((A>SL4B_RttpCodes.const_READ_DENY_DELAY&&A<SL4B_RttpCodes.const_WRITE_DENY_DELAY)||(A>SL4B_RttpCodes.const_READ_DENY&&A<SL4B_RttpCodes.const_WRITE_DENY)||(A>SL4B_RttpCodes.const_WRITE_DENY_DELAY&&A<SL4B_RttpCodes.const_UNAVAILABLE_DELAY)||(A>SL4B_RttpCodes.const_WRITE_DENY&&A<SL4B_RttpCodes.const_UNAVAILABLE)){l_nAuthCode=A%10;}return l_nAuthCode;
};
function SL_MC(A,B){this.m_sObjectName=A;this.m_sRttpType=B;}
SL_MC.prototype = new SL_MW;SL_MC.prototype.receiveMessage = function(B,A){var l_nRttpCode=B.getRttpCode();
switch(l_nRttpCode){
case SL4B_RttpCodes.const_CREATE_OK:break;
default :break;
}};
function SL_CY(A,B){this.m_sThrottleStatus=A;this.m_bIsGlobal=B;}
SL_CY.prototype = new SL_MW;SL_CY.prototype.receiveMessage = function(B,A){var l_nRttpCode=B.getRttpCode();
switch(l_nRttpCode){
case SL4B_RttpCodes.const_THROTTLE_OK:break;
default :break;
}};
function SL_JS(A){this.m_sObjectName=A;}
SL_JS.prototype = new SL_MW;SL_JS.prototype.receiveMessage = function(B,A){var l_nRttpCode=B.getRttpCode();
switch(l_nRttpCode){
case SL4B_RttpCodes.const_DELETE_OK:break;
default :break;
}};
var SL4B_ObjectSubscription=function(){};
if(false){function SL4B_ObjectSubscription(){}
}SL4B_ObjectSubscription = function(B,E,D,C){this.m_sSubscriptionId=B;this.m_oSubscriber=eval(B);this.m_sObjectName=E;this.m_sFilter=D;this.m_pFieldLists=new Array();this.m_bAllFields=false;this.normaliseFieldList = function(A){var l_sReturnList=A;
if(typeof (A)!="undefined"&&A!=null&&A!=SL4B_ObjectSubscription.const_ALL_FIELDS){if(A.charAt(0)!=","){l_sReturnList=","+l_sReturnList;}if(A.charAt(A.length-1)!=","){l_sReturnList+=",";}}return l_sReturnList;
};
if(typeof (C)!="undefined"){this.addFields(C);}};
SL4B_ObjectSubscription.const_ALL_FIELDS="";SL4B_ObjectSubscription.isAllFields = function(A){return (typeof A=="undefined"||A==null||A==SL4B_ObjectSubscription.const_ALL_FIELDS);
};
SL4B_ObjectSubscription.prototype.addFields = SL_AN;SL4B_ObjectSubscription.prototype.removeFields = SL_BI;SL4B_ObjectSubscription.prototype.isSubscribedToField = SL_LX;SL4B_ObjectSubscription.prototype.isSubscribedToAllFields = SL_CF;function SL_AN(A){A=this.normaliseFieldList(A);SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscription.addFields: {0}",A);if(A==null||typeof A=="undefined"){A=SL4B_ObjectSubscription.const_ALL_FIELDS;}if(A==SL4B_ObjectSubscription.const_ALL_FIELDS){this.m_bAllFields=true;}var l_bFound=false;
for(var l_nFieldList=0,l_nLength=this.m_pFieldLists.length;l_nFieldList<l_nLength;++l_nFieldList){if(this.m_pFieldLists[l_nFieldList]==A){l_bFound=true;break;
}}if(!l_bFound){this.m_pFieldLists.push(A);}}
function SL_BI(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ObjectSubscription.removeFields: {0}",A);A=this.normaliseFieldList(A);if(A==null||typeof A=="undefined"){A=SL4B_ObjectSubscription.const_ALL_FIELDS;}var l_bFound=false;
if(A==SL4B_ObjectSubscription.const_ALL_FIELDS){this.m_bAllFields=false;this.m_pFieldLists=new Array();}else 
{var l_nFieldList=0;
while(l_nFieldList<this.m_pFieldLists.length){if(this.m_pFieldLists[l_nFieldList]==A){this.m_pFieldLists.splice(l_nFieldList,1);}else 
{l_bFound=true;l_nFieldList++;}}}return l_bFound;
}
function SL_LX(A){var l_bIsSubscribed=false;
var l_sTestFieldName=","+A+",";
for(var l_nFieldList=0,l_nLength=this.m_pFieldLists.length;l_nFieldList<l_nLength;++l_nFieldList){if(this.m_pFieldLists[l_nFieldList]==SL4B_ObjectSubscription.const_ALL_FIELDS||this.m_pFieldLists[l_nFieldList].indexOf(l_sTestFieldName)!=-1){l_bIsSubscribed=true;break;
}}return l_bIsSubscribed;
}
function SL_CF(){return this.m_bAllFields;
}
function GF_CachedObjectStatus(E,D,F){this.m_nType=E;this.m_nCode=D;this.m_sMessage=F;this.updateStatus = function(B,A,C){this.m_nType=B;this.m_nCode=A;this.m_sMessage=C;};
}
GF_CachedObjectStatus.const_CONNECTION_LOST=new GF_CachedObjectStatus(SL4B_ObjectStatus.STALE,0,"Liberator connection lost");GF_CachedObjectStatus.const_SUBSCRIBING=new GF_CachedObjectStatus(SL4B_ObjectStatus.STALE,0,"Subscribing to object");var SL4B_RttpMessage=function(){};
if(false){function SL4B_RttpMessage(){}
}SL4B_RttpMessage = function(){this.m_nRttpCode=null;this.m_sSequenceNumber=null;this.m_sObjectNumber=null;this.m_sMessageContent=null;this.m_pMultipleLineContents=null;this.m_bIsMessageComplete=true;};
SL4B_RttpMessage.const_RTTP_CODE_SIZE=2;SL4B_RttpMessage.const_SEQUENCE_NUMBER_SIZE=2;SL4B_RttpMessage.const_OBJECT_NUMBER_SIZE=4;SL4B_RttpMessage.const_MAXIMUM_MESSAGE_CODE_SIZE=SL4B_RttpMessage.const_RTTP_CODE_SIZE+SL4B_RttpMessage.const_SEQUENCE_NUMBER_SIZE+SL4B_RttpMessage.const_OBJECT_NUMBER_SIZE;SL4B_RttpMessage.const_MESSAGE_CODE_END=" ";SL4B_RttpMessage.const_NO_MESSAGE_CONTENT="";SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_START="-";SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_END=".";SL4B_RttpMessage.prototype.setMessage = SL_CD;SL4B_RttpMessage.prototype.internalConstructor = SL_MR;SL4B_RttpMessage.prototype.isMessageComplete = function(){return this.m_bIsMessageComplete;
};
SL4B_RttpMessage.prototype.getRttpCode = function(){return this.m_nRttpCode;
};
SL4B_RttpMessage.prototype.getSequenceNumber = function(){return this.m_sSequenceNumber;
};
SL4B_RttpMessage.prototype.getObjectNumber = function(){return this.m_sObjectNumber;
};
SL4B_RttpMessage.prototype.getMessageContent = function(){return this.m_sMessageContent;
};
SL4B_RttpMessage.prototype.isMultipleLineMessage = function(){return (this.m_pMultipleLineContents!=null);
};
SL4B_RttpMessage.prototype.getMultipleLineContents = function(){return this.m_pMultipleLineContents;
};
SL4B_RttpMessage.prototype.toString = function(){return this.m_nRttpCode+((this.m_sSequenceNumber==null) ? "" : " {"+this.m_sSequenceNumber+"}")+((this.m_sObjectNumber==null) ? "" : " ["+this.m_sObjectNumber+"]")+": "+this.m_sMessageContent;
};
function SL_CD(B,A){if(this.m_bIsMessageComplete){this.m_nRttpCode=null;this.m_sSequenceNumber=null;this.m_sObjectNumber=null;this.m_sMessageContent=SL4B_RttpMessage.const_NO_MESSAGE_CONTENT;this.m_pMultipleLineContents=null;}return this.internalConstructor(B,A);
}
function SL_MR(B,A){if(A>=B.length){throw new SL4B_Exception("An illegal message index ("+A+") was received");
}var l_sRttpMessage=B[A];
if(l_sRttpMessage==null){throw new SL4B_Exception("A null RTTP message was received");
}var l_bIsMultipleLineMessage=false;
if(!this.m_bIsMessageComplete){l_bIsMultipleLineMessage=true;}else 
{var l_nMessageCodeEnd=l_sRttpMessage.indexOf(SL4B_RttpMessage.const_MESSAGE_CODE_END);
if(l_nMessageCodeEnd==-1){var l_nMessageLength=l_sRttpMessage.length;
if(l_sRttpMessage.charAt(l_nMessageLength-1)==SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_START&&l_nMessageLength!=2&&l_nMessageLength!=4&&l_nMessageLength!=6&&l_nMessageLength!=8){l_bIsMultipleLineMessage=true;l_nMessageCodeEnd=l_sRttpMessage.length-1;}else 
{l_nMessageCodeEnd=l_sRttpMessage.length;}}if(l_nMessageCodeEnd>SL4B_RttpMessage.const_MAXIMUM_MESSAGE_CODE_SIZE){if(l_sRttpMessage.charAt(SL4B_RttpMessage.const_MAXIMUM_MESSAGE_CODE_SIZE)==SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_START){l_nMessageCodeEnd=SL4B_RttpMessage.const_MAXIMUM_MESSAGE_CODE_SIZE;l_bIsMultipleLineMessage=true;}else 
if(l_sRttpMessage.charAt(6)==SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_START){l_nMessageCodeEnd=6;l_bIsMultipleLineMessage=true;}else 
if(l_sRttpMessage.charAt(4)==SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_START){l_nMessageCodeEnd=4;l_bIsMultipleLineMessage=true;}else 
if(l_sRttpMessage.charAt(2)==SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_START){l_nMessageCodeEnd=2;l_bIsMultipleLineMessage=true;}}var l_nPosition=SL4B_RttpMessage.const_RTTP_CODE_SIZE;
switch(l_nMessageCodeEnd){
case 2:break;
case 4:this.m_sSequenceNumber=l_sRttpMessage.substr(l_nPosition,SL4B_RttpMessage.const_SEQUENCE_NUMBER_SIZE);l_nPosition+=SL4B_RttpMessage.const_SEQUENCE_NUMBER_SIZE;break;
case 6:this.m_sObjectNumber=l_sRttpMessage.substr(l_nPosition,SL4B_RttpMessage.const_OBJECT_NUMBER_SIZE);l_nPosition+=SL4B_RttpMessage.const_OBJECT_NUMBER_SIZE;break;
case 8:this.m_sSequenceNumber=l_sRttpMessage.substr(l_nPosition,SL4B_RttpMessage.const_SEQUENCE_NUMBER_SIZE);l_nPosition+=SL4B_RttpMessage.const_SEQUENCE_NUMBER_SIZE;this.m_sObjectNumber=l_sRttpMessage.substr(l_nPosition,SL4B_RttpMessage.const_OBJECT_NUMBER_SIZE);l_nPosition+=SL4B_RttpMessage.const_OBJECT_NUMBER_SIZE;break;
default :throw new SL4B_Exception("Unknown RTTP message received '"+l_sRttpMessage+"'");
}this.m_nRttpCode=GF_Base64Decoder.decodeRttpCode(l_sRttpMessage.substr(0,SL4B_RttpMessage.const_RTTP_CODE_SIZE));if(l_sRttpMessage.length>=l_nPosition+1){this.m_sMessageContent=l_sRttpMessage.substr(l_nPosition+1);}}if(l_bIsMultipleLineMessage){if(this.m_bIsMessageComplete){this.m_pMultipleLineContents=new Array();}var l_nStartPos=((this.m_bIsMessageComplete) ? A+1 : A);
this.m_bIsMessageComplete=false;for(var l_nLine=l_nStartPos,l_nLength=B.length;l_nLine<l_nLength;++l_nLine){if(l_nLine>A){++A;}if(B[l_nLine]==SL4B_RttpMessage.const_MULTIPLE_LINE_MESSAGE_END){this.m_bIsMessageComplete=true;break;
}else 
{this.m_pMultipleLineContents.push(B[l_nLine]);}}}else 
{this.m_bIsMessageComplete=true;}return A;
}
var SL4B_Type1RecordCache=function(){};
if(false){function SL4B_Type1RecordCache(){}
}SL4B_Type1RecordCache = function(){this.m_pFieldCache=new Object();};
SL4B_Type1RecordCache.prototype.addField = SL4B_Type1RecordCache_AddField;SL4B_Type1RecordCache.prototype.getField = SL4B_Type1RecordCache_GetField;function SL4B_Type1RecordCache_AddField(B,A){this.m_pFieldCache[B]=A;}
function SL4B_Type1RecordCache_GetField(A){return this.m_pFieldCache[A];
}
var SL4B_Type2RecordCache=function(){};
if(false){function SL4B_Type2RecordCache(){}
}SL4B_Type2RecordCache = function(){this.m_sIndexFieldName=null;this.m_pLevelCache=new Object();};
SL4B_Type2RecordCache.prototype.addField = SL_MO;SL4B_Type2RecordCache.prototype.getField = SL_LI;SL4B_Type2RecordCache.prototype.deleteLevel = SL_HA;SL4B_Type2RecordCache.prototype.dump = SL_JK;function SL_MO(B,C,A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Type2RecordCache.addField: {0}, {1}, {2}",B,C,A);if(typeof this.m_pLevelCache[B]=="undefined"){this.m_pLevelCache[B]=new Object();}this.m_pLevelCache[B][C]=A;}
function SL_HA(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Type2RecordCache.deleteLevel: {0}",A);if(typeof this.m_pLevelCache[A]!="undefined"){delete this.m_pLevelCache[A];}}
function SL_JK(){for(l_sLevel in this.m_pLevelCache){var l_oFields=this.m_pLevelCache[l_sLevel];
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Level: {0}",l_sLevel);for(l_sFieldName in l_oFields){var l_sValue=l_oFields[l_sFieldName];
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"\t{0}={1}",l_sFieldName,l_sValue);}}}
function SL_LI(A,B){var l_oFieldCache=this.m_pLevelCache[A];
var l_sValue=null;
if(typeof l_oFieldCache=="undefined"){l_sValue=null;}else 
{l_sValue=l_oFieldCache[B];if(typeof l_sValue=="undefined"){l_sValue=null;}}return l_sValue;
}
function SL_NL(){this.m_pLevelCache=new Array();}
SL_NL.prototype.getField = SL_HU;SL_NL.prototype.dump = SL_BM;function SL_HU(A,B){var l_oFieldCache=this.m_pLevelCache[A];
var l_sValue=null;
if(typeof l_oFieldCache=="undefined"){l_sValue=null;}else 
{l_sValue=l_oFieldCache[B];if(typeof l_sValue=="undefined"){l_sValue=null;}}return l_sValue;
}
function SL_BM(){for(l_sLevel in this.m_pLevelCache){var l_oFields=this.m_pLevelCache[l_sLevel];
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Level: {0}",l_sLevel);for(l_sFieldName in l_oFields){var l_sValue=l_oFields[l_sFieldName];
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"\t{0}={1}",l_sFieldName,l_sValue);}}}
var SL4B_NewsStoryCache=function(){};
if(false){function SL4B_NewsStoryCache(){}
}SL4B_NewsStoryCache = function(){this.m_pTextLines=new Array();};
SL4B_NewsStoryCache.prototype.isNewsStory = true;SL4B_NewsStoryCache.prototype.setTextLines = SL4B_NewsStoryCache_SetTextLines;SL4B_NewsStoryCache.prototype.addTextLines = SL4B_NewsStoryCache_AddTextLines;SL4B_NewsStoryCache.prototype.getTextLines = SL4B_NewsStoryCache_GetTextLines;function SL4B_NewsStoryCache_SetTextLines(A){if(!A||typeof A!="object"||typeof A.length=="undefined"){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"SL4B_NewsStoryCache.setTextLines: attempt to set invalid value for l_pTextLines");}else 
{this.m_pTextLines=new Array();for(var l_nLine=0,l_nLength=A.length;l_nLine<l_nLength;++l_nLine){this.m_pTextLines[l_nLine]=GF_ResponseDecoder.decodeRttpData(A[l_nLine]);}}}
function SL4B_NewsStoryCache_GetTextLines(){return this.m_pTextLines;
}
function SL4B_NewsStoryCache_AddTextLines(A){for(var i=0;i<A.length;i++){if(A[i]==""){if(this.m_pTextLines.length){this.m_pTextLines.push("\\n");}}else 
{this.m_pTextLines.push(GF_ResponseDecoder.decodeRttpData(A[i]));}}}
var SL4B_DirectoryCache=function(){};
if(false){function SL4B_DirectoryCache(){}
}SL4B_DirectoryCache = function(){this.m_pListing=new Object();};
SL4B_DirectoryCache.prototype.dump = SL_GW;function SL_GW(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"DirectoryCache.dump()");for(l_sObject in this.m_pListing){var l_sType=this.m_pListing[l_sObject];
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"\t{0} ({1})",l_sObject,l_sType);}}
var SL4B_ContainerCache=function(){};
if(false){function SL4B_ContainerCache(){}
}SL4B_ContainerCache = function(){this.m_bisDirectory=false;this.m_oListing=new Object();this.m_mObjectNameToNumberMap=new Object();this.m_oOrdering=new Object();this.m_oObjectNameToIdMap=new Object();this.m_nSize=0;};
SL4B_ContainerCache.prototype.addEntry = function(B,C,A){this.m_oListing[B]=C;this.m_mObjectNameToNumberMap[B]=A;};
SL4B_ContainerCache.prototype.removeEntry = function(A){delete this.m_oListing[A];delete this.m_mObjectNameToNumberMap[A];};
SL4B_ContainerCache.prototype.addOrdering = function(B,A){this.m_oOrdering[B]=A;};
SL4B_ContainerCache.prototype.getOrdering = function(A){return this.m_oOrdering[A];
};
SL4B_ContainerCache.prototype.removeOrdering = function(A){delete this.m_oOrdering[A];};
SL4B_ContainerCache.prototype.addToNameIdMap = function(A,B){this.m_oObjectNameToIdMap[A]=B;};
SL4B_ContainerCache.prototype.removeFromNameIdMap = function(A){delete this.m_oObjectNameToIdMap[A];};
SL4B_ContainerCache.prototype.getObjectNameToObjectTypeMap = function(){return this.m_oListing;
};
SL4B_ContainerCache.prototype.dump = SL_EP;SL4B_ContainerCache.prototype.getSize = function(){return this.m_nSize;
};
SL4B_ContainerCache.prototype.setSize = function(A){this.m_nSize=A;};
SL4B_ContainerCache.prototype.setDirectory = function(A){this.m_bIsDirectory=A;};
SL4B_ContainerCache.prototype.isDirectory = function(){return this.m_bIsDirectory;
};
function SL_EP(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ContainerCache.dump()");for(l_sObject in this.m_oListing){var l_sType=this.m_oListing[l_sObject];
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"\t{0} ({1})",l_sObject,l_sType);}}
var SL4B_NewsHeadlineCache=function(){};
if(false){function SL4B_NewsHeadlineCache(){}
}SL4B_NewsHeadlineCache = function(){this.m_pHeadlines=new Array();};
SL4B_NewsHeadlineCache.m_HEADLINE_CACHE_LIMIT=200;SL4B_NewsHeadlineCache.const_SIZE_FIELD="size";SL4B_NewsHeadlineCache.prototype.addHeadline = function(C,B,A){if(this.m_pHeadlines.length>=SL4B_NewsHeadlineCache.m_HEADLINE_CACHE_LIMIT){this.m_pHeadlines.shift();}this.m_pHeadlines.push(new SL_HD(C,B,A));};
SL4B_NewsHeadlineCache.prototype.getHeadline = function(A){return ((A<this.m_pHeadlines.length) ? this.m_pHeadlines[A] : null);
};
SL4B_NewsHeadlineCache.prototype.getSize = function(){return this.m_pHeadlines.length;
};
function SL_HD(C,B,A){this.m_sStoryCode=C;this.m_sHeadline=B;this.m_sDate=A;}
function GF_ChatCache(A){this.m_sObjectKey=A;this.m_pCachedData=[];}
GF_ChatCache.prototype.addToCache = function(A){if(A[GF_ChatFields.STATUS]==SL4B_ChatStatus.SUBSCRIBED){this.m_pCachedData=[];this.m_pCachedData.push(A);}else 
if(A[GF_ChatFields.STATUS]==SL4B_ChatStatus.USER_SUBSCRIBED){if(this.m_pCachedData.length>0&&this.m_pCachedData[0][GF_ChatFields.USER]===A[GF_ChatFields.USER]){this.m_pCachedData.push(A);}}};
GF_ChatCache.prototype.sendCachedData = function(B,A){for(var i=0,nLength=this.m_pCachedData.length;i<nLength;++i){B._$sendChat(this.m_sObjectKey,this.m_pCachedData[i],A);}};
var SL4B_BaseStreamingConnection=function(){};
if(false){function SL4B_BaseStreamingConnection(){}
}SL4B_BaseStreamingConnection = function(D,C,E,B,A){this.CLASS_NAME="SL4B_BaseStreamingConnection";this.m_nConnectedState=0;this.m_nMessageCount=0;this.m_oCurrentConnectionData=C;this.m_nReconnectCount=A;this.m_sResponseFrameUrl=B;this.initialise(D,"/"+E);};
SL4B_BaseStreamingConnection.prototype = new SL4B_AbstractConnection;SL4B_BaseStreamingConnection.prototype.connect = SL_JW;SL4B_BaseStreamingConnection.prototype.getScriptPathUrl = SL_JA;SL4B_BaseStreamingConnection.prototype.reconnect = SL_LF;SL4B_BaseStreamingConnection.prototype.setResponseHttpRequest = SL_KD;SL4B_BaseStreamingConnection.prototype.start = SL_FX;SL4B_BaseStreamingConnection.prototype.super_stop = SL4B_BaseStreamingConnection.prototype.stop;SL4B_BaseStreamingConnection.prototype.stop = SL_FE;SL4B_BaseStreamingConnection.prototype.super_parseRttpMessage = SL4B_BaseStreamingConnection.prototype.parseRttpMessage;SL4B_BaseStreamingConnection.prototype.parseRttpMessage = SL_AH;SL4B_BaseStreamingConnection.prototype.super_processRttpMessageBlock = SL4B_AbstractConnection.prototype.processRttpMessageBlock;SL4B_BaseStreamingConnection.RTTP_MESSAGE_REG_EXP=/^[0-9A-Za-z-_]{2,2}([0-9A-Za-z-_]{2,2})[0-9A-Za-z-_]{4,4}/;function SL_JW(){SL4B_Logger.logConnectionMessage(false,"BaseStreamingConnection.connect");this.m_nMessageCount=0;if(this.m_nConnectedState==0&&this.m_oRequestHttpRequest!=null){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"  connecting...");var l_sResponseFrameUrl;
var l_oMatch=this.m_oCurrentConnectionData.getServerUrl().match(/(https?:\/\/[^\/]+)/);
if(l_oMatch!=null){l_sResponseFrameUrl=l_oMatch[1]+this.m_sResponseFrameUrl;}else 
{l_sResponseFrameUrl=this.m_sResponseFrameUrl;}l_sResponseFrameUrl+="?X-RTTP-Type5-Pad-Length="+SL4B_Accessor.getConfiguration().getType5PadLength();if(!SL4B_Accessor.getConfiguration().isSuppressExceptions()||SL4B_JsUnit.isUnobfuscated()){l_sResponseFrameUrl+="&suppressexceptions=false";}this.m_sResponseUniqueId=this.createChannel(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID,l_sResponseFrameUrl);this.m_nConnectedState=1;SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"BaseStreamingConnection.connect: Connecting to Liberator {0}",l_sResponseFrameUrl);C_CallbackQueue.addCallback(new Array(SL4B_Accessor.getUnderlyingRttpProvider(),"notifyConnectionListeners",this.m_oRttpProvider.const_INFO_CONNECTION_EVENT,"Establishing streaming connection (URL: "+l_sResponseFrameUrl+")"));}}
function SL_JA(A,B){var l_sRootUrl=SL4B_ScriptLoader.getRootUrl();
if(!l_sRootUrl.match(/^https?:\/\/./)){if(l_sRootUrl.charAt(0)=="/"){l_sRootUrl=B.match(/^https?:\/\/[^\/]*/)[0]+l_sRootUrl;}else 
{var l_sPageRoot=B.replace(/\?.*$/,"").replace(/\/[^\/]+$/,"");
l_sRootUrl=l_sPageRoot.replace(/\/$/,"")+"/"+l_sRootUrl.replace(/(^\/)/,"");}var l_oRegExp=new RegExp("\\/[^/.]+\\/\\.\\.");
var l_oMatch;
while((l_oMatch=l_sRootUrl.match(l_oRegExp))){l_sRootUrl=l_sRootUrl.replace(l_oRegExp,"");}}return l_sRootUrl+"sl4b/javascript-rttp-provider";
}
function SL_AH(A){if(this.m_nConnectedState==2){this.super_parseRttpMessage(A);this.m_nMessageCount++;}}
SL4B_BaseStreamingConnection.prototype.processRttpMessageBlock = function(A){if(this._isValidMessageBlock(A)){this.super_processRttpMessageBlock(A);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"Received {0} message(s) unexpectedly before logged in, first message: {1}",A.length,A[0]);}};
SL4B_BaseStreamingConnection.prototype._isValidMessageBlock = function(A){var bIsConnectedAndLoggedIn=(this.m_nConnectedState===2);
return (bIsConnectedAndLoggedIn||this._messageBlockContainsExpectedSequenceNumber(A));
};
SL4B_BaseStreamingConnection.prototype._messageBlockContainsExpectedSequenceNumber = function(A){var sCurrentEncodedSequenceNumber=this.getLastSequenceNumber();
var nNextExpectedSequenceNumber=GF_Base64Decoder.decodeNextExpectedSequenceNumber(sCurrentEncodedSequenceNumber);
for(var i=0,nLength=A.length;i<nLength;++i){var oMatch=A[i].match(SL4B_BaseStreamingConnection.RTTP_MESSAGE_REG_EXP);
if(oMatch!==null){var nMessageSequenceNumber=GF_Base64Decoder.decodeSequenceNumber(oMatch[1]);
return (nMessageSequenceNumber===nNextExpectedSequenceNumber);
}}return true;
};
SL4B_BaseStreamingConnection.prototype.messageBlockComplete = function(){if(this.m_nConnectedState==2&&this.m_nMessageCount>this.m_nReconnectCount){this.reconnect();}};
function SL_LF(){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"BaseStreamingConnection.reconnect()");var oConnectionManager=this.m_oRttpProvider.m_oConnectionManager;
var oManagedConnection=this.m_oRttpProvider.getManagedConnection();
if(oManagedConnection._$isFullReconnectRequired()){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"BaseStreamingConnection.reconnect: not attempting to reconnect as there are stateful responses outstanding");}else 
{SL4B_Logger.logConnectionMessage(true,"Message limit {0} has been reached (message count {1}), attempting session reconnect",this.m_nReconnectCount,this.m_nMessageCount);this._stopResponseFrame();this._clearAllPendingTimeouts();SL4B_ConnectionProxy.getInstance().stopClockSync();this.m_nConnectedState=0;oConnectionManager.m_sPreviousSessionId=this.m_oRttpProvider.getSessionId()+"/"+this.getLastSequenceNumber();SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"BaseStreamingConnection.reconnect: {0}",oConnectionManager.m_sPreviousSessionId);oManagedConnection._setSessionId(null);oConnectionManager.setLoggedIn(false);this.connect();}}
function SL_KD(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"BaseStreamingConnection.setResponseHttpRequest");this.m_oResponseHttpRequest=A;if(this.m_nConnectedState==1){this.m_nConnectedState=2;}}
function SL_FX(){SL4B_Logger.logConnectionMessage(false,"BaseStreamingConnection.start");this.createStandardRequestChannel();}
function SL_FE(){this.super_stop();this._stopResponseFrame();}
SL4B_BaseStreamingConnection.prototype._stopResponseFrame = function(){if(this.m_nConnectedState!==3){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"Invoking stop on streaming frame.");var l_oFrameWindow=SL4B_Accessor.getBrowserAdapter().getFrameWindow(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID);

try {l_oFrameWindow.stop();}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"Attempt to invoke stop on type 5 streaming frame failed: {0}, connection state {1}",SL4B_Accessor.getBrowserAdapter().convertExceptionToString(e),this.m_nConnectedState);}
this.m_nConnectedState=3;}};
if(window.addEventListener){window.addEventListener("keypress",SL_FZ,true);}else 
{if(document.body){document.body.attachEvent("onkeydown",SL_FZ);}else 
{window.attachEvent("onload",function(){document.body.attachEvent("onkeydown",SL_FZ);});}}function SL_FZ(A){A=A||window.event;if(A.keyCode==27){var eTarget=A.target||A.srcElement;
if(A.preventDefault){A.preventDefault();}else 
{A.returnValue=false;}if((eTarget.tagName=="INPUT")&&((eTarget.type=="text")||(eTarget.type=="password"))){eTarget.value="";eTarget.blur();eTarget.focus();}else 
if(eTarget.tagName=="SELECT"){eTarget.blur();eTarget.focus();}}}
var SL4B_Type2Connection=function(){};
if(false){function SL4B_Type2Connection(){}
}SL4B_Type2Connection = function(B,A){var l_nReconnectCount=10000;
SL4B_BaseStreamingConnection.apply(this,[B,A,"RTTP-TYPE2","/sl4b/javascript-rttp-provider/streaming-type2.html",l_nReconnectCount]);this.CLASS_NAME="SL4B_Type2Connection";};
SL4B_Type2Connection.prototype = new SL4B_BaseStreamingConnection;var SL4B_Type3Connection=function(){};
if(false){function SL4B_Type3Connection(){}
}SL4B_Type3Connection = function(B,A){this.CLASS_NAME="SL4B_Type3Connection";this.m_nPollTimeout=null;this.m_oCurrentConnectionData=A;this.m_nRefreshPeriod=SL4B_Accessor.getConfiguration().getType3PollPeriod();this.initialise(B,"/RTTP-TYPE3");};
SL4B_Type3Connection.prototype = new SL4B_AbstractConnection;SL4B_Type3Connection.prototype.connect = SL_QS;SL4B_Type3Connection.prototype.super_send = SL4B_Type3Connection.prototype.send;SL4B_Type3Connection.prototype.send = SL_QJ;SL4B_Type3Connection.prototype.setRequestHttpRequest = SL_MX;SL4B_Type3Connection.prototype.clearPollTimeout = SL_DT;SL4B_Type3Connection.prototype.pollServer = SL_QM;SL4B_Type3Connection.prototype.start = SL_NG;SL4B_Type3Connection.prototype.super_stop = SL4B_Type3Connection.prototype.stop;SL4B_Type3Connection.prototype.stop = SL_LW;function SL_QS(){SL4B_Logger.logConnectionMessage(false,"Type3Connection.connect");if(this.m_oRequestHttpRequest!=null&&!this.m_bConnectionStopped){this.m_oRequestHttpRequest.send(this.m_sUrlPrefix);var l_oMatch=this.m_oCurrentConnectionData.getServerUrl().match(/(https?:\/\/[^\/]+)/);
var l_sFullType3Url=((l_oMatch!=null) ? l_oMatch[1] : "")+this.m_sUrlPrefix;
C_CallbackQueue.addCallback(new Array(SL4B_Accessor.getUnderlyingRttpProvider(),"notifyConnectionListeners",this.m_oRttpProvider.const_INFO_CONNECTION_EVENT,"Establishing polling connection (URL: "+l_sFullType3Url+")"));}}
function SL_QJ(A){this.clearPollTimeout();this.super_send(A);}
function SL_MX(A){this.m_oRequestHttpRequest=A;this.clearPollTimeout();this.m_nPollTimeout=setTimeout("SL4B_ConnectionProxy.getInstance().getConnection().pollServer()",this.m_nRefreshPeriod);}
function SL_DT(){if(this.m_nPollTimeout!==null){clearTimeout(this.m_nPollTimeout);this.m_nPollTimeout=null;}}
function SL_QM(){if(this.m_nPollTimeout!=null&&this.m_oRttpProvider.getSessionId()!=null){this.m_oRttpProvider.getManagedConnection()._sendPriorityMessage("",SL4B_ManagedConnection.NO_RESPONSE_EXPECTED_MESSAGE_RECEIVER,true);}}
function SL_NG(){SL4B_Logger.logConnectionMessage(false,"Type3Connection.start");this.createStandardRequestChannel();}
function SL_LW(){this.super_stop();this.clearPollTimeout();}
var SL4B_Type4Connection=function(){};
if(false){function SL4B_Type4Connection(){}
}SL4B_Type4Connection = function(B,A){this.CLASS_NAME="SL4B_Type4Connection";this.m_oCurrentConnectionData=A;var l_sUrlPrefix=B.getJsContainerUrl()+"/";
this.sResponseFrameUrl=l_sUrlPrefix+SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_URL;this.sResponseFrameUrl+="&"+SL4B_JavaScriptRttpProviderConstants.const_INIT_PARAMETER+"=true";this.sResponseFrameUrl+="&"+SL4B_JavaScriptRttpProviderConstants.const_TYPE4_PARAMETER+"=true";this.bNeedToSendPrefix=true;this.initialise(B,"/RTTP-TYPE4");};
SL4B_Type4Connection.prototype = new SL4B_AbstractConnection();SL4B_Type4Connection.prototype.super_stop = SL4B_AbstractConnection.prototype.stop;SL4B_Type4Connection.prototype.stop = function(){if(SL4B_Accessor.getBrowserAdapter().getFrameWindow(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID).stop!==undefined){SL4B_Accessor.getBrowserAdapter().getFrameWindow(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID).stop();}this.super_stop();};
SL4B_Type4Connection.prototype.setResponseHttpRequest = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINER_INT,"Type4Connection.setResponseHttpRequest");SL4B_AbstractConnection.prototype.setResponseHttpRequest.call(this,A);if(this.bNeedToSendPrefix&&(this.m_oResponseHttpRequest!=null&&!this.m_bConnectionStopped)){this.bNeedToSendPrefix=false;this.m_oResponseHttpRequest.send(this.m_sUrlPrefix);}};
SL4B_Type4Connection.prototype.connect = function(){SL4B_Logger.logConnectionMessage(false,"Type4Connection.connect");};
SL4B_Type4Connection.prototype.start = function(){SL4B_Logger.logConnectionMessage(false,"Type4Connection.start");this.m_sResponseUniqueId=this.createChannel(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID,this.sResponseFrameUrl);this.createStandardRequestChannel();};
var SL4B_Type5Connection=function(){};
if(false){function SL4B_Type5Connection(){}
}SL4B_Type5Connection = function(B,A){var l_nReconnectCount=SL4B_Accessor.getConfiguration().getType5ReconnectCount();
SL4B_BaseStreamingConnection.apply(this,[B,A,"RTTP-TYPE5","/RTTP-TYPE5",l_nReconnectCount]);this.CLASS_NAME="SL4B_Type5Connection";};
SL4B_Type5Connection.prototype = new SL4B_BaseStreamingConnection;var SL4B_Type6Connection=function(){};
if(false){function SL4B_Type6Connection(){}
}SL4B_Type6Connection = function(B,A){var l_nReconnectCount=SL4B_Accessor.getConfiguration().getType5ReconnectCount();
SL4B_BaseStreamingConnection.apply(this,[B,A,"RTTP-TYPE5","/sl4b/javascript-rttp-provider/streaming-type6.html",l_nReconnectCount]);this.CLASS_NAME="SL4B_Type6Connection";};
SL4B_Type6Connection.prototype = new SL4B_BaseStreamingConnection;var SL4B_Type7Connection=function(){};
if(false){function SL4B_Type7Connection(){}
}SL4B_Type7Connection = function(B,A){var l_nReconnectCount=SL4B_Accessor.getConfiguration().getType5ReconnectCount();
SL4B_BaseStreamingConnection.apply(this,[B,A,"RTTP-TYPE5","/sl4b/javascript-rttp-provider/streaming-type7.html",l_nReconnectCount]);this.CLASS_NAME="SL4B_Type7Connection";};
SL4B_Type7Connection.prototype = new SL4B_BaseStreamingConnection;var LF_Type5RttpMessageParserProxy=function(){this.m_oConnectionProxy=null;this.initialise = function(){this.m_oConnectionProxy=SL4B_ConnectionProxy.getInstance();};
this.processRttpMessageBlock = function(A){this.m_oConnectionProxy.processRttpMessageBlock(A);};
this.initialise();};

try {LF_Type5RttpMessageParserProxy=new LF_Type5RttpMessageParserProxy();}catch(e){}
function SL4B_StreamingType5(){this.m_pEmptyArray=new Array();this.reset();}
SL4B_StreamingType5.prototype.reset = function(){this.m_nBufferSize=0;this.m_pMessageBuffer=new Array();};
SL4B_StreamingType5.prototype.processMessagesInBuffer = function(){var l_pMessageBuffer=this.m_pMessageBuffer;
this.reset();LF_Type5RttpMessageParserProxy.processRttpMessageBlock(l_pMessageBuffer);};
SL4B_StreamingType5.prototype.processException = function(B,A){SL4B_Accessor.getLogger().printMessage("critical:   SL4B_StreamingType5.processException: message = "+A+", exception = "+B);};
SL4B_StreamingType5=new SL4B_StreamingType5();function a(A){SL4B_StreamingType5.m_pMessageBuffer[SL4B_StreamingType5.m_nBufferSize]=A;++SL4B_StreamingType5.m_nBufferSize;}
function z(){if(SL4B_StreamingType5.m_nBufferSize>0){SL4B_MethodInvocationProxy.invoke(SL4B_StreamingType5,"processMessagesInBuffer",[],function(A){SL4B_StreamingType5.processException(A,"Exception occured whilst processing message buffer");});}}
GF_RequestEncoder = new function(){this.const_FIELD_SEPARATOR=",";this.const_NON_ENCODED_CHARACTERS="A-Za-z0-9_\\x2D.*\/:";this.m_oFilterFieldRegExp=new RegExp("(^imagefilter=|^filter=|^auto=|^monitor=|^ctrid=|^ctrstart=|^ctrend=)(.*)");this.m_pFieldSeparatorToRegExpMap=new Object();this.encodeRttpData = function(A){return escape(A).replace(/\+/g,"%2B").replace(/%20/g,"+").replace(/%3A/g,":").replace(/@/g,"%40");
};
this.encodeUrl = function(A){return escape(A).replace(/(\/)/g,"%2F").replace(/\+/g,"%2B").replace(/%20/g,"+");
};
this.encodeFieldList = function(A,B){var l_sEncodedFieldList=A;
if(A&&A!=""&&A.match(this.getFieldListRegExp(B))!=null){l_sEncodedFieldList="";var l_pFields=A.split(B);
for(var l_nField=0,l_nLength=l_pFields.length;l_nField<l_nLength;++l_nField){var l_sField;
var l_oMatch=l_pFields[l_nField].match(this.m_oFilterFieldRegExp);
if(l_oMatch){l_sField=l_oMatch[1]+GF_RequestEncoder.encodeRttpData(l_oMatch[2]);}else 
{l_sField=GF_RequestEncoder.encodeRttpData(l_pFields[l_nField]);}l_sEncodedFieldList+=this.const_FIELD_SEPARATOR+l_sField;}l_sEncodedFieldList=l_sEncodedFieldList.substring(1);}return l_sEncodedFieldList;
};
this.getFieldListRegExp = function(A){var l_oRegExp=this.m_pFieldSeparatorToRegExpMap[A];
if(!l_oRegExp){if(A==this.const_FIELD_SEPARATOR){l_oRegExp=new RegExp("[^"+this.const_NON_ENCODED_CHARACTERS+this.const_FIELD_SEPARATOR+"]");}else 
{l_oRegExp=new RegExp("[^"+this.const_NON_ENCODED_CHARACTERS+"]");}this.m_pFieldSeparatorToRegExpMap[A]=l_oRegExp;}return l_oRegExp;
};
};
GF_ResponseDecoder = new function(){this.m_fUnescape=window.unescape;this.m_oDecodeRegExp=/\+/g;this.decodeRttpData = function(A){return this.m_fUnescape(A.replace(this.m_oDecodeRegExp," "));
};
};
var g_nConnectionManagerDebugId=0;
var SL4B_ConnectionManager=function(){};
if(false){function SL4B_ConnectionManager(){}
}SL4B_ConnectionManager = function(B,C,A){this.const_CAPABILITIES="HttpRequestLineLength="+SL4B_Accessor.getConfiguration().getMaxGetLength()+",HttpBodyLength=";this.CLASS_NAME="ConnectionManager (instance: "+(g_nConnectionManagerDebugId++)+")";this.m_fConnectionCreator=B;this.m_oLiberatorConfiguration=C;this.m_oManagedConnection=A;this.m_oConnectionProxy=SL4B_ConnectionProxy.getInstance();this.m_sPreviousSessionId=SL4B_JavaScriptRttpProvider.const_NEW_SESSION_ID;this.m_bIsStopped=true;this.m_oCurrentConnectionData=null;this.m_pConnectionListeners=new Array();this.m_bRequestWindowReady=false;this.m_bLoggedIn=false;this.m_bLogInMessageProcessing=false;this.m_nConnectionCheckInterval=SL4B_Accessor.getConfiguration().getConnectionTimeout();this.m_nConnectionCheckTimeoutId=null;this.m_nLoginTimeout=SL4B_Accessor.getConfiguration().getLoginTimeout();this.m_nLoginTimeoutId=null;this.m_bConnectionLost=false;this.m_oMessageReceiver=null;this.m_bFieldMapAvailable=false;this.m_pFieldCodeToFieldNameMap=new Object();var l_sAppendText="";
var l_sCommonDomain=GF_CommonDomainExtractor.getCommonDomain();
if(l_sCommonDomain){l_sAppendText="?domain="+l_sCommonDomain;}this.m_sEmptyPageUrl=SL4B_ScriptLoader.getRootUrl()+"sl4b/javascript-rttp-provider/empty.html"+l_sAppendText;SL4B_NoopScheduler.setConnectionManager(this);};
SL4B_ConnectionManager.prototype.getSessionId = function(){return this.m_oManagedConnection._getSessionId();
};
SL4B_ConnectionManager.prototype.setSessionIdFromMessage = function(A){this.m_oManagedConnection._setSessionId(this.parseSessionId(A));};
SL4B_ConnectionManager.prototype.parseSessionId = function(A){return A.substr(0,A.indexOf(" "));
};
SL4B_ConnectionManager.prototype.getConnectionProxy = function(){return this.m_oConnectionProxy;
};
SL4B_ConnectionManager.prototype.connect = function(){this.m_bIsStopped=false;if(this.m_oManagedConnection._hasSessionId()==false&&this.m_oConnectionProxy.isDisconnected()){this.m_oConnectionProxy.setConnectionState(SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTING);this.m_oConnectionProxy.connect();}};
SL4B_ConnectionManager.prototype.getCurrentConnectionData = function(){return this.m_oCurrentConnectionData;
};
SL4B_ConnectionManager.prototype.addConnectionListener = function(A){this.m_pConnectionListeners.push(A);};
SL4B_ConnectionManager.prototype.removeConnectionListener = function(A){var l_nMatchIndex=-1;
for(var l_nListener=0,l_nLength=this.m_pConnectionListeners.length;l_nListener<l_nLength;++l_nListener){if(this.m_pConnectionListeners[l_nListener]==A){l_nMatchIndex=l_nListener;break;
}}if(l_nMatchIndex!=-1){this.m_pConnectionListeners.splice(l_nMatchIndex,1);}return (l_nMatchIndex!=-1);
};
SL4B_ConnectionManager.prototype.notifyConnectionListeners = function(A){var l_pArguments=arguments;
var l_aCopy=this.m_pConnectionListeners.slice();
for(var l_nListener=0,l_nLength=l_aCopy.length;l_nListener<l_nLength;++l_nListener){
try {switch(A){
case SL4B_AbstractRttpProvider.prototype.const_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].connectionError(l_pArguments[1]);break;
case SL4B_AbstractRttpProvider.prototype.const_WARNING_CONNECTION_EVENT:l_aCopy[l_nListener].connectionWarning(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
case SL4B_AbstractRttpProvider.prototype.const_INFO_CONNECTION_EVENT:l_aCopy[l_nListener].connectionInfo(l_pArguments[1]);break;
case SL4B_AbstractRttpProvider.prototype.const_ATTEMPT_CONNECTION_EVENT:l_aCopy[l_nListener].connectionAttempt(l_pArguments[1],l_pArguments[2]);break;
case SL4B_AbstractRttpProvider.prototype.const_OK_CONNECTION_EVENT:l_aCopy[l_nListener].connectionOk(l_pArguments[1],l_pArguments[2],l_pArguments[3]);break;
case SL4B_AbstractRttpProvider.prototype.const_RECONNECTION_OK_CONNECTION_EVENT:l_aCopy[l_nListener].reconnectionOk();break;
case SL4B_AbstractRttpProvider.prototype.const_FILE_DOWNLOAD_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].fileDownloadError(l_pArguments[1],l_pArguments[2]);break;
case SL4B_AbstractRttpProvider.prototype.const_LOGIN_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].loginError(l_pArguments[1]);break;
case SL4B_AbstractRttpProvider.prototype.const_LOGIN_OK_CONNECTION_EVENT:l_aCopy[l_nListener].loginOk();break;
case SL4B_AbstractRttpProvider.prototype.const_CREDENTIALS_RETRIEVED_CONNECTION_EVENT:l_aCopy[l_nListener].credentialsRetrieved(l_pArguments[1]);break;
case SL4B_AbstractRttpProvider.prototype.const_MESSAGE_CONNECTION_EVENT:l_aCopy[l_nListener].message(l_pArguments[1],l_pArguments[2]);break;
case SL4B_AbstractRttpProvider.prototype.const_SERVICE_MESSAGE_CONNECTION_EVENT:l_aCopy[l_nListener].serviceMessage(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
case SL4B_AbstractRttpProvider.prototype.const_SESSION_EJECTED_CONNECTION_EVENT:l_aCopy[l_nListener].sessionEjected(l_pArguments[1],l_pArguments[2]);break;
case SL4B_AbstractRttpProvider.prototype.const_SOURCE_MESSAGE_CONNECTION_EVENT:l_aCopy[l_nListener].sourceMessage(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
case SL4B_AbstractRttpProvider.prototype.const_STATISTICS_CONNECTION_EVENT:l_aCopy[l_nListener].statistics(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4],l_pArguments[5]);break;
case SL4B_AbstractRttpProvider.prototype.const_CREDENTIALS_PROVIDER_SESSION_ERROR_CONNECTION_EVENT:l_aCopy[l_nListener].credentialsProviderSessionError(l_pArguments[1],l_pArguments[2],l_pArguments[3],l_pArguments[4]);break;
default :SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ConnectionManager.notifyConnectionListeners: "+"Received an unknown connection event '"+A+"'. Ignoring event.");}}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ConnectionManager.notifyConnectionListeners: Exception thrown by a listener whilst processing a \"{0}\" event; exception was {1}",A,SL4B_Accessor.getBrowserAdapter().convertExceptionToString(e));}
}if(A==SL4B_AbstractRttpProvider.prototype.const_RECONNECTION_OK_CONNECTION_EVENT||A==SL4B_AbstractRttpProvider.prototype.const_LOGIN_OK_CONNECTION_EVENT){this.m_oManagedConnection._sendNextRttpMessage();}};
SL4B_ConnectionManager.prototype.createConnection = function(A){SL4B_Logger.logConnectionMessage(false,"ConnectionManager.createConnection({0})",A);this.m_oConnectionProxy.setConnectionState(SL4B_ConnectionProxy.const_CONNECTION_STATE_DISCONNECTED);if(!A){var l_oConnectionData=this.m_oLiberatorConfiguration.getNextConnection();
this.m_oCurrentConnectionData=l_oConnectionData;SL4B_Logger.logConnectionMessage(false,"Next connection information: {0}",l_oConnectionData);if(l_oConnectionData==null){this.connectionLost();return false;
}}var l_oConnectionData=this.m_oCurrentConnectionData;
var l_oConnectionMethod=l_oConnectionData.getMethod();
var l_oConnection=this.m_fConnectionCreator(l_oConnectionData);
this.m_oConnectionProxy.setConnection(l_oConnection);l_oConnection._$setConnectionManager(this);this.startRttpMessageListening();if(l_oConnection.constructor==SL4B_Type3Connection){l_oConnectionMethod=SL4B_ConnectionMethod.POLLING;}C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_AbstractRttpProvider.prototype.const_ATTEMPT_CONNECTION_EVENT,l_oConnectionData.getServerUrl(),l_oConnectionMethod));this.m_oConnectionProxy.start();return true;
};
SL4B_ConnectionManager.prototype.isLoggedIn = function(){return this.m_bLoggedIn;
};
SL4B_ConnectionManager.prototype.setLoggedIn = function(A){if(A==false){SL4B_NoopScheduler.reset();}else 
{this.m_bLogInMessageProcessing=false;}this.m_bLoggedIn=A;};
SL4B_ConnectionManager.prototype.startConnectionChecking = function(){this.m_nConnectionCheckTimeoutId=setTimeout("SL4B_Accessor.getUnderlyingRttpProvider().checkConnected()",this.m_nConnectionCheckInterval);};
SL4B_ConnectionManager.prototype.clearConnectionCheckTimeout = function(){if(this.m_nConnectionCheckTimeoutId!=null){clearTimeout(this.m_nConnectionCheckTimeoutId);this.m_nConnectionCheckTimeoutId=null;}};
SL4B_ConnectionManager.prototype.clearLoginTimeout = function(){if(this.m_nLoginTimeoutId!=null){clearTimeout(this.m_nLoginTimeoutId);this.m_nLoginTimeoutId=null;}};
SL4B_ConnectionManager.prototype.reconnectInternal = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionManager.reconnectInternal({0})",A);this.stopConnection();this.m_oConnectionProxy.setConnectionState(SL4B_ConnectionProxy.const_CONNECTION_STATE_RECONNECTING);this.m_sPreviousSessionId=A;this.m_bRequestWindowReady=false;this.m_oManagedConnection._setSessionId(null);this.setLoggedIn(false);if(this.createConnection(A!=SL4B_JavaScriptRttpProvider.const_NEW_SESSION_ID)){this.clearConnectionCheckTimeout();this.startConnectionChecking();}};
SL4B_ConnectionManager.prototype.liberatorUnavailable = function(){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_JavaScriptRttpProvider.prototype.const_WARNING_CONNECTION_EVENT,"Liberator unavailable",SL4B_ConnectionWarningReason.LIBERATOR_UNAVAILABLE,this.m_oCurrentConnectionData.getServerUrl(),this.m_oCurrentConnectionData.getMethod()));this.connectionLost();};
SL4B_ConnectionManager.prototype.connectionLost = function(){this.m_oLiberatorConfiguration.resetConnections();this.m_bConnectionLost=true;this.clearConnectionCheckTimeout();this.stopConnection();SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"JavaScriptRttpProvider.createConnection: failed to reconnect - no more connection types to try");C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_AbstractRttpProvider.prototype.const_ERROR_CONNECTION_EVENT,"Failed to connect"));};
SL4B_ConnectionManager.prototype.setMessageReceiver = function(A){if(A!==null&&typeof A.receiveMessage!="function"){throw new SL4B_Exception("Specified listener does not define the receiveMessage method");
}this.m_oMessageReceiver=A;};
SL4B_ConnectionManager.prototype.receiveMessage = function(A){if(this.m_oMessageReceiver!==null){SL4B_MethodInvocationProxy.invoke(this.m_oMessageReceiver,"receiveMessage",[A]);}};
SL4B_ConnectionManager.prototype.stopRttpMessageListening = function(){this.m_oConnectionProxy.setMessageReceiver(null);};
SL4B_ConnectionManager.prototype.startRttpMessageListening = function(){this.m_oConnectionProxy.setMessageReceiver(this);};
SL4B_ConnectionManager.prototype.reconnect = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionManager.reconnect()");if(this.m_bConnectionLost){this.m_bConnectionLost=false;this.startConnectionChecking();}this.m_bFieldMapAvailable=false;this.reconnectInternal(SL4B_JavaScriptRttpProvider.const_NEW_SESSION_ID);};
SL4B_ConnectionManager.prototype.createConnectionLost = function(B,A){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"ConnectionManager.createConnectionLost: Connection lost: "+B);this.clearLoginTimeout();C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_JavaScriptRttpProvider.prototype.const_WARNING_CONNECTION_EVENT,B,SL4B_ConnectionWarningReason.CONNECTION_LOST,this.m_oCurrentConnectionData.getServerUrl(),this.m_oCurrentConnectionData.getMethod()));var sSessionId=SL4B_JavaScriptRttpProvider.const_NEW_SESSION_ID;
if(!A&&!this.m_oManagedConnection._$isFullReconnectRequired()){sSessionId=this.m_oManagedConnection._getSessionId()+"/"+this.m_oConnectionProxy.getConnection().getLastSequenceNumber();SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"ConnectionManager.createConnectionLost: attempting session reconnect");}else 
{var sMessage="attempting full reconnect"+(A ? "" : " due to indeterminate client/server state");
SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"ConnectionManager.createConnectionLost: {0}",sMessage);}this.reconnectInternal(sSessionId);};
SL4B_ConnectionManager.prototype.checkConnected = function(){var l_sConnectionState=this.m_oConnectionProxy.getConnectionState();
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionManager.checkConnected: {0}",l_sConnectionState);this.m_nConnectionCheckTimeoutId=null;if(l_sConnectionState!=SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTED){var l_currentConnectionData=this.m_oCurrentConnectionData;
C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_JavaScriptRttpProvider.prototype.const_WARNING_CONNECTION_EVENT,"Connection timed out - "+l_currentConnectionData,SL4B_ConnectionWarningReason.CONNECTION_FAILED,l_currentConnectionData.getServerUrl(),l_currentConnectionData.getMethod()));this.reconnect();}};
SL4B_ConnectionManager.prototype.setFieldCodeMapping = function(A){this.m_bFieldMapAvailable=true;var l_pFieldNameValuePairs=A.split(" ");
for(var l_nFieldPair=0,l_nLength=l_pFieldNameValuePairs.length;l_nFieldPair<l_nLength;++l_nFieldPair){var l_nIndex=l_pFieldNameValuePairs[l_nFieldPair].indexOf("=");
this.m_pFieldCodeToFieldNameMap[l_pFieldNameValuePairs[l_nFieldPair].substr(0,l_nIndex)]=GF_ResponseDecoder.decodeRttpData(l_pFieldNameValuePairs[l_nFieldPair].substr(l_nIndex+1));}};
SL4B_ConnectionManager.prototype.getFieldName = function(A){var l_sFieldName=this.m_pFieldCodeToFieldNameMap[A];
return ((l_sFieldName===undefined) ? GF_ResponseDecoder.decodeRttpData(A) : l_sFieldName);
};
SL4B_ConnectionManager.prototype.responseHttpRequestReady = function(){this.connect();};
SL4B_ConnectionManager.prototype.requestHttpRequestReady = function(){this.m_bRequestWindowReady=true;this.connect();this.m_oManagedConnection._sendNextRttpMessage();};
SL4B_ConnectionManager.prototype.startConnection = function(){setTimeout("SL4B_Accessor.getUnderlyingRttpProvider().m_oConnectionManager.startConnectionInternal();",0);};
SL4B_ConnectionManager.prototype.startConnectionInternal = function(){this.createConnection(false);this.startConnectionChecking();};
SL4B_ConnectionManager.prototype.login = function(A,B){this.clearLoginTimeout();if(this.m_bLogInMessageProcessing===false){SL4B_Logger.logConnectionMessage(true,"ConnectionManager.login: username = {0}; password = {1}",A,B);var l_sLoginSession=this.m_sPreviousSessionId;
if(this.m_bFieldMapAvailable==false){l_sLoginSession="0";}var l_nVersion=SL4B_Accessor.getCapabilities().getRttpVersion();
var l_sLoginMessage="LOGIN "+l_sLoginSession+" "+GF_RequestEncoder.encodeRttpData(SL4B_Accessor.getConfiguration().getApplicationId())+"/ RTTP/"+l_nVersion.toFixed(1)+" "+GF_RequestEncoder.encodeRttpData(A)+" "+GF_RequestEncoder.encodeRttpData(B);
if(l_nVersion>=2.1){l_sLoginMessage+=" "+this.const_CAPABILITIES;}C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_AbstractRttpProvider.prototype.const_CREDENTIALS_RETRIEVED_CONNECTION_EVENT,SL4B_Accessor.getCredentialsProvider().getUsername()));this.m_oManagedConnection.clearResponseQueue();this.m_bLogInMessageProcessing=true;this.m_oManagedConnection._sendPriorityMessage(l_sLoginMessage,this.m_oManagedConnection.m_oSystemEventReceiverRecord.getListener(),true);}else 
{SL4B_Logger.logConnectionMessage(true,"ConnectionManager.login: Attempt to login again, even though a login is currently in progress.");}SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Login message sent. Waiting {0}ms for login OK response.",this.m_nLoginTimeout);this.m_nLoginTimeoutId=setTimeout("SL4B_Accessor.getUnderlyingRttpProvider().createConnectionLost(\"Login Timeout\", true)",this.m_nLoginTimeout);};
SL4B_ConnectionManager.prototype.createStreamingFrame = function(A){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"ConnectionManager.createStreamingFrame: frameid = {0}; url = {1}",A,this.m_sEmptyPageUrl);var l_sHtml="<iframe id=\""+A+"\" style=\"display:none;\" src=\""+this.m_sEmptyPageUrl+"\"></iframe>";
document.write(l_sHtml);setTimeout("SL4B_Accessor.getUnderlyingRttpProvider().m_oConnectionManager.replaceStreamingFrame(\""+A+"\", \""+this.m_sEmptyPageUrl+"\")",0);SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionManager.createStreamingFrame: html = {0}",l_sHtml);C_LiberatorUrlCheck.createLiberatorUrlCheck(A);};
SL4B_ConnectionManager.prototype.replaceStreamingFrame = function(B,A){var l_oFrameWindow=SL4B_Accessor.getBrowserAdapter().getFrameWindow(B);
if(l_oFrameWindow&&l_oFrameWindow.location){l_oFrameWindow.location.replace(A);}};
SL4B_ConnectionManager.prototype.cleanUpStreamingFrames = function(){this.replaceStreamingFrame(SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_ID,this.m_sEmptyPageUrl);this.replaceStreamingFrame(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID,this.m_sEmptyPageUrl);SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"ConnectionManager.cleanUpStreamingFrames()");};
SL4B_ConnectionManager.prototype.logout = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"JavaScriptRttpProvider.logout()");if(this.m_bLoggedIn){this.m_oManagedConnection._sendPriorityMessage("LOGOUT",this.m_oManagedConnection.m_oSystemEventReceiverRecord.getListener(),true);}this.m_sPreviousSessionId=SL4B_JavaScriptRttpProvider.const_NEW_SESSION_ID;this.m_bFieldMapAvailable=false;this.clearConnectionCheckTimeout();this.getConnectionProxy().setConnectionState(SL4B_ConnectionProxy.const_CONNECTION_STATE_DISCONNECTED);this.cleanUpStreamingFrames();};
SL4B_ConnectionManager.prototype.initialise = function(){
try {if(SL4B_JavaScriptRttpProvider.bFramesCreatedFlag==false){SL4B_JavaScriptRttpProvider.bFramesCreatedFlag=true;this.createStreamingFrame(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID);this.createStreamingFrame(SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_ID);}}catch(e){return false;
}
return true;
};
SL4B_ConnectionManager.prototype.noop = function(){if(this.m_bLoggedIn){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"ConnectionManager.noop: {0}",this.getConnectionProxy().getConnectionState());switch(this.getConnectionProxy().getConnectionState()){
case SL4B_ConnectionProxy.const_CONNECTION_STATE_INITIALISING:break;
case SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTED:this.m_oManagedConnection.sendMessage("NOOP",this.m_oManagedConnection.m_oSystemEventReceiverRecord.getListener());SL4B_NoopScheduler.startNoopTimeout();break;
case SL4B_ConnectionProxy.const_CONNECTION_STATE_RECONNECTING:break;
case SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTING:break;
}}};
SL4B_ConnectionManager.prototype.stop = function(){if(this.m_bIsStopped==false){this.m_bIsStopped=true;SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"AbstractRttpProvider.stop");this.logout();
try {SL4B_FrameRegistrarAccessor.removeMasterFrame();}catch(e){}
this.m_pRequestQueue=new Array();this.m_pPriorityRequestQueue=new Array();this.m_bRequestWindowReady=true;this.clearConnectionCheckTimeout();this.stopConnection();if(!this.m_bConnectionLost){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",SL4B_AbstractRttpProvider.prototype.const_ERROR_CONNECTION_EVENT,"Connection stopped"));}}};
SL4B_ConnectionManager.prototype.stopConnection = function(){this.stopRttpMessageListening();this.m_oConnectionProxy.stop();this.m_bLogInMessageProcessing=false;};
SL4B_ConnectionManager.prototype.sendSync = function(A){this.m_oConnectionProxy.sendSync(A);};
SL4B_ConnectionManager.prototype.getJsContainerUrl = function(){var l_sContainerUrl=SL4B_Accessor.getConfiguration().getJsContainerUrl();
if(l_sContainerUrl==null){var l_oConnectionData=this.getCurrentConnectionData();
if(l_oConnectionData==null){l_oConnectionData=this.m_oLiberatorConfiguration.peekAtNextConnection();}l_sContainerUrl=l_oConnectionData.getServerUrl()+"/"+SL4B_Accessor.getConfiguration().getJsContainerPath();}return l_sContainerUrl.replace(/\/$/,"");
};
SL4B_ConnectionManager.prototype.readyToRequest = function(){return this.m_bRequestWindowReady;
};
SL4B_ConnectionManager.prototype.makingRequest = function(){this.m_bRequestWindowReady=false;};
function SL4B_NoopScheduler(){SL4B_Accessor.getStatistics().addResponseQueueStatisticsListener(this);this.m_oConnectionManager=null;this.m_nNoopSendTimeoutId=null;this.m_nNoopReceivedTimeoutId=null;this.m_nNOOPInterval=10000;this.m_nNOOPTimeout=1000;}
SL4B_NoopScheduler.prototype = new SL4B_ResponseQueueStatisticsListener();SL4B_NoopScheduler.prototype.m_fConstructor = SL4B_NoopScheduler;SL4B_NoopScheduler.prototype.setConnectionManager = function(A){if(this.m_oConnectionManager!=null){this.reset();}this.m_oConnectionManager=A;this.m_nNOOPInterval=SL4B_Accessor.getConfiguration().getNOOPInterval();this.m_nNOOPTimeout=SL4B_Accessor.getConfiguration().getNOOPTimeout();};
SL4B_NoopScheduler.prototype.onBatchQueued = function(A){this.reset();};
SL4B_NoopScheduler.prototype.onAfterBatchProcessed = function(A){if((this.m_oConnectionManager.getConnectionProxy().getConnectionState()==SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTED)&&this.m_oConnectionManager.isLoggedIn()){this.startNoopSending();}};
SL4B_NoopScheduler.prototype.reset = function(){this._clearNoopSending();this._clearNoopTimeout();};
SL4B_NoopScheduler.prototype._clearNoopSending = function(){if(this.m_nNoopSendTimeoutId!=null){clearTimeout(this.m_nNoopSendTimeoutId);this.m_nNoopSendTimeoutId=null;}};
SL4B_NoopScheduler.prototype._clearNoopTimeout = function(){if(this.m_nNoopReceivedTimeoutId!=null){clearTimeout(this.m_nNoopReceivedTimeoutId);this.m_nNoopReceivedTimeoutId=null;}};
SL4B_NoopScheduler.prototype.startNoopSending = function(){if(this.m_nNoopSendTimeoutId==null){this.m_nNoopSendTimeoutId=setTimeout("SL4B_Accessor.getUnderlyingRttpProvider().m_oConnectionManager.noop()",this.m_nNOOPInterval);}};
SL4B_NoopScheduler.prototype.startNoopTimeout = function(){if(this.m_nNoopReceivedTimeoutId!=null){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"SL4B_NoopScheduler.startNoopTimeout while a noop timeout is already set.)");}this.m_nNoopReceivedTimeoutId=setTimeout("SL4B_Accessor.getUnderlyingRttpProvider().createConnectionLost(\"Request Timeout\", false)",this.m_nNOOPTimeout);};
SL4B_NoopScheduler=new SL4B_NoopScheduler();var SL4B_JavaScriptRttpProvider=function(){};
if(false){function SL4B_JavaScriptRttpProvider(){}
}SL4B_JavaScriptRttpProvider = function(B,C){this.CLASS_NAME="SL4B_JavaScriptRttpProvider";SL4B_AbstractRttpProvider.apply(this);this.m_oLiberatorConfiguration=B;var thisProvider=this;
var l_fConnectionCreator=function(A){var l_oConnectionMethod=A.getMethod();
if(l_oConnectionMethod!=null){return l_oConnectionMethod.createConnection(thisProvider,A);
}SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"JavaScriptRttpProvider.createConnection: invalid connection type ({0}) using type 3",l_oConnectionMethod);return new SL4B_Type3Connection(this);
};
this.m_oManagedConnection=new SL4B_ManagedConnection();this.m_oManagedConnection.setSystemEventReceiver(this);this.m_oConnectionManager=new SL4B_ConnectionManager(l_fConnectionCreator,B,this.m_oManagedConnection);this.m_oManagedConnection._$setConnectionManager(this.m_oConnectionManager);this.m_bFatalError=false;if(SL4B_JavaScriptRttpProvider.oObjectSubscriptionManager==null){SL4B_JavaScriptRttpProvider.oObjectSubscriptionManager=new SL4B_ObjectSubscriptionManager(this);}this.m_oObjectSubscriptionManager=SL4B_JavaScriptRttpProvider.oObjectSubscriptionManager;this.m_oActionSubscriptionManager=C;this.m_oObjectCache=new SL4B_ObjectCache(this,this.m_oObjectSubscriptionManager);};
SL4B_JavaScriptRttpProvider.prototype = new SL4B_AbstractRttpProvider;SL4B_JavaScriptRttpProvider.createProvider = function(B,A){var oProvider=null;
if(A==null){oProvider=new SL4B_JavaScriptRttpProvider(B,new GF_ActionSubscriptionManager());}else 
{oProvider=new SL4B_JavaScriptRttpProvider(B,A.m_oActionSubscriptionManager);}return oProvider;
};
SL4B_JavaScriptRttpProvider.prototype.getManagedConnection = function(){return this.m_oManagedConnection;
};
SL4B_JavaScriptRttpProvider.const_NEW_SESSION_ID="0";SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_ID="frmRequest";SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID="frmResponse";SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_URL="container.html?"+SL4B_JavaScriptRttpProviderConstants.const_TYPE_PARAMETER+"="+SL4B_JavaScriptRttpProviderConstants.const_REQUEST_TYPE;SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_URL="container.html?"+SL4B_JavaScriptRttpProviderConstants.const_TYPE_PARAMETER+"="+SL4B_JavaScriptRttpProviderConstants.const_RESPONSE_TYPE;SL4B_JavaScriptRttpProvider.bFramesCreatedFlag=false;SL4B_JavaScriptRttpProvider.oObjectSubscriptionManager=null;SL4B_JavaScriptRttpProvider.prototype.getSessionId = function(){return this.m_oConnectionManager.getSessionId();
};
SL4B_JavaScriptRttpProvider.prototype.receiveMessage = SL_OL;SL4B_JavaScriptRttpProvider.prototype.initialise = SL_HL;SL4B_JavaScriptRttpProvider.prototype.onLoad = SL_CR;SL4B_JavaScriptRttpProvider.prototype.responseHttpRequestReady = SL_CB;SL4B_JavaScriptRttpProvider.prototype.requestHttpRequestReady = SL_AY;SL4B_JavaScriptRttpProvider.prototype.createConnection = SL_GA;SL4B_JavaScriptRttpProvider.prototype.createConnectionLost = SL_EZ;SL4B_JavaScriptRttpProvider.prototype.connect = SL_OI;SL4B_JavaScriptRttpProvider.prototype.login = SL_NN;SL4B_JavaScriptRttpProvider.prototype.logout = SL_QI;SL4B_JavaScriptRttpProvider.prototype.super_stop = SL4B_JavaScriptRttpProvider.prototype.stop;SL4B_JavaScriptRttpProvider.prototype.stop = SL_BA;SL4B_JavaScriptRttpProvider.prototype.getVersion = SL_EM;SL4B_JavaScriptRttpProvider.prototype.getVersionInfo = SL_QB;SL4B_JavaScriptRttpProvider.prototype.getObject = SL_LD;SL4B_JavaScriptRttpProvider.prototype.getObjects = SL_KX;SL4B_JavaScriptRttpProvider.prototype.removeObject = SL_LC;SL4B_JavaScriptRttpProvider.prototype.removeObjects = SL_CP;SL4B_JavaScriptRttpProvider.prototype.removeSubscriber = SL_IW;SL4B_JavaScriptRttpProvider.prototype.contribObject = SL_QN;SL4B_JavaScriptRttpProvider.prototype.createObject = SL_GR;SL4B_JavaScriptRttpProvider.prototype.deleteObject = SL_JU;SL4B_JavaScriptRttpProvider.prototype.reconnect = SL_MK;SL4B_JavaScriptRttpProvider.prototype.checkConnected = SL_FN;SL4B_JavaScriptRttpProvider.prototype.getJsContainerUrl = SL_JF;SL4B_JavaScriptRttpProvider.prototype.getAutoDirectory = SL_NI;SL4B_JavaScriptRttpProvider.prototype.removeAutoDirectory = SL_FP;SL4B_JavaScriptRttpProvider.prototype.getContainer = SL_EF;SL4B_JavaScriptRttpProvider.prototype.setContainerWindow = SL_DY;SL4B_JavaScriptRttpProvider.prototype.clearContainerWindow = SL_MV;SL4B_JavaScriptRttpProvider.prototype.removeContainer = SL_NV;SL4B_JavaScriptRttpProvider.prototype.getFieldName = SL_BX;SL4B_JavaScriptRttpProvider.prototype.setGlobalThrottle = SL_IH;SL4B_JavaScriptRttpProvider.prototype.setThrottleObject = SL_AW;SL4B_JavaScriptRttpProvider.prototype.setThrottleObjects = SL_AF;SL4B_JavaScriptRttpProvider.prototype.addConnectionListener = function(A){this.m_oConnectionManager.addConnectionListener(A);};
SL4B_JavaScriptRttpProvider.prototype.removeConnectionListener = function(A){this.m_oConnectionManager.removeConnectionListener(A);};
SL4B_JavaScriptRttpProvider.prototype.notifyConnectionListeners = function(){SL4B_MethodInvocationProxy.invoke(this.m_oConnectionManager,"notifyConnectionListeners",arguments);};
SL4B_JavaScriptRttpProvider.prototype.getObjectCache = function(){return this.m_oObjectCache;
};
function SL_GA(A){this.m_oConnectionManager.createConnection(A);}
function SL_EZ(B,A){this.m_oConnectionManager.createConnectionLost(B,A);}
function SL_FN(){this.m_oConnectionManager.checkConnected();}
function SL_OL(A,C,B){if(SL4B_Accessor.getRttpProvider()!=this&&SL4B_Accessor.getUnderlyingRttpProvider()!=this){return;
}var l_nRttpCode=A.getRttpCode();
if(l_nRttpCode==SL4B_RttpCodes.const_NOOP_OK){}else 
if(l_nRttpCode==SL4B_RttpCodes.const_CONNECT_OK){this.m_oLiberatorConfiguration.connectionOk();this.m_oConnectionManager.setSessionIdFromMessage(A.getMessageContent());setTimeout("SL4B_Accessor.getRttpProvider().connected()",0);var l_sHostName=A.getMessageContent().match(/host=(.*)\sversion=/)[1];
var l_sTime=A.getMessageContent().match(/time=(\d*)/)[1];
var l_sVersion=A.getMessageContent().match(/version=(.*)\s/)[1];
var l_nVersion=parseFloat(l_sVersion);
SL4B_Accessor.getCapabilities().setRttpVersion(l_nVersion);this.m_oConnectionManager.getConnectionProxy().setConnectionState(SL4B_ConnectionProxy.const_CONNECTION_STATE_CONNECTED);C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_OK_CONNECTION_EVENT,l_sHostName,this.m_oConnectionManager.getCurrentConnectionData().getMethod(),l_sTime));}else 
if(l_nRttpCode==SL4B_RttpCodes.const_LOGIN_OK){this.m_oConnectionManager.setLoggedIn(true);this.m_oManagedConnection.clear();this.m_oObjectCache.clear();this.m_oObjectSubscriptionManager.reRequestObjects();var pWords=A.getMessageContent().split(" ");
if(pWords.length==2){this.storeCapabilities(pWords[1]);}this.loggedIn();}else 
if(l_nRttpCode==SL4B_RttpCodes.const_RECON_OK){this.m_oConnectionManager.setLoggedIn(true);C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_RECONNECTION_OK_CONNECTION_EVENT));this.loggedIn();this.m_oObjectSubscriptionManager.sendCurrentObjectStatusToAll();}else 
if(l_nRttpCode>=SL4B_RttpCodes.const_INVALID_USER&&l_nRttpCode<SL4B_RttpCodes.const_NOT_LOGGED_IN){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_LOGIN_ERROR_CONNECTION_EVENT,A.getMessageContent()));this.m_oConnectionManager.stopConnection();this.m_oConnectionManager.clearConnectionCheckTimeout();}else 
if(l_nRttpCode==SL4B_RttpCodes.const_FIELD_MAP){this.m_oConnectionManager.setFieldCodeMapping(A.getMessageContent());}else 
if(l_nRttpCode>=SL4B_RttpCodes.const_SOURCE_UP&&l_nRttpCode<=SL4B_RttpCodes.const_SOURCE_WARN){var l_sWords=A.getMessageContent().split(" ");
C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_SOURCE_MESSAGE_CONNECTION_EVENT,l_nRttpCode,l_sWords[0],l_sWords[1],l_sWords[2]));}else 
if(l_nRttpCode==SL4B_RttpCodes.const_SESSION_EJECTED){C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_SESSION_EJECTED_CONNECTION_EVENT,A.getMessageContent()));this.m_oConnectionManager.stopConnection();this.m_oConnectionManager.clearConnectionCheckTimeout();}else 
if(l_nRttpCode>=SL4B_RttpCodes.const_SERVICE_OK&&l_nRttpCode<=SL4B_RttpCodes.const_SERVICE_LIMITED){var l_sWords=A.getMessageContent().split(" ");
C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_SERVICE_MESSAGE_CONNECTION_EVENT,l_nRttpCode,l_sWords[0],l_sWords[1],""));}else 
if(l_nRttpCode>=SL4B_RttpCodes.const_STATUS_MSG&&l_nRttpCode<=SL4B_RttpCodes.const_ERROR_MSG){var l_sWords=A.getMessageContent().split(" ");
C_CallbackQueue.addCallback(new Array(this,"notifyConnectionListeners",this.const_MESSAGE_CONNECTION_EVENT,l_nRttpCode,l_sWords[0],l_sWords[1]));}else 
{}}
SL4B_JavaScriptRttpProvider.prototype.storeCapabilities = function(A){var pCapabilityKVPairs=A.split(",");
for(var i=0,nLength=pCapabilityKVPairs.length;i<nLength;++i){var sCapabilityKVPair=pCapabilityKVPairs[i];
var pWords=sCapabilityKVPair.split("=");
if(pWords.length==2){SL4B_Accessor.getCapabilities().add(pWords[0],pWords[1]);}}};
SL4B_JavaScriptRttpProvider.prototype.loggedIn = function(){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINEST_INT,"Login successful, starting NOOP messages");this.m_oConnectionManager.clearLoginTimeout();SL4B_NoopScheduler.startNoopSending();if(SL4B_Accessor.getConfiguration().isEnableLatency()){this.m_oConnectionManager.sendSync(true);}SL4B_AbstractRttpProvider.prototype.loggedIn.apply(this,[]);};
function SL_HL(){SL4B_Logger.logConnectionMessage(false,"JavaScriptRttpProvider.initialise");this.m_oConnectionManager.setMessageReceiver(this.m_oManagedConnection);this.m_bFatalError=(this.m_oConnectionManager.initialise()==false);}
function SL_JF(){return this.m_oConnectionManager.getJsContainerUrl();
}
function SL_CB(){this.m_oConnectionManager.responseHttpRequestReady();}
function SL_AY(){this.m_oConnectionManager.requestHttpRequestReady();}
function SL_CR(A){SL4B_Logger.logConnectionMessage(false,"JavaScriptRttpProvider.onLoad()");if(!this.m_bFatalError){this.m_oConnectionManager.startConnection();}}
SL4B_JavaScriptRttpProvider.prototype.onUnload = function(){this._removeStreamingFrame(SL4B_JavaScriptRttpProvider.const_REQUEST_FRAME_ID);this._removeStreamingFrame(SL4B_JavaScriptRttpProvider.const_RESPONSE_FRAME_ID);};
SL4B_JavaScriptRttpProvider.prototype._removeStreamingFrame = function(A){
try {var eFrameElement=SL4B_Accessor.getBrowserAdapter().getElementById(A);
eFrameElement.parentNode.removeChild(eFrameElement);}catch(e){}
};
function SL_OI(){this.m_oConnectionManager.connect();}
function SL_MK(){this.m_oConnectionManager.reconnect();}
function SL_NN(A,B){this.m_oConnectionManager.login(A,B);}
function SL_IH(A){this.m_oActionSubscriptionManager.throttleGlobal(A);}
function SL_AF(A,B){this.m_oActionSubscriptionManager.throttleObjects(A,B);}
function SL_AW(A,B){this.m_oActionSubscriptionManager.throttleObjects(A,B);}
function SL_QI(){this.m_oConnectionManager.logout();}
function SL_BA(){this.m_oConnectionManager.stop();}
function SL_EM(){return SL4B_Version.getVersion();
}
function SL_QB(){return SL4B_Version.getVersionInfo();
}
function SL_LD(C,B,A){this.m_oObjectSubscriptionManager.requestObject(this.getListener(C),B,A);}
function SL_KX(C,A,B){this.m_oObjectSubscriptionManager.requestObjects(this.getListener(C),A,B);}
function SL_LC(C,B,A){this.m_oObjectSubscriptionManager.discardObject(this.getListener(C),B,A);}
function SL_CP(C,A,B){this.m_oObjectSubscriptionManager.discardObjects(this.getListener(C),A,B);}
function SL_IW(A){this.m_oObjectSubscriptionManager.removeSubscriber(this.getListener(A));}
function SL_QN(C,A,B){if(B==null||B.size()==0){throw new SL4B_Exception("JavaScriptRttpProvider.contribObject: field data object cannot be null or empty");
}this.m_oActionSubscriptionManager.contribObject(this.getListener(C),A,B);}
function SL_GR(A,B){this.m_oActionSubscriptionManager.createObject(A,B);}
function SL_JU(A){this.m_oActionSubscriptionManager.deleteObject(A);}
function SL_NI(E,D,A,B,C){var l_sCombinedFieldList=this.createFieldListForAutoDirectory(B,C,A);
this.m_oObjectSubscriptionManager.registerProxySubscriber(this.getListener(E),this.getListener(new SL4B_ProxySubscriber(E)),D,l_sCombinedFieldList);this.m_oObjectSubscriptionManager.requestObject(this.getListener(E),D,l_sCombinedFieldList);}
function SL_FP(E,D,A,B,C){var l_sCombinedFieldList=this.createFieldListForAutoDirectory(B,C,A);
this.m_oObjectSubscriptionManager.discardObject(this.getListener(E),D,l_sCombinedFieldList);}
function SL_EF(E,A,C,D,B){return this.m_oObjectSubscriptionManager.getContainer(E,A,C,D,B);
}
function SL_DY(B,C,A){this.m_oObjectSubscriptionManager.setContainerWindow(B,C,A);}
function SL_MV(A){this.setContainerWindow(A);}
function SL_NV(B,A){var l_oRequestData=this.m_oObjectSubscriptionManager.getContainerRequestData(A.getId());
var l_sCombinedFieldList=this.createFieldListForContainer(A.getId(),l_oRequestData.getFieldList(),l_oRequestData.getWindowStart(),l_oRequestData.getWindowEnd());
this.m_oObjectSubscriptionManager.discardObject(this.getListener(B),l_oRequestData.getContainerName(),l_sCombinedFieldList);}
SL4B_JavaScriptRttpProvider.checkWindowRange = function(B,A){if(typeof (B)!="undefined"){if(typeof (A)=="undefined"){throw new SL4B_Exception("JavaScriptRttpProvider.getContainer: When specifying a window, both start and end must be passed");
}B=parseInt(B);A=parseInt(A);if(isNaN(B)||isNaN(A)){throw new SL4B_Exception("JavaScriptRttpProvider.getContainer: Both window parameters must be an integer");
}if(0>B||B>A){throw new SL4B_Exception("JavaScriptRttpProvider.getContainer: Window start must be non-negative and window end must be more than window start");
}}};
function SL_BX(A){return this.m_oConnectionManager.getFieldName(A);
}
var SL4B_ProxySubscriber=function(){};
if(false){function SL4B_ProxySubscriber(){}
}SL4B_ProxySubscriber = function(A){this.m_oProxy=A;this.m_bIsProxySubscriber=true;this.initialise();};
SL4B_ProxySubscriber.prototype = new SL4B_AbstractSubscriber;SL4B_ProxySubscriber.prototype.ready = function(){};
SL4B_ProxySubscriber.prototype.structureChange = function(A,D,C,B){this.m_oProxy.structureChange(A,D,C,B);};
SL4B_ProxySubscriber.prototype.chat = function(C,B,D,A,E){this.m_oProxy.chat(l_sObjectName,B,D,A,E);};
SL4B_ProxySubscriber.prototype.contribOk = function(A){this.m_oProxy.contribOk(A);};
SL4B_ProxySubscriber.prototype.contribFailed = function(A,B){this.m_oProxy.contribFailed(A,B);};
SL4B_ProxySubscriber.prototype.directoryUpdated = function(D,C,A,B){this.m_oProxy.directoryUpdated(D,C,A,B);};
SL4B_ProxySubscriber.prototype.directoryMultiUpdated = function(A,B){this.m_oProxy.directoryMultiUpdated(A,B);};
SL4B_ProxySubscriber.prototype.fieldDeleted = function(A,C,B){this.m_oProxy.fieldDeleted(A,C,B);};
SL4B_ProxySubscriber.prototype.type2Clear = function(A){this.m_oProxy.type2Clear(A);};
SL4B_ProxySubscriber.prototype.type3Clear = function(A){this.m_oProxy.type3Clear(A);};
SL4B_ProxySubscriber.prototype.newsUpdated = function(A,D,C,B){this.m_oProxy.newsUpdated(A,D,C,B);};
SL4B_ProxySubscriber.prototype.objectDeleted = function(A){this.m_oProxy.objectDeleted(A);};
SL4B_ProxySubscriber.prototype.objectInfo = function(C,B,D,A){this.m_oProxy.objectInfo(C,B,D,A);};
SL4B_ProxySubscriber.prototype.objectNotFound = function(A){this.m_oProxy.objectNotFound(A);};
SL4B_ProxySubscriber.prototype.objectNotStale = function(A,B){this.m_oProxy.objectNotStale(A,B);};
SL4B_ProxySubscriber.prototype.objectReadDenied = function(A){this.m_oProxy.objectReadDenied(A);};
SL4B_ProxySubscriber.prototype.objectStale = function(A,B){this.m_oProxy.objectStale(A,B);};
SL4B_ProxySubscriber.prototype.objectStatus = function(D,B,A,C){this.m_oProxy.objectStatus(D,B,A,C);};
SL4B_ProxySubscriber.prototype.objectType = function(C,B,A){this.m_oProxy.objectType(C,B,A);};
SL4B_ProxySubscriber.prototype.objectUnavailable = function(A){this.m_oProxy.objectUnavailable(A);};
SL4B_ProxySubscriber.prototype.objectUpdated = function(A){this.m_oProxy.objectUpdated(A);};
SL4B_ProxySubscriber.prototype.objectWriteDenied = function(A){this.m_oProxy.objectWriteDenied(A);};
SL4B_ProxySubscriber.prototype.pageUpdated = function(E,D,B,A,C){this.m_oProxy.pageUpdated(E,D,B,A,C);};
SL4B_ProxySubscriber.prototype.recordMultiUpdated = function(A,B){this.m_oProxy.recordMultiUpdated(A,B);};
SL4B_ProxySubscriber.prototype.recordUpdated = function(B,C,A){this.m_oProxy.recordUpdated(B,l_oFieldData);};
SL4B_ProxySubscriber.prototype.storyReset = function(A){this.m_oProxy.storyReset(A);};
SL4B_ProxySubscriber.prototype.storyUpdated = function(A,B){this.m_oProxy.storyUpdated(A,B);};
SL4B_ProxySubscriber.prototype.permissionUpdated = function(A,B,C){this.m_oProxy.permissionUpdated(A,B,C);};
SL4B_ProxySubscriber.prototype.permissionDeleted = function(A,B){this.m_oProxy.permissionDeleted(A,B);};
function SL4B_FieldCheck(){this.m_mFieldSet={};}
SL4B_FieldCheck.prototype.addFields = function(A){if(SL4B_ObjectSubscription.isAllFields(A)){this.m_mFieldSet[SL4B_ObjectSubscription.const_ALL_FIELDS]=true;}else 
{var l_pFields=A.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
for(var i=0,l_nLength=l_pFields.length;i<l_nLength;++i){this.m_mFieldSet[l_pFields[i]]=true;}}};
SL4B_FieldCheck.prototype.contains = function(A){var l_pFields=A.split(SL4B_ObjectCache.const_FIELD_NAME_DELIMITER);
var l_bContainsFields=true;
if(this.m_mFieldSet[SL4B_ObjectSubscription.const_ALL_FIELDS]!==true){if(SL4B_ObjectSubscription.isAllFields(A)){l_bContainsFields=false;}else 
{for(var i=0,l_nLength=l_pFields.length;i<l_nLength;++i){if(this.m_mFieldSet[l_pFields[i]]!==true){l_bContainsFields=false;break;
}}}}return l_bContainsFields;
};
var SL4B_TestRttpProvider=function(){};
if(false){function SL4B_TestRttpProvider(){}
}SL4B_TestRttpProvider = function(){SL4B_AbstractRttpProvider.apply(this);this.m_pObjects=new Object();this.m_pFields=new Object();this.m_pSubscriptions=new Object();this.m_nTickCount=1;this.addDecimalField("ASK",1.53,3.23);this.addDecimalField("BID",1.53,3.23);this.addDecimalField("OPEN",1.53,3.23);this.addDecimalField("CLOSE",1.53,3.23);this.addIntegerField("TRDPRC_1",10,23);this.addIntegerField("LAST",1,5);this.addObject("/I/VOD.L",1500,1);this.addObject("/I/BP.L",5000,4);this.addObject("/I/BARC.L",3000,133);this.addObject("/I/GBP=",12500,234);};
SL4B_TestRttpProvider.prototype = new SL4B_AbstractRttpProvider;SL4B_TestRttpProvider.prototype.tick = SL_CQ;SL4B_TestRttpProvider.prototype.addDecimalField = SL_CS;SL4B_TestRttpProvider.prototype.addIntegerField = SL_IO;SL4B_TestRttpProvider.prototype.addStringField = SL_BO;SL4B_TestRttpProvider.prototype.addObject = SL_EK;SL4B_TestRttpProvider.prototype.getNextValue = SL_KY;SL4B_TestRttpProvider.prototype.initialise = SL_FT;SL4B_TestRttpProvider.prototype.connect = SL_ES;SL4B_TestRttpProvider.prototype.login = SL_FJ;SL4B_TestRttpProvider.prototype.getObject = SL_DF;SL4B_TestRttpProvider.prototype.getObjects = SL_OQ;SL4B_TestRttpProvider.prototype.removeObject = SL_FL;SL4B_TestRttpProvider.prototype.removeObjects = SL_EB;SL4B_TestRttpProvider.prototype.getObjectType = SL_MB;SL4B_TestRttpProvider.prototype.setThrottleObject = SL_LB;SL4B_TestRttpProvider.prototype.setThrottleObjects = SL_QX;SL4B_TestRttpProvider.prototype.setGlobalThrottle = SL_QA;SL4B_TestRttpProvider.prototype.disableWTStatsTimeout = SL_QQ;SL4B_TestRttpProvider.prototype.clearObjectListeners = SL_JN;SL4B_TestRttpProvider.prototype.blockObjectListeners = SL_GV;SL4B_TestRttpProvider.prototype.unblockObjectListeners = SL_LA;SL4B_TestRttpProvider.prototype.createObject = SL_NP;SL4B_TestRttpProvider.prototype.contribObject = SL_AS;SL4B_TestRttpProvider.prototype.deleteObject = SL_AR;SL4B_TestRttpProvider.prototype.getFieldNames = SL_BN;SL4B_TestRttpProvider.prototype.logout = SL_PN;SL4B_TestRttpProvider.prototype.debug = SL_IP;SL4B_TestRttpProvider.prototype.setDebugLevel = SL_NR;SL4B_TestRttpProvider.prototype.getVersion = SL_LT;SL4B_TestRttpProvider.prototype.getVersionInfo = SL_OT;function SL_ES(){setTimeout("SL4B_Accessor.getRttpProvider().connected()",100);}
function SL_FT(){this.connect();}
function SL_FJ(A,B){this.credentialsRetrieved();this.loggedIn();this.m_hSetInterval=setInterval("SL4B_Accessor.getRttpProvider().tick()",200);}
function SL_DF(C,B,A){var l_oObject=this.m_pObjects[B];
if(typeof l_oObject=="undefined"){setTimeout(C.WTObjectNotFound(B),500);return;
}var l_oLiberatorSubscription=this.m_pSubscriptions[this.getListener(C)];
if(typeof l_oLiberatorSubscription=="undefined"){l_oLiberatorSubscription=new SL_IN();l_oLiberatorSubscription.m_oSubscriber=C;this.m_pSubscriptions[this.getListener(C)]=l_oLiberatorSubscription;}var l_oSubscriptionObject=l_oLiberatorSubscription.m_pObjects[B];
if(typeof l_oSubscriptionObject=="undefined"){l_oSubscriptionObject=new SL_CI();l_oSubscriptionObject.m_sName=B;l_oLiberatorSubscription.m_pObjects[B]=l_oSubscriptionObject;}l_oSubscriptionObject.add(A.split(","));}
function SL_OQ(C,A,B){l_pObjects=A.split(" ");for(var l_nCount=0;l_nCount<l_pObjects.length;l_nCount++){var l_sObjectName=l_pObjects[l_nCount];
this.getObject(C,l_sObjectName,B);}}
function SL_FL(C,B,A){throw new SL4B_Error("removeObject method not implemented in TestRttpProvider");
}
function SL_EB(C,A,B){throw new SL4B_Error("removeObjects method not implemented in TestRttpProvider");
}
function SL_MB(B,A){throw new SL4B_Error("getObjectType method not implemented in TestRttpProvider");
}
function SL_LB(A,B){var l_oObject=this.m_pObjects[A];
if(typeof l_oObject!="undefined"){}throw new SL4B_Error("setThrottleObject method not implemented in TestRttpProvider");
}
function SL_QX(A,B){throw new SL4B_Error("setThrottleObjects method not implemented in TestRttpProvider");
}
function SL_QA(A){throw new SL4B_Error("setGlobalThrottle method not implemented in TestRttpProvider");
}
function SL_QQ(A){throw new SL4B_Error("disableWTStatsTimeout method not implemented in TestRttpProvider");
}
function SL_JN(B,A){if(typeof A=="undefined"){}else 
{}}
function SL_GV(B,A){if(typeof A=="undefined"){}else 
{}}
function SL_LA(B,A){if(typeof A=="undefined"){}else 
{}}
function SL_NP(A,B){throw new SL4B_Error("createObject method not implemented in TestRttpProvider");
}
function SL_AS(C,A,B){for(var l_nFieldIndex=0,l_nLength=B.size();l_nFieldIndex<l_nLength;++l_nFieldIndex){var l_oField=B.getField(l_nFieldIndex);
if(l_nFieldIndex==(l_nLength-1)){this.m_oRttpApplet.contribObject(A,l_oField.m_sName,l_oField.m_sValue,this.getListener(C));}else 
{this.m_oRttpApplet.contribObject(A,l_oField.m_sName,l_oField.m_sValue,null);}}}
function SL_AR(A){throw new SL4B_Error("deleteObject method not implemented in TestRttpProvider");
}
function SL_BN(){var l_sNames="";
for(var l_nCount=0;l_nCount<l_pFieldNames.length;l_nCount++){if(l_nCount!=0){l_sNames+=",";}l_sNames+=l_pFieldNames[l_nCount];}return l_sNames;
}
function SL_PN(){clearInterval(this.m_hSetInterval);}
function SL_IP(B,A){throw new SL4B_Error("debug method not implemented in TestRttpProvider");
}
function SL_NR(A){throw new SL4B_Error("setDebugLevel method not implemented in TestRttpProvider");
}
function SL_LT(){throw new SL4B_Error("getVersion method not implemented in TestRttpProvider");
}
function SL_OT(){throw new SL4B_Error("getVersionInfo method not implemented in TestRttpProvider");
}
function SL_JL(){this.m_sName="";this.m_sType="numeric";this.m_sDefaultValue="?";this.m_nMax;this.m_nMin;}
function SL_FU(){this.m_sName="";this.m_sDirectory="";this.m_nFreqency=1000;this.m_nLastUpdateTime=0;this.m_nUpdateId=0;this.m_nOffset;this.m_pFields=new Object();}
function SL_BY(){this.m_sName="";this.m_sValue="";this.m_nUpdateId=0;}
function SL_IN(){this.m_oSubscriber=null;this.m_pObjects=new Object();this.toString = function(){var l_sRtn="";
for(l_sObjectName in this.m_pObjects){l_sRtn+="\t"+this.m_pObjects[l_sObjectName]+"\n";}return l_sRtn;
};
}
function SL_CI(){this.m_sName=null;this.m_pFields=new Object();this.m_nUpdateId=0;this.toString = function(){var l_sRtn=this.m_sName+": ";
for(l_sField in this.m_pFields){l_sRtn+=l_sField+", ";}return l_sRtn;
};
this.add = function(A){for(var l_nCount=0;l_nCount<A.length;l_nCount++){var l_sField=A[l_nCount];
if(typeof this.m_pFields[l_sField]=="undefined"){this.m_pFields[l_sField]=l_sField;}}};
}
function SL_HT(){this.m_sName=null;this.m_sValue=null;}
function SL_GX(){this.m_pData=new Array();}
SL_GX.prototype = new SL4B_RecordFieldData;SL_GX.prototype.size = function(){return this.m_pData.length;
};
SL_GX.prototype.getFieldName = function(A){this.checkIndex(A);return this.m_pData[A].m_sName;
};
SL_GX.prototype.getFieldValue = function(A){this.checkIndex(A);return this.m_pData[A].m_sValue;
};
SL_GX.prototype.checkIndex = function(A){if(A<0||A>=this.m_pData.length){throw new SL4B_Exception("Index "+A+" is out of bounds");
}};
function SL_CS(C,B,A){var l_oField=new SL_JL();
l_oField.m_sName=C;l_oField.m_sType="decimal";l_oField.m_nMin=B;l_oField.m_nMax=A;this.m_pFields[C]=l_oField;}
function SL_IO(C,B,A){var l_oField=new SL_JL();
l_oField.m_sName=C;l_oField.m_sType="integer";l_oField.m_nMin=B;l_oField.m_nMax=A;this.m_pFields[C]=l_oField;}
function SL_BO(B,A){var l_oField=new SL_JL();
l_oField.m_sName=B;l_oField.m_sType="string";l_oField.m_sDefaultValue=A;this.m_pFields[B]=l_oField;}
function SL_EK(C,A,B){var l_nNow=(new Date()).valueOf();
l_oObject=new SL_FU();l_oObject.m_sName=C;l_oObject.m_nOffset=B;l_oObject.m_nLastUpdateTime=0;l_oObject.m_nUpdateId=1;l_oObject.m_nFreqency=A;l_oObject.m_sDirectory=C.substring(0,C.lastIndexOf("/")+1);for(l_sFieldName in this.m_pFields){var l_oField=this.m_pFields[l_sFieldName];
var l_oFieldValue=new SL_BY();
l_oFieldValue.m_sName=l_oField.m_sName;l_oFieldValue.m_sValue=this.getNextValue(l_oObject,l_oField);l_oFieldValue.m_nUpdateId=1;l_oObject.m_pFields[l_oFieldValue.m_sName]=l_oFieldValue;}this.m_pObjects[C]=l_oObject;}
function SL_KY(B,A){var l_oReturn="";
if(A.m_sType=="decimal"){l_oReturn=(Math.random()*(A.m_nMax-A.m_nMin))+A.m_nMin+B.m_nOffset;l_oReturn=Math.floor(l_oReturn*100)/100;}if(A.m_sType=="integer"){l_oReturn=(Math.random()*(A.m_nMax-A.m_nMin))+A.m_nMin+B.m_nOffset;l_oReturn=Math.floor(l_oReturn);}return l_oReturn;
}
function SL_CQ(){this.m_nTickCount++;var l_nNow=(new Date()).valueOf();
for(l_sObjectName in this.m_pObjects){var l_oObject=this.m_pObjects[l_sObjectName];
if((l_oObject.m_nLastUpdateTime+l_oObject.m_nFreqency)<l_nNow){for(l_sFieldName in this.m_pFields){var l_oField=this.m_pFields[l_sFieldName];
var l_oFieldValue=l_oObject.m_pFields[l_oField.m_sName];
if(l_oField.m_sType=="decimal"||l_oField.m_sType=="integer"){if(Math.random()>0.5){l_oFieldValue.m_sValue=this.getNextValue(l_oObject,l_oField);l_oFieldValue.m_nUpdateId=this.m_nTickCount;l_oObject.m_nUpdateId=this.m_nTickCount;l_oObject.m_nLastUpdateTime=l_nNow;}}}}}for(l_sSubscriber in this.m_pSubscriptions){var l_oLiberatorSubscription=this.m_pSubscriptions[l_sSubscriber];
for(l_sObjectName in l_oLiberatorSubscription.m_pObjects){var l_oLiberatorSubsciptionObject=l_oLiberatorSubscription.m_pObjects[l_sObjectName];
var l_oObject=this.m_pObjects[l_sObjectName];
if(typeof l_oObject!="undefined"&&l_oObject.m_nUpdateId>l_oLiberatorSubsciptionObject.m_nUpdateId){var l_oData=new SL_GX();
for(l_sField in l_oLiberatorSubsciptionObject.m_pFields){var l_oFieldValue=l_oObject.m_pFields[l_sField];
if(typeof l_oFieldValue!="undefined"&&l_oFieldValue.m_nUpdateId>l_oLiberatorSubsciptionObject.m_nUpdateId){var l_oNotificationFieldValue=new SL_HT();
l_oNotificationFieldValue.m_sName=l_sField;l_oNotificationFieldValue.m_sValue=l_oFieldValue.m_sValue;l_oData.m_pData.push(l_oNotificationFieldValue);}}l_oLiberatorSubscription.m_oSubscriber.WTRecordMultiUpdated(l_sObjectName,l_oData);l_oLiberatorSubsciptionObject.m_nUpdateId=l_oObject.m_nUpdateId;}}}}
function SL_FA(){SL4B_ScriptLoader.createRttpProvider();}
function SL_KQ(){this.m_nSliceSize=20;this.m_pRtmlObjectContainers=new Object();this.initialise();}
SL_KQ.prototype = new SL4B_AbstractSubscriber;SL_KQ.prototype.ready = SL_KA;SL_KQ.prototype.getRequiredSymbols = SL_LO;SL_KQ.prototype.optimiseAndRequestObjects = SL_JQ;SL_KQ.prototype.recordUpdated = SL_BB;SL_KQ.prototype.objectStatus = SL_OH;function SL_KA(){SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"RtmlSubscriber.ready: called.");var l_pElements=this.getRequiredSymbols();
SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"RtmlSubscriber.ready: found {0} quote tags.",l_pElements.length);this.optimiseAndRequestObjects(l_pElements);}
function SL_LO(){SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"RtmlSubscriber: Finding quote tags...");var l_oQuoteTag=null;
var l_nCount=1;
var l_pListOfQuoteElements=new Array();
var l_oBrowserAdapter=SL4B_Accessor.getBrowserAdapter();
if(l_oBrowserAdapter.isInternetExplorer()){for(var i=0;i<document.all.length;i++){if(typeof (document.all[i].id)!='undefined'){if(document.all[i].id.toLowerCase()=="quote"){var l_oQuoteTag=document.all[i];
SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"RtmlSubscriber: Found quote tag... ("+l_nCount+") : "+l_oQuoteTag+"("+l_oQuoteTag.innerHTML+")");l_pListOfQuoteElements.push(l_oQuoteTag);l_oQuoteTag.id="QUOTE"+l_nCount++;}}}}else 
{
do{l_oQuoteTag=l_oBrowserAdapter.getElementById("QUOTE");if(l_oQuoteTag==null){l_oQuoteTag=l_oBrowserAdapter.getElementById("quote");if(l_oQuoteTag==null){l_oQuoteTag=l_oBrowserAdapter.getElementById("Quote");}}if(l_oQuoteTag!=null){SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"RtmlSubscriber: Found quote tag... ("+l_nCount++, +") : "+l_oQuoteTag+"("+l_oQuoteTag.innerHTML+")");l_pListOfQuoteElements.push(l_oQuoteTag);l_oQuoteTag.setAttribute("id","QUOTE"+l_pListOfQuoteElements.length);}}while(l_oQuoteTag!=null);}return l_pListOfQuoteElements;
}
function SL_JQ(A){for(var l_i=0;l_i<A.length;l_i++){var l_oQuoteElement=new SL_AE(A[l_i]);
if(this.m_pRtmlObjectContainers[l_oQuoteElement.m_sObjectName]==null){this.m_pRtmlObjectContainers[l_oQuoteElement.m_sObjectName]=new SL_CG(l_oQuoteElement.m_sObjectName);}this.m_pRtmlObjectContainers[l_oQuoteElement.m_sObjectName].addRtmlQuoteElement(l_oQuoteElement);}var l_pTagList=new Array();
for(l_sObjectName in this.m_pRtmlObjectContainers){l_pTagList=l_pTagList.concat(this.m_pRtmlObjectContainers[l_sObjectName].getUniqueFields());}l_pTagList.sort(SL_OZ);for(var l_i=l_pTagList.length-1;l_i>0;l_i--){if((l_pTagList[l_i].m_sFieldName==l_pTagList[l_i-1].m_sFieldName)){l_pTagList[l_i-1].m_sObjectName+=SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER+l_pTagList[l_i].m_sObjectName;l_pTagList=l_pTagList.slice(0,l_i).concat(l_pTagList.slice(l_i+1));}}l_pTagList.sort(SL_QR);for(var l_i=l_pTagList.length-1;l_i>0;l_i--){if((l_pTagList[l_i].m_sObjectName==l_pTagList[l_i-1].m_sObjectName)){l_pTagList[l_i-1].m_sFieldName+=","+l_pTagList[l_i].m_sFieldName;l_pTagList=l_pTagList.slice(0,l_i).concat(l_pTagList.slice(l_i+1));}}var l_nRequests=0;
if(this.m_nSliceSize>0){for(var l_i=0;l_i<l_pTagList.length;l_i++){var l_sSymbolsArray=l_pTagList[l_i].m_sObjectName.split(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
var l_nStart=0;
var l_nEnd=this.m_nSliceSize;
while(l_nEnd<l_sSymbolsArray.length){var l_sObjectName=(l_sSymbolsArray.slice(l_nStart,l_nEnd)).join(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"RtmlSubscriber.optimiseAndRequestObjects: Requesting object(s) {0} with fields {1}.",l_sObjectName,l_pTagList[l_i].m_sFieldName);SL4B_Accessor.getRttpProvider().getObjects(this,l_sObjectName,l_pTagList[l_i].m_sFieldName);l_nRequests++;l_nStart=l_nEnd;l_nEnd=l_nEnd+this.m_nSliceSize;}var l_sObjectName=(l_sSymbolsArray.slice(l_nStart,l_sSymbolsArray.length)).join(SL4B_AbstractRttpProvider.const_OBJECT_NAME_DELIMITER);
SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"RtmlSubscriber.optimiseAndRequestObjects: Requesting object(s) {0} with fields {1}.",l_sObjectName,l_pTagList[l_i].m_sFieldName);SL4B_Accessor.getRttpProvider().getObjects(this,l_sObjectName,l_pTagList[l_i].m_sFieldName);l_nRequests++;}}else 
{for(var l_i=0;l_i<l_pTagList.length;l_i++){SL4B_Logger.log(SL4B_DebugLevel.const_RTTP_FINE_INT,"RtmlSubscriber.optimiseAndRequestObjects: Requesting object(s) {0} with fields {1}.",l_pTagList[l_i].m_sObjectName,l_pTagList[l_i].m_sFieldName);SL4B_Accessor.getRttpProvider().getObjects(this,l_pTagList[l_i].m_sObjectName,l_pTagList[l_i].m_sFieldName);l_nRequests++;}}SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"RTML Subscriber: Made {0} requests after optimisation.",l_nRequests);}
function SL_OZ(A,B){if(A.m_sFieldName>B.m_sFieldName){return 1;
}if(A.m_sFieldName<B.m_sFieldName){return -1;
}if(A.m_sObjectName>B.m_sObjectName){return 1;
}if(A.m_sObjectName<B.m_sObjectName){return -1;
}return 0;
}
function SL_QR(A,B){if(A.m_sObjectName>B.m_sObjectName){return 1;
}if(A.m_sObjectName<B.m_sObjectName){return -1;
}return 0;
}
function SL_BB(B,C,A){this.m_pRtmlObjectContainers[B].updateRtmlQuoteElements(C,A);}
function SL_OH(D,B,A,C){if(B==SL4B_ObjectStatus.STALE){this.m_pRtmlObjectContainers[D].updateRtmlQuoteElementsStatus(true);}else 
if(B==SL4B_ObjectStatus.OK||B==SL4B_ObjectStatus.LIMITED){this.m_pRtmlObjectContainers[D].updateRtmlQuoteElementsStatus(false);}}
function SL_AE(A){this.m_sObjectName=A.getAttribute("symbol");this.m_sFieldName=A.getAttribute("field");if(this.m_sFieldName==null){this.m_sFieldName=A.getAttribute("fid");}this.m_oHtmlElement=A;this.m_dFlashTime=this.getQuoteAttribute("flashtime",SL_AE.const_INTEGER);this.m_sBgChange=this.getQuoteAttribute("bgchange",SL_AE.const_STRING);this.m_sBgDn=this.getQuoteAttribute("bgdn",SL_AE.const_BGCOLOR);this.m_sBgUp=this.getQuoteAttribute("bgup",SL_AE.const_BGCOLOR);this.m_sBgEq=this.getQuoteAttribute("bgeq",SL_AE.const_BGCOLOR);this.m_sFgChange=this.getQuoteAttribute("fgchange",SL_AE.const_STRING);this.m_sFgDn=this.getQuoteAttribute("fgdn",SL_AE.const_FGCOLOR);this.m_sFgUp=this.getQuoteAttribute("fgup",SL_AE.const_FGCOLOR);this.m_sFgEq=this.getQuoteAttribute("fgeq",SL_AE.const_FGCOLOR);this.m_sFgFlash=this.getQuoteAttribute("fgflash",SL_AE.const_STRING);this.m_sPlus=this.getQuoteAttribute("plus",SL_AE.const_INTEGER);this.m_dFractionHandling=this.getQuoteAttribute("fractionhandling",SL_AE.const_INTEGER);this.m_dToDp=this.getQuoteAttribute("todp",SL_AE.const_INTEGER);this.m_sRound=this.getQuoteAttribute("round",SL_AE.const_STRING);this.m_dAddCommas=this.getQuoteAttribute("addcommas",SL_AE.const_INTEGER);this.m_dToSf=this.getQuoteAttribute("tosf",SL_AE.const_POSITIVE_INTEGER);this.m_sGfxEq=this.getQuoteAttribute("gfxeq",SL_AE.const_STRING);this.m_sRootUrl=SL4B_ScriptLoader.getRelativeUrlPrefix();this.m_sGfxUp=this.getQuoteAttribute("gfxup",SL_AE.const_STRING);if(this.m_sGfxUp==null){this.m_sGfxUp=this.m_sRootUrl+'rtml/img/up.gif';}this.m_sGfxDn=this.getQuoteAttribute("gfxdn",SL_AE.const_STRING);if(this.m_sGfxDn==null){this.m_sGfxDn=this.m_sRootUrl+'rtml/img/down.gif';}this.m_fTransformFunction=null;
try {this.m_fTransformFunction=eval(this.getQuoteAttribute("transform",SL_AE.const_STRING));}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"RtmlQuoteElement.constructor: Transform function '{0}' could not be found!",this.getQuoteAttribute("transform",SL_AE.const_STRING));}
this.m_oTransformParam=null;
try {this.m_oTransformParam=eval("RTML_transformParam="+this.getQuoteAttribute("transformparam",SL_AE.const_STRING));}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"RtmlQuoteElement.constructor: Transform param {0} could not be parsed!",this.getQuoteAttribute("transformparam",SL_AE.const_STRING));}
this.m_bIsIndicator=(A.getAttribute("indicator")!=null);l_bContainsChange=false;if(this.m_sFieldName!=null){var l_bContainsChange=((this.m_sFieldName.toLowerCase().indexOf('chng')!=-1)||(this.m_sFieldName.toLowerCase().indexOf('change')!=-1));
}if(this.m_sFgChange==null&&l_bContainsChange==true){this.m_sFgChange="abs";}if(this.m_sPlus==null&&l_bContainsChange==true){this.m_sPlus=1;}if(this.m_sBgChange=="rel"&&this.m_sFgChange=="abs"){this.m_sChangedType="RtmlAbsFgRelBg"+this.m_oHtmlElement.getAttribute("id");this.m_fChangedFunction=RTML_AbsFgRelBgUpdate;}else 
if(this.m_sBgChange=="abs"&&this.m_sFgChange=="abs"){this.m_sChangedType="RtmlAbsolute"+this.m_oHtmlElement.getAttribute("id");this.m_fChangedFunction=RTML_AbsoluteUpdate;}else 
if(this.m_sBgChange=="abs"){this.m_sChangedType="RtmlRelFgAbsBg"+this.m_oHtmlElement.getAttribute("id");this.m_fChangedFunction=RTML_RelFgAbsBgUpdate;}else 
if(this.m_sBgChange=="rel"){this.m_sChangedType="RtmlRelative"+this.m_oHtmlElement.getAttribute("id");this.m_fChangedFunction=RTML_RelativeUpdate;}if(this.m_dFlashTime<=0||this.m_sBgUp.toLowerCase().indexOf("none")!=-1||this.m_sBgDn.toLowerCase().indexOf("none")!=-1||this.m_sBgEq.toLowerCase().indexOf("none")!=-1){this.m_sBgUp=this.m_sBgDn=this.m_sBgEq="";}if(this.m_sFgUp.toLowerCase().indexOf("none")!=-1||this.m_sFgDn.toLowerCase().indexOf("none")!=-1||this.m_sFgEq.toLowerCase().indexOf("none")!=-1){this.m_sFgUp=this.m_sFgDn=this.m_sFgEq=this.m_sFgFlash="";}RTSL_AddFlashType(this.m_sChangedType,this.m_fChangedFunction,this.m_sBgUp,this.m_sBgDn,this.m_sBgEq,'',this.m_sFgFlash,this.m_sFgFlash,this.m_sFgFlash,'black',this.m_sFgUp,this.m_sFgDn,this.m_sFgEq,'black');}
SL_AE.prototype.updateQuoteValue = SL_ON;SL_AE.prototype.updateQuoteStatus = SL_QF;SL_AE.prototype.getQuoteAttribute = SL_JO;SL_AE.prototype.getParentAttribute = SL_MG;SL_AE.const_INTEGER=1;SL_AE.const_POSITIVE_INTEGER=2;SL_AE.const_STRING=3;SL_AE.const_FGCOLOR=4;SL_AE.const_BGCOLOR=5;function RTML_RelativeUpdate(A,C,D,G,B,E,F){var l_oUpdateFlash=SL_CX(A,C,D.value,G,B);
return (new GF_Update(C,D.displayValue,l_oUpdateFlash.m_sFlashClr,l_oUpdateFlash.m_sFlashText,l_oUpdateFlash.m_sFinalText,l_oUpdateFlash.m_sFinalClr,G,B,'innerText',F));
}
function RTML_AbsoluteUpdate(D,B,C,G,A,E,F){var l_sPrevVal=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B] : '');
g_pPreviousValue[B]=C.value;var l_oFinalUpdate=SL_NE(D,0,GF_ConvertToDecimal(C.value),'0.00');
return (new GF_Update(B,C.displayValue,l_oFinalUpdate.m_sFlashClr,l_oFinalUpdate.m_sFlashText,l_oFinalUpdate.m_sFinalText,l_oFinalUpdate.m_sFinalClr,G,A,'innerText',F));
}
function RTML_AbsFgRelBgUpdate(D,B,C,G,A,E,F){var l_sPrevVal=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B] : '');
g_pPreviousValue[B]=C.value;var l_nOld=GF_ConvertToDecimal(l_sPrevVal);
var l_nNew=GF_ConvertToDecimal(C.value);
var l_oRelUpdate=SL_NE(D,l_nOld,l_nNew,l_sPrevVal);
var l_oAbsUpdate=SL_NE(D,0,l_nNew,'0.00');
return (new GF_Update(B,C.displayValue,l_oRelUpdate.m_sFlashClr,l_oAbsUpdate.m_sFlashText,l_oAbsUpdate.m_sFinalText,l_oRelUpdate.m_sFinalClr,G,A,'innerText',F));
}
function RTML_RelFgAbsBgUpdate(D,B,C,G,A,E,F){var l_sPrevVal=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B] : '');
g_pPreviousValue[B]=C.value;var l_nOld=GF_ConvertToDecimal(l_sPrevVal);
var l_nNew=GF_ConvertToDecimal(C.value);
var l_oRelUpdate=SL_NE(D,l_nOld,l_nNew,l_sPrevVal);
var l_oAbsUpdate=SL_NE(D,0,l_nNew,'0.00');
return (new GF_Update(B,C.displayValue,l_oAbsUpdate.m_sFlashClr,l_oRelUpdate.m_sFlashText,l_oRelUpdate.m_sFinalText,l_oAbsUpdate.m_sFinalClr,G,A,'innerText',F));
}
function SL_ON(A){if(!this.m_bIsIndicator){var l_dNewComparisonValue=A;
switch(this.m_dFractionHandling){
case 1:A=RTSL_FractionToDecimal(A);l_dNewComparisonValue=A;break;
case 2:A=RTSL_FractionSimplify(A);l_dNewComparisonValue=RTSL_FractionToDecimal(A);break;
case 3:l_dNewComparisonValue=RTSL_FractionToDecimal(A);break;
}if(this.m_fTransformFunction!=null){var l_oTransformResult=this.m_fTransformFunction(A,this.m_oTransformParam,this.m_sObjectName,this.m_sFieldName);
if(l_oTransformResult instanceof RTML_TransformResult){l_dNewComparisonValue=l_oTransformResult.value;A=l_oTransformResult.displayValue;}else 
{l_dNewComparisonValue=l_oTransformResult;A=l_oTransformResult;}}if(this.m_dToSf>0){A=RTSL_ToSignificantFigures(A,this.m_dToSf);}if(this.m_dToDp>0){A=RTSL_ToDecimalPlaces(A,this.m_dToDp,false,this.m_sRound);}if(this.m_dAddCommas==1){A=RTSL_AddCommas(A);}if((this.m_sPlus==1)&&(parseFloat(A)>0)){A='+'+A;}var l_oUpdateValue=new RTML_TransformResult(l_dNewComparisonValue,A);
var l_oUpdate=RTSL_CreateUpdate(this.m_oHtmlElement.getAttribute("id"),this.m_sChangedType,l_oUpdateValue,false,false,null,this.m_dFlashTime);
}else 
{var l_sImgId=this.m_oHtmlElement.id+"Img";
if(this.m_oHtmlElement.innerHTML.indexOf("IMG")==-1&&this.m_oHtmlElement.innerHTML.indexOf("img")==-1){this.m_oHtmlElement.innerHTML="<i"+"mg id="+l_sImgId+" src='"+this.m_sRootUrl+"rtml/img/blank.gif'"+"></i"+"mg>";}var l_oImageArray=new MOD_CreateImages(0,8,8);
l_oImageArray.addImage(-1,this.m_sGfxDn);(this.m_sGfxEq==null) ? l_oImageArray.addImage(0,this.m_sRootUrl+'rtml/img/blank.gif') : l_oImageArray.addImage(0,this.m_sGfxEq);l_oImageArray.addImage(1,this.m_sGfxUp);var l_oUpdate=null;
if(this.m_sFgChange=='rel'||this.m_sFgChange==null){if(this.m_sGfxEq==null){l_oUpdate=RTSL_CreateUpdate(l_sImgId,'UpDownRelIndicator',A,false,false,l_oImageArray);}else 
{l_oUpdate=RTSL_CreateUpdate(l_sImgId,'Indicator',A,false,false,l_oImageArray);}}else 
{l_oUpdate=RTSL_CreateUpdate(l_sImgId,'UpDownAbsIndicator',A,false,false,l_oImageArray);}}RTSL_DisplayUpdate(l_oUpdate);}
function SL_QF(A){if(!this.m_bIsIndicator){if(A){RTSL_FlushUpdate(this.m_oHtmlElement.getAttribute("id"));this.m_oHtmlElement.style.textDecoration="line-through";}else 
{this.m_oHtmlElement.style.textDecoration="none";}}}
function SL_JO(B,A){var isError=false;
var l_vAttributeValue=this.m_oHtmlElement.getAttribute(B);
if(l_vAttributeValue==null){switch(A){
case SL_AE.const_FGCOLOR:l_vAttributeValue=this.getQuoteAttribute("fg",SL_AE.const_STRING);break;
case SL_AE.const_BGCOLOR:l_vAttributeValue=this.getQuoteAttribute("bg",SL_AE.const_STRING);break;
}}if(l_vAttributeValue==null){l_vAttributeValue=this.getParentAttribute(B);}if(l_vAttributeValue!=null){switch(A){
case SL_AE.const_INTEGER:isError=!SL4B_Accessor.getConfiguration().checkInteger(l_vAttributeValue);l_vAttributeValue=parseInt(l_vAttributeValue);break;
case SL_AE.const_POSITIVE_INTEGER:isError=!SL4B_Accessor.getConfiguration().checkPositiveInteger(l_vAttributeValue);l_vAttributeValue=parseInt(l_vAttributeValue);break;
case SL_AE.const_STRING:default :break;
}}if(isError){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"LF_RtmlQuoteElement_GetQuoteAttribute: Attribute Value: {0} for Attribute {1} is Incorrect, Using Defaults",l_vAttributeValue,B);}if(l_vAttributeValue==null||isError){switch(A){
case SL_AE.const_INTEGER:l_vAttributeValue=SL4B_Accessor.getConfiguration().getIntegerScriptTagAttribute(B);break;
case SL_AE.const_POSITIVE_INTEGER:l_vAttributeValue=SL4B_Accessor.getConfiguration().getPositiveIntegerScriptTagAttribute(B);break;
case SL_AE.const_STRING:default :l_vAttributeValue=SL4B_Accessor.getConfiguration().getScriptTagAttribute(B);break;
}}return l_vAttributeValue;
}
function SL_MG(A){var l_vAttributeValue=null;
var l_oCurrentElement=this.m_oHtmlElement.parentNode;
while(l_oCurrentElement!=window.document&&l_oCurrentElement!=null&&typeof (l_oCurrentElement.getAttribute)!='undefined'){l_vAttributeValue=l_oCurrentElement.getAttribute(A);if(l_vAttributeValue!=null){break;
}l_oCurrentElement=l_oCurrentElement.parentNode;}return l_vAttributeValue;
}
function SL_CG(A){this.m_sObjectName=A;this.m_pRtmlQuoteElements=new Object();}
SL_CG.prototype.addRtmlQuoteElement = SL_JG;SL_CG.prototype.getUniqueFields = SL_KR;SL_CG.prototype.updateRtmlQuoteElements = SL_FR;SL_CG.prototype.updateRtmlQuoteElementsStatus = SL_GH;function SL_JG(A){if(this.m_pRtmlQuoteElements[A.m_sFieldName]==null){this.m_pRtmlQuoteElements[A.m_sFieldName]=new Array();}this.m_pRtmlQuoteElements[A.m_sFieldName].push(A);}
function SL_KR(){var l_pUniqueFields=new Array();
for(l_sFieldName in this.m_pRtmlQuoteElements){l_pUniqueFields.push(this.m_pRtmlQuoteElements[l_sFieldName][0]);}return l_pUniqueFields;
}
function SL_FR(B,A){var l_pElements=this.m_pRtmlQuoteElements[B];
for(l_oQuoteElement in l_pElements){l_pElements[l_oQuoteElement].updateQuoteValue(A);}}
function SL_GH(A){for(l_sFieldName in this.m_pRtmlQuoteElements){var l_pElements=this.m_pRtmlQuoteElements[l_sFieldName];
for(l_oQuoteElement in l_pElements){l_pElements[l_oQuoteElement].updateQuoteStatus(A);}}}
RTML_RtmlSubscriberAccessor = new function(){this.m_oRtmlSubscriber=new SL_KQ();this.getRtmlSubscriber = function(A){return ((typeof A=="undefined") ? this.m_oRtmlSubscriber : A);
};
};
RTML_TransformResult = function(A,B){this.value=A;this.displayValue=B;};
function RTSL_ToDecimalPlaces(A,B,C,D){if(isNaN(A)){return A;
}var l_sRoundType=RTSL_DefaultValue(D,"default");
var l_nPower=Math.pow(10,B);
var l_nVal;
if(l_sRoundType=="up"){l_nVal=(Math.ceil(A*l_nPower))/l_nPower;}else 
if(l_sRoundType=="down"){l_nVal=(Math.floor(A*l_nPower))/l_nPower;}else 
{l_nVal=(Math.round(A*l_nPower))/l_nPower;}var l_sVal=l_nVal.toString(10);
if(l_nVal==0){l_sVal+=".";for(var l_nCount=0;l_nCount<B;l_nCount++){l_sVal+="0";}}if(C){var l_nNumZeros=l_sVal.search(/\./);
var l_bNeedsDot=false;
if(l_nNumZeros==-1){l_nNumZeros=B;l_bNeedsDot=true;}else 
{l_nNumZeros=B-(l_sVal.length-l_nNumZeros-1);l_nNumZeros=((l_nNumZeros<0) ? (0) : (l_nNumZeros));}if(l_nNumZeros>0){if(l_bNeedsDot){l_sVal+=".";}}for(var l_nCount=0;l_nCount<l_nNumZeros;l_nCount++){l_sVal+="0";}}return l_sVal;
}
function RTSL_AddCommas(A){if(isNaN(A)){return A;
}var l_sAbsVal=new String(Math.abs(A));
l_sAbsVal=l_sAbsVal.split('.');var l_sComma='';
var l_nPosition;

do{l_sComma=l_sAbsVal[0].substr(((l_sAbsVal[0].length-3>=0) ? l_sAbsVal[0].length-3 : 0))+((l_sComma!='') ? ',' : '')+l_sComma;l_sAbsVal[0]=l_sAbsVal[0].substr(0,l_sAbsVal[0].length-3);}while(l_sAbsVal[0].length>0);var l_sVal=new String(A);
l_sVal=l_sVal.split('.');if(typeof (l_sVal[1])!='undefined'&&l_sVal[1].length>0){l_sComma+='.'+l_sVal[1];}var l_nDir=((A==0) ? 1 : (A/Math.abs(A)));
l_sComma=((l_nDir==1) ? l_sComma : ('-'+l_sComma));return l_sComma;
}
function RTSL_FractionToDecimal(A){if(!SL_LR(A)){return A;
}A=A.toString();var l_nVal=new Number(A);
var l_nInt=SL_CV(A);
if(isNaN(l_nInt)){return A;
}var l_nNum=SL_KU(A);
if(isNaN(l_nNum)){return A;
}var l_nDen=SL_BF(A);
if(isNaN(l_nDen)){return A;
}var l_nDec=(l_nDen==0) ? (0) : (SL_ET(A)*l_nNum/l_nDen);
l_nVal=l_nInt+l_nDec;return l_nVal;
}
function RTSL_FractionSimplify(A){if(!SL_LR(A)){return A;
}var l_nInt=SL_CV(A);
if(isNaN(l_nInt)){return A;
}var l_nNum=SL_KU(A);
if(isNaN(l_nNum)){return A;
}else 
if(l_nNum==0){return l_nInt.toString();
}var l_nDen=SL_BF(A);
if(isNaN(l_nDen)){return A;
}else 
if(l_nDen==0){return A;
}var l_nHcm=SL_QZ(l_nNum,l_nDen);
l_nNum/=l_nHcm;l_nDen/=l_nHcm;var l_sStr=((l_nInt==0) ? '' : (l_nInt.toString()+' '));
return (l_sStr+l_nNum.toString()+'/'+l_nDen.toString());
}
function RTSL_FractionToHTML(A){var l_sMatch;
if(l_sMatch=A.match(/\-?[0-9]+\s[0-9]+\/[0-9]+/)){var l_sInt=(l_sMatch.toString().match(/^\-?[0-9]+/)).toString();
var l_sFraction=(l_sMatch.toString().match(/[0-9]+\/[0-9]+$/)).toString();
A=l_sInt+SL_KM(l_sFraction);}else 
if(l_sMatch=A.match(/[0-9]+\/[0-9]+$/)){var l_sFraction=(l_sMatch.toString().match(/[0-9]+\/[0-9]+$/)).toString();
A=SL_KM(l_sFraction);if(A.charAt(0)==0){A=A.substring(1);}}return A;
}
function SL_KM(A){var l_sResult;
var l_nFrac=eval(A);
switch(l_nFrac){
case 0.25:l_sResult='&frac14;';break;
case 0.5:l_sResult='&frac12;';break;
case 0.75:l_sResult='&frac34;';break;
default :l_sResult=' '+A;}return l_sResult;
}
function RTSL_ToSignificantFigures(B,A){if(B==null||isNaN(B)||A<=0||B=="0"){return B;
}B=B.toString();var l_bSign=(B.indexOf("-")==0);
if(l_bSign){B=B.substr(1);}var l_oRegExp=/^[^1-9]*/;
var l_sBegin=B.match(l_oRegExp).toString();
var l_sEnd=B.replace(l_oRegExp,"");
l_sEnd=SL_IE(l_sEnd,A);if(l_sBegin.length){if(l_sEnd.length<A){for(var l_nCount=l_sEnd.length;l_nCount<A;l_nCount++){l_sEnd+="0";}}else 
if(l_sEnd.length>A){l_sEnd=l_sEnd.substring(0,A);}}return ((l_bSign) ? ("-") : (""))+l_sBegin+l_sEnd;
}
function SL_IE(B,A){var l_bPadZeros=true;
var l_nLengthToUse=Math.round(B).toString().length;
var l_nPower=Math.pow(10,-(l_nLengthToUse-A));
var l_nVal;
l_nVal=(Math.round(B*l_nPower))/l_nPower;var l_sVal=l_nVal.toString(10);
return l_sVal;
}
function SL_LR(A){return (A.toString().indexOf("/",1)==-1) ? false : true;
}
function SL_CV(A){var l_nSpacePos=A.indexOf(" ",1);
var l_vResult;
if(l_nSpacePos==-1){l_vResult=0;}else 
if('u'+parseInt(A.substring(0,l_nSpacePos))=='uNaN'){l_vResult=A;}else 
{l_vResult=parseInt(A.substring(0,l_nSpacePos));}return l_vResult;
}
function SL_KU(A){var l_nSpacePos=A.indexOf(" ",1);
var l_nDivPos=A.indexOf('/');
return parseInt(A.substring(l_nSpacePos,l_nDivPos),10);
}
function SL_BF(A){var l_nDivPos=A.indexOf('/');
return new Number(A.substr(l_nDivPos+1));
}
function SL_ET(A){return (A.charAt(0)=='-') ? -1 : 1;
}
function SL_QZ(A,B){var l_nResult;
l_nResult=A%B;if(l_nResult==0){return B;
}return SL_QZ(B,l_nResult);
}
LF_ElementCache = new function(){this.m_pElementLookup=new Object();this.m_pHtmlElements=new Object();this.getElement = function(A){var l_oElement=this.m_pElementLookup[A];
if(typeof l_oElement=="undefined"||l_oElement==null){if(typeof RTSL_GetElementFromDOM=="function"){l_oElement=RTSL_GetElementFromDOM(A);}else 
{l_oElement=SL4B_Accessor.getBrowserAdapter().getElementById(A);}this.addElement(A,l_oElement);}return l_oElement;
};
this.addElement = function(B,A){var l_bAdded=(typeof A!="undefined"&&A!=null&&typeof B!="undefined"&&B!=null);
if(l_bAdded){this.m_pElementLookup[B]=A;}return l_bAdded;
};
this.removeElement = function(A){var l_bRemoved=(typeof this.m_pElementLookup[A]!="undefined");
if(l_bRemoved){delete (this.m_pElementLookup[A]);}return l_bRemoved;
};
this.reset = function(){this.m_pElementLookup=new Array();};
};
function RTSL_GetElementFromCache(A){return LF_ElementCache.getElement(A);
}
function RTSL_AddElementToCache(B,A){return LF_ElementCache.addElement(B,A);
}
function RTSL_RemoveElementFromCache(A){return LF_ElementCache.removeElement(A);
}
function RTSL_ResetElementCache(){LF_ElementCache.reset();}
function RTSL_CreateElement(A,B,C){var l_oElement;
if(typeof document.createElement==null){l_oElement=null;}else 
{var l_oTemplate=LF_ElementCache.m_pHtmlElements[A.toLowerCase()];
if(l_oTemplate){l_oElement=l_oTemplate.cloneNode(true);}else 
{LF_ElementCache.m_pHtmlElements[A.toLowerCase()]=document.createElement(A);l_oElement=RTSL_CreateElement(A,B,C);}if(typeof B!="undefined"&&B!=null){l_oElement.id=B;RTSL_AddElementToCache(B,l_oElement);}if(C&&typeof C!="undefined"){C.appendChild(l_oElement);}}return l_oElement;
}
function SL_HH(){}
SL_HH.prototype = new SL4B_ConnectionListener;SL_HH.prototype.loginOk = SL_RE;SL_HH.prototype.loginError = SL_PU;SL_HH.prototype.connectionOk = SL_AV;SL_HH.prototype.connectionError = SL_IK;function SL_RE(){if(typeof RTSL_LoginOk=="function"){RTSL_LoginOk(null);}}
function SL_PU(A){if(typeof RTSL_LoginFailed=="function"){RTSL_LoginFailed(null,A);}else 
{SL4B_Logger.synchronizedAlert('Sorry. You do not have the authorisation to view live data from this source.\nPlease contact the web site host if you have received this message in error.');}}
function SL_AV(C,A,B){if(typeof RTSL_StatusConnected=="function"){RTSL_StatusConnected(null);}}
function SL_IK(){if(typeof RTSL_ConnectionLost=="function"){RTSL_ConnectionLost(null);}else 
{SL4B_Logger.synchronizedAlert("Connection lost - reconnection failed");}}
function SL_IL(){SL4B_Accessor.getRttpProvider().addConnectionListener(new SL_HH());}
function SL_EQ(){this.initialise();}
SL_EQ.prototype = new SL4B_AbstractSubscriber;SL_EQ.prototype.ready = SL_CH;SL_EQ.prototype.directoryUpdated = SL_JY;SL_EQ.prototype.newsUpdated = SL_KH;SL_EQ.prototype.objectUpdated = SL_OS;SL_EQ.prototype.pageUpdated = SL_BD;SL_EQ.prototype.super_recordMultiUpdated = SL_EQ.prototype.recordMultiUpdated;SL_EQ.prototype.recordMultiUpdated = SL_NU;SL_EQ.prototype.recordUpdated = SL_PH;SL_EQ.prototype.storyReset = SL_BE;SL_EQ.prototype.storyUpdated = SL_NS;SL_EQ.prototype.chat = SL_CA;SL_EQ.prototype.contribFailed = SL_PM;SL_EQ.prototype.contribOk = SL_JM;SL_EQ.prototype.fieldDeleted = SL_GS;SL_EQ.prototype.type2Clear = SL_MT;SL_EQ.prototype.type3Clear = SL_PA;SL_EQ.prototype.objectDeleted = SL_EN;SL_EQ.prototype.objectInfo = SL_EG;SL_EQ.prototype.objectNotFound = SL_FD;SL_EQ.prototype.objectStatus = SL_KF;SL_EQ.prototype.objectType = SL_JD;SL_EQ.prototype.objectUnavailable = SL_IM;SL_EQ.prototype.objectNotStale = SL_NC;SL_EQ.prototype.objectStale = SL_HS;SL_EQ.prototype.objectReadDenied = SL_MQ;SL_EQ.prototype.objectWriteDenied = SL_HR;SL_EQ.prototype.clientMethodUndefined = SL_ID;function SL_CH(){if(typeof RTSL_Ready=="function"){RTSL_Ready();}else 
{if(SL4B_Accessor.getConfiguration().includeRtsl()){this.clientMethodUndefined("RTSL_Ready","This method must be present in your script in order to use RTSL!");SL4B_Accessor.getRttpProvider().stop();}}}
function SL_JY(D,C,A,B){if(typeof RTSL_DirUpdated=="function"){RTSL_DirUpdated(D,C,A,B);}else 
{this.clientMethodUndefined("RTSL_DirUpdated");}}
function SL_KH(C,D,B,A){if(typeof RTSL_NewsUpdated=="function"){RTSL_NewsUpdated(C,D,B,A);}else 
{this.clientMethodUndefined("RTSL_NewsUpdated");}}
function SL_OS(A){if(typeof RTSL_ObjectUpdated=="function"){RTSL_ObjectUpdated(A);}else 
{this.clientMethodUndefined("RTSL_ObjectUpdated");}}
function SL_BD(D,B,A,E,C){if(typeof RTSL_PageUpdated=="function"){RTSL_PageUpdated(D,B,A,E,C);}else 
{this.clientMethodUndefined("RTSL_PageUpdated");}}
function SL_NU(A,B){if(typeof RTSL_RecordMultiUpdated=="function"){RTSL_RecordMultiUpdated(A,B);}else 
{this.super_recordMultiUpdated(A,B);}}
function SL_PH(B,C,A){if(typeof RTSL_RecordUpdated=="function"){RTSL_RecordUpdated(B,C,A);}else 
{this.clientMethodUndefined("RTSL_RecordUpdated");}}
function SL_BE(A){if(typeof RTSL_StoryReset=="function"){RTSL_StoryReset(A);}else 
{this.clientMethodUndefined("RTSL_StoryReset");}}
function SL_NS(B,A){if(typeof RTSL_StoryUpdated=="function"){RTSL_StoryUpdated(B,A);}else 
{this.clientMethodUndefined("RTSL_StoryUpdated");}}
function SL_CA(){}
function SL_PM(B,A,C){if(typeof RTSL_ContribFailed=="function"){RTSL_ContribFailed(B,A,C);}else 
{this.clientMethodUndefined("RTSL_ContribFailed");}}
function SL_JM(B,A){if(typeof RTSL_ContribOk=="function"){RTSL_ContribOk(B,A);}else 
{this.clientMethodUndefined("RTSL_ContribOk");}}
function SL_GS(C,A,B){if(typeof RTSL_FieldDeleted=="function"){RTSL_FieldDeleted(C,A,B);}else 
{this.clientMethodUndefined("RTSL_FieldDeleted");}}
function SL_MT(A){if(typeof RTSL_Type2Clear=="function"){RTSL_Type2Clear(A);}else 
{this.clientMethodUndefined("RTSL_Type2Clear");}}
function SL_PA(A){if(typeof RTSL_Type3Clear=="function"){RTSL_Type3Clear(A);}else 
{this.clientMethodUndefined("RTSL_Type3Clear");}}
function SL_EN(A){if(typeof RTSL_ObjectDeleted=="function"){RTSL_ObjectDeleted(A);}else 
{this.clientMethodUndefined("RTSL_ObjectDeleted");}}
function SL_EG(B,A,C,D){if(typeof RTSL_ObjectInfo=="function"){RTSL_ObjectInfo(B,A,C,D);}else 
{this.clientMethodUndefined("RTSL_ObjectInfo");}}
function SL_FD(A){if(typeof RTSL_ObjectNotFound=="function"){RTSL_ObjectNotFound(A);}else 
{this.clientMethodUndefined("RTSL_ObjectNotFound");}}
function SL_KF(C,B,A,D){if(typeof RTSL_ObjectStatus=="function"){RTSL_ObjectStatus(C,B,A,D);}else 
{this.clientMethodUndefined("RTSL_ObjectStatus");}}
function SL_JD(C,B,A){if(typeof RTSL_ObjectType=="function"){RTSL_ObjectType(C,B,A);}else 
{this.clientMethodUndefined("RTSL_ObjectType");}}
function SL_IM(A){if(typeof RTSL_ObjectUnavailable=="function"){RTSL_ObjectUnavailable(A);}else 
{this.clientMethodUndefined("RTSL_ObjectUnavailable");}}
function SL_NC(A){}
function SL_HS(){}
function SL_MQ(A){if(typeof RTSL_ObjectReadDenied=="function"){RTSL_ObjectReadDenied(A);}else 
{this.clientMethodUndefined("RTSL_ObjectReadDenied");}}
function SL_HR(A){if(typeof RTSL_ObjectWriteDenied=="function"){RTSL_ObjectWriteDenied(A);}else 
{this.clientMethodUndefined("RTSL_ObjectWriteDenied");}}
function SL_ID(B,A){SL4B_Logger.alert(B+" is undefined."+((typeof A!="undefined") ? " "+A : ""));}
RTSL_RtslSubscriberAccessor = new function(){this.m_oRtslSubscriber=new SL_EQ();this.getRtslSubscriber = function(A){return ((typeof A=="undefined") ? this.m_oRtslSubscriber : A);
};
};
function RTSL_BlockObjectListeners(A,B){SL4B_Accessor.getRttpProvider().blockObjectListeners(RTSL_RtslSubscriberAccessor.getRtslSubscriber(B),A);}
function RTSL_ClearObjectListeners(A,B){SL4B_Accessor.getRttpProvider().clearObjectListeners(RTSL_RtslSubscriberAccessor.getRtslSubscriber(B),A);}
function RTSL_GetObject(B,A,C){SL4B_Accessor.getRttpProvider().getObject(RTSL_RtslSubscriberAccessor.getRtslSubscriber(C),B,A);}
function RTSL_GetObjects(A,B,C){SL4B_Accessor.getRttpProvider().getObjects(RTSL_RtslSubscriberAccessor.getRtslSubscriber(C),A,B);}
function RTSL_Reconnect(){SL4B_Accessor.getRttpProvider().reconnect();}
function RTSL_RemoveObject(D,C,F,A,B,E){SL4B_Accessor.getRttpProvider().removeObject(RTSL_RtslSubscriberAccessor.getRtslSubscriber(F),D,C);}
function RTSL_RemoveObjects(C,D,F,A,B,E){SL4B_Accessor.getRttpProvider().removeObjects(RTSL_RtslSubscriberAccessor.getRtslSubscriber(F),C,D);}
function RTSL_SetGlobalThrottle(A){SL4B_Accessor.getRttpProvider().setGlobalThrottle(A);}
function RTSL_SetThrottleObject(A,B){SL4B_Accessor.getRttpProvider().setThrottleObject(A,B);}
function RTSL_SetThrottleObjects(A,B){SL4B_Accessor.getRttpProvider().setThrottleObjects(A,B);}
function RTSL_Stop(){SL4B_Accessor.getRttpProvider().stop();}
function RTSL_UnblockObjectListeners(A,B){SL4B_Accessor.getRttpProvider().unblockObjectListeners(RTSL_RtslSubscriberAccessor.getRtslSubscriber(B),A);}
function RTSL_CreateObject(B,A){SL4B_Accessor.getRttpProvider().createObject(B,A);}
function RTSL_DeleteObject(A){SL4B_Accessor.getRttpProvider().deleteObject(A);}
function RTSL_ContribObject(C,D,A,B){var l_oContributionFieldData=SL_OU.getContributionFieldData(C);
l_oContributionFieldData.addField(D,A);if(B){var l_oContribSubscriber=new SL_IG(C,l_oContributionFieldData);
SL_OU.removeObjectFromQueue(C);return l_oContribSubscriber.m_nIdentifier;
}return null;
}
function RTSL_GetObjectType(A,B){SL4B_Accessor.getRttpProvider().getObjectType(RTSL_RtslSubscriberAccessor.getRtslSubscriber(B),A);}
function RTSL_GetFieldNames(){return SL4B_Accessor.getRttpProvider().getFieldNames();
}
function RTSL_GetObjectNameDelimiter(){var l_oConfiguration=SL4B_Accessor.getConfiguration();
return l_oConfiguration.getObjectNameDelimiter();
}
function RTSL_GetVersion(){return SL4B_Accessor.getRttpProvider().getVersion();
}
function RTSL_GetVersionInfo(){return SL4B_Accessor.getRttpProvider().getVersionInfo();
}
function RTSL_Version(){return SL4B_Version.getVersion();
}
function RTSL_VersionInfo(){return SL4B_Version.getVersionInfo();
}
SL_OU = new function(){this.m_pContributionDataQueue=new Object();this.getContributionFieldData = function(A){if(typeof this.m_pContributionDataQueue[A]=="undefined"){this.m_pContributionDataQueue[A]=new SL4B_ContributionFieldData();}return this.m_pContributionDataQueue[A];
};
this.removeObjectFromQueue = function(A){if(typeof this.m_pContributionDataQueue[A]!="undefined"){delete (this.m_pContributionDataQueue[A]);}};
};
SL_HF = new function(){this.m_nCurrentUniqueIdentifier=1;this.getUniqueIdentifier = function(){return this.m_nCurrentUniqueIdentifier++;
};
};
function SL_IG(B,A){this.m_nIdentifier=SL_HF.getUniqueIdentifier();this.m_sObjectName=B;this.m_oContributionFieldData=A;this.initialise();}
SL_IG.prototype = new SL4B_AbstractSubscriber;SL_IG.prototype.ready = SL_QH;SL_IG.prototype.getIdentifier = function(){return this.m_nIdentifier;
};
SL_IG.prototype.contribOk = SL_BT;SL_IG.prototype.contribFailed = SL_LM;function SL_QH(){SL4B_Accessor.getRttpProvider().contribObject(this,this.m_sObjectName,this.m_oContributionFieldData);}
function SL_BT(A){if(typeof RTSL_ContribOk!="undefined"){RTSL_ContribOk(this.m_nIdentifier,A);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ContributionSubscriber.contribOk: The required method RTSL_ContribOk was not defined in the users code. This is required to receive successful contribution messages.");}}
function SL_LM(A,B){if(typeof RTSL_ContribFailed!="undefined"){RTSL_ContribFailed(this.m_nIdentifier,A,B);}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"ContributionSubscriber.contribFailed: The required method RTSL_ContribFailed was not defined in the users code. This is required to receive failed contribution messages.");}}
SL_IG.prototype.getContributionIdentifier = function(){return this.m_nIdentifier;
};
function RTSL_Assert(A){var l_oConfiguration=SL4B_Accessor.getConfiguration();

try {if(l_oConfiguration.getDebugLevel()>SL4B_DebugLevel.getNumericDebugLevel(SL4B_DebugLevel.CRITICAL)&&!A){RTSL_CallStack();debugger;}}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_WARN_INT,"Unable to launch debugger as an invalid debug level was specified");SL4B_Accessor.getExceptionHandler().processException(e);}
}
function RTSL_CallStack(){var l_fFunc=RTSL_CallStack;
var l_nCount=1;
var l_sMsg='';
while(l_fFunc.caller!=null){var l_sFuncName=l_fFunc.toString();
var l_nFuncNameStart=9;
var l_nFuncNameEnd=l_sFuncName.search(/\(/)-l_nFuncNameStart;
l_sFuncName=l_sFuncName.substr(l_nFuncNameStart,l_nFuncNameEnd);l_sMsg+=((l_sMsg=='') ? '' : '\n')+(l_nCount++)+': '+l_sFuncName;l_sMsg+=' ( ';var l_pArgs=l_fFunc.arguments;
for(var l_nArg=0;l_nArg<l_pArgs.length;++l_nArg){l_sMsg+=((l_nArg==0) ? '' : ' , ')+l_pArgs[l_nArg];}l_sMsg+=' )';l_fFunc=l_fFunc.caller;}SL4B_Accessor.getLogger().printMessage('JavaScript call stack follows\n----------------------------------------\n'+l_sMsg+'\n----------------------------------------');}
function SL_QY(B,A){var l_oRttpProvider=SL4B_Accessor.getRttpProvider();
if(typeof A=="undefined"){l_oRttpProvider.debug(B);}else 
{l_oRttpProvider.debug(A,B);}}
function RTSL_Alert(A){SL4B_Logger.synchronizedAlert(A);}
var g_oUpdateFlash=null;
var g_pUpdateClearQueue=new SL_CE();
var g_pPreviousValue=new Object();
var g_fDecimalConvertor=null;
RTSL_SetUpdateFlash();RTSL_AddFlashType('Relative',RTSL_RelativeUpdate,'blue','red','yellow','yellow','white','white','black','black','blue','red','','');RTSL_AddFlashType('Absolute',RTSL_AbsoluteUpdate,'blue','red','yellow','yellow','white','white','black','black','blue','red','green','green');RTSL_AddFlashType('Image',RTSL_ImageUpdate);RTSL_AddFlashType('Indicator',RTSL_IndicatorUpdate);RTSL_AddFlashType('NoFlash',RTSL_NoFlashUpdate);RTSL_AddFlashType('Text',RTSL_TextUpdate,'','','','yellow','','','','black','','','','');RTSL_AddFlashType('HTML',RTSL_HTMLUpdate,'','','','yellow','','','','black','','','','');RTSL_AddFlashType('UpDownRelIndicator',RTSL_UpDownRelIndicatorUpdate);RTSL_AddFlashType('UpDownAbsIndicator',RTSL_UpDownAbsIndicatorUpdate);function RTSL_SetUpdateFlash(B,A){if(g_oUpdateFlash==null){g_oUpdateFlash=new Object();g_oUpdateFlash.m_sFlashTypes=new Object();g_oUpdateFlash.m_pCurrHighlights=new Object();}g_oUpdateFlash.m_nFlashTime=RTSL_DefaultValue(B,2000);g_oUpdateFlash.m_nUpdateFreq=RTSL_DefaultValue(A,500);}
function RTSL_AddFlashType(G,E,J,R,K,A,O,D,H,B,L,P,Q,I,N,C,F,M){g_oUpdateFlash.m_sFlashTypes[G]=new SL_NQ(E,J,R,K,A,O,D,H,B,L,P,Q,I,N,C,F,M);}
function RTSL_SetDecimalConvertor(A){g_fDecimalConvertor=A;}
function RTSL_UpdateFlashTypes(A){var l_sFlashType;
for(l_sFlashType in g_oUpdateFlash.m_sFlashTypes){if(typeof g_oUpdateFlash.m_sFlashTypes[l_sFlashType]!='function'){g_oUpdateFlash.m_sFlashTypes[l_sFlashType].m_oUp.m_RestoreDefaults();g_oUpdateFlash.m_sFlashTypes[l_sFlashType].m_oDown.m_RestoreDefaults();g_oUpdateFlash.m_sFlashTypes[l_sFlashType].m_oEqual.m_RestoreDefaults();g_oUpdateFlash.m_sFlashTypes[l_sFlashType].m_oFresh.m_RestoreDefaults();}}for(l_sUpdatedFlashType in A){if(typeof g_oUpdateFlash.m_sFlashTypes[l_sUpdatedFlashType]!='undefined'&&typeof A[l_sUpdatedFlashType]!='function'){g_oUpdateFlash.m_sFlashTypes[l_sUpdatedFlashType].m_oUp.m_SetColours(A[l_sUpdatedFlashType].m_oUp);g_oUpdateFlash.m_sFlashTypes[l_sUpdatedFlashType].m_oDown.m_SetColours(A[l_sUpdatedFlashType].m_oDown);g_oUpdateFlash.m_sFlashTypes[l_sUpdatedFlashType].m_oEqual.m_SetColours(A[l_sUpdatedFlashType].m_oEqual);g_oUpdateFlash.m_sFlashTypes[l_sUpdatedFlashType].m_oFresh.m_SetColours(A[l_sUpdatedFlashType].m_oFresh);}}}
function SL_NQ(E,I,Q,J,A,N,D,G,B,K,O,P,H,M,C,F,L){this.m_fEvalUpdate=E;this.m_oUp=new SL_BU(I,N,K,M);this.m_oDown=new SL_BU(Q,D,O,C);this.m_oEqual=new SL_BU(J,G,P,F);this.m_oFresh=new SL_BU(A,B,H,L);}
function SL_BU(D,B,A,C){this.m_sFlashClr=RTSL_DefaultValue(D,'');this.m_sFlashText=RTSL_DefaultValue(B,'white');this.m_sFinalText=RTSL_DefaultValue(A,this.m_sFlashClr);this.m_sFinalClr=RTSL_DefaultValue(C,'');this.m_sDefaultFlashClr=this.m_sFlashClr;this.m_sDefaultFlashText=this.m_sFlashText;this.m_sDefaultFinalText=this.m_sFinalText;this.m_sDefaultFinalClr=this.m_sFinalClr;}
SL_BU.prototype.m_RestoreDefaults = SL_PG;SL_BU.prototype.m_SetColours = SL_LL;function SL_PG(){this.m_sFlashClr=this.m_sDefaultFlashClr;this.m_sFlashText=this.m_sDefaultFlashText;this.m_sFinalText=this.m_sDefaultFinalText;this.m_sFinalClr=this.m_sDefaultFinalClr;}
function SL_LL(A){this.m_sFlashClr=A.m_sFlashClr;this.m_sFlashText=A.m_sFlashText;this.m_sFinalText=A.m_sFinalText;this.m_sFinalClr=A.m_sFinalClr;}
function SL_NE(A,C,B,D){var l_oUpdateFlash=g_oUpdateFlash.m_sFlashTypes[A].m_oFresh;
if(D==''||D==' '){l_oUpdateFlash=g_oUpdateFlash.m_sFlashTypes[A].m_oFresh;}else 
if(B==C){l_oUpdateFlash=g_oUpdateFlash.m_sFlashTypes[A].m_oEqual;}else 
if(B<C){l_oUpdateFlash=g_oUpdateFlash.m_sFlashTypes[A].m_oDown;}else 
if(B>C){l_oUpdateFlash=g_oUpdateFlash.m_sFlashTypes[A].m_oUp;}return l_oUpdateFlash;
}
function SL_CX(B,D,A,E,C){var l_sPrevVal=((typeof (g_pPreviousValue[D])!='undefined') ? g_pPreviousValue[D] : '');
g_pPreviousValue[D]=A;l_nOld=GF_ConvertToDecimal(l_sPrevVal);l_nNew=GF_ConvertToDecimal(A);return SL_NE(B,l_nOld,l_nNew,l_sPrevVal);
}
function RTSL_RelativeUpdate(B,D,A,G,C,E,F){var l_oUpdateFlash=SL_CX(B,D,A,G,C);
return (new GF_Update(D,A,l_oUpdateFlash.m_sFlashClr,l_oUpdateFlash.m_sFlashText,l_oUpdateFlash.m_sFinalText,l_oUpdateFlash.m_sFinalClr,G,C,'innerText',F));
}
function RTSL_ImageUpdate(A,D,C,F,B,E){C=((typeof (E.m_pImageMappings[C])=='undefined') ? E.m_vDefaultValue : C);var l_sImgSrc=E.m_pImageMappings[C].src;
var l_vPrevSrc=((typeof (g_pPreviousValue[D])!='undefined') ? g_pPreviousValue[D] : E.m_vDefaultValue);
g_pPreviousValue[D]=C;return ((l_vPrevSrc==C) ? null : (new GF_Update(D,l_sImgSrc,'','','','',true,false,'src')));
}
function RTSL_IndicatorUpdate(C,B,D,F,A,E){var l_nPrevVal=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B][0] : null);
var l_nPrevDir=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B][1] : null);
var l_nDir=0;
if(l_nPrevVal!=null){if(D>l_nPrevVal){l_nDir=1;}else 
if(D<l_nPrevVal){l_nDir=-1;}}if(typeof (g_pPreviousValue[B])=='undefined'){g_pPreviousValue[B]=new Array();}g_pPreviousValue[B][0]=D;g_pPreviousValue[B][1]=l_nDir;var l_sImgSrc=E.m_pImageMappings[l_nDir].src;
return ((l_nPrevVal==null||l_nPrevDir==l_nDir) ? null : (new GF_Update(B,l_sImgSrc,'','','','',true,false,'src')));
}
function RTSL_UpDownRelIndicatorUpdate(C,B,D,F,A,E){var l_nPrevVal=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B][0] : null);
var l_nPrevDir=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B][1] : null);
var l_nDir=0;
if(l_nPrevVal!=null){if(D>l_nPrevVal){l_nDir=1;}else 
if(D<l_nPrevVal){l_nDir=-1;}}if(l_nDir==0&&l_nPrevDir!=null){l_nDir=l_nPrevDir;}if(typeof (g_pPreviousValue[B])=='undefined'){g_pPreviousValue[B]=new Array();}g_pPreviousValue[B][0]=D;g_pPreviousValue[B][1]=l_nDir;var l_sImgSrc=E.m_pImageMappings[l_nDir].src;
return ((l_nPrevVal==null||l_nPrevDir==l_nDir) ? null : (new GF_Update(B,l_sImgSrc,'','','','',true,false,'src')));
}
function RTSL_UpDownAbsIndicatorUpdate(C,B,D,F,A,E){var l_nPrevVal=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B][0] : null);
var l_nPrevDir=((typeof (g_pPreviousValue[B])!='undefined') ? g_pPreviousValue[B][1] : null);
var l_nDir=0;
if(D>0){l_nDir=1;}else 
if(D<0){l_nDir=-1;}if(typeof (g_pPreviousValue[B])=='undefined'){g_pPreviousValue[B]=new Array();}g_pPreviousValue[B][0]=D;g_pPreviousValue[B][1]=l_nDir;var l_sImgSrc=E.m_pImageMappings[l_nDir].src;
return ((l_nPrevDir==l_nDir) ? null : (new GF_Update(B,l_sImgSrc,'','','','',true,false,'src')));
}
function RTSL_AbsoluteUpdate(C,B,D,G,A,E,F){var l_oFlashUpdate=SL_CX(C,B,D,G,A);
var l_oFinalUpdate=SL_NE(C,0,GF_ConvertToDecimal(D),'0.00');
if(GF_ConvertToDecimal(D)>0){if(D.substring(0,1)!='+'){D='+'+D;}}return (new GF_Update(B,D,l_oFlashUpdate.m_sFlashClr,l_oFlashUpdate.m_sFlashText,l_oFinalUpdate.m_sFinalText,l_oFinalUpdate.m_sFinalClr,G,A,'innerText',F));
}
function RTSL_NoFlashUpdate(B,D,A,F,C,E){return (new GF_Update(D,A,'','','','',true,C,'innerText'));
}
function RTSL_TextUpdate(B,D,A,G,C,E,F){var l_oUpdate=g_oUpdateFlash.m_sFlashTypes[B].m_oFresh;
return (new GF_Update(D,A,l_oUpdate.m_sFlashClr,l_oUpdate.m_sFlashText,l_oUpdate.m_sFinalText,'',G,C,'innerText',F));
}
function RTSL_HTMLUpdate(B,D,A,G,C,E,F){var l_oUpdate=g_oUpdateFlash.m_sFlashTypes[B].m_oFresh;
return (new GF_Update(D,A,l_oUpdate.m_sFlashClr,l_oUpdate.m_sFlashText,l_oUpdate.m_sFinalText,'',G,C,'innerHTML',F));
}
function GF_ConvertToDecimal(A){var l_nConverted=A;
if(g_fDecimalConvertor){l_nConverted=g_fDecimalConvertor(A);}else 
{
try {if((window.RTML_TransformResult)&&(A instanceof RTML_TransformResult)){l_nConverted=A.value;}else 
if(typeof A=="Object"){l_nConverted=A.toString();}l_nConverted=parseFloat(l_nConverted);}catch(e){l_nConverted=A;}
}return l_nConverted;
}
function RTSL_CreateUpdate(B,C,D,G,A,E,F){G=RTSL_DefaultValue(G,false);A=RTSL_DefaultValue(A,false);E=RTSL_DefaultValue(E,null);var l_oUpdate=null;
var l_nNewFlashTime=RTSL_DefaultValue(F,g_oUpdateFlash.m_nFlashTime);
RTSL_GetElementFromCache(B);if(typeof (g_oUpdateFlash.m_sFlashTypes[C])!='undefined'){l_oUpdate=(g_oUpdateFlash.m_sFlashTypes[C].m_fEvalUpdate(C,B,D,G,A,E,l_nNewFlashTime));}else 
{var l_oRttpProvider=SL4B_Accessor.getRttpProvider();
l_oRttpProvider.debug('Update flash type '+C+' not found','error');}return l_oUpdate;
}
function GF_Update(D,C,J,G,E,I,H,B,A,F){this.m_sDiv=D;this.m_sValue=C;this.m_sFlashClr=J;this.m_sFlashText=G;this.m_sFinalText=E;this.m_sFinalClr=I;this.m_bNoFlash=H;this.m_bDisplayCommas=B;this.m_sDivElement=A;this.m_nFlashTime=F;return this;
}
function RTSL_DisplayUpdate(A){if(A!=null){var l_oElement=RTSL_GetElementFromCache(A.m_sDiv);
l_oElement.value=A.m_sValue;if(A.m_sDivElement=='src'){l_oElement.src=A.m_sValue;}else 
if(l_oElement.type=='button'){l_oElement.value=(A.m_bDisplayCommas) ? (SL_PQ(A.m_sValue)) : (A.m_sValue);}else 
{switch(A.m_sDivElement){
case 'innerHTML':l_oElement.innerHTML=(A.m_bDisplayCommas) ? (SL_PQ(A.m_sValue)) : (A.m_sValue);break;
case 'nodeValue':case 'innerText':l_oElement.childNodes[0].nodeValue=(A.m_bDisplayCommas) ? (SL_PQ(A.m_sValue)) : (A.m_sValue);break;
default :l_oElement.innerText=(A.m_bDisplayCommas) ? (SL_PQ(A.m_sValue)) : (A.m_sValue);break;
}if(A.m_bNoFlash==false){
try {l_oElement.style.color=A.m_sFlashText;l_oElement.style.backgroundColor=A.m_sFlashClr;}catch(e){}
l_oElement.style.color=A.m_sFlashText;l_oElement.style.backgroundColor=A.m_sFlashClr;g_pUpdateClearQueue.m_Add(A.m_sDiv,A.m_sFinalText,A.m_nFlashTime);}else 
{l_oElement.style.color=A.m_sFinalText;g_pUpdateClearQueue.m_Remove(A.m_sDiv);}}}}
function RTSL_FlushUpdate(A){var l_oUpdate=g_pUpdateClearQueue.m_Remove(A);
if(l_oUpdate!=null){var l_oElement=RTSL_GetElementFromCache(A);
l_oElement.style.color=l_oUpdate.m_sColour;l_oElement.style.backgroundColor='';}}
function SL_CE(){this.m_pQueue=new Array();this.m_pLookup=new Object();}
SL_CE.prototype.m_Add = SL_DH;SL_CE.prototype.m_Remove = SL_NA;SL_CE.timeoutID=null;function SL_DH(A,C,B){if(typeof (this.m_pQueue[B])=='undefined'){this.m_pQueue[B]=new Array();}var l_nIndex=this.m_pQueue[B].length;
if(l_nIndex==0&&SL_CE.timeoutID==null){SL_CE.timeoutID=setTimeout('C_ClearUpdateFlashes('+B+')',B);}else 
{this.m_Remove(A);}this.m_pQueue[B][l_nIndex]=new SL_AJ(A,C,B);this.m_pLookup[A]=new SL_EE(B,l_nIndex);}
function SL_NA(A){if(typeof (this.m_pLookup[A])!='undefined'){var l_nFlashTime=this.m_pLookup[A].m_nFlashTime;
for(var l_nOldIndex=this.m_pLookup[A].m_nIndex;l_nOldIndex>=0;--l_nOldIndex){if(typeof (this.m_pQueue[l_nFlashTime][l_nOldIndex])!='undefined'&&this.m_pQueue[l_nFlashTime][l_nOldIndex].m_sElementId==A){this.m_pQueue[l_nFlashTime][l_nOldIndex].m_bActiveUpdate=false;return this.m_pQueue[l_nFlashTime][l_nOldIndex];
}}}return null;
}
function SL_AJ(A,C,B){this.m_sElementId=A;this.m_sColour=C;this.m_dtExpiryTime=new Date().valueOf()+B;this.m_bActiveUpdate=true;}
function C_ClearUpdateFlashes(A){SL_CE.timeoutID=null;var l_dtCurrentTime=new Date().valueOf();
if(g_pUpdateClearQueue.m_pQueue[A]!=null){while(g_pUpdateClearQueue.m_pQueue[A].length&&g_pUpdateClearQueue.m_pQueue[A][0].m_dtExpiryTime<=l_dtCurrentTime){var l_sElementId=g_pUpdateClearQueue.m_pQueue[A][0].m_sElementId;
if(g_pUpdateClearQueue.m_pQueue[A][0].m_bActiveUpdate){var l_oElement=RTSL_GetElementFromCache(l_sElementId);
if(l_oElement!=null){l_oElement.style.color=g_pUpdateClearQueue.m_pQueue[A][0].m_sColour;l_oElement.style.backgroundColor='';}delete (g_pUpdateClearQueue.m_pLookup[l_sElementId]);}g_pUpdateClearQueue.m_pQueue[A]=g_pUpdateClearQueue.m_pQueue[A].slice(1);}if(g_pUpdateClearQueue.m_pQueue[A].length>0&&SL_CE.timeoutID==null){var l_nTimeoutPeriod=g_pUpdateClearQueue.m_pQueue[A][0].m_dtExpiryTime-(new Date().valueOf());
if(l_nTimeoutPeriod<0){l_nTimeoutPeriod=0;}else 
if(l_nTimeoutPeriod>A){l_nTimeoutPeriod=A;}SL_CE.timeoutID=setTimeout('C_ClearUpdateFlashes('+A+')',l_nTimeoutPeriod);}}}
function SL_EE(B,A){this.m_nFlashTime=B;this.m_nIndex=A;}
function RTSL_ClearPreviousValue(A){if(typeof g_pPreviousValue[A]!='undefined'){delete (g_pPreviousValue[A]);}}
function MOD_CreateImages(B,A,C){this.m_vDefaultValue=B;this.m_nWidth=A;this.m_nHeight=C;this.m_pImageMappings=new Object();}
MOD_CreateImages.prototype.addImage = SL_IX;function SL_IX(A,B){this.m_pImageMappings[A]=new Image();this.m_pImageMappings[A].src=B;}
function SL_PQ(A){if(isNaN(A)){return A;
}var l_sAbsVal=new String(Math.abs(A));
l_sAbsVal=l_sAbsVal.split('.');var l_sComma='';
var l_nPosition;

do{l_sComma=l_sAbsVal[0].substr(((l_sAbsVal[0].length-3>=0) ? l_sAbsVal[0].length-3 : 0))+((l_sComma!='') ? ',' : '')+l_sComma;l_sAbsVal[0]=l_sAbsVal[0].substr(0,l_sAbsVal[0].length-3);}while(l_sAbsVal[0].length>0);var l_sVal=new String(A);
l_sVal=l_sVal.split('.');if(typeof (l_sVal[1])!='undefined'&&l_sVal[1].length>0){l_sComma+='.'+l_sVal[1];}var l_nDir=((A==0) ? 1 : (A/Math.abs(A)));
l_sComma=((l_nDir==1) ? l_sComma : ('-'+l_sComma));return l_sComma;
}
var SL4B_UpdateBatcher=function(){};
SL4B_UpdateBatcher = new function(){this.initializeMemberVariables = function(){this.m_nQuantisation=100;this.m_nMaxProcessorUtilisation=0.5;this.m_mBinIdToUpdateBinMap=SL_BC.createMap();this.m_mClearedElementIdToBinIdMap=SL_BC.createMap();this.m_bStarted=false;this.m_bIsRunning=false;};
this.initializeMemberVariables();this.addUpdate = function(A){if(!(A instanceof SL4B_Update)){throw new SL4B_Exception("Update was invalid");
}else 
{if(!this.m_bStarted){this.m_bStarted=true;this.m_bIsRunning=true;this.m_nNextBinId=this.getBinId(this.getTimeStamp());this.startProccessingBins();}var l_pNextUpdateBin=this.getNextUpdateBin();
var l_nUpdateId=A.getIdentifer();
if(this.m_mClearedElementIdToBinIdMap[l_nUpdateId]){this.removeClearUpdate(l_nUpdateId);}l_pNextUpdateBin[l_nUpdateId]=A;}};
this.start = function(){if(!this.m_bStarted){throw new SL4B_Exception("The addUpdate() method has not yet been called and so the batcher was not yet running.");
}else 
if(this.m_bIsRunning){throw new SL4B_Exception("The update batcher was already running.");
}else 
{this.m_bIsRunning=true;this.startProccessingBins();}};
this.stop = function(){if(!this.m_bIsRunning){throw new SL4B_Exception("The update batcher was not currently running.");
}else 
{this.m_bIsRunning=false;}};
this.getTimeStamp = function(){return (new Date()).valueOf();
};
this.getQuantisationPeriod = function(){return this.m_nQuantisation;
};
this.startProccessingBins = function(){this.processPendingBins();};
this.flushUpdates = function(){clearTimeout(this.m_nTimeoutId);delete this.m_nTimeoutId;var l_nStartTime=this.getTimeStamp();
var l_nPresentBinId=this.getBinId(l_nStartTime);
var l_nBinId;
for(l_nBinId in this.m_mBinIdToUpdateBinMap){l_pUpdateBin=this.m_mBinIdToUpdateBinMap[l_nBinId];this.processUpdateBin(l_pUpdateBin,l_nPresentBinId);this.deleteUpdateBin(l_nBinId);}this.m_pClearedElementIdToBinIdMap={};this.startProccessingBins();};
this.processPendingBins = function(){if(this.m_bIsRunning){var l_nStartTime=this.getTimeStamp();
var l_nFirstBinId=this.m_nNextBinId;
var l_nPresentBinId=this.getBinId(l_nStartTime);
this.m_nNextBinId=l_nPresentBinId+1;for(var l_nBinId=l_nFirstBinId;l_nBinId<=l_nPresentBinId;++l_nBinId){var l_pUpdateBin=this.m_mBinIdToUpdateBinMap[l_nBinId];
if(l_pUpdateBin){this.processUpdateBin(l_pUpdateBin,l_nPresentBinId);this.deleteUpdateBin(l_nBinId);}}var l_nTimeTaken=this.getTimeStamp()-l_nStartTime;
var l_nMinTimeTakenIncludingSleep=l_nTimeTaken/this.m_nMaxProcessorUtilisation;
var l_nSleepTime;
if(l_nMinTimeTakenIncludingSleep<=this.m_nQuantisation){l_nSleepTime=this.m_nQuantisation-l_nTimeTaken;}else 
{l_nSleepTime=l_nMinTimeTakenIncludingSleep-l_nTimeTaken;}this.setTimeout(l_nSleepTime);}};
this.setTimeout = function(A){this.m_nTimeoutId=window.setTimeout(this.m_fProcessPendingBins,A,"SL4B update batcher");};
this.generateProcessPendingBinsFunction = function(){var l_nThis=this;
return function(){l_nThis.processPendingBins();};
};
this.m_fProcessPendingBins=this.generateProcessPendingBinsFunction();this.processUpdateBin = function(A,B){for(l_sUpdateId in A){var l_oUpdate=A[l_sUpdateId];
var l_oClearUpdate=l_oUpdate.drawUpdate();
this.removeClearUpdate(l_sUpdateId);if(l_oClearUpdate){var l_nFlashTime=l_oClearUpdate.getFlashTime();
var l_nFlashBinId=B+Math.ceil(l_nFlashTime/this.m_nQuantisation);
var l_pFlashUpdateBin=this.getUpdateBin(l_nFlashBinId);
l_pFlashUpdateBin[l_sUpdateId]=l_oUpdate;if(this.m_mClearedElementIdToBinIdMap[l_sUpdateId]){this.m_mClearedElementIdToBinIdMap[l_sUpdateId].push(l_nFlashBinId);}else 
{this.m_mClearedElementIdToBinIdMap[l_sUpdateId]=[l_nFlashBinId];}}}};
this.removeClearUpdate = function(A){var l_nBinId=this.m_mClearedElementIdToBinIdMap[A];
if(l_nBinId){this.m_mClearedElementIdToBinIdMap=SL_BC.removeItem(this.m_mClearedElementIdToBinIdMap,A);for(var x=0,l=l_nBinId.length;x<l;x++){delete this.m_mBinIdToUpdateBinMap[l_nBinId[x]][A];}}};
this.getBinId = function(A){return Math.floor(A/this.m_nQuantisation);
};
this.getNextBinId = function(){return this.m_nNextBinId;
};
this.setNextBinId = function(A){this.m_nNextBinId=A;};
this.getUpdateBin = function(A){var l_pUpdateBin=this.m_mBinIdToUpdateBinMap[A];
if(!l_pUpdateBin){l_pUpdateBin={};this.m_mBinIdToUpdateBinMap[A]=l_pUpdateBin;}return l_pUpdateBin;
};
this.getNextUpdateBin = function(){return this.getUpdateBin(this.m_nNextBinId);
};
this.deleteUpdateBin = function(A){this.m_mBinIdToUpdateBinMap=SL_BC.removeItem(this.m_mBinIdToUpdateBinMap,A);};
this.getBinIdForClearedElement = function(A){return this.m_mClearedElementIdToBinIdMap[A];
};
};
var SL4B_Update=function(){};
if(false){function SL4B_Update(){}
}SL4B_Update = function(B,A){this.m_sIdentifier=B;this.m_vValue=A;this.m_nFlashTime=1000;};
SL4B_Update.prototype.getIdentifer = function(){return this.m_sIdentifier;
};
SL4B_Update.prototype.toString = function(){return this.m_sIdentifier+": "+this.m_vValue;
};
SL4B_Update.prototype.getFlashTime = function(){return this.m_nFlashTime;
};
SL4B_Update.prototype.setFlashTime = function(A){this.m_nFlashTime=A;};
SL4B_Update.prototype.drawUpdate = function(){return null;
};
var SL4B_ElementCache={};
var SL4B_TestUpdate=function(){};
if(false){function SL4B_TestUpdate(){}
}SL4B_TestUpdate = function(D,A,C,B){SL4B_Update.apply(this,[D,A]);this.m_sUpdateType=C;this.m_bFirstDraw=true;this.m_bCacheValue=(B===undefined ? true : B);};
SL4B_TestUpdate.prototype = new SL4B_Update();SL4B_TestUpdate.classPrefixes={};SL4B_TestUpdate.values={};SL4B_TestUpdate.prototype.drawUpdate = function(){var l_oElem=SL4B_ElementCache[this.m_sIdentifier];
var l_bHasOldValue=false;
if(!l_oElem){l_oElem=document.getElementById(this.m_sIdentifier);SL4B_ElementCache[this.m_sIdentifier]=l_oElem;}if(l_oElem){var l_sClassPrefix=SL4B_TestUpdate.classPrefixes[this.m_sIdentifier];
if(!l_sClassPrefix){SL4B_TestUpdate.classPrefixes[this.m_sIdentifier]=SL4B_TestUpdate.createClassPrefix(l_oElem.className);l_sClassPrefix=SL4B_TestUpdate.classPrefixes[this.m_sIdentifier];}var l_vOldValue=SL4B_TestUpdate.values[this.m_sIdentifier];
var l_sClass="";
var l_bFirstDraw=this.m_bFirstDraw;
if(this.m_bFirstDraw){this.m_bFirstDraw=false;var l_oTextNode=l_oElem.firstChild;
if(l_oTextNode){l_oTextNode.nodeValue=this.m_vValue;if(this.callbackFn!==undefined){this.callbackFn();}}if(this.m_bCacheValue){SL4B_TestUpdate.values[this.m_sIdentifier]=this.m_vValue;}l_bHasOldValue=(l_vOldValue!==undefined&&l_vOldValue!=="");if(l_bHasOldValue){this.m_sClassSuffix=this.getDirection(this.m_sUpdateType,l_vOldValue,this.m_vValue);l_sClass="recent"+this.m_sClassSuffix;}}else 
{l_sClass="old"+this.m_sClassSuffix;}l_sClass=l_sClassPrefix+l_sClass;l_oElem.className=l_sClass;}return (l_bFirstDraw&&l_bHasOldValue) ? this : null;
};
SL4B_TestUpdate.createClassPrefix = function(A){l_sClassPrefix=(A) ? A.replace(/((recent)|(old))((Flat)|(Up)|(Down)) ?/,"","g") : null;l_sClassPrefix=(l_sClassPrefix) ? l_sClassPrefix+" " : "";return l_sClassPrefix;
};
SL4B_TestUpdate.prototype.getDirection = function(C,B,A){var l_sDirection;
if(g_fDecimalConvertor!=null){if(B){B=g_fDecimalConvertor(B);}if(A){A=g_fDecimalConvertor(A);}}if(C=="Relative"){if(!B||(A==B)){l_sDirection="Flat";}else 
if(A>B){l_sDirection="Up";}else 
if(A<B){l_sDirection="Down";}}else 
if(C=="Absolute"){if(this.m_vValue==0){l_sDirection="Flat";}else 
if(this.m_vValue>0){l_sDirection="Up";}else 
{l_sDirection="Down";}}else 
if(C=="Text"){l_sDirection="Flat";}else 
{debugger;}return l_sDirection;
};
SL4B_TestUpdate.prototype.setCacheValueFlag = function(A){this.m_bCacheValue=A;};
SL4B_TestUpdate.prototype.getFlashTime = function(){return 500;
};
SL4B_TestUpdate.updateElementClassName = function(B,A){SL4B_TestUpdate.classPrefixes[B]=SL4B_TestUpdate.createClassPrefix(A);};
var SL4B_SingleFile=true;
var SL4B_ScriptLoader = new function(){this.const_STANDARD_CREDENTIALS_PROVIDER="standard";this.const_KEYMASTER_CREDENTIALS_PROVIDER="keymaster";this.m_oIndexScript=null;this.m_sRelativeUrlPrefix="";this.m_bLogFileNames=false;this.findIndexScript=SL_LV;this.getRelativeUrlPrefix=SL_OA;this.getRootUrl = function(){return this.m_sRelativeUrlPrefix;
};
this.loadRelativeScript=SL_HM;this.loadScript=SL_BJ;this.loadRequiredScripts=SL_HO;this.loadConfiguredScripts=SL_HE;this.setCommonDomain=SL_RJ;this.createRttpProvider=SL_AI;this.getIndexScript = function(){return this.m_oIndexScript;
};
this.loadSl4bScript = function(A){this.loadRelativeScript("sl4b/"+A);};
this.loadRtmlScript = function(A){this.loadRelativeScript("rtml/"+A);};
this.loadRtslScript = function(A){this.loadRelativeScript("rtsl/"+A);};
this.getElementById = function(A){return document.getElementById(A);
};
this.isInternetExplorer = function(){return (navigator.userAgent.toLowerCase().match(/msie/)!=null);
};
this.m_oIndexScript=this.findIndexScript();this.m_sRelativeUrlPrefix=this.getRelativeUrlPrefix();};
SL4B_ScriptLoader.const_OBJECT_RTTP_PROVIDER="object";SL4B_ScriptLoader.const_APPLET_RTTP_PROVIDER="applet";SL4B_ScriptLoader.const_JAVASCRIPT_RTTP_PROVIDER="javascript";SL4B_ScriptLoader.const_TEST_RTTP_PROVIDER="test";function SL_LV(){var l_oIndexScript=null;
if(this.getElementById("sl4b")){l_oIndexScript=this.getElementById("sl4b");}else 
if(this.getElementById("rtml")){l_oIndexScript=this.getElementById("rtml");}else 
if(this.getElementById("rtsl")){l_oIndexScript=this.getElementById("rtsl");}else 
{var l_pScripts=document.getElementsByTagName("script");
if(l_pScripts.length==1){l_oIndexScript=l_pScripts[0];l_oIndexScript.id="sl4b";}else 
{for(var l_nScript=l_pScripts.length-1;l_nScript>=0;--l_nScript){if(l_pScripts[l_nScript].src.match(/(^|\/)(sl4b|rt[ms]l)($|\/$|\/index2?.js$)/)){l_oIndexScript=l_pScripts[l_nScript];l_oIndexScript.id="sl4b";break;
}}if(l_oIndexScript==null){throw new SL4B_Error("ScriptLoader unable to locate SL4B/RTML/RTSL script tag in DOM");
}}}return l_oIndexScript;
}
function SL_OA(){var l_sRelativeUrlPrefix="";
var l_oMatch=this.m_oIndexScript.src.match(/(.*)(sl4b|rt[ms]l)($|\/$|\/index2?.js$)/);
if(l_oMatch==null){l_oMatch=this.m_oIndexScript.src.match(/(([.][.]\/)*)/);l_sRelativeUrlPrefix="../"+l_oMatch[1];}else 
{l_sRelativeUrlPrefix=l_oMatch[1];}return l_sRelativeUrlPrefix;
}
function SL_HM(A){this.loadScript(this.m_sRelativeUrlPrefix+A);}
function SL_BJ(A){if(this.m_bLogFileNames){SL4B_Logger.log(SL4B_DebugLevel.const_DEBUG_INT,"ScriptLoader.loadScript: Loading {0}",A);}document.write("<scr"+"ipt language=\"JavaScript\" src=\""+A+"\"></scr"+"ipt>");}
function SL_HO(){SL_LJ();SL_JV();}
function SL_HE(A){SL4B_WindowEventHandler.initialise();SL_HC();SL4B_Accessor.getLogger().openDebugConsoleOnStartUp(false);if(A.getService()!=null&&A.getScriptTagAttribute("commondomain")==null){alert("FATAL SL4B ERROR:\nThe \"commondomain\" configuration attribute must be explicitly set when the \"service\" attribute is used");return;
}if(!this.setCommonDomain(A)){alert("FATAL SL4B ERROR:\nThe host name for the web page you have entered must end with \""+A.getCommonDomain()+"\".\nUnable to connect to establish a streaming connection.");return;
}SL4B_Accessor.getLogger().openDebugConsoleOnStartUp(true);C_CallbackQueue.start();this.m_bLogFileNames=true;if(A.isMasterFrame()){if(A.getCredentialsProvider()==this.const_STANDARD_CREDENTIALS_PROVIDER){SL_RB();}else 
if(A.getCredentialsProvider()==this.const_KEYMASTER_CREDENTIALS_PROVIDER){SL_CU();}else 
{this.loadScript(A.getCredentialsProvider());}}if(!A.isMasterFrame()){}else 
{if(false){}if(A.getService()!=null){SL_JI();}if(A.getRttpProvider()==SL4B_ScriptLoader.const_APPLET_RTTP_PROVIDER){}else 
if(A.getRttpProvider()==SL4B_ScriptLoader.const_OBJECT_RTTP_PROVIDER){SL_GI();}else 
if(A.getRttpProvider()==SL4B_ScriptLoader.const_JAVASCRIPT_RTTP_PROVIDER){}else 
if(A.getRttpProvider()==SL4B_ScriptLoader.const_TEST_RTTP_PROVIDER){}else 
{this.loadScript(A.getRttpProvider());}}SL_FA();if(A.includeRtml()){}if(A.includeRtsl()||A.includeFlash()){}if(A.includeRtsl()){SL_IL();}if(A.includeFlash()){}}
function SL_RJ(A){if(window.G_UNIT_TESTING){return true;
}var l_bDomainSet=true;
var l_sCommonDomain=A.getCommonDomain();
SL4B_FrameRegistrarAccessor.setCommonContainerDomain(l_sCommonDomain);if(l_sCommonDomain!=null){
try {SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"ScriptLoader.setCommonDomain: Setting document.domain to: {0}",l_sCommonDomain);document.domain=l_sCommonDomain;}catch(e){SL4B_Logger.log(SL4B_DebugLevel.const_ERROR_INT,"ScriptLoader.setCommonDomain: Failed to set the common domain to: {0}",l_sCommonDomain);l_bDomainSet=false;}
}else 
{SL4B_Logger.log(SL4B_DebugLevel.const_INFO_INT,"ScriptLoader.setCommonDomain: Setting document.domain to: {0}");}return l_bDomainSet;
}
function SL_AI(){var l_oConfiguration=SL4B_Accessor.getConfiguration();
var l_oProvider=null;
var l_bSetUnderlyingRttpProvider=true;
if(!l_oConfiguration.isMasterFrame()){l_oProvider=new SL4B_SlaveFrameRttpProvider();}else 
if(l_oConfiguration.getService()!=null){l_oProvider=new SL4B_FailoverRttpProvider();l_bSetUnderlyingRttpProvider=false;}else 
{l_oProvider=SL4B_Accessor.getRttpProviderFactory().createRttpProvider(new SL4B_SimpleLiberatorConfiguration());}if(l_oProvider!=null){SL4B_Accessor.setRttpProvider(l_oProvider);if(l_bSetUnderlyingRttpProvider){SL4B_Accessor.setUnderlyingRttpProvider(l_oProvider);}l_oProvider.addConnectionListener(new SL4B_LogConnectionListener(SL4B_Logger));}}
var SL4B_Throwable=function(){};
if(false){function SL4B_Throwable(){}
}SL4B_Throwable = function(A){this.m_sClassName=null;this.m_sMessage=null;this.m_pStackTrace=new Array();this.initialise("SL4B_Throwable",A);};
SL4B_Throwable.prototype.initialise = SL_KL;SL4B_Throwable.prototype.getClass = function(){return this.m_sClassName;
};
SL4B_Throwable.prototype.getMessage = function(){return this.m_sMessage;
};
SL4B_Throwable.prototype.getStackTrace = function(){return this.m_pStackTrace;
};
SL4B_Throwable.prototype.toString = function(){return this.m_sClassName+":\n   message="+this.m_sMessage+"\n   stack trace:\n      "+this.getStackTrace().join("\n      ");
};
function SL_KL(A,B){this.m_sClassName=A;this.m_sMessage=B;var l_fCaller=SL_KL.caller;
while((l_fCaller=l_fCaller.caller)!=null){if(this.m_pStackTrace.length>20){this.m_pStackTrace.push("...");break;
}else 
{var l_sFunctionInfo="";
var l_oMatch=l_fCaller.toString().match(/function\x20([^_]*_[^_(]*)_([^(]*)/);
if(l_oMatch==null){l_oMatch=l_fCaller.toString().match(/function\x20([^_]*_[^(]*)/);if(l_oMatch==null){l_sFunctionInfo+="{anonymous method call}";}else 
{l_sFunctionInfo+=""+l_oMatch[1]+".<init>";}}else 
{l_sFunctionInfo+=""+l_oMatch[1]+"."+l_oMatch[2].charAt(0).toLowerCase()+l_oMatch[2].substr(1);}l_sFunctionInfo+=" (";for(var l_nArgument=0,l_nLength=l_fCaller.arguments.length;l_nArgument<l_nLength;++l_nArgument){var l_vArgValue=l_fCaller.arguments[l_nArgument];
l_sFunctionInfo+=((l_nArgument==0) ? "" : ", ")+((typeof l_vArgValue=="string") ? "\""+l_vArgValue+"\"" : l_vArgValue);}l_sFunctionInfo+=")";this.m_pStackTrace.push(l_sFunctionInfo);}}}
var SL4B_Error=function(){};
if(false){function SL4B_Error(){}
}SL4B_Error = function(A){this.initialise(SL4B_Error.const_ERROR_CLASS,A);};
SL4B_Error.prototype = new SL4B_Throwable;SL4B_Error.const_ERROR_CLASS="SL4B_Error";var SL4B_Exception=function(){};
if(false){function SL4B_Exception(){}
}SL4B_Exception = function(A){this.initialise(SL4B_Exception.const_EXCEPTION_CLASS,A);};
SL4B_Exception.prototype = new SL4B_Throwable;SL4B_Exception.const_EXCEPTION_CLASS="SL4B_Exception";var SL4B_Version=function(){};
if(false){function SL4B_Version(){}
}SL4B_Version = new function(){this.m_sVersionNumber="4.5.7";this.m_sBuildNumber="141234";this.m_sBuildDate="11-Aug-2009";this.m_sCopyright="Copyright 1995-2009 Caplin Systems Ltd";this.getVersion = function(){return this.m_sVersionNumber;
};
this.getBuildNumber = function(){return this.m_sBuildNumber;
};
this.getBuildDate = function(){return this.m_sBuildDate;
};
this.getVersionInfo = function(){return "SL4B "+this.m_sVersionNumber+"-"+this.m_sBuildNumber+" (Built "+this.m_sBuildDate+"), "+this.m_sCopyright;
};
};
function RTSL_DefaultValue(A,B){return ((A==null)||(typeof (A)=="undefined") ? B : A);
}
SL4B_ScriptLoader.loadRequiredScripts();