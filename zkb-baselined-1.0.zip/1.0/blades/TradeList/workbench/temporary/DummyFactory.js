
DummyFactory = function(fModelListener) {
	this.m_fModelListener = fModelListener;
};

DummyFactory.prototype.setPresentationModel = function(oModel) {
	this.m_fModelListener(oModel);
};

DummyFactory.prototype.getPresentationModel = function() {
	return this.m_oPresentationModel;
};





DummyFactory.prototype.getFiAccounts = function()
{
	return new Ext.data.SimpleStore({
		"fields": ["value", "label"],
		"data" : [
			["CUSTOMER1_BRONZE", "BRONZE"],
			["CUSTOMER1_EUR_COVERED", "EUR_COVERED"],
			["CUSTOMER1_GOLD", "GOLD"],
			["CUSTOMER1_SILVER", "SILVER"],
			["CUSTOMER1_PROP_TRAD", "PROP_TRAD"]
		]
	});
};

DummyFactory.prototype.getBusinessDateProvider = function() {
	return new WorkbenchBusinessDateProvider() ;
	
};

//
WorkbenchBusinessDateProvider = function () {
};

WorkbenchBusinessDateProvider.prototype.getFISettlementDates = function (oListener) {
	var currentDate = new Date();
	var pDates = [];
	for (var i = 1; i <= 7; ++i)	{
		var day = currentDate.getDate() + i;
		var newDate = new Date();
		newDate.setDate(day);
		pDates.push(newDate.toDateString());
	}
	oListener.businessCalendarCallback("",0,0, pDates);
};

if (!caplin.framework) {
	caplin.framework = {};
	caplin.framework.ApplicationFactory = {};
}
caplin.framework.ApplicationFactory.INSTANCE = new DummyFactory();