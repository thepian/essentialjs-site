NotificationRowSourceTest = TestCase("NotificationRowSourceTest");

NotificationRowSourceTest.prototype.setUp = function()
{
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	oRowSource = new caplinx.alerts.rowsource.NotificationRowSource();
	mockRowSourceListener = mock(caplin.grid.rowsource.RowSourceListener);
	oRowSource.addRowSourceListener(mockRowSourceListener.proxy());
	mockRowSourceListener.stubs().rowUpdated(ANYTHING, ANYTHING);
 	mockRowSourceListener.stubs().rowAdded(ANYTHING, ANYTHING, ANYTHING);
 	mockRowSourceListener.stubs().structureChangeCompleted();
	
	//mock NotificationService singleton
	this.notificationService = Mock4JS.mockObject(caplin.alerts.NotificationService);
	this.realNotificationService = caplin.alerts.NotificationService;
	caplin.alerts.NotificationService = this.notificationService.proxy();
	this.notificationService.stubs().addListener(ANYTHING);
};

NotificationRowSourceTest.prototype.tearDown = function()
{
	oRowSource.terminateUpdates();
	caplin.alerts.NotificationService = this.realNotificationService;
	Mock4JS.verifyAllMocks();
};

NotificationRowSourceTest.prototype.testWhenNotifiedPassesDataOntoGrid = function()
{
	var mNotificationData1 = {
		id:"101",
		time:"1234567890",
		subject:"/FX/GBPUSD",
		description:"BestBid >= 1.23",
		status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW
	};
	var mNotificationData2 = {
		id:"102",
		time:"1234567891",
		subject:"/FX/GBPUSD",
		description:"BestBid >= 1.23",
		status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW
	};
	mockRowSourceListener.expects(once()).rowAdded("101", mNotificationData1, 0);
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	oRowSource.onNotificationAdded(mNotificationData1);
	mockRowSourceListener.expects(once()).rowAdded("102", mNotificationData2, 0);
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	oRowSource.onNotificationAdded(mNotificationData2);
};

NotificationRowSourceTest.prototype.testDataUnavailableCausesTheGridToDisplayAnErrorMessage = function() {
	caplin.alerts.NotificationService = this.realNotificationService;
	
	mockRowSourceListener.expects(once()).allRowsRemoved();
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	mockRowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.NOT_FOUND);
	oRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_FOUND);
	
	mockRowSourceListener.expects(once()).allRowsRemoved();
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	mockRowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.NOT_PERMISSIONED);
	oRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_PERMISSIONED);
	
	mockRowSourceListener.expects(once()).allRowsRemoved();
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	mockRowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.ERROR);
	oRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.UNKNOWN_ERROR);

	mockRowSourceListener.expects(once()).allRowsRemoved();
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	mockRowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.DELETED);
	oRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.RTTP_CONTAINER_DELETED);
};


NotificationRowSourceTest.prototype.testGetAllRowsReturnsExistingNotificationsInReverseOrder = function()
{
	var mNotification1 = {id:"11", time:"1234567890"};
	var mNotification2 = {id:"12", time:"1234567891"};
	var mRow1 = {
			id: "11",
			data: mNotification1
	};
	var mRow2 = {
			id: "12",
			data: mNotification2
	};
	this.notificationService.stubs().getAllNotifications().will(returnValue([mNotification1, mNotification2]));
	assertArrayEquals([mRow2, mRow1], oRowSource.getAllRows());
};

NotificationRowSourceTest.prototype.testGridIsInformedOfDismissedNotifications = function()
{
	var sAlertId = "101";
	mockRowSourceListener.expects(once()).rowUpdated(sAlertId, {status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_DISMISSED});
	oRowSource.onNotificationDismissed(sAlertId);
};

NotificationRowSourceTest.prototype.testGridIsInformedOfRemovedNotifications = function()
{
	var sAlertId = "101";	
	mockRowSourceListener.expects(once()).rowRemoved(sAlertId);
	oRowSource.onNotificationRemoved(sAlertId);
};

NotificationRowSourceTest.prototype.testRowsAreAddedWhenDataIsAvailable = function()
{
	var mNotificationData1 = {
		id:"101",
		time:"1234567890",
		subject:"/FX/GBPUSD",
		description:"BestBid >= 1.23",
		status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW
	};
	var mNotificationData2 = {
		id:"102",
		time:"1234567891",
		subject:"/FX/GBPUSD",
		description:"BestBid >= 1.234",
		status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW
	};
	oRowSource.onNotificationAdded(mNotificationData1);
	oRowSource.onNotificationAdded(mNotificationData2);
	this.notificationService.stubs().getAllNotifications().will(returnValue([mNotificationData1, mNotificationData2]));
	
	mockRowSourceListener.expects(once()).rowAdded(mNotificationData1["id"], mNotificationData1, 0);
	mockRowSourceListener.expects(once()).rowAdded(mNotificationData2["id"], mNotificationData2, 0);
	mockRowSourceListener.expects(once()).structureChangeCompleted();
	
	oRowSource.onDataAvailable();
};

NotificationRowSourceTest.prototype.testShouldAddFictitiousRowWhenDataAvailableAndNoNotificationsPresent = function() {
	//given
	this.notificationService.stubs().getAllNotifications().will(returnValue([]));
	
	//expectations	
	mockRowSourceListener.expects(once()).rowAdded("-1", {status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW}, 0);
	mockRowSourceListener.expects(once()).rowUpdated("-1", {status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_DISMISSED}, 0);
	mockRowSourceListener.expects(once()).rowRemoved("-1");
	mockRowSourceListener.expects(exactly(2)).structureChangeCompleted();
	
	//when
	oRowSource.onDataAvailable();
};

NotificationRowSourceTest.prototype.testShouldUpdateRecordToStatusStaleOnStaleEvent = function() {
	//Given
	var sAlertId = "alert1";

	//Expectations
	mockRowSourceListener.expects(once()).rowUpdated(sAlertId, {RECORD_STATUS:SL4B_ObjectStatus.STALE});
	
	//When
	oRowSource.onNotificationStale(sAlertId);
};

NotificationRowSourceTest.prototype.testShouldUpdateRecordToStatusNotStaleOnNotStaleEvent = function() {
	//Given
	var sAlertId = "alert1";
	
	//Expectations
	mockRowSourceListener.expects(once()).rowUpdated(sAlertId, {RECORD_STATUS:""});
	
	//When
	oRowSource.onNotificationNotStale(sAlertId);
};
