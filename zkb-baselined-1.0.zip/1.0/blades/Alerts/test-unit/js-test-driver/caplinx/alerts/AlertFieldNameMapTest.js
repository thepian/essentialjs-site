AlertFieldNameMapTest = TestCase("AlertFieldNameMapTest");

AlertFieldNameMapTest.prototype.setUp = function() {
	oAlertFieldNameMap = caplinx.alerts.AlertFieldNameMap;
	
	this.oRealAlertsProperties = caplin.alerts.AlertsProperties;
	caplin.alerts.AlertsProperties = new caplin.singletons["caplin.alerts.AlertsProperties"]();
	caplin.alerts.AlertsProperties.onAfterClassLoad = function() {
		this.m_mFields = 
			{
				"/FX/.*": 
				{BestBid : 
					{name: ct.i18n('blade.alerts.form.fx.bid'), operator: ">="}, 
				BestAsk : 
					{name: ct.i18n('blade.alerts.form.fx.ask'), operator: "<="}
				},
				"/FI/.*": 
				{BidYield : 
					{name: ct.i18n('blade.alerts.form.fi.bid'), operator: ">="}, 
				AskYield : 
					{name: ct.i18n('blade.alerts.form.fi.ask'), operator: "<="}
				},
				"/COMMANDHTTPD/.*": 
				{BestBid : 
					{name: ct.i18n('blade.alerts.form.fx.bid'), operator: ">="}, 
				BestAsk : 
					{name: ct.i18n('blade.alerts.form.fx.ask'), operator: "<="}
				}
			};
	};
	caplin.alerts.AlertsProperties.onAfterClassLoad();
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();

};

AlertFieldNameMapTest.prototype.tearDown = function() {
	caplin.alerts.AlertsProperties = this.oRealAlertsProperties;
};

AlertFieldNameMapTest.prototype.testItShouldReplaceFieldNameInAStringWithMonitoredNameForAnInstrument = function() {
	//given
	var sStringToReplace = "blade.alerts.form.fx.bid will be replaced by BestBid";

	//when
	var sResultString = oAlertFieldNameMap.replaceWithMonitoredName("/FX/GBPUSD", sStringToReplace);
	
	//assertThat
	var sExpectedString = "BestBid will be replaced by BestBid";
	assertEquals(sExpectedString, sResultString);	
};

AlertFieldNameMapTest.prototype.testItShouldReplaceFieldNameInAStringWithDisplayNameForAnInstrument = function() {
	//given
	var sStringToReplace = "BestBid will be replaced by Bid";

	//when
	var sResultString = oAlertFieldNameMap.replaceWithDisplayName("/FX/GBPUSD", sStringToReplace);
	
	//assertThat
	var sExpectedString = "blade.alerts.form.fx.bid will be replaced by Bid";
	assertEquals(sExpectedString, sResultString);	
};


AlertFieldNameMapTest.prototype.testItShouldReturnAllDisplayFieldsForFxInstrumentType = function() {
	//given
	var sSubject = "/FX/INSTRUMENT";
	
	//when
	var pReturnedFields = oAlertFieldNameMap.getFieldsAsArray(sSubject);
	
	//then	
	var pExpectedFields = ['blade.alerts.form.fx.bid', 'blade.alerts.form.fx.ask'];
	assertArrayEquals(pExpectedFields, pReturnedFields);
};

AlertFieldNameMapTest.prototype.testItShouldReturnAllDisplayFieldsForFiInstrumentType = function() {
	//given
	var sSubject = "/FI/INSTRUMENT";
	
	//when
	var pReturnedFields = oAlertFieldNameMap.getFieldsAsArray(sSubject);
	
	//then	
	var pExpectedFields = ['blade.alerts.form.fi.bid', 'blade.alerts.form.fi.ask'];
	assertArrayEquals(pExpectedFields, pReturnedFields);
};

AlertFieldNameMapTest.prototype.testItShouldReturnAllXaquaFieldsForFXInstrument = function() {
	//given
	var sSubject = "/FX/EURUSD";
	
	//when
	var pReturnedFields = oAlertFieldNameMap.getXaquaFieldsAsArray(sSubject);
	
	//then	
	var pExpectedFields = ['BestBid', 'BestAsk'];
	assertArrayEquals(pExpectedFields, pReturnedFields);
};

AlertFieldNameMapTest.prototype.testItShouldReturnXaquaFieldForFXInstrument = function() {
	//given
	var sSubject = "/FX/EURUSD";
	var sDisplayFieldName = "blade.alerts.form.fx.ask";
	
	//when
	var pReturnedField = oAlertFieldNameMap.getXaquaFieldNameFor(sSubject, sDisplayFieldName);
	
	//then	
	var pExpectedField = 'BestAsk';
	assertEquals(pExpectedField, pReturnedField);
};


AlertFieldNameMapTest.prototype.testItShouldReturnDisplayFieldForXaquaField = function() {
	//given
	var sSubject = "/FX/EURUSD";
	var sXaquaField = "BestBid";
	
	//when
	var pReturnedFieldName = oAlertFieldNameMap.getDisplayFieldNameFor(sSubject, sXaquaField);
	
	//then	
	var pExpectedField = 'blade.alerts.form.fx.bid';
	assertEquals(pExpectedField, pReturnedFieldName);
};

AlertFieldNameMapTest.prototype.testItShouldReturnDefaultOperatorForXaquaField = function() {
	//given
	var sSubject = "/FX/EURUSD";
	var sXaquaField = "BestBid";
	
	//when
	var pReturnedOperator = oAlertFieldNameMap.getDefaultOperatorFor(sSubject, sXaquaField);
	
	//then	
	var pExpectedOperator = '>=';
	assertEquals(pExpectedOperator, pReturnedOperator);
};
