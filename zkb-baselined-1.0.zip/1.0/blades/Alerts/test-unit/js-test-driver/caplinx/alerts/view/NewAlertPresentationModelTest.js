NewAlertPresentationModelTest = TestCase("NewAlertPresentationModelTest");

NewAlertPresentationModelTest.prototype.setUp = function()
{
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	oMockForm = mock(caplin.form.presentation.Form);
	oMockProperty = mock(caplin.form.presentation.PresentationProperty);
	oAnotherMockProperty = mock(caplin.form.presentation.PresentationProperty);
	
	pProperties = [oMockProperty.proxy(), oAnotherMockProperty.proxy()];
	
	oMockForm.stubs().autoGenerateProperties().will(returnValue(pProperties));
	oMockForm.stubs().bindProperty(ANYTHING);
	oMockForm.stubs().bindProperties(ANYTHING);
	oMockForm.stubs().getProperty(ANYTHING).will(returnValue(oMockProperty.proxy()));
	oMockForm.stubs().setValue(ANYTHING, ANYTHING);
	oMockForm.stubs().getValue(ANYTHING).will(returnValue(""));
	
	oMockProperty.stubs().addListener(ANYTHING);
	oMockProperty.stubs().getValue().will(returnValue(""));

	//mock TriggerService singleton
	this.triggerService = Mock4JS.mockObject(caplin.alerts.TriggerService);
	this.realTriggerService = caplin.alerts.TriggerService;
	caplin.alerts.TriggerService = this.triggerService.proxy();
	this.triggerService.stubs().addTrigger(ANYTHING, ANYTHING);
	
	oMockInstrumentSubscriber = mock(caplinx.alerts.view.InstrumentSubscriber);
	
	oPresentationModel = new caplinx.alerts.view.NewAlertPresentationModel({});
	oPresentationModel._createInstrumentSubscriber = function(sSubject) {
		return oMockInstrumentSubscriber.proxy();
	};
	
	this.oRealAlertsProperties = caplin.alerts.AlertsProperties;
	caplin.alerts.AlertsProperties = new caplin.singletons["caplin.alerts.AlertsProperties"]();
	caplin.alerts.AlertsProperties.onAfterClassLoad = function() {
		this.m_mFields = 
			{
				"/FX/.*": 
				{BestBid : 
					{name: ct.i18n('blade.alerts.form.fx.bid'), operator: ">="}, 
				BestAsk : 
					{name: ct.i18n('blade.alerts.form.fx.ask'), operator: "<="}
				},
				"/FI/.*": 
				{BidYield : 
					{name: ct.i18n('blade.alerts.form.fi.bid'), operator: ">="}, 
				AskYield : 
					{name: ct.i18n('blade.alerts.form.fi.ask'), operator: "<="}
				},
				"/COMMANDHTTPD/.*": 
				{BestBid : 
					{name: ct.i18n('blade.alerts.form.fx.bid'), operator: ">="}, 
				BestAsk : 
					{name: ct.i18n('blade.alerts.form.fx.ask'), operator: "<="}
				}
			};
	};
	caplin.alerts.AlertsProperties.onAfterClassLoad();
	
	var mLocalizationPrefs = {
			"thousandsSeparator" : ",",
			"decimalRadixCharacter" : "."
	};
	caplin.i18n.getTranslator().setLocalizationPreferences(mLocalizationPrefs);
	

};

NewAlertPresentationModelTest.prototype.tearDown = function(){
	caplin.alerts.TriggerService = this.realTriggerService;
	caplin.alerts.AlertsProperties = this.oRealAlertsProperties;
	Mock4JS.verifyAllMocks();	
};

NewAlertPresentationModelTest.prototype.testPropertiesBoundOnInitialise = function()
{
	oMockForm.expects(once()).bindProperties(pProperties);
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testSubmitButtonDisabledOnTriggerAdded = function()
{
	oPresentationModel.initialise(oMockForm.proxy());

	oMockForm.expects(once()).setValue("submitEnabled", false);
	
	oPresentationModel.sendTrigger();
};

NewAlertPresentationModelTest.prototype.testSubmitButtonReenabledOnSendTriggerCallbackWhenNotAddedSuccessfully = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("submitEnabled", true);
	fCallback("INVALID");
};

NewAlertPresentationModelTest.prototype.testSubmitButtonNotReenabledOnSendTriggerCallbackWhenAddedSuccessfully = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(never()).setValue("submitEnabled", true);
	fCallback("ADDED");
};


NewAlertPresentationModelTest.prototype.testTriggerDataSentCorrectlyOnSendTrigger = function()
{
	oPresentationModel.initialise(oMockForm.proxy());

	oMockForm.stubs().getValue("subject").will(returnValue("TriggerSubject"));
	oMockForm.stubs().getValue("instrument").will(returnValue("TriggerInstrument"));
	oMockForm.stubs().getValue("name").will(returnValue("TriggerName"));
	oMockForm.stubs().getValue("field").will(returnValue("Ask"));
	oMockForm.stubs().getValue("operator").will(returnValue(">="));
	oMockForm.stubs().getValue("value").will(returnValue("1.4"));
	
	var oTriggerData = {
			"subject": "TriggerSubject",  
			"instrument": "TriggerInstrument",  
			"name": "TriggerName",  
			"alertCondition": "Ask >= 1.4"  
	};
	
	this.triggerService.expects(once()).addTrigger(oTriggerData, ANYTHING);
		
	oPresentationModel.sendTrigger();
};

NewAlertPresentationModelTest.prototype.testAllInputFieldsAreEnabledWhenFormInitialised = function()
{
	oMockForm.expects(once()).setValue("inputsEnabled", true);
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testAllInputFieldsAreDisabledWhenSaveButtonClicked = function()
{
	oPresentationModel.initialise(oMockForm.proxy());
	
	oMockForm.expects(once()).setValue("inputsEnabled", false);
	oPresentationModel.sendTrigger();	
};

NewAlertPresentationModelTest.prototype.testReturnsFXFieldsWhenSubjectIsFX = function()
{
	var sSubject = "/FX/INSTRUMENT";
	
	var mExpectedOptions = ["blade.alerts.form.fx.bid","blade.alerts.form.fx.ask"];
	oPresentationModel.initialise(oMockForm.proxy());
	
	oMockForm.stubs().getValue("subject").will(returnValue(sSubject));
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
	
	assertEquals(mExpectedOptions, oPresentationModel.getFieldOptions());
};

NewAlertPresentationModelTest.prototype.testReturnsBlankWhenSubjectDoesNotMatchConfiguration = function()
{
	oPresentationModel.initialise(oMockForm.proxy());
	oMockForm.stubs().getValue("subject").will(returnValue("/FXF/INSTRUMENT"));
	assertEquals([], oPresentationModel.getFieldOptions());
};

NewAlertPresentationModelTest.prototype.testSubmitButtonIsDisabledWhenFormInIntialState = function()
{
	oMockForm.expects(once()).setValue("submitEnabled", false);
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testSubmitButtonIsNotEnabledWhenOnlyOneFieldValid = function()
{
	var oNameProperty = new caplin.form.presentation.PresentationProperty("name", "");
	oMockForm.stubs().getProperty("name").will(returnValue(oNameProperty));
	oPresentationModel.initialise(oMockForm.proxy());
	
	oMockForm.expects(never()).setValue("submitEnabled", true);
	oNameProperty.setValue("valid_value");
};

NewAlertPresentationModelTest.prototype.testSubmitButtonIsEnabledWhenAllFieldsValid = function()
{
	
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
	var sSubject = "/FX/INSTRUMENT";
	oMockInstrumentSubscriber.stubs().start();

	var oNameProperty = this.createPropertyFor("name");
	var oFieldProperty = this.createPropertyFor("field");
	var oOperatorProperty = this.createPropertyFor("operator");
	var oValueProperty = this.createPropertyFor("value");

	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	
	oPresentationModel.updateField("BestAsk", "1.334");
	oPresentationModel.updateField("BestBid", "1.332");
	
	oMockForm.expects(never()).setValue("submitEnabled", true);
	oNameProperty.setValue("valid_value");
	oFieldProperty.setValue("blade.alerts.form.fx.ask");
	oOperatorProperty.setValue(">=");
	
	oMockForm.expects(once()).setValue("submitEnabled", true);
	oValueProperty.setValue("1.2345");
};


NewAlertPresentationModelTest.prototype.testSubmitButtonIsDisabledWhenAnyFieldBecomesInvalid = function()
{
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
	var sSubject = "/FX/INSTRUMENT";
	oMockInstrumentSubscriber.stubs().start();
	var oNameProperty = this.createPropertyFor("name");
	var oFieldProperty = this.createPropertyFor("field");
	var oOperatorProperty = this.createPropertyFor("operator");
	var oValueProperty = this.createPropertyFor("value");

	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oPresentationModel.updateField("BestAsk", "1.334");
	oPresentationModel.updateField("BestBid", "1.332");

	
	oNameProperty.setValue("2345");
	oFieldProperty.setValue("blade.alerts.form.fx.ask");
	oOperatorProperty.setValue(">=");
	oValueProperty.setValue("1.2345");
	
	oMockForm.expects(once()).setValue("submitEnabled", false);
	oNameProperty.setValue("");
};

NewAlertPresentationModelTest.prototype.testValidationMessagesAreNotShownOnInitialise = function()
{
	oMockForm.expects(once()).setValue("name-valid", "control-wrapper form-field-valid");
	oMockForm.expects(once()).setValue("value-valid", "control-wrapper form-field-valid");
	oMockForm.expects(once()).setValue("field-valid", "control-wrapper form-field-valid");
	oMockForm.expects(once()).setValue("operator-valid", "control-wrapper form-field-valid");
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testValidationMessagesAreShownWhenFieldsBecomeInvalid = function()
{
	var oNameProperty = this.createPropertyFor("name");
	var oValueProperty = this.createPropertyFor("value");
	var oFieldProperty = this.createPropertyFor("field");
	var oOperatorProperty = this.createPropertyFor("operator");

	oNameProperty.setValue("Valid value");
	oValueProperty.setValue("1.2345");
	oPresentationModel.initialise(oMockForm.proxy());
	
	oMockForm.expects(once()).setValue("field-valid", "control-wrapper form-field-invalid");
	oFieldProperty.setValue("");

	oMockForm.expects(once()).setValue("operator-valid", "control-wrapper form-field-invalid");
	oOperatorProperty.setValue("");

	oMockForm.expects(once()).setValue("name-valid", "control-wrapper form-field-invalid");
	oNameProperty.setValue("");
	
	oMockForm.expects(once()).setValue("value-valid", "control-wrapper form-field-invalid");
	oValueProperty.setValue("1.b");
	
};

NewAlertPresentationModelTest.prototype.createPropertyFor = function(sFieldName) {
	var oProperty = new caplin.form.presentation.PresentationProperty(sFieldName, "");
	oMockForm.stubs().getProperty(sFieldName).will(returnValue(oProperty));
	return oProperty;
};

NewAlertPresentationModelTest.prototype.testStatusMessageWhenTriggerAddedSuccessfully = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("alert-status-header", "blade.alerts.form.alert_added_message.header");
	oMockForm.expects(once()).setValue("alert-status-text", "blade.alerts.form.alert_added_message.text");
	fCallback("ADDED");
};

NewAlertPresentationModelTest.prototype.testStatusMessageWhenTriggerNotAddedSuccessfully = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("alert-status-header", "blade.alerts.form.alert_invalid_message.header");
	oMockForm.expects(once()).setValue("alert-status-text", "blade.alerts.form.alert_invalid_message.text");
	fCallback("INVALID");
};

NewAlertPresentationModelTest.prototype.testSubmitButtonMarkedAsSaveOnFormInitialised = function()
{
	oMockForm.expects(once()).setValue("form-save-retry", "blade.alerts.form.button.save");
	oPresentationModel.initialise(oMockForm.proxy());
};


NewAlertPresentationModelTest.prototype.testSaveButtonChangesToRetryWhenTriggerNotAddedSuccessfully = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("form-save-retry", "blade.alerts.form.button.retry");
	fCallback("INVALID");
};

NewAlertPresentationModelTest.prototype.testStatusMessageWhenTriggerAddInProgress = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	fCallback("INVALID");
	
	oMockForm.expects(once()).setValue("alert-status-header", "blade.alerts.form.alert_inprogress_message.header");
	oMockForm.expects(once()).setValue("alert-status-text", "blade.alerts.form.alert_inprogress_message.text");
	oPresentationModel.sendTrigger();
};

NewAlertPresentationModelTest.prototype.testCancelButtonMarkedAsCancelOnFormInitialised = function()
{
	oMockForm.expects(once()).setValue("form-cancel-close", "blade.alerts.form.button.cancel");
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testCancelButtonEnabledOnFormInitialised = function()
{
	oMockForm.expects(once()).setValue("closeEnabled", true);
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testCancelButtonChangesToCloseWhenTriggerAddedSuccessfully = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("form-cancel-close", "blade.alerts.form.button.close");
	fCallback("ADDED");
};


NewAlertPresentationModelTest.prototype.testCancelButtonDisabledWhenTriggerAddInProgress = function()
{
	oPresentationModel.initialise(oMockForm.proxy());
	
	oMockForm.expects(once()).setValue("closeEnabled", false);
	oPresentationModel.sendTrigger();
};

NewAlertPresentationModelTest.prototype.testCancelButtonReEnabledWhenTriggerAddCompleted = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	
	oMockForm.expects(once()).setValue("closeEnabled", false);
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("closeEnabled", true);
	fCallback("INVALID");

	oMockForm.expects(once()).setValue("closeEnabled", false);
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("closeEnabled", true);
	fCallback("ADDED");
};

NewAlertPresentationModelTest.prototype.testSaveButtonVisibleOnFormInitialised = function()
{
	oMockForm.expects(once()).setValue("form-save-retry-visible", true);
	oPresentationModel.initialise(oMockForm.proxy());
};

NewAlertPresentationModelTest.prototype.testSaveButtonInvisibleWhenTriggerAddCompleted = function()
{
	var fCallback; 
	caplin.alerts.TriggerService.addTrigger = function(oTriggerData, fCallbackFunction)
	{
		fCallback = fCallbackFunction;
	};
	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.sendTrigger();
	
	oMockForm.expects(once()).setValue("form-save-retry-visible", false);
	fCallback("ADDED");
};


NewAlertPresentationModelTest.prototype.testSubscribesToFieldUpdatesForSubject = function()
{
	//Given
	var sSubject = "/FX/INSTRUMENT";
	oPresentationModel.initialise(oMockForm.proxy());
	
	//Then Expect
	oMockInstrumentSubscriber.expects(once()).start();
	
	//When
	oPresentationModel.setSubject(sSubject);
};

NewAlertPresentationModelTest.prototype.testUnsubscribesToFieldUpdatesForSubjectWhenFormIsClosed = function()
{

	//Given	
	oMockInstrumentSubscriber.stubs().start();
	var sSubject = "/FX/INSTRUMENT";
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	
	//Then Expect
	oMockInstrumentSubscriber.expects(once()).unsubscribe();
	
	//When
	oPresentationModel.close();
};

NewAlertPresentationModelTest.prototype.testUpdatesValueFieldBasedOnCurrentValueOfTriggerName = function()
{
	//Given
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();	
	var sSubject = "/FX/INSTRUMENT";
	var sAskValue = "1.233";
	var oFieldProperty = this.createPropertyFor("field");	
	
	oMockForm.stubs().setValue(ANYTHING, ANYTHING);
	oMockInstrumentSubscriber.stubs().start();

	
	var oValueProperty = this.createPropertyFor("value");	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oFieldProperty.setValue("blade.alerts.form.fx.bid");
	oPresentationModel.updateField("BestAsk", "1.233");
	oPresentationModel.updateField("BestBid", "1.2334");
	
	//Then Expect 
	oMockForm.expects(once()).setValue("value", sAskValue);
			
	//When
	oFieldProperty.setValue("blade.alerts.form.fx.ask");
	
};

NewAlertPresentationModelTest.prototype.testShouldUpdateValueFieldOnlyWhenSelectedFieldChanges = function()
{
	//Given
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();	
	var sSubject = "/FX/INSTRUMENT";
	var oFieldProperty = this.createPropertyFor("field");	
	
	oMockInstrumentSubscriber.stubs().start();
	
	var oValueProperty = this.createPropertyFor("value");	
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oPresentationModel.updateField("BestAsk", "1.334");
	oPresentationModel.updateField("BestBid", "1.332");
	
	//Then Expect 
	oMockForm.expects(once()).setValue("value", "1.332");
			
	//When
	oFieldProperty.setValue("blade.alerts.form.fx.bid");
	oFieldProperty.setValue("blade.alerts.form.fx.bid");
};

NewAlertPresentationModelTest.prototype.testFXFieldValueIsFormatted = function() {
	//given
	var sValue ="1234.1234";
	var sFormattedValueStreamed ="1,234.1234";
	var sFormattedValueCurrent ="1234.1234";
	var sSubject = "/FX/INSTRUMENT";
	var oValueProperty = this.createPropertyFor("value");
	var oFieldProperty = this.createPropertyFor("field");

	oMockInstrumentSubscriber.stubs().start();
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oFieldProperty.setValue("blade.alerts.form.fx.ask");
	
	//then
	oMockForm.expects(once()).setValue("current-field-value",sFormattedValueStreamed);
	oMockForm.expects(once()).setValue("value",sFormattedValueCurrent);

	//when
	oPresentationModel.updateField("BestAsk", sValue);	
};

NewAlertPresentationModelTest.prototype.testFIFieldValueIsFormatted = function() {
	//given
	var sValue ="1234.1234";
	var sFormattedValueStreamed ="1,234.123";
	var sFormattedValueCurrent ="1234.123";
	var sSubject = "/FI/INSTRUMENT";
	var oValueProperty = this.createPropertyFor("value");
	var oFieldProperty = this.createPropertyFor("field");

	oMockInstrumentSubscriber.stubs().start();
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oFieldProperty.setValue("blade.alerts.form.fi.ask");
	
	//then
	oMockForm.expects(once()).setValue("current-field-value",sFormattedValueStreamed);
	oMockForm.expects(once()).setValue("value",sFormattedValueCurrent);

	//when
	oPresentationModel.updateField("AskYield", sValue);
};

NewAlertPresentationModelTest.prototype.testMarksCurrentFieldValueAsAvailableWhenSubscriptionIsEnabled = function() {
	//given
	oPresentationModel.initialise(oMockForm.proxy());
	
	//expectations
	oMockForm.expects(once()).setValue("field-value-class", "");
	
	//when
	oPresentationModel.available();	
};

NewAlertPresentationModelTest.prototype.testMarksCurrentFieldValueAsStaleWhenSubscriptionFails = function() {
	//given
	oPresentationModel.initialise(oMockForm.proxy());
	
	//expectations
	oMockForm.expects(once()).setValue("field-value-class", "stale");
	
	//when
	oPresentationModel.stale();	
};

NewAlertPresentationModelTest.prototype.testShouldUpdateValueFieldIfEmptyAndRecievedUpdatesAfterGoingStale = function() {
	//given
	var sSubject = "/FX/INSTRUMENT";
	var sValue ="13.23";
	var oFieldProperty = this.createPropertyFor("field");
	
	oMockInstrumentSubscriber.stubs().start();
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oFieldProperty.setValue("blade.alerts.form.fx.bid");
	oMockForm.stubs().getValue("value").will(returnValue(""));
	//when
	oPresentationModel.stale();	
	
	//expectations
	oMockForm.expects(once()).setValue("value", sValue);
	
	oPresentationModel.available();	
	oPresentationModel.updateField("BestBid", sValue);
};

NewAlertPresentationModelTest.prototype.testShouldIgnoreValueFieldIfNotEmptyAndRecievedUpdatesAfterGoingStale = function() {
	//given
	var sSubject = "/FX/INSTRUMENT";
	var sValue ="13.23";
	var oFieldProperty = this.createPropertyFor("field");
	
	oMockInstrumentSubscriber.stubs().start();
	oPresentationModel.initialise(oMockForm.proxy());
	oPresentationModel.setSubject(sSubject);
	oFieldProperty.setValue("blade.alerts.form.fx.bid");
	
	oMockForm.stubs().getValue("value").will(returnValue("1.23"));

	//when
	oPresentationModel.stale();	
	
	//expectations
	oMockForm.expects(never()).setValue("value", sValue);
	
	oPresentationModel.available();	
	oPresentationModel.updateField("BestBid", sValue);
};

NewAlertPresentationModelTest.prototype.testFieldAndOperatorWhenBidFieldIsSet = function()
{
	//given
	var sSubject = "/FX/INSTRUMENT";
	var sField = "BestBid";
	var sOperator = ">=";
	
	//when
	oPresentationModel.initialise(oMockForm.proxy());
	oMockForm.stubs().getValue("subject").will(returnValue(sSubject));
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
		
	//expectations
	oMockForm.expects(once()).setValue("field", ct.i18n("blade.alerts.form.fx.bid"));
	oMockForm.expects(once()).setValue("operator", sOperator);
	
	oPresentationModel.setField(sField);
};

NewAlertPresentationModelTest.prototype.testFieldAndOperatorWhenAskFieldIsSet = function()
{
	//given
	var sSubject = "/FX/INSTRUMENT";
	var sField = "BestAsk";
	var sOperator = "<=";
	
	//when
	oPresentationModel.initialise(oMockForm.proxy());
	oMockForm.stubs().getValue("subject").will(returnValue(sSubject));
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
	
	//expectations
	oMockForm.expects(once()).setValue("field", ct.i18n("blade.alerts.form.fx.ask"));
	oMockForm.expects(once()).setValue("operator", sOperator);	
	
	oPresentationModel.setField(sField);
};

NewAlertPresentationModelTest.prototype.testFieldAndOperatorWhenNoPriceFieldIsSet = function()
{
	//given
	var sSubject = "/FX/INSTRUMENT";
	//when
	oPresentationModel.initialise(oMockForm.proxy());
	oMockForm.stubs().getValue("subject").will(returnValue(sSubject));
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
	
	//expectations
	oMockForm.expects(never()).setValue("field", ANYTHING);
	oMockForm.expects(never()).setValue("operator", ANYTHING);

	oPresentationModel.setField("NonPriceField");
};

NewAlertPresentationModelTest.prototype.testShouldSetDefaultOperatorWhenFieldChanges = function()
{
	//given
	var sSubject = "/FX/INSTRUMENT";
	var sField = "BestAsk";
	var sOperator = "<=";
	
	//when
	oPresentationModel.initialise(oMockForm.proxy());
	oMockForm.stubs().getValue("subject").will(returnValue(sSubject));
	caplinx.alerts.AlertFieldNameMap.onAfterClassLoad();
	
	oMockForm.stubs().setValue("field", ct.i18n("blade.alerts.form.fx.ask"));
	oMockForm.stubs().setValue("operator", sOperator);	
	oPresentationModel.setField(sField);
	
	//expectations
	oMockForm.expects(once()).setValue("field", ct.i18n("blade.alerts.form.fx.bid"));
	oMockForm.expects(once()).setValue("operator", ">=");	
	
	//when
	oPresentationModel.setField("BestBid");
};
