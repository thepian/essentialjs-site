AlertsDrawerPersistorTest = TestCase("AlertsDrawerPersistorTest");

AlertsDrawerPersistorTest.prototype.setUp = function()
{
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	this.mockUserPropertyStore = mock(caplin.core.properties.UserPropertyStore);
	var mockUserPropertyStoreProxy = this.mockUserPropertyStore.proxy();
	caplin.core.AbstractFactory.INSTANCE = {
		getUserPropertyStore: function()
		{
			return mockUserPropertyStoreProxy;
		}
	};
	this.oAlertsDrawerPersistor = new caplinx.alerts.view.component.AlertsDrawerPersistor("TestKey");
	this.sKey = "alert.config.TestKey"; 
	
	this.mockComponent = mock(caplin.component.composite.CompositeComponent);
	this.mockComponentProxy = this.mockComponent.proxy();
};

AlertsDrawerPersistorTest.prototype.tearDown = function()
{
	caplin.core.AbstractFactory.INSTANCE = null;
	Mock4JS.verifyAllMocks();	
	
};

AlertsDrawerPersistorTest.prototype.testItShouldAddSelfAsColumnModelListenerForGridComponent = function()
{
	//given
	var mockGridComponent = mock(caplin.grid.GridView);
	var mockGridComponenProxy = mockGridComponent.proxy();
	var mockColumnModel = mock(caplin.grid.GridColumnModel);
	this.oAlertsDrawerPersistor._getComponent = function() 
	{
		return mockGridComponenProxy;
	};
	
	//expectations
	mockGridComponent.expects(once()).getGridColumnModel().will(returnValue(mockColumnModel.proxy()));
	mockColumnModel.expects(once()).addColumnModelListener(this.oAlertsDrawerPersistor);
	
	//when
	this.oAlertsDrawerPersistor.addAsListenerTo(this.mockComponentProxy);
};

AlertsDrawerPersistorTest.prototype.testItShouldSaveGridConfigWhenColumnsAreAdded = function()
{
	//given
	var sXml = "<compositecomponent></compositecomponent>";
	
	var mockGridComponent = mock(caplin.grid.GridView);
	var mockGridComponenProxy = mockGridComponent.proxy();
	var mockColumnModel = mock(caplin.grid.GridColumnModel);
	this.oAlertsDrawerPersistor._getComponent = function() 
	{
		return mockGridComponenProxy;
	};
	//stubs
	mockGridComponent.stubs().getGridColumnModel().will(returnValue(mockColumnModel.proxy()));
	mockColumnModel.stubs().addColumnModelListener(this.oAlertsDrawerPersistor);
	
	this.oAlertsDrawerPersistor.addAsListenerTo(this.mockComponentProxy);
	
	//expectations
	this.mockComponent.expects(once()).getSerializedState().will(returnValue(sXml));
	this.mockUserPropertyStore.expects(once()).setUserProperty(this.sKey, sXml);
	
	//when
	this.oAlertsDrawerPersistor.onColumnsAdded();
};

AlertsDrawerPersistorTest.prototype.testItShouldRetreiveGridConfigFromUserPropertyStore = function()
{
	//given
	var sKey = "notificationgrid";
	
	//expectations
	this.mockUserPropertyStore.expects(once()).getUserProperty(this.sKey);
	
	//when
	this.oAlertsDrawerPersistor.getXMLTemplate();
	
};
