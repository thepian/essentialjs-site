TriggerManagerRowSourceTest = TestCase("TriggerManagerRowSourceTest");

TriggerManagerRowSourceTest.prototype.setUp = function() {
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();

	//mock TriggerService singleton
	this.triggerService = Mock4JS.mockObject(caplin.alerts.TriggerService);
	this.realTriggerService = caplin.alerts.TriggerService;
	caplin.alerts.TriggerService=this.triggerService.proxy();
};

TriggerManagerRowSourceTest.prototype.tearDown = function(){
	caplin.alerts.TriggerService=this.realTriggerService;
	Mock4JS.verifyAllMocks();	
};

TriggerManagerRowSourceTest.prototype.testWhenRowSourceIsAskedForDataItGetsTriggersFromTriggerService = function() {
	//given
	this.triggerService.stubs().addListener(ANYTHING);
	var triggerManagerRowSource = new caplinx.alerts.rowsource.TriggerManagerRowSource();
	
	//expectations
	var pTriggers = [
	                 {"id":"1", "name": "name", "condition": "condition1"},
	                 {"id":"2", "name": "name3", "condition": "condition2"}
	                ];
	this.triggerService.expects(once()).getAllTriggers().will(returnValue(pTriggers));
	
	//when
	var pReturned = triggerManagerRowSource.getAllRows();
	
	//then
	var pExpected = [
	                 {"id":"2", "data": {"id":"2", "name": "name3", "condition": "condition2"}},
	                 {"id":"1", "data": {"id":"1", "name": "name", "condition": "condition1"}}
	                ];	
	assertArrayEquals(pExpected, pReturned);
};

TriggerManagerRowSourceTest.prototype.testWhenTriggerServiceNotifiesOfAddThenItIsPassedOnToTheGrid = function() {
	//given
	this.triggerService.expects(once()).addListener(ANYTHING);
	var triggerManagerRowSource = new caplinx.alerts.rowsource.TriggerManagerRowSource();
	
	var rowSourceListener = mock(caplin.grid.rowsource.RowSourceListener);
	triggerManagerRowSource.addRowSourceListener(rowSourceListener.proxy());
	
	//expectations
	rowSourceListener.expects(once()).rowAdded("3", {"id":"3", "subject": "/FX/GBPUSD", "alertCondition": "condition"}, 0);
	rowSourceListener.expects(once()).structureChangeCompleted();
	
	//when
	triggerManagerRowSource.onTriggerAdded({"id":"3", "subject": "/FX/GBPUSD", "alertCondition": "condition"});
	
	//then
	//assertion
};

TriggerManagerRowSourceTest.prototype.testDataUnavailable = function() {	
	caplin.alerts.TriggerService = new caplin.singletons["caplin.alerts.TriggerService"]();
	
	this.triggerService.stubs().addListener(ANYTHING);
	var triggerManagerRowSource = new caplinx.alerts.rowsource.TriggerManagerRowSource();
	
	var rowSourceListener = mock(caplin.grid.rowsource.RowSourceListener);
	triggerManagerRowSource.addRowSourceListener(rowSourceListener.proxy());
	
	rowSourceListener.expects(once()).allRowsRemoved();
	rowSourceListener.expects(once()).structureChangeCompleted();
	rowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.NOT_FOUND);
	triggerManagerRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_FOUND);
	
	rowSourceListener.expects(once()).allRowsRemoved();
	rowSourceListener.expects(once()).structureChangeCompleted();
	rowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.NOT_PERMISSIONED);
	triggerManagerRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_PERMISSIONED);
	
	rowSourceListener.expects(once()).allRowsRemoved();
	rowSourceListener.expects(once()).structureChangeCompleted();
	rowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.ERROR);
	triggerManagerRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.UNKNOWN_ERROR);
	
	rowSourceListener.expects(once()).allRowsRemoved();
	rowSourceListener.expects(once()).structureChangeCompleted();
	rowSourceListener.expects(once()).dataUnavailable(caplin.grid.RowDataUnavailable.DELETED);
	triggerManagerRowSource.onDataUnavailable(caplin.alerts.AlertsConstants.RTTP_CONTAINER_DELETED);
};

TriggerManagerRowSourceTest.prototype.testTriggerRemovedIsPassedOnToTheGrid = function() {
	caplin.alerts.TriggerService = new caplin.singletons["caplin.alerts.TriggerService"]();
	
	this.triggerService.stubs().addListener(ANYTHING);
	var triggerManagerRowSource = new caplinx.alerts.rowsource.TriggerManagerRowSource();
	
	var rowSourceListener = mock(caplin.grid.rowsource.RowSourceListener);
	triggerManagerRowSource.addRowSourceListener(rowSourceListener.proxy());
	
	rowSourceListener.expects(once()).rowRemoved("2");
	rowSourceListener.expects(once()).structureChangeCompleted();
	
	triggerManagerRowSource.onTriggerRemoved("2");
};

TriggerManagerRowSourceTest.prototype.testShouldAddAllRowsBackOnDataAvailable = function() {
	//given
	var pTriggers = [
	                 {"id":"1", "name": "name", "subject": "/FX/GBPUSD", "alertCondition": "condition1"},
	                 {"id":"2", "name": "name3", "subject": "/FX/GBPUSD", "alertCondition": "condition2"}
	                ];
	this.triggerService.stubs().addListener(ANYTHING);
	this.triggerService.stubs().getAllTriggers().will(returnValue(pTriggers));
	                
	var triggerManagerRowSource = new caplinx.alerts.rowsource.TriggerManagerRowSource();

	var rowSourceListener = mock(caplin.grid.rowsource.RowSourceListener);
	triggerManagerRowSource.addRowSourceListener(rowSourceListener.proxy());
	
	//expectations
	rowSourceListener.expects(once()).rowAdded("1", ANYTHING, 0);
	rowSourceListener.expects(once()).rowAdded("2", ANYTHING, 0);
	rowSourceListener.expects(once()).structureChangeCompleted();
		
	//when
	triggerManagerRowSource.onDataAvailable();
};

TriggerManagerRowSourceTest.prototype.testShouldAddAndRemoveAFictitiousRowWhenDataAvailableAndThereAreNoTriggers = function() {
	//given
	this.triggerService.stubs().addListener(ANYTHING);
	this.triggerService.stubs().getAllTriggers().will(returnValue([]));

	var triggerManagerRowSource = new caplinx.alerts.rowsource.TriggerManagerRowSource();
	
	var rowSourceListener = mock(caplin.grid.rowsource.RowSourceListener);
	triggerManagerRowSource.addRowSourceListener(rowSourceListener.proxy());
	
	//expectations
	rowSourceListener.expects(once()).rowAdded("-1", ANYTHING, 0);
	rowSourceListener.expects(once()).rowRemoved("-1");
	rowSourceListener.expects(exactly(2)).structureChangeCompleted();
		
	//when
	triggerManagerRowSource.onDataAvailable();
};