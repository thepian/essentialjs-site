InstrumentSubscriberTest = TestCase("InstrumentSubscriberTest");

SL4B_Accessor = {
	getRttpProvider : function() {
		return { 
			getObject : function() {
				
			},
			removeObject: function() {
				
			}
		};
	}
};
InstrumentSubscriberTest.prototype.setUp = function()
{
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	oMockPresentationModel = mock(caplinx.alerts.view.NewAlertPresentationModel);
	sSubjectName = "/SOME/SUBJECT";
	pFieldNames = ["FIELD_ONE", "FIELD_TWO"];

	oInstrumentSubscriber = new caplinx.alerts.view.InstrumentSubscriber(sSubjectName, pFieldNames, oMockPresentationModel.proxy());
	oInstrumentSubscriber.start();
};

InstrumentSubscriberTest.prototype.tearDown = function(){
	oInstrumentSubscriber.unsubscribe();
	Mock4JS.verifyAllMocks();	
};

InstrumentSubscriberTest.prototype.testUpdatesViewUponReceivingSubscribedFieldData = function()
{
	//Given
	var oFieldData = {
		getFieldMap : function() {
			return { "FIELD_ONE" : "VALUE_ONE", "FIELD_TWO" : "VALUE_TWO" };
		}	
	};
	
	//Then Expect
	oMockPresentationModel.expects(once()).updateField("FIELD_ONE", "VALUE_ONE");
	oMockPresentationModel.expects(once()).updateField("FIELD_TWO", "VALUE_TWO");
	
	//When
	oInstrumentSubscriber.recordMultiUpdated(sSubjectName, oFieldData); 
};

InstrumentSubscriberTest.prototype.testMarksPresentationModelDataAsAvailable = function() {
	//given
	
	//expectation
	oMockPresentationModel.expects(once()).available();
	
	//when
	oInstrumentSubscriber.objectStatus(sSubjectName, oInstrumentSubscriber.OBJECT_STATUS_OK, 0, "received ok");
};

InstrumentSubscriberTest.prototype.testMarksPresentationModelDataAsStale = function() {
	//given
	
	//expectation
	oMockPresentationModel.expects(once()).stale();
	
	//when
	oInstrumentSubscriber.objectStatus(sSubjectName,oInstrumentSubscriber.OBJECT_STATUS_STALE, 0, "received stale");
};

