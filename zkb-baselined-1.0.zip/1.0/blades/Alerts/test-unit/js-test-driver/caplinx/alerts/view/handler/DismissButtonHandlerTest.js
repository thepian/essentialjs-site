DismissButtonHandlerTest = TestCase("DismissButtonHandlerTest");

DismissButtonHandlerTest.prototype.setUp = function() {
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	this.mockButton = mock(caplin.widget.formcontrols.ThreeImageButton);	
	this.m_oDismissButtonHandler = new caplinx.alerts.view.handler.DismissButtonHandler(this.mockButton.proxy());
};

DismissButtonHandlerTest.prototype.tearDown = function()
{
	this.mockButton = null;
	this.m_oDismissButtonHandler = null;
	Mock4JS.verifyAllMocks();
};

DismissButtonHandlerTest.prototype.testItShouldDisableDismissButtonIfRecordIsStale = function () {
	//given
	var sSubject = "notification1";
	var nIndex = "12";
	var mockGridRowModel = mock(caplin.grid.GridRowModel);
	var oNotificationRow = {RECORD_STATUS : SL4B_ObjectStatus.STALE};
	mockGridRowModel.stubs().getIndexBySubject(sSubject).will(returnValue(nIndex));
	mockGridRowModel.stubs().getRowData(nIndex).will(returnValue(oNotificationRow));

	//expectation
	this.mockButton.expects(once()).disable(true);

	//when
	this.m_oDismissButtonHandler.handleGridRowSelection(mockGridRowModel.proxy(), [sSubject]);
};