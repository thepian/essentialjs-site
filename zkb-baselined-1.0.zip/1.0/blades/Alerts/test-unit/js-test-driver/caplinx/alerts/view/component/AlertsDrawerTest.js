AlertsDrawerTest = TestCase("AlertsDrawerTest");

AlertsDrawerTest.prototype.setUp = function()
{
	Mock4JS.addMockSupport(window);
	Mock4JS.clearMocksToVerify();
	
	this.m_oMockComponent = mock(caplin.webcentric.presentation.FrameItem);
	this.m_oMockComponent.stubs().show();
	this.m_oMockComponent.stubs().hide();

	this.originalAlertsDrawer = caplinx.alerts.view.component.AlertsDrawer;
	caplinx.alerts.view.component.AlertsDrawer = new caplin.singletons["caplinx.alerts.view.component.AlertsDrawer"]();
	
	var self = this;
	caplinx.alerts.view.component.AlertsDrawer._buildComponent = function()
	{
		return self.m_oMockComponent.proxy();
	};
	caplinx.alerts.view.component.AlertsDrawer._showAndSelectNotificationsGrid = function()
	{
	};
};

AlertsDrawerTest.prototype.tearDown = function()
{
	caplinx.alerts.view.component.AlertsDrawer = this.originalAlertsDrawer;
	Mock4JS.verifyAllMocks();
};

AlertsDrawerTest.prototype.testComponentIsShown = function()
{
	this.m_oMockComponent.expects(once()).show();
	caplinx.alerts.view.component.AlertsDrawer.show();
};

AlertsDrawerTest.prototype.testComponentIsHidden = function()
{
	this.m_oMockComponent.expects(once()).hide();
	caplinx.alerts.view.component.AlertsDrawer.hide();
};

AlertsDrawerTest.prototype.testToggleAfterShowHidesComponent = function()
{
	caplinx.alerts.view.component.AlertsDrawer.show();
	this.m_oMockComponent.expects(once()).hide();
	caplinx.alerts.view.component.AlertsDrawer.toggle();
};

AlertsDrawerTest.prototype.testToggleAfterHideShowsComponent = function()
{
	caplinx.alerts.view.component.AlertsDrawer.hide();
	this.m_oMockComponent.expects(once()).show();
	caplinx.alerts.view.component.AlertsDrawer.toggle();
};

AlertsDrawerTest.prototype.testToggleBeforeHideOrShowShowsComponent = function()
{
	this.m_oMockComponent.expects(once()).show();
	caplinx.alerts.view.component.AlertsDrawer.toggle();
};