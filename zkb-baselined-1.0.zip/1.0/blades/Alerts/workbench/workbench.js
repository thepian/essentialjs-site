var oWorkbenchApplicationFactory = {
	getControlFactory: function()
	{
		return new caplin.renderer.control.ControlFactory();
	}
};
caplin.renderer.AbstractFactory.setInstance(oWorkbenchApplicationFactory);

caplin.namespace("caplin.webcentric.core");

caplin.webcentric.core.EventManager = {
	registerAsEventListener: function(event, fCallback) 
	{
		
	},
	registerOneShotEventListener: function(event, fCallback) 
	{
		
	}
};
