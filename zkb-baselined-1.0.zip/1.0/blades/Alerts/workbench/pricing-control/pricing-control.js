caplin.namespace("caplin.alerts.workbench");

caplin.alerts.workbench.PricingControl = {};

caplin.alerts.workbench.PricingControl.m_pUrlsToLoad = [];

caplin.alerts.workbench.PricingControl.sCommandHttpdUrl = "http://xaqua.caplin.com:40109/datasrc?";

caplin.alerts.workbench.PricingControl.initialise = function(){
	caplin.alerts.workbench.PricingControl.sCommandHttpdUrl = "http://" + workbenchConfig.get('xaquahostname') + ":40109/datasrc?";
	document.getElementById("commandHttpd").src = this.sCommandHttpdUrl + "command=add-active-request /COMMANDHTTPD/CONTAINER 228 48";
};

caplin.alerts.workbench.PricingControl.addInstrument = function(){
	this.sendInstrumentData("add-active-request");
};

caplin.alerts.workbench.PricingControl.enableContainer = function(){
	document.getElementById("commandHttpd").src = this.sCommandHttpdUrl + "command=add-active-request /COMMANDHTTPD/CONTAINER 228 48";
};

caplin.alerts.workbench.PricingControl.updateInstrument = function(){
	this.sendInstrumentData("send-update");
};

caplin.alerts.workbench.PricingControl.addInstrumentToContainer = function(){
	var subject = document.getElementById("pricing-Subject").value;	
	document.getElementById("commandHttpd").src = this.sCommandHttpdUrl + "command=send-update /COMMANDHTTPD/CONTAINER 228 48 " + subject;
};

caplin.alerts.workbench.PricingControl.sendInstrumentData = function(command){
	var tier = document.getElementById("pricing-Tier").value || "T1";
	var subject = document.getElementById("pricing-Subject").value;
	var instrumentDescription = document.getElementById("pricing-InstrumentDescription").value;
	var bestBid = document.getElementById("pricing-BestBid").value;
	var bestAsk = document.getElementById("pricing-BestAsk").value;
	
	var sFileNamesAndValues = "InstrumentDescription " + instrumentDescription + " BestBid " + bestBid + " BestAsk " + bestAsk;
	document.getElementById("commandHttpd").src = this.sCommandHttpdUrl + "command=" + command + " " + subject + "/" + tier + " 222 48 " + sFileNamesAndValues;	
};

caplin.alerts.workbench.PricingControl.enableConnection = function() {
		document.getElementById("commandHttpd").src = this.sCommandHttpdUrl + "command=connect 0";
};

caplin.alerts.workbench.PricingControl.disableConnection = function() {
		document.getElementById("commandHttpd").src = this.sCommandHttpdUrl + "command=disconnect 0";
};
		