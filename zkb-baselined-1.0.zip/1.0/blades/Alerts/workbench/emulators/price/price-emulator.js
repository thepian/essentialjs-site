caplin.namespace("caplinx.emulators");

caplinx.emulators.PriceEmulator = function()
{
};

caplinx.emulators.PriceEmulator.prototype.reset = function()
{
	document.getElementById("addBestBidPrice").value = null;
	document.getElementById("addBestAskPrice").value = null;
	document.getElementById("addBidYieldPrice").value = null;
	document.getElementById("addAskYieldPrice").value = null;
};

caplinx.emulators.PriceEmulator.prototype.sendStale = function(sSubject) {
	caplinx.emulators.SL4BEmulator.sendRecordResponse(sSubject, 1, "stale");
	document.getElementById("send_price_update").disabled = true;
};

caplinx.emulators.PriceEmulator.prototype.sendAvailable = function(sSubject) {
	caplinx.emulators.SL4BEmulator.sendRecordResponse(sSubject, 3, "ok");
	document.getElementById("send_price_update").disabled = false;
};

caplinx.emulators.PriceEmulator.prototype.sendPriceUpdate = function(sBestBidPrice, sBestAskPrice, sBidYieldPrice, sAskYieldPrice)
{
	if(this._isEmpty(sBestBidPrice)  && 
	   this._isEmpty(sBestAskPrice)  &&
	   this._isEmpty(sBidYieldPrice) && 
	   this._isEmpty(sAskYieldPrice)) 
	{
		alert("Incorrect Input");
		return;
	}
	var mData = { 
		"BestBid" : sBestBidPrice, 
		"BestAsk" : sBestAskPrice, 
		"BidYield" : sBidYieldPrice,
		"AskYield" : sAskYieldPrice 
	};
	
	for (var sFieldName in mData) {
		if(!mData[sFieldName]) {
			delete mData[sFieldName];
		}
	}
	
	caplinx.emulators.SL4BEmulator.onEmulatedPriceUpdate(mData);
};

caplinx.emulators.PriceEmulator.prototype._isEmpty = function (inputStr) 
{ 
	if ( null == inputStr || "" === inputStr ) 
	{ 
		return true; 
	} 
	return false; 
}


caplin.singleton("caplinx.emulators.PriceEmulator");
