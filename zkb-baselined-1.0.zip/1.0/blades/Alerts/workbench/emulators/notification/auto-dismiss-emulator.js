caplin.namespace("caplinx.alerts.workbench");

caplinx.alerts.workbench.AutoDismissEmulator = function() {
	this.m_pCriteria = [];
	this.m_sCurrentSource = "";
	this.m_sCurrentCategory = "";
};

caplinx.alerts.workbench.AutoDismissEmulator.prototype.initialise = function() {
	document.getElementById("autoDismiss").disabled = true;
	document.getElementById("set-source").value = "Triggered";
	document.getElementById("set-category").value = "Triggered";
};

caplinx.alerts.workbench.AutoDismissEmulator.prototype.enableAutoDismiss = function() {
	var sSource = document.getElementById("auto-dismiss-source").value;
	var sCategory = document.getElementById("auto-dismiss-category").value;
	if(sSource == '' && sCategory == '' ) {
		document.getElementById("autoDismiss").disabled = true;
	} else {
		document.getElementById("autoDismiss").disabled = false;
	}
};

caplinx.alerts.workbench.AutoDismissEmulator.prototype.clearAutoDismiss = function(nIndex) {
	var sSource = this.m_pCriteria[nIndex-1]['source'];
	var sCategory = this.m_pCriteria[nIndex-1]['category'];
	document.getElementById("clear-auto-dismiss-button-" + nIndex).disabled = true ;
	var eRow = document.getElementById("auto-dismiss-row-" + nIndex);
	var eAutoDismissSelector = document.getElementById("auto-dismiss-table");
	eAutoDismissSelector.removeChild(eRow);
	caplin.alerts.NotificationService.clearAutoDismiss(sSource, sCategory);
};

caplinx.alerts.workbench.AutoDismissEmulator.prototype.setAutoDismiss = function() {
	var sSource = document.getElementById("auto-dismiss-source").value;
	sSource = sSource.length !== 0 ? sSource : undefined;
	var sCategory = document.getElementById("auto-dismiss-category").value;
	sCategory = sCategory.length !== 0 ? sCategory : undefined;
	if(caplin.alerts.NotificationService.setAutoDismiss(sSource, sCategory)) {
		this._addAutoDismissCriteriaRecord(sSource, sCategory);
	}
};

caplinx.alerts.workbench.AutoDismissEmulator.prototype._addAutoDismissCriteriaRecord = function(sSource, sCategory) {
	this.m_pCriteria.push({'source':sSource, 'category':sCategory});
	var eAutoDismissSelector;
	eAutoDismissSelector = document.getElementById("auto-dismiss-table");
	var eCriteriaRow = document.createElement('tr');
	eCriteriaRow.id = "auto-dismiss-row-" + this.m_pCriteria.length;
	var eSourceData = document.createElement('td');
	eSourceData.innerHTML = sSource;
	eCriteriaRow.appendChild(eSourceData);
	var eCategoryData = document.createElement('td');
	eCategoryData.innerHTML = sCategory;
	eCriteriaRow.appendChild(eCategoryData);
	var eClearDismiss = document.createElement('td');
	eClearDismiss.innerHTML = '<input id="clear-auto-dismiss-button-' + (this.m_pCriteria.length) + '" type="submit" value="Clear"' + 
		' onClick="caplinx.alerts.workbench.AutoDismissEmulator.clearAutoDismiss('+ (this.m_pCriteria.length)+ ');">';
	
	eCriteriaRow.appendChild(eClearDismiss);
	
	eAutoDismissSelector.appendChild(eCriteriaRow);
};

caplinx.alerts.workbench.AutoDismissEmulator.prototype.sendAutoNotification = function() {
	var sCategory  = document.getElementById("set-category").value;
	var sSource = document.getElementById("set-source").value ;
	
	caplinx.alerts.AlertsEmulator.onAutoGenerateNotifcation(sSource, sCategory);
};

caplin.singleton("caplinx.alerts.workbench.AutoDismissEmulator");