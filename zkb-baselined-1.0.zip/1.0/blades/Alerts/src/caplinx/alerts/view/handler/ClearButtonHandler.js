caplin.namespace("caplinx.alerts.view.handler");

caplin.include("caplin.alerts.NotificationService");
caplin.include("caplinx.alerts.view.handler.GridBarButtonHandler", true);

caplinx.alerts.view.handler.ClearButtonHandler = function(eButton)
{
};

caplin.implement(caplinx.alerts.view.handler.ClearButtonHandler, caplinx.alerts.view.handler.GridBarButtonHandler)

caplinx.alerts.view.handler.ClearButtonHandler.prototype.handleGridRowSelection = function(oGridRowModel, pSelectedRows) {
	
};

caplinx.alerts.view.handler.ClearButtonHandler.prototype.execute = function(pSelectedRows)
{
	caplin.alerts.NotificationService.clearHistory();
};