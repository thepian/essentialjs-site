caplin.namespace("caplinx.alerts.view");

/**
 * Instrument Subscriber Inner Class
 */ 
caplinx.alerts.view.InstrumentSubscriber = function(sSubjectName, pFieldNames, oPresentationModel) {
    this.m_sSubjectName = sSubjectName;
    this.m_pFieldNames = pFieldNames;
    this.m_oPresentationModel = oPresentationModel;
    this.m_bAvailable = false;
};

caplinx.alerts.view.InstrumentSubscriber.prototype.OBJECT_STATUS_STALE = 1;
caplinx.alerts.view.InstrumentSubscriber.prototype.OBJECT_STATUS_OK = 3;


caplin.extend(caplinx.alerts.view.InstrumentSubscriber, SL4B_AbstractSubscriber);

caplinx.alerts.view.InstrumentSubscriber.prototype.start = function(oView) {
    this.initialise();
};

caplinx.alerts.view.InstrumentSubscriber.prototype.ready = function() {
	SL4B_Accessor.getRttpProvider().getObject(this, this.m_sSubjectName, this.m_pFieldNames.join(","));
};

caplinx.alerts.view.InstrumentSubscriber.prototype.recordMultiUpdated = function(sSubjectName, oFieldData) {
	var mFieldData = oFieldData.getFieldMap();
	for(var sFieldName in mFieldData) {
		this.m_oPresentationModel.updateField(sFieldName, mFieldData[sFieldName]);
	}
};

caplinx.alerts.view.InstrumentSubscriber.prototype.unsubscribe = function() {
   SL4B_Accessor.getRttpProvider().removeObject(this, this.m_sSubjectName, this.m_pFieldNames.join(","));
};

caplinx.alerts.view.InstrumentSubscriber.prototype.objectStatus = function(sSubjectName, nType, nCode, sMessage) {
	if(this.m_sSubjectName === sSubjectName) {
		if(nType === this.OBJECT_STATUS_STALE) {
			this.m_oPresentationModel.stale();
		} 
		if(nType === this.OBJECT_STATUS_OK) {
			this.m_oPresentationModel.available();
		} 
	}
};

