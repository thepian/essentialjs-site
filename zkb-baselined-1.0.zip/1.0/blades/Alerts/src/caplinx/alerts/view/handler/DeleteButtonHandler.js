caplin.namespace("caplinx.alerts.view.handler");

caplin.include("caplin.alerts.NotificationService");
caplin.include("caplinx.alerts.view.handler.GridBarButtonHandler", true);

caplinx.alerts.view.handler.DeleteButtonHandler = function(eButton)
{
};

caplin.implement(caplinx.alerts.view.handler.DeleteButtonHandler, caplinx.alerts.view.handler.GridBarButtonHandler)

caplinx.alerts.view.handler.DeleteButtonHandler.prototype.handleGridRowSelection = function(pSelectedRows) {
	
};

caplinx.alerts.view.handler.DeleteButtonHandler.prototype.execute = function(pSelectedRows)
{
	if (pSelectedRows.length > 0) {
		caplin.alerts.TriggerService.removeTriggers(pSelectedRows);
	}
};

