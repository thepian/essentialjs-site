caplin.namespace("caplinx.alerts.view.handler");

caplinx.alerts.view.handler.GridBarButtonHandler = function()
{
};

caplinx.alerts.view.handler.GridBarButtonHandler.prototype.execute = function()
{
};

caplinx.alerts.view.handler.GridBarButtonHandler.prototype.handleGridRowSelection = function() {
	
};

caplinx.alerts.view.handler.GridBarButtonHandler.prototype.addObserver = function()
{
};