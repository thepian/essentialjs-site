/**
 * @fileoverview
 * Defines the caplinx.alerts.view.AlertsService class.
 */
caplin.namespace("caplinx.alerts.view.handler");
caplin.include("caplin.alerts.AlertsService", true);
caplin.include("caplinx.alerts.view.NewAlertFormInitialiser");
caplin.include("caplinx.alerts.view.component.AlertsDrawer");

/**
 * @class
 * Registers an instance of caplinx.alerts.view.AlertsService into the caplin.core.ServiceRegistry to allow access to the Alert Blade view features from the main application
 * @implements caplin.alerts.AlertsService
 * @constructor
 */
caplinx.alerts.view.AlertsService = function() {};

caplin.implement(caplinx.alerts.view.AlertsService, caplin.alerts.AlertsService);

/**
 * Creates a new form builder element to create a new alert and opens it in a webcentric dialog.
 *
 * @param {caplinx.alerts.view.AlertsService} sInstrument: The currency pair the new alert will monitor, GBPUSD
 * @param {caplinx.alerts.view.AlertsService} sField: The field that is attached to column that is clicked on. Used to set the default bid/ask drop down in the form.
 * @param {caplinx.alerts.view.AlertsService} sSubject: The Liberator symbol for the currency pair, /FX/GBPUSD
 */
caplinx.alerts.view.AlertsService.prototype.openAlertCreateDialog = function(sInstrument, sField, sSubject) {
	var mAttributes = {field: sField, instrument: sInstrument, subject:sSubject};
	new caplinx.alerts.view.NewAlertFormInitialiser().execute(mAttributes);
};

/**
 * Toggles the visibility of a composite component element that lists notifications, alerts and history
 */
caplinx.alerts.view.AlertsService.prototype.openAlertManagerDialog = function() {
	caplinx.alerts.view.component.AlertsDrawer.toggle();
};

/**
 * Creates a element that displays the current notification count and appends it to a parent element.
 */
caplinx.alerts.view.AlertsService.prototype.createNotificationCounter = function(eContainer) {
	new caplinx.alerts.view.NotificationCounter(eContainer);
};

/**
 * @private
 */
caplinx.alerts.view.AlertsService.onAfterClassLoad = function() {
	var alertService = new caplinx.alerts.view.AlertsService();
	caplin.core.ServiceRegistry.registerService("caplin.alerts.AlertService", alertService);
};

caplin.notifyAfterClassLoad(caplinx.alerts.view.AlertsService);