caplin.namespace("caplinx.alerts.view");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.alerts.AlertsConstants");
caplin.include("caplin.alerts.TriggerService");
caplin.include("caplin.alerts.NotificationService");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.alerts.view.NewAlertFormInitialiser = function()
{
	
};

caplinx.alerts.view.NewAlertFormInitialiser.prototype.execute = function(mData)
{
	if(!caplin.alerts.TriggerService.isTriggerLimitExceeded())
	{
		var oDialog = this._getNewAlertDialogJSON(mData);			
		webcentric.showDialog(oDialog);
	}
	else
	{
		caplin.framework.ApplicationFactory.getInstance().getAlertDispatcher().alert(
				ct.i18n("blade.alerts.activealerts.AmountExceeded.description"), {caption : ct.i18n("blade.alerts.activealerts.AmountExceeded")});
	};
};

caplinx.alerts.view.NewAlertFormInitialiser.prototype._getNewAlertDialogJSON = function(mData)
{	
	return {
		type:"showDialog",
		properties:{},
		nodeList:[
		{
			type:"caplin:Dialog",
			properties: {
				identifier:"new_alert_dialog",
				caption:ct.i18n("cx.dialog.caption.new_alert"),
				dialog:"true",
				singleton:"identifier",
				decorators:"dialogDecorator",
				top:100,
				left:100,
				width:650,
				height:192
			},
			nodeList:[
			{
				type:"state",
				properties:{},
				nodeList:[
				{
					type:"form",
					properties:{
						template:"form:alerts",
						controller:"caplinx.alerts.view.controller.NewAlertController",
						instrument:mData.instrument,
						subject:mData.subject,
						field:mData.field
					},
					nodeList:[]
				}
				]
			},
			{
				type:"Decorators",
				properties:{
					persist:"false",
					xref:"Declarations/Decorators[@id='dialogDecorator']"
				},
				nodeList:[]
			}
			]
		}
		]
	};
};