caplin.namespace("caplinx.alerts.view.controller");

caplin.include("caplin.form.presentation.BaseFormController", true);
caplin.include("caplin.form.presentation.Form");
caplin.include("caplinx.alerts.view.NewAlertPresentationModel");

caplinx.alerts.view.controller.NewAlertController = function() {
	this.m_oPresentationModel  = new caplinx.alerts.view.NewAlertPresentationModel(this);
	this.m_sField = null;
	this.m_sSubject = null;
	this.m_sInstrumentDescription = null;
};

caplin.extend(caplinx.alerts.view.controller.NewAlertController, caplin.form.presentation.BaseFormController);

caplinx.alerts.view.controller.NewAlertController.prototype.setFormData = function(oFormData) {
	caplin.form.presentation.BaseFormController.call(this, oFormData, this.m_oPresentationModel);
	this.m_oPresentationModel.setSubject(this.m_sSubject);
	this.m_oPresentationModel.setInstrument(this.m_sInstrumentDescription);
	this.m_oPresentationModel.setField(this.m_sField);
};

caplinx.alerts.view.controller.NewAlertController.prototype.setInstrument = function(sInstrument) {
	this.m_sInstrumentDescription = sInstrument;
};

caplinx.alerts.view.controller.NewAlertController.prototype.setSubject = function(sSubject) {
	this.m_sSubject = sSubject;
};

caplinx.alerts.view.controller.NewAlertController.prototype.setField = function(sField) {
	this.m_sField = sField;
};

caplinx.alerts.view.controller.NewAlertController.prototype.setContainer = function(oContainer)
{
	this.m_oPresentationModel.setContainer(oContainer);
};

caplinx.alerts.view.controller.NewAlertController.prototype.setComponentXml = function(oXml)
{
	var pFormAttributes = oXml.attributes;
	for(var i = 0; i < pFormAttributes.length; ++i)
	{
		var attr = pFormAttributes[i];
		var sPropertyName = attr.name;
		var sPropertySetter = "set" + sPropertyName.substr(0, 1).toUpperCase() + sPropertyName.substr(1);
		if(typeof this[sPropertySetter] === "function")
		{
			var sPropertyValue = attr.value;
			this[sPropertySetter](sPropertyValue);
		}
	}
};
