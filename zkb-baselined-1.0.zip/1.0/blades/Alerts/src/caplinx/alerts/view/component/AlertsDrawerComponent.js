caplin.namespace("caplinx.alerts.view.component");

caplin.include("caplin.framework.webcentric.ComponentWrapper", true);
caplin.include("caplin.component.ComponentFactory");
caplin.include("caplin.webcentric.presentation.FrameworkItem");
caplin.include("caplinx.alerts.view.component.AlertsDrawerPersistor");

caplinx.alerts.view.component.AlertsDrawerComponent = function(mOptions)
{
	var oModel = mOptions["model"];
	var oState = oModel.selectSingleNode("state");
	var sKey = oState.selectSingleNode("compositeComponent").properties.refId;
	var oAlertsDrawerPersistor = new caplinx.alerts.view.component.AlertsDrawerPersistor(sKey);
	var oPresentation = caplin.webcentric.presentation.FrameworkItem.presentationForModel(oModel);
	var sXml = this._getXml(oAlertsDrawerPersistor, oState);
	var oComponent = caplin.component.ComponentFactory.createComponent(sXml);
	var sCaption = oModel.properties.caption;
	var sPermissionKey = oModel.properties.pkey;
	var oFrameManager = new caplin.framework.webcentric.WebcentricFrameManager();
	
	caplin.framework.webcentric.ComponentWrapper.call(this, oComponent, sCaption, sPermissionKey, oPresentation, oFrameManager);
	
	// replace the set component modified with an empty method -- maybe have been done even more simply by disabling
	// serialization within the composite component, or does this class add anything else?
	this.m_oComponentFrame.setComponentModified = function()
	{
		// do nothing
	};
	
	oAlertsDrawerPersistor.addAsListenerTo(oComponent);
};
caplin.extend(caplinx.alerts.view.component.AlertsDrawerComponent, caplin.framework.webcentric.ComponentWrapper);

caplinx.alerts.view.component.AlertsDrawerComponent.prototype._getXml = function(oAlertsDrawerPersistor, oState)
{
	if(oAlertsDrawerPersistor.getXMLTemplate())
	{
		return oAlertsDrawerPersistor.getXMLTemplate();
	}
	else
	{
		return oState.firstChild().to_xml();
	}
};
