caplin.namespace("caplinx.alerts.view.handler");

caplin.include("caplin.alerts.NotificationService");
caplin.include("caplinx.alerts.view.handler.GridBarButtonHandler", true);

caplinx.alerts.view.handler.DismissButtonHandler = function(oButton)
{
	this.m_oButton = oButton;	
};

caplin.implement(caplinx.alerts.view.handler.DismissButtonHandler, caplinx.alerts.view.handler.GridBarButtonHandler)

caplinx.alerts.view.handler.DismissButtonHandler.prototype.handleGridRowSelection = function(oGridRowModel, pSelectedRows) {
	if(this._isStale(oGridRowModel, pSelectedRows)) {
		this.m_oButton.disable(true);
	} else {
		this.m_oButton.disable(false);
	}
	
};

caplinx.alerts.view.handler.DismissButtonHandler.prototype._isStale = function(oGridRowModel, pSelectedRows) {
	for(var index = 0 ; index < pSelectedRows.length; index++) {
		var nIndex = oGridRowModel.getIndexBySubject(pSelectedRows[index]);
		var oNotificationRow = oGridRowModel.getRowData(nIndex);
		if(oNotificationRow.RECORD_STATUS === SL4B_ObjectStatus.STALE) {
			return true;
		}
	}
	return false;
};

caplinx.alerts.view.handler.DismissButtonHandler.prototype.execute = function(pSelectedRows)
{
	if (pSelectedRows.length > 0) {
		caplin.alerts.NotificationService.dismissNotifications(pSelectedRows);
	}
};
