caplin.namespace("caplinx.alerts.view.component");
 
caplin.include("caplin.component.ComponentFactory", true);
caplin.include("caplinx.alerts.view.component.NotificationsButtonBarComponent");
 
/**
 * @singleton
 */
caplinx.alerts.view.component.NotificationsButtonBarViewGenerator = function()
{
	caplin.notifyAfterClassLoad(this);
};
 
caplinx.alerts.view.component.NotificationsButtonBarViewGenerator.prototype.createFromSerializedState = function (sComponentXML)
{
	var oXml = caplin.core.XmlParser.parse(sComponentXML);
	var pButtons = oXml.getElementsByTagName('button');
    return new caplinx.alerts.view.component.NotificationsButtonBarComponent(pButtons);
};

caplinx.alerts.view.component.NotificationsButtonBarViewGenerator.prototype.onAfterClassLoad = function()
{
	caplin.component.ComponentFactory.registerComponent('gridButtonBar', caplinx.alerts.view.component.NotificationsButtonBarViewGenerator.createFromSerializedState);
};

caplin.singleton("caplinx.alerts.view.component.NotificationsButtonBarViewGenerator");
