caplin.namespace("caplinx.alerts.rowsource");

caplin.include("caplin.grid.rowsource.SortRowSource", true);

caplinx.alerts.rowsource.ActiveAlertsDefaultSortRowSource = function(eXmlConfig, oPreviousRowSource)
{
	caplin.grid.rowsource.SortRowSource.apply(this,arguments);
	caplin.grid.rowsource.SortRowSource.prototype.setSortRule.apply(this, [new caplin.component.sort.FieldSortRule("timeCreated",caplin.component.sort.FieldSortRule.NUMERIC_SORT,caplin.component.sort.FieldSortRule.DESCENDING)]);
};

caplin.extend(caplinx.alerts.rowsource.ActiveAlertsDefaultSortRowSource, caplin.grid.rowsource.SortRowSource);

caplinx.alerts.rowsource.ActiveAlertsDefaultSortRowSource.prototype.setSortRule = function(oSortRule){};

caplinx.alerts.rowsource.ActiveAlertsDefaultSortRowSource.prototype.clearSortRule = function(){};