caplin.namespace("caplinx.alerts.rowsource");

caplin.include("caplin.grid.RowDataUnavailable", true);
caplin.include("caplin.grid.rowsource.RowSource", true);
caplin.include("caplin.alerts.NotificationService", true);
caplin.include("caplin.alerts.NotificationServiceListener", true);

caplinx.alerts.rowsource.NotificationRowSource = function()
{
	this.m_oObservable = new caplin.core.Observable();
	caplin.alerts.NotificationService.addListener(this);
};

caplin.implement(caplinx.alerts.rowsource.NotificationRowSource, caplin.grid.rowsource.RowSource);
caplin.implement(caplinx.alerts.rowsource.NotificationRowSource, caplin.alerts.NotificationServiceListener);


//--------------------------------------------------------------------------------------
//---------------------- caplin.grid.rowsource.RowSource functions ---------------------
//--------------------------------------------------------------------------------------

caplinx.alerts.rowsource.NotificationRowSource.prototype.addRowSourceListener = function(oRowSourceListener)
{
	this.m_oObservable.addObserver(oRowSourceListener);
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.terminateUpdates = function()
{
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.getAllRows = function()
{
	var pNotifications = caplin.alerts.NotificationService.getAllNotifications();
	var pRows = [];
	for(var i = pNotifications.length - 1; i >= 0; --i)
	{
		var mNotification = pNotifications[i];
		pRows.push({id: mNotification.id, data:mNotification});
	}
	return pRows;
};

//--------------------------------------------------------------------------------------------------
//---------------------- caplin.alerts.NotificationServiceListener functions ----------------------
//--------------------------------------------------------------------------------------------------

caplinx.alerts.rowsource.NotificationRowSource.prototype.onNotificationAdded = function(oNotification)
{
	//do stuff to get row data and id
	//trigger row added event
	if (oNotification.source === "Triggered")	
	{
		oNotification.description = caplinx.alerts.AlertFieldNameMap.replaceWithDisplayName(oNotification.subject, oNotification.description);
	}
	
	this.m_oObservable.notifyObservers("rowAdded", [oNotification.id, oNotification, 0]);
	this.m_oObservable.notifyObservers("structureChangeCompleted", []);
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.onNotificationDismissed = function(sId)
{
	this.m_oObservable.notifyObservers("rowUpdated", [sId, {status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_DISMISSED}]);
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.onNotificationRemoved = function(sId)
{
	this.m_oObservable.notifyObservers("rowRemoved", [sId]);
	this.m_oObservable.notifyObservers('structureChangeCompleted', []);
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.onDataUnavailable = function(nReason) {
	var sReason = this._getDataUnavailableMessage(nReason);
	
	this.m_oObservable.notifyObservers("allRowsRemoved", []);
	this.m_oObservable.notifyObservers("structureChangeCompleted", []);
	this.m_oObservable.notifyObservers("dataUnavailable", [sReason]);
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.onDataAvailable = function() {
	var pNotifications = caplin.alerts.NotificationService.getAllNotifications();
	
	if(pNotifications.length === 0) {
		this.m_oObservable.notifyObservers('rowAdded', ["-1", {status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_NEW}, 0]);		
		this.m_oObservable.notifyObservers('rowUpdated', ["-1", {status:caplin.alerts.AlertsConstants.NOTIFICATION_STATUS_DISMISSED}, 0]);		
		this.m_oObservable.notifyObservers('structureChangeCompleted', []);
		this.m_oObservable.notifyObservers('rowRemoved', ["-1"]);		
		this.m_oObservable.notifyObservers('structureChangeCompleted', []);
	} else {
		for(var i = pNotifications.length - 1; i >= 0; --i)	{
			var mNotification = pNotifications[i];
			mNotification.description = caplinx.alerts.AlertFieldNameMap.replaceWithDisplayName(mNotification.subject, mNotification.description);
			this.m_oObservable.notifyObservers("rowAdded", [mNotification.id, mNotification, 0]);
		}
		this.m_oObservable.notifyObservers("structureChangeCompleted", []);
	}
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.onNotificationStale = function(sAlertId)
{
	this.m_oObservable.notifyObservers("rowUpdated", [sAlertId, {RECORD_STATUS:SL4B_ObjectStatus.STALE}]);
};

caplinx.alerts.rowsource.NotificationRowSource.prototype.onNotificationNotStale = function(sAlertId)
{
	this.m_oObservable.notifyObservers("rowUpdated", [sAlertId, {RECORD_STATUS:""}]);
};

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

caplinx.alerts.rowsource.NotificationRowSource.prototype._getDataUnavailableMessage = function(nReason)
{
	if(!this.m_mDataUnavailableMessages)
	{
		this.m_mDataUnavailableMessages = {};
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_FOUND] = caplin.grid.RowDataUnavailable.NOT_FOUND;
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.RTTP_CONTAINER_NOT_PERMISSIONED] = caplin.grid.RowDataUnavailable.NOT_PERMISSIONED;
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.UNKNOWN_ERROR] = caplin.grid.RowDataUnavailable.ERROR;
		this.m_mDataUnavailableMessages[caplin.alerts.AlertsConstants.RTTP_CONTAINER_DELETED] = caplin.grid.RowDataUnavailable.DELETED;
	}
	
	return this.m_mDataUnavailableMessages[nReason];
};
