caplin.namespace("caplinx.trading.fx");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.core.XmlUtility");

caplinx.trading.fx.ErrorMessageFactory = function()
{
	caplin.notifyAfterClassLoad(this);
};

caplinx.trading.fx.ErrorMessageFactory.prototype.onAfterClassLoad = function()
{
	this.m_sStateNameToErrorMessageInfoMap = {
		Error: { title: ct.i18n("cx.trading.fx.error.message.title.error"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.unspecified_error") },
		PermissionDenied: { title: ct.i18n("cx.trading.fx.error.message.title.permission_denied"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.permission_denied") },
		SubmitError: { title: ct.i18n("cx.trading.fx.error.message.title.permission_denied"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.permission_denied") },
		QuoteDenied: { title: ct.i18n("cx.trading.fx.error.message.title.quote_denied"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.quote_denied") },
		DealError: { title: ct.i18n("cx.trading.fx.error.message.title.deal_error"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.deal_error") },
		Withdrawn: { title: ct.i18n("cx.trading.fx.error.message.title.withdrawn"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.quote_withdrawn") },
		Expired: { title: ct.i18n("cx.trading.fx.error.message.title.expired"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.quote_expired") },
		Disconnected: { title: ct.i18n("cx.trading.fx.error.message.title.disconnected"), defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.disconnected") },
		Timeout: { 
			title: ct.i18n("cx.trading.fx.error.message.title.timeout"), 
			defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.unable_to_confirm")
		}
	};
};

caplinx.trading.fx.ErrorMessageFactory.prototype.getTitle = function(sStateName)
{
	var mInfo = this._getErrorMessageInfo(sStateName);
	return mInfo.title;
};

caplinx.trading.fx.ErrorMessageFactory.prototype.getFormattedErrorMessage = function(sStateName, sMessage)
{
	var mInfo = this._getErrorMessageInfo(sStateName);
	if (sMessage === "" || sMessage === null || sMessage === undefined)
	{
		sMessage = mInfo.defaultMessage;
	}
	else
	{
		sMessage = caplin.core.XmlUtility.encodeValue(sMessage).replace(/&apos;/g, "'");
	}
	return sMessage;
};

caplinx.trading.fx.ErrorMessageFactory.prototype._getErrorMessageInfo = function(sStateName)
{
	var mInfo = this.m_sStateNameToErrorMessageInfoMap[sStateName];
	if (mInfo === undefined)
	{
		mInfo = { title: sStateName + ".", defaultMessage: ct.i18n("cx.trading.fx.error.message.defaultmsg.unspecified_error") };
	}
	return mInfo;
};

caplin.singleton("caplinx.trading.fx.ErrorMessageFactory");
