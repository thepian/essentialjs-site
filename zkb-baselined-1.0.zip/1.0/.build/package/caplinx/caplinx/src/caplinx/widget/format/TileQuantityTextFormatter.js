caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.TextFormatter", true);
caplin.include("caplinx.widget.format.QuantityTextFormatter", true);

caplinx.widget.format.TileQuantityTextFormatter = function()
{
	this.m_oQuantityTextFormatter = new caplinx.widget.format.QuantityTextFormatter();
};

caplin.extend(caplinx.widget.format.TileQuantityTextFormatter, caplinx.widget.format.QuantityTextFormatter);

caplinx.widget.format.TileQuantityTextFormatter.prototype.formatText = function(sValue)
{
	if (isFinite(sValue) && sValue !== null && sValue !== "") 
	{
		return this.m_oQuantityTextFormatter.insertCommas(sValue);
	}
	else
	{
		return "NaN";
	}
}

caplinx.widget.format.TileQuantityTextFormatter.prototype.parseUserInput = function(sToConvert)
{
	return this.m_oQuantityTextFormatter.parseUserInput(sToConvert);	
}