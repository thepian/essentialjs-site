caplin.namespace("caplinx.component.form");

/**
 * @class
 * Interface implemented by classes wishing to listen to state events on a {@link caplinx.component.form.StatusBarComponent}.
 * 
 * Overriding any of the methods in this listener interface is optional. Doing so will enable you to react to the related event.
 * 
 * @interface
 */

caplinx.component.form.StatusBarListener = function()
{
};

/**
 * Called when a button is pressed
 * 
 * @param {String} sSymbolicName Second part of the button element name
 * @param {Object} oStatusBar StatusBarComponent instance
 */
caplinx.component.form.StatusBarListener.prototype.onButton = function(sSymbolicName,oStatusBar)
{
	// non-mandatory listener method
};
