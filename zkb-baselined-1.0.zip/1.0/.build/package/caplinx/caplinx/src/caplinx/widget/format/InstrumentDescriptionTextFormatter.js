/**
 * @fileoverview Provides the {@link caplinx.widget.format.InstrumentDescriptionTextFormatter}
 * class which is responsible for converting an instrument description field into a suitable
 * display format.
 */

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.TextFormatter", true);
caplin.include("caplin.widget.format.DateTextFormatter", true);
caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");

/**
 * Constructs a new <code>InstrumentDescriptionTextFormatter</code>.
 * 
 * @class Responsible for converting the date part of a instrument description field to the user's
 * preferred date format, and restricting the coupon rate to 3 decimal places.
 */
caplinx.widget.format.InstrumentDescriptionTextFormatter = function()
{
	/**
	 * Regular expression used to determine whether the description contains a coupon date and date
	 * component (i.e. for bonds) or not.
	 * 
	 * @type RegExp
	 * @private
	 */
	this.m_oBondDescriptionRegExp = new RegExp("^(.*) (\\d+.\\d+) (\\d\\d)/(\\d\\d)/(\\d\\d)$");

	/**
	 * Text formatter that converts a date into the user's preferred format.
	 * 
	 * @type caplin.widget.format.TextFormatter
	 * @private
	 */
	this.m_oDateTextFormatter =  caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory().getTextFormatter("caplin.widget.format.DateTextFormatter");

	/**
	 * Text formatter that converts a coupon rate to 3 decimal places.
	 * 
	 * @type caplin.widget.format.TextFormatter
	 * @private
	 */
	this.m_oDecimalPlaceTextFormatter = caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory().getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "3");
};

caplinx.widget.format.InstrumentDescriptionTextFormatter.prototype = new caplin.widget.format.TextFormatter;

/**
 * Converts a date, if present, in the specified instrument description, to the user's preferred
 * format and also converts a coupon rate to 3 decimal places.
 * 
 * @param {String} sDescription The instrument description to be formatted.
 * @type String
 * @return The formatted instrument description.
 */
caplinx.widget.format.InstrumentDescriptionTextFormatter.prototype.formatText = function(sDescription) {
	var sFormattedDescription;
	var oMatch = sDescription.match(this.m_oBondDescriptionRegExp);
	if (oMatch)
	{
		sFormattedDescription = oMatch[1] + " " + this.m_oDecimalPlaceTextFormatter.formatText(oMatch[2]) + " " + this.m_oDateTextFormatter.formatText("20" + oMatch[5] + oMatch[3] + oMatch[4]);
	}
	else
	{
		sFormattedDescription = sDescription;
	}
	return sFormattedDescription;
};
