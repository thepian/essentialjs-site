caplin.namespace("caplinx.latency");

caplin.include("caplin.core.Utility");

caplinx.latency.LatencyListener = function()
{
	// do nothing
}

caplinx.latency.LatencyListener.prototype.latencyUpdated = function (nNewLatency, nLatency)
{
	caplin.core.Utility.interfaceMethod("LatencyListener", "latencyUpdated");
}