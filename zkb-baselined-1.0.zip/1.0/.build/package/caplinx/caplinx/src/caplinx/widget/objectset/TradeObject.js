caplin.namespace("caplinx.widget.objectset");

caplin.include("caplin.widget.objectset.DataObject", true);
caplin.include("caplin.widget.serialization.Serializer");

caplinx.widget.objectset.TradeObject = function(l_sObjectName, l_oTradeModel)
{
	// call the super constructor
	caplin.widget.objectset.DataObject.apply(this, []);

	this.m_sObjectName = l_sObjectName;
	this.m_oTradeModel = l_oTradeModel;
};

caplin.extend(caplinx.widget.objectset.TradeObject, caplin.widget.objectset.DataObject);

// WARNING. this method will  return null if setTradeModel has not been set.
caplinx.widget.objectset.TradeObject.prototype.getTradeModel = function() {
	return this.m_oTradeModel;
}

// No clean up of any previous trade model is done in this method.
// It makes sure that the link goes in both directions, by calling trading.setTradeObject if necessary.
// Initial state is not copied.
caplinx.widget.objectset.TradeObject.prototype.setTradeModel = function(l_oTradeModel) {
	this.m_oTradeModel = l_oTradeModel;
	if (l_oTradeModel.getTradeObject() != this) {
		l_oTradeModel.setTradeObject(this);
	}
}

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.getClassIdentifier = function()
{
	return "caplinx.widget.objectset.TradeObject";
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.getSerializer = function()
{
	var l_oSerializer = new caplin.widget.serialization.Serializer();
	l_oSerializer.setConstructor("caplinx.widget.objectset.TradeObject", [this.m_sObjectName]);

    // CIT-514, Serialize values for the account and amount
    if (this.isFiSymbol(this.getName()) && (this.getFieldValue("Account")))
        // Set the account at trade level only for fixed income instruments
        l_oSerializer.addMethodCall("deserializeFieldValue", ["Account", this.getFieldValue("Account")]);
    if (this.getFieldValue("L1_Amount"))
        // Set the trading quantity for all instruments
        l_oSerializer.addMethodCall("deserializeFieldValue", ["L1_Amount", this.getFieldValue("L1_Amount")]);
    if (this.getFieldValue("DealtCurrency") != this.getFieldValue("BaseCurrency")) {
        l_oSerializer.addMethodCall("deserializeFieldValue", ["DealtCurrency", this.getFieldValue("DealtCurrency")]);
    }
    return l_oSerializer;
};

caplinx.widget.objectset.TradeObject.prototype.isFiSymbol = function(l_sObjectName)
{
	if(l_sObjectName.indexOf('/FI/') == 0) {
		return true;
	} else {
		return false;
	}
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.getName = function()
{
	return this.m_sObjectName;
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.isContainer = function()
{
	return false;
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.thisRemoved = function()
{
	// do nothing
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.fieldAdded = function()
{
	// do nothing
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.fieldRemoved = function()
{
	// do nothing
};

// documented in DataObject
caplinx.widget.objectset.TradeObject.prototype.activate = function()
{
	// do nothing
};
