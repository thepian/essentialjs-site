caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.TextFormatter");

/**
 * Constructs a new <code>BracketNegativeAmountsTextFormatter</code> that wraps brackets around negative
 * amounts and removes the standard negation dash char.
 */
caplinx.widget.format.BracketNegativeAmountsTextFormatter = function()
{
};
caplin.extend(caplinx.widget.format.BracketNegativeAmountsTextFormatter, caplin.widget.format.TextFormatter);

/**
 * Wraps brackets around a negative amount and removes the standard negative dash char.
 *
 * @param {String} sValue The price to be formatted.
 * @type String
 * @return The formatted price.
 */
caplinx.widget.format.BracketNegativeAmountsTextFormatter.prototype.formatText = function(l_sValue) {
    var l_sResult = l_sValue;
    if (l_sValue) {
        if (!l_sValue.length) l_sValue = l_sValue.toString();
        if (!isNaN(parseInt(l_sValue))) if(l_sValue < 0) l_sResult = '(' + l_sValue.substring(1, l_sValue.length) + ')';
    }
    return l_sResult;
};
