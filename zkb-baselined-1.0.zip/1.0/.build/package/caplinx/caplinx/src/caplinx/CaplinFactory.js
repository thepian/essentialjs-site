caplin.namespace("caplinx");

caplin.include("caplin.framework.ApplicationFactory", true);
caplin.include("caplin.component.AbstractFactory", true);
caplin.include("caplin.dom.AbstractFactory", true);
caplin.include("caplin.framework.AbstractFactory", true);
caplin.include("caplin.grid.AbstractFactory", true);
caplin.include("caplin.renderer.AbstractFactory", true);
caplin.include("caplin.security.AbstractFactory", true);
caplin.include("caplin.services.AbstractFactory", true);
caplin.include("caplin.trading.AbstractFactory", true);
caplin.include("caplin.core.AbstractFactory", true);

caplin.include("caplinx.fields.FieldManager");
caplin.include("caplinx.fields.FieldNames", true);
caplin.include("caplinx.widget.fields.IndicativeFields");
caplin.include("caplinx.trading.ObjectMapper");
caplin.include("caplinx.trading.trademodel.FxTradeFactory", true);
caplin.include("caplinx.permissioning.CaplinPermissionService");
caplin.include("caplinx.utilities.SymbolMapper");

caplin.include("caplin.widget.format.NumberTextFormatter");
caplin.include("caplin.widget.format.StandardFieldValueProcessor");
caplin.include("caplinx.widget.format.BlotterPriceFieldValueProcessor");
caplin.include("caplin.widget.element.renderer.listener.QuantityChangeListener");
caplin.include("caplin.widget.element.renderer.ElementRenderer");
caplin.include("caplin.widget.element.renderer.SpreadElementRenderer");
caplin.include("caplin.widget.element.renderer.MultipleFieldElementRenderer");
caplin.include("caplin.widget.preferences.PreferenceFields");
caplin.include("caplin.widget.format.TextFormatterFactory");

caplin.include("caplin.widget.objectset.grid.ColumnManager");
caplin.include("caplinx.trading.presentation.tile.FxTile");
caplin.include("caplin.widget.containers.WebcentricContainer");

caplin.include("caplin.trading.trademodel.FxTrade");
caplin.include("caplin.trading.trademodel.FxTradeLeg");
caplin.include("caplin.trading.trademodel.SL4BTradeSubscriber", true);
caplin.include("caplin.trading.trademodel.TradeLegFactory");
caplin.include("caplin.trading.trademodel.DataHolder");
caplin.include("caplin.trading.trademodel.TradeChannelMapper", true);
caplin.include("caplin.trading.trademodel.SubjectMapper");
caplin.include("caplin.trading.trademodel.InstrumentDataSubscriber");
caplin.include("caplin.trading.trademodel.SL4BInstrumentDataSubscriber");
caplin.include("caplinx.trading.trademodel.FxTenorProvider");
caplin.include("caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator");

caplin.include("caplin.trading.statemachine.State");
caplin.include("caplin.trading.statemachine.StateModel");
caplin.include("caplin.trading.statemachine.Transition");
caplin.include("caplin.trading.statemachine.StateMachine");
caplin.include("caplin.trading.statemachine.StateMachineFactory", true);
caplin.include("caplin.services.date.BusinessDateProvider");

caplin.include("caplin.services.date.BusinessDateProvider");
caplin.include("caplin.services.CurrencyPairAutoCompleteProvider");
caplin.include("caplin.services.search.CrossCurrencyProvider");

caplin.include("caplinx.trading.presentation.FxTradeTicket");

caplin.include("caplin.dom.alert.WebcentricAlertDispatcher", true);
caplin.include("caplin.renderer.control.ControlFactory", true);
caplin.include("caplin.trading.trademodel.TradeService", true);
caplin.include("caplin.trading.trademodel.TradeFactory", true);
caplin.include("caplin.trading.trademodel.TradeChannelMapper", true);
caplin.include("caplin.core.XmlParser", true);
caplin.include("caplin.trading.statemachine.StateModel", true);

caplin.include("caplin.core.ApplicationProperties", true);
caplin.include("caplin.core.properties.WebcentricServletUserPropertyStore", true);
caplin.include("caplin.core.MapFactory", true);
caplin.include("caplin.dom.alert.StandardAlertDispatcher", true);

caplin.include("caplin.widget.objectset.grid.ColumnInfo");
caplin.include("caplin.widget.preferences.WebcentricPreferencesController");
caplin.include("caplin.core.Exception");
caplin.include("caplin.trading.derivation.TierDerivation");
caplin.include("caplin.trading.derivation.SimpleDerivation");

caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplinx.widget.format.QuantityTextFormatter");

caplinx.CaplinFactory = function()
{
	if (!window.JsTestDriver) {
		if(window.location.search.match("mode=dev") || window.location.search.match("mode=caplin"))
		{
			caplin.services.HTMLResourceService.loadHTMLFiles(["source/html-messages/Messages.html", "html_en.htmlbundle"]);
			caplin.services.XMLResourceService.INSTANCE.loadXMLFiles("resource.xmlbundle");
		}
		else
		{
			caplin.services.HTMLResourceService.loadHTMLFiles(["source/html-messages/Messages.html", "blades/html_en.html"]);
			caplin.services.XMLResourceService.INSTANCE.loadXMLFiles("blades/resource-bundle.xml");
		}
	}
	caplin.fields = {};
	caplin.fields.FieldNames = new caplinx.fields.FieldNames();
	
	//Changes made for PCT-164 - using trademodels from xml bundle
	var eTradeModelNode = caplin.services.XMLResourceService.INSTANCE.getXMLDocument(this.TRADE_MODEL_DEFINITION)[0];
	if(eTradeModelNode) {
		var sTradeModelXml = caplin.stream.helper.Xml.toXml(eTradeModelNode);
		this.m_oStateMachineFactory = new caplin.trading.statemachine.StateMachineFactory();
		this.m_oStateMachineFactory.loadModelsFromXml(sTradeModelXml);
	}
	
	this._createTradeService();
	
	this.m_oFieldManager = null;
	this.m_oColumnManager = null;
	this.m_oPreferencesController = null;
	this.m_oContainer = null;
	this.m_oBusinessDateProvider = null;
	this.m_oCurrencyPairAutoCompleteProvider = null;
	this.m_oCurrencyProvider = null;
};

caplinx.CaplinFactory.prototype.name = "caplinx.CaplinFactory";
caplinx.CaplinFactory.prototype.TRADE_MODEL_DEFINITION = "tradeModels";

caplin.extend(caplinx.CaplinFactory, caplin.framework.ApplicationFactory);
caplin.extend(caplinx.CaplinFactory, caplin.component.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.dom.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.framework.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.grid.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.renderer.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.security.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.services.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.trading.AbstractFactory);
caplin.extend(caplinx.CaplinFactory, caplin.core.AbstractFactory);

caplinx.CaplinFactory.prototype.getFieldManager = function()
{
	if (this.m_oFieldManager === null)
	{
		this.m_oFieldManager = new caplinx.fields.FieldManager();
	}
	return this.m_oFieldManager;
};

/**
 * @see caplin.services.AbstractFactory#getBusinessDateProvider
 */
caplinx.CaplinFactory.prototype.getBusinessDateProvider = function()
{
	if (this.m_oBusinessDateProvider === null)
	{
		this.m_oBusinessDateProvider = new caplin.services.date.BusinessDateProvider("source/services/calendar-service.jsp");
	}
	return this.m_oBusinessDateProvider;
};

/**
 * @see caplin.services.AbstractFactory#getCurrencyPairAutoCompleteProvider
 */
caplinx.CaplinFactory.prototype.getCurrencyPairAutoCompleteProvider = function()
{
	if (this.m_oCurrencyPairAutoCompleteProvider === null)
	{
		var baseProvider = new caplin.services.CurrencyPairAutoCompleteProvider();
		var permissioningService  = this.getPermissionService();
		this.m_oCurrencyPairAutoCompleteProvider = new caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator(baseProvider, permissioningService);
	}
	return this.m_oCurrencyPairAutoCompleteProvider;
};

/**
 * @see caplin.services.AbstractFactory#getCurrencyProvider
 */
caplinx.CaplinFactory.prototype.getCurrencyProvider = function()
{
	if (this.m_oCurrencyProvider === null)
	{
		this.m_oCurrencyProvider = caplin.services.search.CrossCurrencyProvider.createFromConfiguration();
	}
	return this.m_oCurrencyProvider;
};

caplinx.CaplinFactory.prototype.getColumnManager = function()
{
	if (this.m_oColumnManager === null)
	{
		this.m_oColumnManager = new caplin.widget.objectset.grid.ColumnManager();
		var oFieldManager = this.getFieldManager();
		var oBlotterPriceFieldValueProcessor = new caplinx.widget.format.BlotterPriceFieldValueProcessor();
		
		// Blotter columns
		this._addColumnInfo("blotter-fx-trade-id", "ID", 100, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["TradeID"])], ["TradeID"], oFieldManager));
		this._addColumnInfo("currency-pair", "Currency Pair", 90, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["L1_Instrument","L2_Instrument","L3_Instrument"])], ["L1_Instrument","L2_Instrument","L3_Instrument"], oFieldManager));
		this._addColumnInfo("dealt-currency", "Dealt Currency", 90, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["L1_DealtCurrency"])],["L1_DealtCurrency"], oFieldManager));
		this._addColumnInfo("blotter-status", "Status", 90, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["Status"])], ["Status"], oFieldManager));
		this._addColumnInfo("buy-sell", "B/S", 45, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["L1_BuySell","L2_BuySell","L3_BuySell"])], ["L1_BuySell","L2_BuySell","L3_BuySell"], oFieldManager));
		this._addColumnInfo("blotter-amount", "Amount", 90, new caplin.widget.element.renderer.ElementRenderer([this._createBlotterAmountFieldValueProcessor(["L1_Amount","L2_Amount","L3_Amount"])], ["L1_Amount","L2_Amount","L3_Amount"], oFieldManager));
		this._addColumnInfo("blotter-rate", "Rate", 70, new caplin.widget.element.renderer.ElementRenderer([oBlotterPriceFieldValueProcessor], ["L1_Price","L2_Price","L3_Price","BlotterType"], oFieldManager));
		this._addColumnInfo("settlement-date", "S/D", 80, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["L1_SettlementDate","L2_SettlementDate","L3_SettlementDate"])], ["L1_SettlementDate","L2_SettlementDate","L3_SettlementDate"], oFieldManager));
		this._addColumnInfo("account", "Account", 140, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["Account"])], ["Account"], oFieldManager));
		this._addColumnInfo("trade-date", "T/D", 80, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["TradeDate"])], ["TradeDate"], oFieldManager));
		this._addColumnInfo("time-stamp", "Time", 60, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["TimeStamp"])], ["TimeStamp"], oFieldManager));
		this._addColumnInfo("user-id", "User ID", 120, new caplin.widget.element.renderer.ElementRenderer([this._createFieldValueProcessor(["UserName"])], ["UserName"], oFieldManager));
		
		// multiple field columns
		this._addColumnInfo("rate", "Rate", 115, new caplin.widget.element.renderer.SpreadElementRenderer([
			this._createFieldValueProcessor([caplinx.widget.fields.IndicativeFields.BEST_BID]),
			this._createFieldValueProcessor([caplinx.widget.fields.IndicativeFields.BEST_ASK])], 
			[caplinx.widget.fields.IndicativeFields.BEST_BID, caplinx.widget.fields.IndicativeFields.BEST_ASK, "ratePrcsn", "PricingType"], 
			oFieldManager, "/", false), true);
	}
	return this.m_oColumnManager;
};

caplinx.CaplinFactory.prototype._addColumnInfo = function(sIdentifier, sDisplayName, nWidth, oElementRenderer, bWriteUniqueClassName)
{
	bWriteUniqueClassName = bWriteUniqueClassName || false;

	var oColumnInfo = new caplin.widget.objectset.grid.ColumnInfo(sIdentifier, sDisplayName, oElementRenderer, bWriteUniqueClassName);
	oColumnInfo.setWidth(nWidth);
	
	this.m_oColumnManager.addColumnInfo(oColumnInfo);
};

caplinx.CaplinFactory.prototype._createFieldValueProcessor = function(pFieldNames)
{
	return new caplin.widget.format.StandardFieldValueProcessor(this.getFieldManager().getField(pFieldNames[0]).getTextFormatter());
};

caplinx.CaplinFactory.prototype._createBlotterAmountFieldValueProcessor = function(pFieldNames)
{
	var oQuantityTextFormatter = this.getTextFormatterFactory().getTextFormatter("caplin.widget.format.NumberTextFormatter");
	return new caplin.widget.format.StandardFieldValueProcessor(oQuantityTextFormatter);
};

caplinx.CaplinFactory.prototype.getPreferencesController = function()
{
	if (this.m_oPreferencesController === null)
	{
		// TODO: do this properly via configuration from the Application Server
		this.m_oPreferencesController = new caplin.widget.preferences.WebcentricPreferencesController();
		
		// set the default FX amount
		this.m_oPreferencesController.getModel().setPreference(caplin.widget.preferences.PreferenceFields.INITIAL_AMOUNT_PREFIX + "FX", 1000000);
	}
	return this.m_oPreferencesController;
};

caplinx.CaplinFactory.prototype.getTradeModel = function(nextId, leg1IndicativeRTTPObjectName, sTradingProtocol)
{
	return new caplinx.trading.state.TradeModel(nextId, leg1IndicativeRTTPObjectName, sTradingProtocol);
	
};

caplinx.CaplinFactory.prototype.getStateMachine = function(sProtocol)
{
	return this.m_oStateMachineFactory.getStateMachine(sProtocol);
};

caplinx.CaplinFactory.prototype.getTextFormatterFactory = function()
{
	if (! this.m_textFormatterFactory ) {
		this.m_textFormatterFactory = new caplin.widget.format.TextFormatterFactory();
		// Formatter fields.
		this.m_textFormatterFactory.setAlias(caplin.widget.format.TextFormatterFactory.DEFAULT_PRICE_FORMATTER, "caplin.widget.format.DecimalPlaceTextFormatter","3,true", "");
		this.m_textFormatterFactory.setAlias(caplin.widget.format.TextFormatterFactory.DEFAULT_QUANTITY_FORMATTER,"caplinx.widget.format.QuantityTextFormatter" );
	}
	
	return this.m_textFormatterFactory; 
};

/**
 * @see caplin.trading.AbstractFactory#createTile
 */
caplinx.CaplinFactory.prototype.createTile = function(oTilePersistenceModel, oTileView)
{
	return new caplinx.trading.presentation.tile.FxTile(oTilePersistenceModel, oTileView);
};

caplinx.CaplinFactory.prototype.createFXTrade = function(sTradingProtocol, sInstrumentName)
{
	var mTradeFields = {
			AssetClass: "FX",
			TradingProtocol: sTradingProtocol,
			InstrumentName: sInstrumentName
	};
	return this.m_oTradeService.createNewTrade(mTradeFields);
};

caplinx.CaplinFactory.prototype.createBondsTrade = function(sInstrumentName)
{
	var mTradeFields = {
			AssetClass: "FI",
			InstrumentName: sInstrumentName
	};
	return this.m_oTradeService.createNewTrade(mTradeFields);
};

caplinx.CaplinFactory.prototype.getTradeService = function()
{
	return this.m_oTradeService;
};

caplinx.CaplinFactory.prototype._createTradeService = function()
{
	this.m_oTradeService = new caplin.trading.trademodel.TradeService();

	this.m_oFxSl4bTradeSubscriber = new caplin.trading.trademodel.SL4BTradeSubscriber(
			this.getTradeChannelMapper("/FT/TRADE/FX"), this.m_oTradeService);
	var oFxTradeFactory = new caplinx.trading.trademodel.FxTradeFactory(this.m_oFxSl4bTradeSubscriber);
	var mFxMatchCriteria = {"AssetClass": "FX"}; 

	this.m_oFiSl4bTradeSubscriber = new caplin.trading.trademodel.SL4BTradeSubscriber(
			this.getTradeChannelMapper("/FT/TRADE/FI"), this.m_oTradeService);
	var oFiTradeFactory = new caplinx.trading.trademodel.FiTradeFactory(this.m_oFiSl4bTradeSubscriber);

	this.m_oTradeService.registerTradeFactory(mFxMatchCriteria, oFxTradeFactory);
};

caplinx.CaplinFactory.prototype.createLeg = function(sAssetClass, oTrade, nLegId)
{	
	if(sAssetClass === "FX")
	{
		var oBDS = this.getBusinessDateProvider();
		var oSubjectMapper = new caplin.trading.trademodel.SubjectMapper();
		var oInstrumentSubscriber = new caplin.trading.trademodel.SL4BInstrumentDataSubscriber(oSubjectMapper);
		var oTenorProvider = new caplinx.trading.trademodel.FxTenorProvider();
		var oLeg =  new caplin.trading.trademodel.FxTradeLeg(oTrade, nLegId, oBDS, oTenorProvider);
			
		if(oTrade.getTradingProtocol() == "ESP")
		{
			oLeg.setInstrumentDataSubscriber(oInstrumentSubscriber);
		}
	}
	else
	{
		throw new caplin.core.Exception("Unknown asset class: " + sAssetClass);	
	}
	return oLeg;
};

caplinx.CaplinFactory.prototype.getTradeChannelMapper = function(sChannel)
{
	var oTradeChannelMapper = new caplin.trading.trademodel.TradeChannelMapper();
	oTradeChannelMapper.getChannel = function() {
		return sChannel;
	};
	oTradeChannelMapper.getObjectList = function() {
		return sChannel;
	};
	return oTradeChannelMapper;
};	

caplinx.CaplinFactory.prototype.getIndicativeFields = function()
{
	return caplinx.widget.fields.IndicativeFields; 
};

caplinx.CaplinFactory.prototype.getObjectMapper = function()
{
	if (!this.m_oObjectMapper)
	{
		this.m_oObjectMapper = new caplinx.trading.ObjectMapper();
	}
	return this.m_oObjectMapper;
};

caplinx.CaplinFactory.prototype.getIndicativeTradeSubscriber = function()
{
	return new caplin.trading.TradeLegFieldSubscriber(); 
};

caplinx.CaplinFactory.prototype.getFiAccounts = function()
{
	return new Ext.data.SimpleStore({
		"fields": ["value", "label"],
		"data" : [
			["CUSTOMER1_BRONZE", "BRONZE"],
			["CUSTOMER1_EUR_COVERED", "EUR_COVERED"],
			["CUSTOMER1_GOLD", "GOLD"],
			["CUSTOMER1_SILVER", "SILVER"],
			["CUSTOMER1_PROP_TRAD", "PROP_TRAD"]
		]
	});
};

/**
 * Get a reference to the UI container object.
 * 
 * @return {caplin.widget.containers.Container}
 * 		An interface onto the UI container object.
 */
caplinx.CaplinFactory.prototype.getContainer = function()
{
	if (this.m_oContainer === null)
	{
		// By default we will use the webcentric container. However if this is not used by default
		// other application factories which inherit from this will need to implement the getContainer
		// method and return their specific container which may be the webcentric container.
		this.m_oContainer = new caplin.widget.containers.WebcentricContainer();
	}
	return this.m_oContainer;
};

/**
 * A bit of a hack to allow client teams to open their own tickets as of course they don't have caplinx defined
 * 
 * @param {Object} oElementRenderer
 */
caplinx.CaplinFactory.prototype.openTradeTicket = function(oElementRenderer)
{
	var sSide;
	switch (oElementRenderer.m_pFields[0])
	{
		case "BestBid":
		case "BidPrice":
			sSide = "Bid";
		break;
		case "BestAsk":
		case "AskPrice":	
			sSide = "Ask";
		break;
	}
	caplinx.widget.tradeticket.TradeTicketCreator.getInstance().openTicket(oElementRenderer.m_sSubject, sSide, "RFS");
};

caplinx.CaplinFactory.prototype.getSymbolMapper = function()
{
	if (!this.m_oSymbolMapper)
	{
		this.m_oSymbolMapper = new caplinx.utilities.SymbolMapper();
	}
	return this.m_oSymbolMapper;
};

/**
 * A bit of a hack to allow client teams to open their own tickets as of course they don't have caplinx defined
 * 
 * @param {Object} oElementRenderer
 */
caplinx.CaplinFactory.prototype.openTradeTicketV4 = function(oElementRenderer, sSide)
{
	var pTrades = this.getTradeService().getTrades();
	if(false)
	{
		caplinx.widget.tradeticket.TradeTicketCreator.getInstance().openTicketFromTrade(pTrades[0]);
	}
	else
	{
		caplinx.widget.tradeticket.TradeTicketCreator.getInstance().openTicket(oElementRenderer.getSubject(), sSide, "RFS");
	}
};


caplinx.CaplinFactory.prototype.openTradeTicketFromTrade = function(oTrade)
{
		caplinx.widget.tradeticket.TradeTicketCreator.getInstance().openTicketFromTrade(oTrade);
};

/**
 * 
 * @param {String} sSubject
 * @param {String} sSide
 * @param {String} sProtocol
 */
caplinx.CaplinFactory.prototype.launchFxTradeTicket = function(sSubject, sSide, sProtocol)
{
	caplinx.widget.tradeticket.TradeTicketCreator.getInstance().openTicket(sSubject, sSide, sProtocol);
};


/**
 * Returns the standard caplin <code>ControlFactory</code> for creating the <code>Control</code>s
 * that will be used by the renderer library.
 */
caplinx.CaplinFactory.prototype.getControlFactory = function()
{
	return new caplin.renderer.control.ControlFactory();
};

/**
 * Returns the caplinx permissioning service.
 */
caplinx.CaplinFactory.prototype.getPermissionService = function()
{
	return caplinx.permissioning.CaplinPermissionService;
};

/**
 * @see caplin.dom.AbstractFactory#getAlertDispatcher
 */
caplinx.CaplinFactory.prototype.getAlertDispatcher = function()
{
	if(!this.m_oAlertDispatcher)
	{
		this.m_oAlertDispatcher = new caplin.dom.alert.WebcentricAlertDispatcher();
	}
	return this.m_oAlertDispatcher;
};

/**
 * @see caplin.core.AbstractFactory#getUserPropertyStore
 */
caplinx.CaplinFactory.prototype.getUserPropertyStore = function()
{
	if(!this.m_oUserPropertyStore)
	{
		this.m_oUserPropertyStore = new caplin.core.properties.WebcentricServletUserPropertyStore();
	}
	return this.m_oUserPropertyStore;
};

caplinx.CaplinFactory.onAfterClassLoad = function()
{
	caplin.framework.ApplicationFactory.INSTANCE = new caplinx.CaplinFactory();

	caplin.component.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.dom.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.framework.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.grid.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.renderer.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.security.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.services.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.trading.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
	caplin.core.AbstractFactory.setInstance(caplin.framework.ApplicationFactory.INSTANCE);
};
caplin.notifyAfterClassLoad(caplinx.CaplinFactory);
