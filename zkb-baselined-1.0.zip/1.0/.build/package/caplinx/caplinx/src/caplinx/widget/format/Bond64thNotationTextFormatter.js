caplin.namespace("caplinx.widget.format");

caplin.include("caplinx.widget.format.Bond32ndNotationTextFormatter", true);

/**
 * Converts the specified price to the equivalent value in the bond (32nd) notation format. If a
 * number is specified that does not map directly to a bond notation value, it will be formatted as
 * a decimal to 3 decimal places, whilst if a non number is specified, then the value will be
 * returned without any formatting.
 * 
 * <p>The bond notation format follows these rules:</p>
 * <table>
 * <tr> <th>Display</th> <th>Notes</th>                                                                        </tr>
 * <tr> <td>-</td>       <td>Indicator of a negative value, if the value is positive this will be omitted</td> </tr>
 * <tr> <td>number</td>  <td>The whole number (e.g. <b>10</b> for the number 10.5)</td>                        </tr>
 * <tr> <td>-</td>       <td>Separator character between whole number and 32nd value</td>                      </tr>
 * <tr> <td>number</td>  <td>The number of 32nds (e.g. <b>16</b> for the number 10.5)</td>                     </tr>
 * <tr> <td>+</td>       <td>Indicator whether an extra 64th should be added to the value or not</td>          </tr>
 * </table>
 * 
 * <p>Examples:</p>
 * <table>
 * <tr> <th>Decimal Price</th> <th>Bond Notation Price</th> </tr>
 * <tr> <td>10</td>            <td>10-00</td>               </tr>
 * <tr> <td>10.015625</td>     <td>10-00+</td>              </tr>
 * <tr> <td>10.25</td>         <td>10-08</td>               </tr>
 * <tr> <td>10.5</td>          <td>10-16</td>               </tr>
 * <tr> <td>10.984375</td>     <td>10-31+</td>              </tr>
 * </table>
 * 
 * @param {String} sValue The price to be formatted.
 * @type String
 * @return The formatted price.
 */
caplinx.widget.format.Bond64thNotationTextFormatter = function() {};

caplin.extend(caplinx.widget.format.Bond64thNotationTextFormatter, caplinx.widget.format.Bond32ndNotationTextFormatter);

caplinx.widget.format.Bond64thNotationTextFormatter.prototype.getTrailingSymbol = function (n32ndsLeftover) {
	switch (n32ndsLeftover) {
		case 0: return this.m_sNonBreakingSpace;
		case 0.5: return this.m_s64thIndicator;
		default: return null;
	}
}