/**
 * @fileoverview
 * Defines caplinx.historicdata.MarketOverviewSettingsController class.
 */

caplin.namespace("caplinx.historicdata");

caplin.include("caplin.component.composite.CompositeComponentController", true);
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplin.component.form.SimpleFormListener", true);
caplin.include("caplin.core.DateExpressionParser");
caplin.include("caplin.core.Exception");
caplin.include("caplin.dom.Utility");
caplin.include("caplin.component.form.SimpleFormComponent");

/**
 * Constructs a new <code>MarketOverviewSettingsController</code>.
 * @class
 * 
 * @param {caplin.component.form.SimpleFormComponent} oComponent The form component that this controller will
 * 			manipulate and add functionality to.
 * 
 * <p>The purpose of this class is to control the market overview chart settings panel. The settings panel contains the following components</p>
 * 
 * <ul>
 * 	<li>A ComboBox ed to select a currency. The combobox is populated with hard-coded values</li>
 * 	<li>A Refresh button. When it is clicked a &quot;currencyChanged&quot; event is published over the OpenAjax hub with the currency that is
 * selected in the ComboBox.</li>
 * 	<li>A Hide button. When clicked, it results in the settings panel being hidden.</li>
 * <ul>
 * 
 * <p>For more information on the OpenAjax hub see the
 * <a href="http://www.openajax.org/member/wiki/OpenAjax_Hub_1.0_Specification>OpenAjax hub 1.0 specification</a></p>
 * 
 * @implements caplin.component.form.SimpleFormListener
 */
caplinx.historicdata.MarketOverviewSettingsController = function(oComponent)
{
	if((oComponent instanceof caplin.component.form.SimpleFormComponent) === false)
	{
		throw new caplin.core.Exception("oComponent must be an instance of caplin.component.form.SimpleFormComponent",
				"caplinx.historicdata.MarketOverviewSettingsController");
	}
	
	/** @private */
	this.m_oRefreshButton = null;
	/** @private */
	this.m_oHideButton = null;
	/**@private*/
	this.m_oComboBox = null;
	/** @private */
	this.m_oComponent = oComponent;
	/** @private */
	this.m_nHideButtonListenerId = null;
	/**@private*/
	this.m_nRefreshButtonListenerId = null;
	/** @private */
	this.m_bParsedComponentsHaveBeenSetup = false;
	
	this.m_oComponent.addListener(this);
	
	if( this.m_oComponent.formComponentsHaveBeenParsed() === true )
	{
		this._setupParsedComponents( this.m_oComponent.getFormComponents() );
	}
};
caplin.implement(caplinx.historicdata.MarketOverviewSettingsController, caplin.component.form.SimpleFormListener);

/*******************************************************************************
 *      caplin.component.composite.CompositeComponentController Interface
 *******************************************************************************/

/**
 * Informs the instance that it should clean up.
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype.finalize = function()
{
	this.m_oHideButton.removeOnClickListener( this.m_nHideButtonListenerId );
	this.m_oRefreshButton.removeOnClickListener( this.m_nRefreshButtonListenerId );
};

/*******************************************************************************
 *             caplin.component.form.SimpleFormListener Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.form.SimpleFormListener#onComponentsParsed
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype.onComponentsParsed = function(mParsedComponents)
{
	this._setupParsedComponents(mParsedComponents);
};

/**
 * @private
 * @see caplin.component.form.SimpleFormListener#onHide
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype.onHide = function()
{
	this.m_oComboBox.collapse();
	this.m_oComboBox.purgeListeners();
};

/**
 * @private
 * @see caplin.component.form.SimpleFormListener#onOpen
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype.onOpen = function(nWidth, nHeight)
{
	this.m_oComboBox.setSize({width:164, height:20});
};


/*******************************************************************************
 *             					Private Methods
 *******************************************************************************/

/**
 * @private
 * @param {Map} mParsedComponents A collection of visual widgets such as buttons that are to be placed on this
 * settings panel. These visual widgets are defined in the simple form for this settings panel.
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype._setupParsedComponents = function(mParsedComponents)
{
	if (this.m_bParsedComponentsHaveBeenSetup === false) 
	{
		this.m_oHideButton = mParsedComponents.Hide;
		this.m_nHideButtonListenerId = this.m_oHideButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onHide"));
		
		this.m_oRefreshButton = mParsedComponents.Refresh;
		this.m_nRefreshButtonListenerId = this.m_oRefreshButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onRefresh"));
		
		this.m_oComboBox = mParsedComponents.ComboBox;
		var oDataStore = this.m_oComboBox.getStore();
		oDataStore.loadData([["USD (US Dollar)"],["CHF (Swiss Franc)"],["EUR (Euro)"],["GBP (Sterling)"],["JPY (Yen)"],["SEK (Swedish Krona)"]], true);
		this.m_oComboBox.setValue("USD (US Dollar)");
		this.m_oComboBox.on("select", this._comboBoxValueSelected, this);
		
		this.m_bParsedComponentsHaveBeenSetup = true;
	}
};

/** @private */
caplinx.historicdata.MarketOverviewSettingsController.prototype._comboBoxValueSelected = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined) {
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.MarketOverviewSettingsController");
	}
	else
	{
		var sCurrency = this.m_oComboBox.getValue()[0];
		OpenAjax.hub.publish("settingsPanel." + sChannelId + ".currencyChanged", {
			"currency": sCurrency
		});
	}	
};

/**
 * This function is executed when a user clicks on the Hide button of the Settings Panel.
 * The effect is that an open ajax toggleSettingsPanel event is raised.
 * @private
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype._onHide = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined)
	{
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.MarketOverviewSettingsController");
	}
	else
	{
		OpenAjax.hub.publish("settings." + sChannelId + ".toggleSettingsPanel");
	}	
};

/**
 * This function is executed when a user clicks on the Refresh button of the Settings panel.
 * The effect is that an open ajax currencyChanged event is raised to indicate that a new set of
 * data should be requested for the selected currency.
 * @private
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype._onRefresh = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined) {
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.MarketOverviewSettingsController");
	}
	else
	{
		var sCurrency = this.m_oComboBox.getValue();
		OpenAjax.hub.publish("settingsPanel." + sChannelId + ".currencyChanged", {
			"currency": sCurrency
		});
	}
};

/**
 * @private
 * Used when publishing events over the OpenAjax hub.
 */
caplinx.historicdata.MarketOverviewSettingsController.prototype._getCurrentChannelId = function()
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oComponent );
	return sChannel;
};
