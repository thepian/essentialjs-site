caplin.namespace("caplinx.renderer.handler");

caplin.include("caplin.renderer.handler.Handler", true);
caplin.include("caplin.core.StringUtility", true);
caplin.include("caplinx.utilities.NumericRangeMatcher", true);
caplin.include("caplin.grid.GridColumnFilter");

caplinx.renderer.handler.RangeFilterHandler = function()
{
	this.m_oMatcher = new caplinx.utilities.NumericRangeMatcher();
};
caplin.implement(caplinx.renderer.handler.RangeFilterHandler, caplin.renderer.handler.Handler);

/**
 * {@see caplin.renderer.handler.Handler#onChange}
 */
caplinx.renderer.handler.RangeFilterHandler.prototype.onChange = function(sNewValue, oControlRenderer)
{
	if(this.applyFilterIfValidRequest(sNewValue, oControlRenderer) === false)
	{
		oControlRenderer.onError("caplinx.renderer.handler.RangeFilterHandler", "You have entered an incorrect data format for this filter.");
		oControlRenderer.onInvalidChange();
	}
};

caplinx.renderer.handler.RangeFilterHandler.prototype.applyFilterIfValidRequest = function(sNewValue, oControlRenderer)
{
	var oColumn = oControlRenderer.getFieldModel();
	var vMatches;
	
	if(vMatches = this.m_oMatcher.getRangeMatch(sNewValue))
	{
		var nLowValue = parseFloat(vMatches[0]);
		var nHighValue = parseFloat(vMatches[1]);
		if (nLowValue > nHighValue)
		{
			oControlRenderer.onError("caplinx.renderer.handler.RangeFilterHandler", "You have entered a invalid range. The first value must be lower than the second value. "+ nLowValue +" is greater than " + nHighValue);
		}
		else
		{
			var sField = oColumn.getFieldNames()[0];
			oColumn.clearFilters();
			oColumn.setFilters(
				new caplin.grid.GridColumnFilter(sField, caplin.grid.GridColumnFilter.LESS_THAN_OR_EQUAL, nHighValue ),
				new caplin.grid.GridColumnFilter(sField, caplin.grid.GridColumnFilter.GREATER_THAN_OR_EQUAL, nLowValue )
				);	
		}
	}
	else if(sMatch = this.m_oMatcher.getGreaterThanMatch(sNewValue))
	{
		this.clearFiltersAndApplyNewFilter(caplin.grid.GridColumnFilter.GREATER_THAN, sMatch, oColumn)
	}
	else if(sMatch = this.m_oMatcher.getGreaterThanOrEqualMatch(sNewValue))
	{
		this.clearFiltersAndApplyNewFilter(caplin.grid.GridColumnFilter.GREATER_THAN_OR_EQUAL, sMatch, oColumn)
	}
	else if(sMatch = this.m_oMatcher.getLessThanMatch(sNewValue))
	{
		this.clearFiltersAndApplyNewFilter(caplin.grid.GridColumnFilter.LESS_THAN, sMatch, oColumn)
	}
	else if(sMatch = this.m_oMatcher.getLessThanOrEqualMatch(sNewValue))
	{
		this.clearFiltersAndApplyNewFilter(caplin.grid.GridColumnFilter.LESS_THAN_OR_EQUAL, sMatch, oColumn)
	}
	else if(sMatch = this.m_oMatcher.getEqualToMatch(sNewValue))
	{
		this.clearFiltersAndApplyNewFilter(caplin.grid.GridColumnFilter.NUMERIC_MATCH, sMatch, oColumn)
	}
	else if(caplin.core.StringUtility.stripWhitespace(sNewValue) === "")
	{
		oColumn.clearFilters();
	}
	else
	{
		return false;
	}
};

caplinx.renderer.handler.RangeFilterHandler.prototype.clearFiltersAndApplyNewFilter = function(nGridColumnFilterType, sMatch, oColumn)
{
	oColumn.clearFilters();
	oColumn.addFilter(nGridColumnFilterType, sMatch);
};

caplin.singleton("caplinx.renderer.handler.RangeFilterHandler");
