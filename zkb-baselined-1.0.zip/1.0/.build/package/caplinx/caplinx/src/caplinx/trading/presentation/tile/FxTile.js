caplin.namespace("caplinx.trading.presentation.tile");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplin.trading.presentation.tile.Tile", true);
caplin.include("caplinx.trading.presentation.tile.FxTileStatus", true);
caplin.include("caplin.dom.AbstractFactory");
caplin.include("caplin.services.AbstractFactory");
caplin.include("caplin.widget.formcontrols.ImageButton");
caplin.include("caplin.widget.element.renderer.ElementRenderer");
caplin.include("caplin.widget.element.IdentifierFactory");
caplin.include("caplin.dom.controls.form.FlexibleButton");
caplin.include("caplinx.trading.presentation.tile.FxTileController");
caplin.include("caplinx.widget.element.renderer.listener.FXQuantityChangeListener");
caplin.include("caplinx.widget.element.renderer.FxTileTextBoxElementRenderer");
caplin.include("caplinx.widget.tradeticket.TradeTicketCreator");
caplin.include("caplinx.trading.presentation.listeners.FxFieldListener");
caplin.include("caplinx.trading.presentation.listeners.FxTileInstrumentListener");
caplin.include("caplinx.trading.presentation.listeners.FxTileAmountListener");
caplin.include("caplinx.trading.presentation.listeners.FxTileSettlementDateListener");
caplin.include("caplinx.trading.presentation.listeners.FxTileMaxTierLimitExceededListener");
caplin.include("caplinx.trading.presentation.listeners.FxTileMaxTierLimitListener");
caplin.include("caplin.widget.trading.TradingProtocols");
caplin.include("caplinx.trading.presentation.listeners.FxTileDealtCurrencyListener");
caplin.include("caplinx.trading.fx.ErrorMessageFactory");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplin.element.formatter.DateFormatter");
caplin.include("caplinx.widget.format.TileQuantityTextFormatter");
caplin.include("caplinx.trading.presentation.tile.FxTilePriceButton");
caplin.include("caplinx.trading.presentation.tile.FxTileCurrencyPairChooser");
caplin.include("caplinx.trading.presentation.tile.FxTileRenderer");
caplin.include("caplinx.trading.presentation.tile.PermissionModel");
caplin.include("caplinx.permissioning.CaplinPermissionService");
caplin.include("caplin.core.Exception");
caplin.include("caplin.widget.element.ElementFactory");
caplin.include("caplin.widget.format.StandardFieldValueProcessor");
caplin.include("caplinx.widget.format.QuantityTextFormatter");
caplin.include("caplinx.widget.format.FxPipPriceFieldValueProcessor");

caplin.include("caplinx.tobo.TOBOUserManagerListener", true);
caplin.include("caplinx.tobo.TOBOUserManager");

caplinx.trading.presentation.tile.FxTile = function()
{
	
};
caplin.implement(caplinx.trading.presentation.tile.FxTile, caplin.trading.presentation.tile.Tile);
caplin.implement(caplinx.trading.presentation.tile.FxTile, caplinx.tobo.TOBOUserManagerListener);

/**
 * @see caplin.trading.presentation.tile.Tile#initialize
 */
caplinx.trading.presentation.tile.FxTile.prototype.initialize = function(oTileView, oTilePersistenceModel)
{

	this.m_oTilePersistenceModel = oTilePersistenceModel;
	this.m_sObjectName = this.m_oTilePersistenceModel.getInstrument();
	this.m_oController = new caplinx.trading.presentation.tile.FxTileController(this);
	this.m_sObjectName = this.m_sObjectName.replace(/</g,"&lt;").replace(/>/g,"&gt;");
	this.m_sInstrumentName = this.m_sObjectName.split("/")[2];
	
	this.m_sAccount = null;
	this.m_oFactory = caplin.framework.ApplicationFactory.getInstance();
	this._createTradeAndSetupLeg();
	
	this.m_oTileView = oTileView;
	this.m_oAutoCompleteProvider = caplin.services.AbstractFactory.getInstance().getCurrencyPairAutoCompleteProvider();
	this.m_oAutoCompleteBox = null;
	this.m_nId = caplin.widget.element.IdentifierFactory.getIdentifier();
	
	this.m_sMaxTierLimit = 0;
	
	/* HTML Element used to render the FX tile */
	this.m_oFxTileElement = null;
	/* Factory for the element renderers */
	this.m_oFieldManager = this.m_oFactory.getFieldManager();
	
	//user action renderers
	this.m_oAskButton = null;
	this.m_oBidButton = null;
	this.m_oDealtCurrencyButton = null;
	
	//display fields renderers
	this.m_oAmountTextField = null;
	
	this.m_nTileTradableListenerID;
	// The member below is for indicating whether or not RFS trading is permitted
	// i.e. can the user click the RFS button?
	this.m_nTicketTradableListenerID;
	
	this.m_oPermissionModel = new caplinx.trading.presentation.tile.PermissionModel(this.m_oController);
	this.m_oPermissionModel.setInstrumentName(this.m_sInstrumentName);
	
	//field values
	this.m_pListenerAndFields = [];
	
	var oTextFormatterFactory = this.m_oFactory.getTextFormatterFactory();
	this.m_oAmountTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "0, true");
	this.m_oQuantityTextFormatter = oTextFormatterFactory.getTextFormatter("caplinx.widget.format.TileQuantityTextFormatter");
	
	this.m_eStatusIconContainerElement = null;
	this.m_eStatusMessageElement = null;
	this.m_oAlertDispatcher = caplin.dom.AbstractFactory.getInstance().getAlertDispatcher();
	
	this.m_bIsButtonsEnabled = false;
	
	if (!this.m_oAutoCompleteProvider.isValidCurrencyPair(this.m_sInstrumentName)) 
	{
		this.m_oPermissionModel.onViewPermissionsChanged(false);
	}
};


caplinx.trading.presentation.tile.FxTile.prototype.getCurrentPermission = function(){
	return this.m_oPermissionModel.getCurrentPermission();
}

caplinx.trading.presentation.tile.FxTile.prototype.stateChanged = function(oState, sEventName, oStateValues)
{
	var sStateName = oState.getName();
	
	switch (sStateName)
	{
		case "Timeout":
			this.timeout();
			caplinx.tobo.TOBOUserManager.tradeFinished();
			break;
		case "OpenSent":
			caplinx.tobo.TOBOUserManager.tradeStarted();
		case "Opened":
			break;
		case "TradeConfirmed":
		case "TradePassed":
		case "TradeExpired":
			this._handleFinalTradeState(sStateName, oStateValues);
			this._reset();
			caplinx.tobo.TOBOUserManager.tradeFinished();
			break;
		default:
			caplinx.tobo.TOBOUserManager.tradeFinished();
			throw new caplin.core.Exception("Invalid trade state:" + sStateName);
	}
};

//This method is used as a hook for performance tests so don't change the method name.
caplinx.trading.presentation.tile.FxTile.prototype._handleFinalTradeState = function(sStateName, oStateValues) {
	switch (sStateName)
	{
		case "TradeConfirmed":
			if(oStateValues.get('TOBOUser'))
			{
				this.m_oAlertDispatcher.alert(
						"FX Tile TOBO - Trade Confirmed " + oStateValues.get('BuySell'),
						this._getAlertOptions(sStateName, oStateValues));
			}
			else
			{
				this.m_oAlertDispatcher.alert(
						"FX Tile - Trade Confirmed " + oStateValues.get('BuySell'),
						this._getAlertOptions(sStateName, oStateValues));
			}
			break;
		case "TradePassed":
			this.m_oAlertDispatcher.alert(
				"FX Tile - Trade Passed ",
				this._getAlertOptions(sStateName, oStateValues));
			break;
		case "TradeExpired":
			this.m_oAlertDispatcher.alert(
				"FX Tile - Trade Expired ",
				this._getAlertOptions(sStateName, oStateValues));
			break;
	}
};

caplinx.trading.presentation.tile.FxTile.prototype.timeout = function()
{
	var sTimeoutMessageHtml = ct.i18n("cx.trading.presentation.fx.tile.contact_support")+ " <span style=\"font-weight: bold\">" + this.m_oFxTrade.getRequestID() + "</span>";
	
	this.m_oController.setError(ct.i18n("cx.trading.presentation.fx.tile.unable_to_confirm"), sTimeoutMessageHtml);
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.FxTile.prototype.render = function(oContainer, oWidgets){
	
	this.m_oFxTileRenderer = new caplinx.trading.presentation.tile.FxTileRenderer(this.m_nId);
	this.m_oFxTileElement = this.m_oFxTileRenderer.render();
		
	document.body.appendChild(this.m_oFxTileElement);
	this.m_oFxTileElement.style.display = "block";

	this._bind(oWidgets, this.m_nId);
	oContainer.appendChild(this.m_oFxTileElement);
		
	this._setupListenersAndInitialValues();
	this._updateDealtCurrency(this.m_oLeg.getDealtCurrency());
	caplinx.tobo.TOBOUserManager.addObserver(this);
	
	// set initial user input state - enable/disable user input based on account selection and permissions
	this.m_oController.updateTileState();
}


caplinx.trading.presentation.tile.FxTile.prototype.onTOBOAccountChanged = function(sAccount){
	var bHasAccount = (sAccount != "" && sAccount != null);
	this.m_oPermissionModel._changePermissionValue(bHasAccount, caplinx.trading.presentation.tile.PermissionModel.ACCOUNT_SELECTED);
	this.m_sAccount = sAccount;
	this.m_oFxTrade.setAccount(sAccount);
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.FxTile.prototype.setAccount = function(){
	//do nothing -remove this method when account drop-down is removed from trade panel header
};

caplinx.trading.presentation.tile.FxTile.prototype.onTOBOUserChanged = function(sUser){
	this.m_oFxTrade.setUserTradedOnBehalfOf(sUser);
	this.m_sUserTradedOnBehalfOf = sUser;
}

//
// The following unimplemented interface methods fix issues in IE
// 
caplinx.trading.presentation.tile.FxTile.prototype.onTOBOUserListChanged = function(pUserList)
{
	//Optional interface method
};
caplinx.trading.presentation.tile.FxTile.prototype.onTOBOUserTypeChanged = function(pUserList)
{
	//Optional interface method
};
caplinx.trading.presentation.tile.FxTile.prototype.onTOBOAccountListChanged = function(pUserList)
{
	//Optional interface method
};
caplinx.trading.presentation.tile.FxTile.prototype.onLockChanged = function()
{
	//Optional interface method
};

caplinx.trading.presentation.tile.FxTile.prototype.showError = function(sTitle, sErrorHtml)
{
	this.m_oFxTileRenderer.showError(sTitle, sErrorHtml);
};

caplinx.trading.presentation.tile.FxTile.prototype.maxTierLimitHandler = function(oValue)
{
	var bOverTierLimit = this.m_oFxTrade.getLeg(0).m_oData.get("MaxTierLimitExceeded") == "true";
	this.m_oAskButton.setButtonRFS(bOverTierLimit);
	this.m_oBidButton.setButtonRFS(bOverTierLimit);

	this.m_oController.updateTileState();
};


caplinx.trading.presentation.tile.FxTile.prototype.settlementDateEventHandler = function()
{
	// AS & IA - PCTD-366 - this fixes the issue with settlement date latency
	this.m_bSettlementDateSet = true;
};

caplinx.trading.presentation.tile.FxTile.prototype.dealtCurrencyEventHandler = function(oValue)
{
	if (oValue) 
	{
		this.m_oTilePersistenceModel.setDealtCurrency(oValue);
		this._updateDealtCurrency(oValue);
		this.m_oController.updateTileState();
	}
};

caplinx.trading.presentation.tile.FxTile.prototype.amountEventHandler = function(sValue, sOldValue)
{
	
	if (sValue !== undefined && sValue != sOldValue) 
	{
		this.m_oTilePersistenceModel.setAmount(sValue);
		if (this.m_oAmountRenderer) 
		{
			this.m_oAmountRenderer.updateElement(this);
		}
	}
};



caplinx.trading.presentation.tile.FxTile.prototype.getMaxTierLimit = function()
{
	return this.m_oLeg.getMaxTierLimit();
};

caplinx.trading.presentation.tile.FxTile.prototype.getSerializedState = function()
{
	return this.m_oTilePersistenceModel.getSerializedState();
};

caplinx.trading.presentation.tile.FxTile.prototype.getId = function()
{
	return this.m_nId;
};

caplinx.trading.presentation.tile.FxTile.prototype.suspend = function()
{
	this.m_oFxTrade.suspend();
};

caplinx.trading.presentation.tile.FxTile.prototype.resume = function()
{
	this.m_oFxTrade.resume();
};

caplinx.trading.presentation.tile.FxTile.prototype.close = function()
{
	this.m_oFxTrade.stop();
	this.removeAllDataFieldChangedListener();
	this.m_oAutoCompleteProvider = null;
	this.m_oAutoCompleteBox = null;
	this.m_oFieldManager = null;	
	this.m_pListenerAndFields = null;
	this.m_oAmountTextFormatter = null;
	this.m_oQuantityTextFormatter = null;
	this.m_eStatusIconContainerElement = null;
	this.m_eStatusMessageElement = null;
	this.m_oAlertDispatcher = null;
	
	this.m_oAskButton.finalize();
	this.m_oBidButton.finalize();
	
};

caplinx.trading.presentation.tile.FxTile.prototype.getFieldValue = function(sFieldName)
{
	return this.m_oLeg.getFieldValue(sFieldName);
};

caplinx.trading.presentation.tile.FxTile.prototype.tierLimitExceededHandler = function(oValue)
{
	var bNotBelowMaxTierLimit = oValue !== false && oValue !== "false";
	// enable buttons (ie. make tradable) if and only if below tier limit
	this.m_oAskButton.setButtonRFS(bNotBelowMaxTierLimit);
	this.m_oBidButton.setButtonRFS(bNotBelowMaxTierLimit);
	this.m_oController.updateTileState();
};


caplinx.trading.presentation.tile.FxTile.prototype.addDataFieldsChangedListener = function(oListener, l_pFieldIds)
{
	for (var i = 0; i < l_pFieldIds.length; i++) 
	{
		this._addDataFieldChangedListener(oListener, l_pFieldIds[i]);
	}
};

caplinx.trading.presentation.tile.FxTile.prototype.removeAllDataFieldChangedListener = function()
{
	for (var i = 0; i < this.m_pListenerAndFields.length; i++) 
	{
		this.m_oLeg.removeDataFieldChangedListener(this.m_pListenerAndFields[i].Listener, this.m_pListenerAndFields[i].Field);
	}
};

caplinx.trading.presentation.tile.FxTile.prototype.applyAllDataFieldChangedListener = function()
{
	for (var i = 0; i < this.m_pListenerAndFields.length; i++) 
	{
		this.m_oLeg.addDataFieldChangedListener(this.m_pListenerAndFields[i].Listener, this.m_pListenerAndFields[i].Field, true);
	}
};

caplinx.trading.presentation.tile.FxTile.prototype.setAmount = function(nOldValue, nValue)
{
	this.m_oLeg.setAmount(nValue);
};

caplinx.trading.presentation.tile.FxTile.prototype.openTradeTicket = function(oFxTile, sSide, bDealerIntervention)
{
	return function() {
		if(caplinx.tobo.TOBOUserManager.canPerformTrade())
		{
		var amount = oFxTile.m_oLeg.getAmount();
		var creator = caplinx.widget.tradeticket.TradeTicketCreator.getInstance();
		creator.openTicket("/FX/"+oFxTile.m_sInstrumentName, sSide, caplin.widget.trading.TradingProtocols.REQUEST_FOR_STREAM, 
				amount, oFxTile.m_oLeg.getDealtCurrency(), oFxTile.m_sAccount, bDealerIntervention);
		}
	};
};

caplinx.trading.presentation.tile.FxTile.prototype._addDataFieldChangedListener = function(oListener, sFieldId)
{
	this.m_oLeg.addDataFieldChangedListener(oListener, sFieldId, true);
	this.m_pListenerAndFields.push({
		'Listener': oListener,
		'Field': sFieldId
	});
};

caplinx.trading.presentation.tile.FxTile.prototype._reset = function()
{
	this.m_oController.setTradeInProgress(false);
	this._resetWithNewTrade(this.m_oFxTrade.getLeg(0).getDealtCurrency());
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.FxTile.prototype._resetWithNewTrade = function(sOldDealtCurrency)
{
	this._removeListeners();
	this.removeAllDataFieldChangedListener();
	this.m_oFxTrade.stop();
	this._createTradeAndSetupLeg();
	this._setupListenersAndInitialValues(sOldDealtCurrency);
	this.applyAllDataFieldChangedListener();
	this.m_oPermissionModel.setInstrumentName(this.m_sInstrumentName);
};

caplinx.trading.presentation.tile.FxTile.prototype._createTradeAndSetupLeg = function()
{
	this.m_oFxTrade = this.m_oFactory.createFXTrade("ESP", this.m_sInstrumentName);
	this.m_oFxTrade.setAccount(this.m_sAccount);
	this.m_oFxTrade.setUserTradedOnBehalfOf(this.m_sUserTradedOnBehalfOf);
	
	this.m_oLeg = this.m_oFxTrade.getLeg(0);
	this.m_bSettlementDateSet = false;
	this.m_oLeg.setTenor("SPOT");
};

caplinx.trading.presentation.tile.FxTile.prototype._$getTrade = function()
{
	return this.m_oFxTrade;
};

caplinx.trading.presentation.tile.FxTile.prototype._setupListenersAndInitialValues = function(sOldDealtCurrency)
{
	
	var sDealtCurrency = (sOldDealtCurrency) ? sOldDealtCurrency : this.m_oTilePersistenceModel.getDealtCurrency();
	this._loadSavedData(sDealtCurrency);
	
	this.m_oFxTrade.addStateChangedListener(this);
	this.m_oController.registerListeners();
	
	this.m_oAmountListener = new caplinx.trading.presentation.listeners.FxTileAmountListener(this);
	this.m_oLeg.addDataFieldChangedListener(this.m_oAmountListener, "Amount", true);
	
	this.m_oDealtCurrencyListener = new caplinx.trading.presentation.listeners.FxTileDealtCurrencyListener(this);
	this.m_oLeg.addDataFieldChangedListener(this.m_oDealtCurrencyListener, "DealtCurrency");
	
	this.m_oSettlementDateListener = new caplinx.trading.presentation.listeners.FxTileSettlementDateListener(this);
	this.m_oLeg.addDataFieldChangedListener(this.m_oSettlementDateListener, "SettlementDate");
	
	this.m_oTierLimitListener = new caplinx.trading.presentation.listeners.FxTileMaxTierLimitListener(this);
	this.m_oLeg.addDataFieldChangedListener(this.m_oTierLimitListener, "L1_MaxTierLimit");
	
	this.m_oTierLimitExceededListener = new caplinx.trading.presentation.listeners.FxTileMaxTierLimitExceededListener(this);
	this.m_oLeg.addDataFieldChangedListener(this.m_oTierLimitExceededListener, "MaxTierLimitExceded", true);

	this.m_oSmallPipFormatListener = new caplinx.trading.presentation.listeners.FxFieldListener(this, this.showSmallPipUpdated);
	this.m_oLeg.addDataFieldChangedListener(this.m_oSmallPipFormatListener, "SmallPip", true);
};

caplinx.trading.presentation.tile.FxTile.prototype._removeListeners = function()
{
	this.m_oFxTrade.removeStateChangedListener(this);
	this.m_oController.unregisterListeners();
	
	this.m_oLeg.removeDataFieldChangedListener(this.m_oAmountListener, "Amount");
	this.m_oLeg.removeDataFieldChangedListener(this.m_oDealtCurrencyListener, "DealtCurrency");
	this.m_oLeg.removeDataFieldChangedListener(this.m_oSettlementDateListener, "SettlementDate");
	this.m_oLeg.removeDataFieldChangedListener(this.m_oTierLimitListener, "MaxTierLimit");
	this.m_oLeg.removeDataFieldChangedListener(this.m_oTierLimitExceededListener, "MaxTierLimitExceded");

	this.m_oLeg.removeDataFieldChangedListener(this.m_oSmallPipFormatListener, "SmallPip");
};

caplinx.trading.presentation.tile.FxTile.prototype.showSmallPipUpdated = function(sValue)
{
	//this.m_oBidValueRenderer.setSmallPipToBeShown(sValue === 'true');
	this.m_oBidButton.setSmallPipToBeShown(sValue === 'true');
};

caplinx.trading.presentation.tile.FxTile.prototype._loadSavedData = function(sDealtCurrency)
{
	this.m_oTilePersistenceModel.getAmount() ? this.m_oLeg.setAmount(this.m_oTilePersistenceModel.getAmount()) : null;
	sDealtCurrency = sDealtCurrency ? sDealtCurrency : this.m_oTilePersistenceModel.getDealtCurrency();
	
	sDealtCurrency ? this.m_oLeg.setDealtCurrency(sDealtCurrency) : null;
};

/*
 * ******************** The following methods relate to the rendering of the Trade Tile *******************************
 */
caplinx.trading.presentation.tile.FxTile.prototype.enableRFSButton = function(sToolTipMessage)
{
	this.m_oRfsLaunchButton.setEnabled(true);
	this.m_oRfsLaunchButton.setTooltip(sToolTipMessage);
};

caplinx.trading.presentation.tile.FxTile.prototype.disableRFSButton = function(sToolTipMessage)
{
	this.m_oRfsLaunchButton.setEnabled(false);
	this.m_oRfsLaunchButton.setTooltip("");
};

caplinx.trading.presentation.tile.FxTile.prototype._enableDealtCurrencyButton = function(sToolTipMessage)
{
	this.m_oDealtCurrencyButton.setEnabled(true);
	this.m_oDealtCurrencyButton.setTooltip(sToolTipMessage);
};

caplinx.trading.presentation.tile.FxTile.prototype.setStatusMessage = function(sStatusType, sMessage)
{
	if (this.m_eStatusIconContainerElement === null)
	{
		this.m_eStatusIconContainerElement = this.m_oFxTileElement.firstChild.childNodes[3].firstChild;
	}
	
	if (this.m_eStatusIconContainerElement !== null)
	{
		this.m_eStatusIconContainerElement.className = sStatusType;
	} 
	
	if (this.m_eStatusMessageElement === null) 
	{
		this.m_eStatusMessageElement = this.m_oFxTileElement.firstChild.childNodes[3].childNodes[2].firstChild;
	}
	
	if (this.m_eStatusMessageElement !== null)
	{
		this.m_eStatusMessageElement.nodeValue = sMessage;
	}
};

caplinx.trading.presentation.tile.FxTile.prototype.setFxTileLayout = function(sFxTileLayout)
{
	this.m_oFxTileElement.firstChild.className = this.m_oFxTileElement.firstChild.className.replace(/fxtile-(\w.*)/, "fxtile-" + sFxTileLayout);
};

caplinx.trading.presentation.tile.FxTile.prototype.enableButtons = function()
{
	this.m_bIsButtonsEnabled = true;
	this.m_oAskButton.setEnabled(true);
	this.m_oBidButton.setEnabled(true);
	this.m_oAmountTextField.setDisabled(false);
	this.m_oAmountTextField.m_oTextBox.className = this.m_oAmountTextField.m_oTextBox.className.replace(' fxTradeQtyTextBoxDisabled', '');
	this._enableDealtCurrencyButton(caplinx.trading.presentation.tile.FxTileController.MESSAGE.SWITCH_CURRENCIES);
	this._setOneClickButtonLabelsAndToolTips();
};

caplinx.trading.presentation.tile.FxTile.prototype.disableButtons = function(sToolTipMessage)
{
	this.m_bIsButtonsEnabled = false;
	this._setOneClickButtonLabelsAndToolTips();
	this.m_oAskButton.setEnabled(false);
	this.m_oBidButton.setEnabled(false);
	this.m_oAskButton.setTooltip("");
	this.m_oBidButton.setTooltip("");
	this.m_oAskButton.setDisabledAlertMsg(sToolTipMessage);
	this.m_oBidButton.setDisabledAlertMsg(sToolTipMessage);
	this.m_oAmountTextField.setDisabled(true);
	if (!this.m_oAmountTextField.m_oTextBox.className.match('fxTradeQtyTextBoxDisabled')) 
	{
		this.m_oAmountTextField.m_oTextBox.className += ' fxTradeQtyTextBoxDisabled';
	}
	this.m_oDealtCurrencyButton.setEnabled(false);
	this.m_oDealtCurrencyButton.setTooltip(sToolTipMessage);
};

/**
 * Sets the message to be shown when clicking on the disabled trade buttons
 * @param {String} sMessage The message to be shown.
 */
caplinx.trading.presentation.tile.FxTile.prototype.setDisabledAlertMessage = function(sMessage)
{
	this.m_oAskButton.setDisabledAlertMsg(sMessage);
	this.m_oBidButton.setDisabledAlertMsg(sMessage);
}


caplinx.trading.presentation.tile.FxTile.prototype._$isTileRendered = function()
{
	return (this.m_oFxTileElement !== null);
};

/*
 * ******************** (END) The above methods relate to the rendering of the Trade Tile (END) *******************************
 */
/*
 * Toggles the currency which the traded quantity refers to and will be traded.
 * @private
 */
caplinx.trading.presentation.tile.FxTile.prototype._updateDealtCurrency = function(sDealtCurrency)
{
	this.m_oDealtCurrencyButton.updateElements({
		contents: sDealtCurrency
	});
};

/*
 * This method sets the labels and tooltips for the one click ESP trade buttons.
 * This is a helper method and should only be called by this._enableOneClickUI()
 * @private
 */
caplinx.trading.presentation.tile.FxTile.prototype._setOneClickButtonLabelsAndToolTips = function()
{
	if (this.m_oLeg.getDealtCurrency() == this.m_oLeg.getBaseCurrency()) 
	{
		this._changeButtonLabel(ct.i18n("cx.trading.presentation.fx.tile.sell_label"), ct.i18n("cx.trading.presentation.fx.tile.buy_label"));
		this._changeButtonToolTip(ct.i18n("cx.trading.presentation.fx.tile.sell_label"), ct.i18n("cx.trading.presentation.fx.tile.buy_label"));
	}
	else 
	{
		this._changeButtonLabel(ct.i18n("cx.trading.presentation.fx.tile.buy_label"), ct.i18n("cx.trading.presentation.fx.tile.sell_label"));
		this._changeButtonToolTip(ct.i18n("cx.trading.presentation.fx.tile.buy_label"), ct.i18n("cx.trading.presentation.fx.tile.sell_label"));
	}
};

/*
 * This methods sets the mouse-over tooltip.
 * @Private
 */
caplinx.trading.presentation.tile.FxTile.prototype._changeButtonToolTip = function(sFirstToolTip, sSecondToolTip)
{
	this.m_oBidButton.setTooltip(ct.i18n("cx.trading.presentation.fx.tile.tooltip") + " " + sFirstToolTip);
	this.m_oAskButton.setTooltip(ct.i18n("cx.trading.presentation.fx.tile.tooltip") + " " + sSecondToolTip);
};


/*
 * This method sets the text on a button that indicates whether clicking the button performs a bid/buy or a ask/sell.
 * @Private
 */
caplinx.trading.presentation.tile.FxTile.prototype._changeButtonLabel = function(sFirstToolTip, sSecondToolTip)
{
	this.m_oBidButton.updateElements({
		sellbuy: sFirstToolTip
	});
	this.m_oAskButton.updateElements({
		sellbuy: sSecondToolTip
	});
};

/*
 * Closure to be executed, when the user clicks the "toggle dealt currency" button.
 * @private
 * @type function closure
 */
caplinx.trading.presentation.tile.FxTile.prototype._onDealtCurrencyClick = function(self)
{
	return function() {
		
		self.m_oLeg.toggleDealtCurrency();
		self._setOneClickButtonLabelsAndToolTips();
	};
};

/*
 * @return Closure to be executed, when the user click the bid or ask button.
 * @private
 * @type function closure
 */
caplinx.trading.presentation.tile.FxTile.prototype._onButtonClick = function(sSide, oFxTile)
{
	return function() {
		oFxTile._doQuickTrade(sSide);
	};
};

// This method is used as a hook for performance tests so don't change the method name.
caplinx.trading.presentation.tile.FxTile.prototype._doQuickTrade = function(sSide) {
	if (parseFloat(this.m_oFxTrade.getLeg(0).getAmount(), 10) > parseFloat(this.m_oFxTrade.getLeg(0).m_oData.get("L1_MaxTierLimit"), 10))
	{
		this.openTradeTicket(this, sSide === 'Bid' ? 'SELL' : 'BUY')();
	}
	else if (this.m_oFxTrade.isEventAllowed("Open") && !this.m_oAmountTextField.m_bIsError && this.hadPriceBeenReceived(sSide)) 
	{
		if(this.m_sAccount == null || this.m_sAccount == "")
		{
			this.m_oAlertDispatcher.alert("<center>" + ct.i18n("cx.trading.presentation.fx.tile.select_amount")+ "</center>");
			return;
		}
		else if(!this['m_sLastDisplayedBest' + sSide])
		{
			this.m_oAlertDispatcher.alert("<center>" + ct.i18n("cx.trading.presentation.fx.tile.not_initialized") + "</center>");
			return;
		}
		
		this.m_oController.setTradeInProgress(true);
		this.m_oController.updateTileState();
		this._executeTrade(sSide, this['m_sLastDisplayedBest' + sSide]);
	}
	else if (!this.m_oFxTrade.isEventAllowed("Open") && this.m_oPermissionModel.m_bTicketTradingPermissioned) 
	{
		this.openTradeTicket(this, sSide === 'Bid' ? 'SELL' : 'BUY')();
	}
}

caplinx.trading.presentation.tile.FxTile.prototype.hadPriceBeenReceived = function(sSide)
{
	return (this['m_sLastDisplayedBest' + sSide] !== undefined);
};

caplinx.trading.presentation.tile.FxTile.prototype._traceLatency = function(){	
	var nNow = (new Date()).valueOf();
	
	var oTraceData = {
		"TRACE-ExecuteButtonPressed" : nNow + "",
		"TRACE-NumberOfOutstandingMessageBatches" : "???"
	}
	if(SL4B_Accessor && SL4B_Accessor.getStatistics && SL4B_Accessor.getStatistics().getResponseQueueStatistics)
	{
		var oStatistics = SL4B_Accessor.getStatistics().getResponseQueueStatistics();
		var nOutstanding = oStatistics.getQueuedBatchCount() + "";
		oTraceData["TRACE-NumberOfOutstandingMessageBatches"] = nOutstanding 
	}
	this.m_oLeg.appendTraceData(oTraceData);
};

caplinx.trading.presentation.tile.FxTile.prototype._executeTrade = function(sSide, sLastDisplayedPrice)
{
    if (sLastDisplayedPrice === undefined || sLastDisplayedPrice === null || sLastDisplayedPrice === "")
	{
       return;
	}
    
	this.m_oLeg.setTradedPrice(sLastDisplayedPrice);
	this.m_oLeg.setSide(sSide);
	this._traceLatency();
	
	try 
	{
		this.m_oFxTrade.processClientEvent("Open");
	} 
	catch (e) 
	{
		caplinx.tobo.TOBOUserManager.tradeFinished();
		caplin.core.Logger.log(caplin.core.LogLevel.CRITICAL, 'Inside FxTile.prototype._executeTrade ' + e.message);
	}
};

caplinx.trading.presentation.tile.FxTile.prototype._clearPrices = function(bClearDisplay){
	this.m_sBidPriceId = undefined;
	this.m_sAskPriceId = undefined;
	this.m_sLastDisplayedBestBid = undefined;
	this.m_sLastDisplayedBestAsk = undefined;

	if (bClearDisplay == true) {
		this.m_oBidButton.clear();
		this.m_oAskButton.clear();
	}	
	
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.FxTile.prototype._renderRFSLaunchButton = function(eHolder, self)
{
	var eButtonContents = document.createElement("div");
	eButtonContents.className = "small-button-label";
	this.m_oRfsLaunchButton = new caplin.dom.controls.form.FlexibleButton(eButtonContents, 26, 16, [], eHolder);
	this.m_oRfsLaunchButton.setUpdatableElements({
		contents: eButtonContents
	});
	this.m_oRfsLaunchButton.addOnClickListener(this.openTradeTicket(this, 'BUY'));
	this.m_oRfsLaunchButton.create();
	this.m_oRfsLaunchButton.setEnabled(true);
	this.m_oRfsLaunchButton.updateElements({
		contents: ct.i18n("cx.trading.presentation.fx.tile.rfs")
	});
};

caplinx.trading.presentation.tile.FxTile.prototype._bind = function(oWidgets, sTileElementLookupIdPrefix)
{
	var oElem = document.getElementById(sTileElementLookupIdPrefix + "_settlementDate");
	this._renderSettlementDate(oElem);
	oElem = document.getElementById(sTileElementLookupIdPrefix + "_rfsButton");
	this._renderRFSLaunchButton(oElem, this);
	
	this.m_oBidButton = new caplinx.trading.presentation.tile.FxTilePriceButton(this, 'Bid', sTileElementLookupIdPrefix);
	this.m_oAskButton = new caplinx.trading.presentation.tile.FxTilePriceButton(this, 'Ask', sTileElementLookupIdPrefix);
	
	oElem = document.getElementById(sTileElementLookupIdPrefix + "_closeButton");
	
	if (oWidgets === undefined) 
	{
		oElem.appendChild(this._getCloseButtonElement(this));
	}
	else 
	{
		// The container may pass in the close button (TempTilesView)
		// Should be refactored to add a close listener
		oElem.appendChild(oWidgets.CLOSE_BUTTON);
	}
	
	this._buildTierElement(sTileElementLookupIdPrefix);
	//this._createTileAutoComplete(sTileElementLookupIdPrefix, this);
	this.m_oAutoCompleteBox = new caplinx.trading.presentation.tile.FxTileCurrencyPairChooser(sTileElementLookupIdPrefix, this);
	
	this._buildMainAmountElement(sTileElementLookupIdPrefix);
	this._buildDealtCurrencySwitch(sTileElementLookupIdPrefix);
};

caplinx.trading.presentation.tile.FxTile.prototype._buildDealtCurrencySwitch = function(sTileElementLookupIdPrefix)
{
	var oElem = document.getElementById(sTileElementLookupIdPrefix + "_dealtCurrency");
	
	var eButtonContents = document.createElement("div");
	eButtonContents.className = "small-button-label";
	this.m_oDealtCurrencyButton = new caplin.dom.controls.form.FlexibleButton(eButtonContents, 26, 16, [], oElem);
	this.m_oDealtCurrencyButton.setUpdatableElements({
		contents: eButtonContents
	});
	this.m_oDealtCurrencyButton.addOnClickListener(this._onDealtCurrencyClick(this));
	this.m_oDealtCurrencyButton.create();
};

caplinx.trading.presentation.tile.FxTile.prototype._buildMainAmountElement = function(sTileElementLookupIdPrefix)
{
	var oElem = document.getElementById(sTileElementLookupIdPrefix + "_tradeQty");
	var oTextFormatterFactory = this.m_oFactory.getTextFormatterFactory();
	var oQuantityTextFormatter = oTextFormatterFactory.getQuantityFormatter("true, 4, true");
	var oQuantityProcessor = new caplin.widget.format.StandardFieldValueProcessor(this.m_oQuantityTextFormatter);
	var oChangeListener = new caplinx.widget.element.renderer.listener.FXQuantityChangeListener("Amount", true, this);
	this.m_oAmountRenderer = new caplinx.widget.element.renderer.FxTileTextBoxElementRenderer([oQuantityProcessor], ["Amount"], this.m_oFieldManager, oChangeListener, "fxTradeQtyTextBox", this);
	this.m_oAmountTextField = this.m_oAmountRenderer.createElement(this, oElem);
};

caplinx.trading.presentation.tile.FxTile.prototype._buildTierElement = function(sTileElementLookupIdPrefix)
{
	this.m_oTierLimitElement = document.getElementById(sTileElementLookupIdPrefix + "_tierLimit");
	oQuantityTextFormatter = new caplinx.widget.format.QuantityTextFormatter(true, 2);
	//oQuantityTextFormatter.setShorten(true);
	var oQuantityProcessor = new caplin.widget.format.StandardFieldValueProcessor(oQuantityTextFormatter);
	this.m_oTierLimitRenderer = new caplin.widget.element.renderer.ElementRenderer([oQuantityProcessor], ["MaxTierLimit"], this.m_oFieldManager);
	this.m_oTierLimitRenderer.setDataModel(this, "Tier");
	this.m_oTierLimitRenderer.createElement(this, this.m_oTierLimitElement);
};

caplinx.trading.presentation.tile.FxTile.prototype._resetCurrency = function()
{
	this.m_oAutoCompleteBox.setValue(this.m_sInstrumentName);
	//this.m_eCurrencyLabel.innerHTML = this.m_sInstrumentName;
};

caplinx.trading.presentation.tile.FxTile.prototype._setCurrency = function(sName)
{
	var pObjectName = this.m_sObjectName.split("/");
	pObjectName[2] = sName;
	this.m_sObjectName = pObjectName.join("/");
	this.m_oTilePersistenceModel.setInstrument(this.m_sObjectName);
	
	this.m_sInstrumentName = sName;
	this._resetWithNewTrade(sName.slice(0, 3));
	this.dealtCurrencyEventHandler(this.m_oLeg.getDealtCurrency());
};

caplinx.trading.presentation.tile.FxTile.prototype._renderSettlementDate = function(eHolder)
{
	var date = this.m_oLeg.getSettlementDate();
	var mFormatParams = { inputFormat:"Ymd", outputFormat: "localize" };
	eHolder.innerHTML = caplin.element.formatter.DateFormatter.format(date, mFormatParams);
	var oListener = {};
	oListener.dataFieldChanged = function(l_sSettlementDate) {		
		eHolder.innerHTML = caplin.element.formatter.DateFormatter.format(l_sSettlementDate, mFormatParams);
	};
	this._addDataFieldChangedListener(oListener, "SettlementDate");
};

caplinx.trading.presentation.tile.FxTile.prototype._getCloseButtonElement = function(self)
{
	var obtnClose = new caplin.widget.formcontrols.ImageButton("tile-close", caplin.widget.formcontrols.ImageButton.BUTTONTYPE_JPG);
	obtnClose.setTooltip("Close");
	obtnClose.addOnClickListener(self.close);
	var obtnCloseElem = obtnClose.getElement();
	return obtnCloseElem;
};

caplinx.trading.presentation.tile.FxTile.prototype._getAlertOptions = function(sStateName, oDataHolderWrapper)
{
	var mFormatParams = { inputFormat:"Ymd", outputFormat: "localize" };
	var sDealtCurrency = oDataHolderWrapper.get('L1_DealtCurrency');
	return {
		'BuySell':oDataHolderWrapper.get('BuySell').toLowerCase(),
		'DealtCurrency': sDealtCurrency,
		'Price': oDataHolderWrapper.get('L1_Price'),
		'Amount': this.m_oAmountTextFormatter.formatText(oDataHolderWrapper.get('L1_Amount')),
		'NotDealtCurrency': oNotDealtCurrency = oDataHolderWrapper.get('L1_Instrument').replace('/FX/', '').replace(sDealtCurrency,''),
		'ValueDate': caplin.element.formatter.DateFormatter.format(oDataHolderWrapper.get('L1_SettlementDate'), mFormatParams),
		'SubmittedFor': oDataHolderWrapper.get('TOBOUser'),
		'Account': oDataHolderWrapper.get('Account')
	};

};

