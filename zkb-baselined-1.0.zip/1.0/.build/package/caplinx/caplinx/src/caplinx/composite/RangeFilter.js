caplin.namespace("caplinx.composite");

caplin.include("caplin.component.filter.LogicalFilterExpression");
caplin.include("caplin.component.filter.FieldFilterExpression");

caplinx.composite.RangeFilter = function(sFieldName, sFirstValue, sOperator, sSecondValue)
{
	this.m_oFilterExpression = null;
	
	if(sOperator === "-")
	{
		this.m_oFilterExpression = new caplin.component.filter.LogicalFilterExpression(caplin.component.filter.LogicalFilterExpression.Operator.AND);
		this.m_oFilterExpression.addFilterExpression(new caplin.component.filter.FieldFilterExpression(sFieldName, caplin.component.filter.FieldFilterExpression.Operator.GREATER_THAN_OR_EQUAL, sFirstValue));
		this.m_oFilterExpression.addFilterExpression(new caplin.component.filter.FieldFilterExpression(sFieldName, caplin.component.filter.FieldFilterExpression.Operator.LESS_THAN_OR_EQUAL, sSecondValue));
	}
	else
	{
		this.m_oFilterExpression = new caplin.component.filter.FieldFilterExpression(sFieldName, caplin.component.filter.FieldFilterExpression.Operator.GREATER_THAN_OR_EQUAL, sFirstValue);
		
	}
};

caplinx.composite.RangeFilter.prototype.getFilterExpression = function()
{
	return this.m_oFilterExpression;
};