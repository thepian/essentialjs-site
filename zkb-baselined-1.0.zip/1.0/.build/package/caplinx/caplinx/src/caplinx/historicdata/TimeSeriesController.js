caplin.namespace("caplinx.historicdata");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.component.composite.CompositeComponentController", true);
caplin.include("caplin.component.form.SimpleFormListener", true);
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplin.chart.menu.ContextMenu");
caplin.include("caplin.chart.TableFormatter");
caplin.include("caplin.core.Utility");
caplin.include("caplin.chart.HTMLTableGenerator");

/**
 * Constructs a new <code>caplinx.historicdata.TimeSeriesController</code>.
 * @constructor
 * @class
 * @implements caplin.component.composite.CompositeComponentController
 */
caplinx.historicdata.TimeSeriesController = function()
{
	/** @private */
	this.m_mComponents = null;
	/** @private */
	this.m_oCompositeComponent = null;
	/** @private */
	this.m_pOpenAjaxSubscriptionHelpers = [];
	/**
	 * @private
	 * @type caplin.chart.menu.HDCContextMenu
	 * Object used to display a context menu
	 */
	this.m_oContextMenu = this._getContextMenu();
};
caplin.implement(caplinx.historicdata.TimeSeriesController, caplin.component.composite.CompositeComponentController);
caplin.implement(caplinx.historicdata.TimeSeriesController, caplin.component.form.SimpleFormListener);

/*******************************************************************************
 *      caplin.component.composite.CompositeComponentController Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#initialize
 */
caplinx.historicdata.TimeSeriesController.prototype.initialize = function(mComponents, oCompositeComponent)
{
	this.m_mComponents = mComponents;
	for(sComponentName in this.m_mComponents)
	{
		if(sComponentName === "chartSettingsPanel")
		{
			var oChartSettingsPanel = this.m_mComponents[sComponentName];
			oChartSettingsPanel.addListener(this);
		}
	}	
	
	if(!OpenAjax)
	{
		throw new caplin.core.Exception("The OpenAjax hub is not defined", "caplinx.historicdata.TimeSeriesController.initialize");
	}
		
	this.m_oCompositeComponent = oCompositeComponent;
	this._setupChannels();
	this._setupContextMenu(this.m_oCompositeComponent);
};	

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#finalize
 */
caplinx.historicdata.TimeSeriesController.prototype.finalize = function()
{
	if(this.m_pOpenAjaxSubscriptionHelpers.length > 0)
	{
		for(var i = 0, l = this.m_pOpenAjaxSubscriptionHelpers.length ; i < l ; i++)
		{
			this.m_pOpenAjaxSubscriptionHelpers.finalize();
		}
		this.m_pOpenAjaxSubscriptionHelpers = null;
	}
	
	this.m_mComponents = null;
	this.m_oContextMenu.finalize();
};

/*******************************************************************************
 *             					Public Methods
 *******************************************************************************

/**
 * This method is responsible for printing the chart
 */
caplinx.historicdata.TimeSeriesController.prototype.print = function()
{
	var nChartSize = this.m_oCompositeComponent.getComponentSize("chart");
	if (nChartSize === 0)
	{
		var oGridView = this.m_mComponents.grid;
		var oGridRowModel = oGridView.getGridRowModel();
		var oDataProvider = oGridRowModel._$getDataProvider();
		var pTableData = oDataProvider.getDataForAllRows();
		var mRendererTypes = oGridView.getRendererTypesIndexedByColumnName();
		var oTableFormatter = new caplin.chart.TableFormatter();
		var pData = oTableFormatter.formatTable(pTableData, mRendererTypes);
		var pFields = oDataProvider.getDataSetFields();
		
		var htmlTableGenerator = new caplin.chart.HTMLTableGenerator();
		var sTable = htmlTableGenerator.generateHTMLTable(pFields, pData);
		
		var sUrl = "gridPrintPage.html?domain=" + window.document.domain;
		var nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
		l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
		l_oPrintWindow = window.open(sUrl, nWindowId, l_sFeatures);

		setTimeout(function(){
			if(l_oPrintWindow){
				l_oPrintWindow.document.body.innerHTML = sTable;
			}
		}, 1000);
		return false;
	}
	else {
		var oChart = this.m_mComponents.chart;
		caplinx.historicdata.TimeSeriesController.Chart = oChart;
	
		//Set the domain and chart title as parameters. The html page picks it up using location.href.
		var sTitle = webcentric.getActiveComponent().get("caption");
		var l_sUrl = "timeSeries_chart_print_template.html?domain=" + window.document.domain + "&title=" + sTitle;
	
		var nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
		var l_sFeatures = "width=650,height=800,left=10,top=10";
		l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
		l_oPrintWindow = window.open(l_sUrl, nWindowId, l_sFeatures);
	}
};

/**
 * This method is responsible for switching the user's view between chart and data view
 */
caplinx.historicdata.TimeSeriesController.prototype.toggleView = function()
{
	var nChartSize = this.m_oCompositeComponent.getComponentSize("chart");
	if (nChartSize === 0) {
		this.m_oCompositeComponent.hideComponent("grid");
	} else {
		this.m_oCompositeComponent.hideComponent("chart");
	}
};

/**
 * This method is responsible for showing and hiding the context menu
 */
caplinx.historicdata.TimeSeriesController.prototype.toggleContextMenu = function()
{
	this._refreshContextMenu();
	this.m_oContextMenu.toggle();
};

/*******************************************************************************
 *             					Private Methods
 *******************************************************************************/

/**
 * @private
 */
caplinx.historicdata.TimeSeriesController.prototype._setupChannels = function()
{	
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "toggle", this, this.toggleView));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "print", this, this.print));
		
	var pComponentsToLink = [this.m_oCompositeComponent];
	
	for (var sKey in this.m_mComponents) {
		pComponentsToLink.push(this.m_mComponents[sKey]);
	}
	
	caplin.component.comms.InterComponentComms.linkComponents(pComponentsToLink);
};

/**
 * @private
 */
caplinx.historicdata.TimeSeriesController.prototype._setupContextMenu = function(oComponent)
{	
	var eCompositeComponentElement = this.m_oCompositeComponent.getElement();	
	eCompositeComponentElement.appendChild(this.m_oContextMenu.getElement());
	this.m_oContextMenu.setRelativeElement(eCompositeComponentElement);
	this.m_oContextMenu.setComponent(oComponent);
};

/**
 * @private
 */
caplinx.historicdata.TimeSeriesController.prototype._getContextMenu = function()
{
	var oContextMenuConfig = {
		showComponent: {
			text:ct.i18n("cx.historic.data.context.menu.show_data"),
			disabled:false,
			event:"toggle"
		},
		exportToExcel: {
			text:ct.i18n("cx.historic.data.context.menu.export_to_excel"),
			disabled:false,
			event:"export",
			separate: true
		},
		print: {
			text:ct.i18n("cx.historic.data.context.menu.print"),
			disabled:false,
			event:"print"
		},
		clearAllData: {
			text:ct.i18n("cx.historic.data.context.menu.clear_all_data"),
			disabled:false,
			event:"clear"
		}
	}	
	
	return new caplin.chart.menu.ContextMenu(oContextMenuConfig);
};

/**
 * @private
 */
caplinx.historicdata.TimeSeriesController.prototype._refreshContextMenu = function()
{
	var nChartSize = this.m_oCompositeComponent.getComponentSize("chart");
	if (nChartSize === 0) {
		this.m_oContextMenu.setItemText("showComponent", ct.i18n("cx.historic.data.context.menu.show_chart"));
	} else {
		this.m_oContextMenu.setItemText("showComponent", ct.i18n("cx.historic.data.context.menu.show_data"));
	}
};