caplin.namespace("caplinx.tobo");

caplin.include("caplin.security.permissioning.PermissionService",true);
caplin.include("caplin.security.permissioning.PermissionServiceListener",true);
caplin.include("caplin.security.permissioning.ProductPermission",true);
caplin.include("caplin.core.Utility");

caplinx.tobo.TOBOUserPermissionServiceListener = function()
{
	this.m_mPermissionListeners = {};
	this.m_mPermissionListenerIds = {};
	this.m_oPermissionService = caplin.security.permissioning.PermissionService;
	this.m_oProductPermission = caplin.security.permissioning.ProductPermission;
};

caplin.implement(caplinx.tobo.TOBOUserPermissionServiceListener, caplin.security.permissioning.PermissionServiceListener);

caplinx.tobo.TOBOUserPermissionServiceListener.prototype.addListener = function(sPermissionType,oContext,sFunction)
{
	if(!this.m_mPermissionListeners[sPermissionType])
	{
		this.m_mPermissionListeners[sPermissionType] = caplin.core.Utility.getFunctionPointerFromMethod(oContext,sFunction);
		this.m_mPermissionListenerIds[sPermissionType] = this.m_oPermissionService.addPermissionSetListener(this.m_oProductPermission.ALL_PRODUCTS, sPermissionType, this.m_oPermissionService.ALLOW, this);
	}
};

caplinx.tobo.TOBOUserPermissionServiceListener.prototype.onPermissionsChanged = function(pPermissions, sProduct, sNamespace)
{
	if(this.m_mPermissionListeners[sNamespace])
	{
		this.m_mPermissionListeners[sNamespace](pPermissions);
	}
};

caplinx.tobo.TOBOUserPermissionServiceListener.prototype.removeListener = function(sPermissionType)
{
	if(this.m_mPermissionListenerIds[sPermissionType] !== undefined)
	{
		this.m_oPermissionService.removeListener(this.m_mPermissionListenerIds[sPermissionType]);
		delete this.m_mPermissionListeners[sPermissionType];
		delete this.m_mPermissionListenerIds[sPermissionType];
	}
};
