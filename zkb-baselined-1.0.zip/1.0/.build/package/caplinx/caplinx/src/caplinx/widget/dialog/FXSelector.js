caplin.namespace("caplinx.widget.dialog");

caplin.include("caplin.i18n.Translator", true);

caplin.include("caplin.core.Logger", true);
caplin.include("caplin.dom.AbstractFactory");

caplin.include("caplin.widget.formcontrols.ThreeImageButton");
caplin.include("caplin.widget.formcontrols.JSONListBox");

/**
 * Constructor
 * Called by webcentric:
 * 		constructor, initialize, reinitialize, getElement
 */
caplinx.widget.dialog.FXSelector = function(oParams) 
{
	this.m_oCurrencyProvider = caplin.services.AbstractFactory.getInstance().getCurrencyProvider();

	var pBaseCodes = this.m_oCurrencyProvider.getBaseCurrencies();
	this.m_pBaseCurrencies = new Array(pBaseCodes.length);
	
	for (var i=0, l=pBaseCodes.length; i < l; i++) 
	{
		this.m_pBaseCurrencies[i] = this.m_oCurrencyProvider.getCurrencyInfo(pBaseCodes[i]);
	}

	this.m_sType = oParams.type;
	this.m_oProductHierarchy = oParams.currencies;
	// These have to have sizes otherwise the listboxes break
	this.basecontainer = document.createElement("div");
	this.basecontainer.className = "listBoxContainer";
	this.basecontainer.style.height = 340;
	this.basecontainer.id = "divBaseCurrencyListBoxContainer";

	this.termscontainer = document.createElement("div");
	this.termscontainer.className = "listBoxContainer";
	this.termscontainer.style.height = 340;
	this.termscontainer.id = "divTermsCurrencyListBoxContainer";

	this.crossname = document.createElement("div");
	this.crossname.className = "selectedCurrencyPair";
	this.m_sImgDirectory = 'source/images';

	// todo: could we possibly use the setStyle() method instead of the updateStyle() method?
	caplin.widget.utilities.StyleHelper.updateStyle(this.crossname, {"height": "20px", "margin-left": "5px"});

	this.selectedBaseCurrency = "";
	this.selectedTermCurrency = "";

	var fBaseCurrencyPtr = caplin.core.Utility.getFunctionPointerFromMethod(this, "setBaseCurrency");
	var fTermCurrencyPtr = caplin.core.Utility.getFunctionPointerFromMethod(this, "setTermsCurrency");

	this.listBoxBaseCurrency = new caplin.widget.formcontrols.JSONListBox(this, this.basecontainer, 'baseCurrencyListBox', fBaseCurrencyPtr, ct.i18n("cx.widget.dialog.fx.selector.base_currency"), false, "code");
    this.listBoxTermsCurrency = new caplin.widget.formcontrols.JSONListBox(this, this.termscontainer, 'termsCurrencyListBox', fTermCurrencyPtr, ct.i18n("cx.widget.dialog.fx.selector.terms_currency"), false, "code");

	//sets the names of attributes but no values
    this.listBoxBaseCurrency.setDisplayAttribute('code,name,issuer');
    this.listBoxTermsCurrency.setDisplayAttribute('code,name,issuer');

    this.listBoxBaseCurrency.setColumnWidths("30,90,100");
    this.listBoxTermsCurrency.setColumnWidths("30,90,100");

    // TODO : Firefox implementation - this will work in ie only!
    // Set the unique select styless for the currency listboxes
    this.listBoxBaseCurrency.setCheckedClassName("checkedCurrencyLeft");
    this.listBoxTermsCurrency.setCheckedClassName("checkedCurrencyRight");

	this.listBoxBaseCurrency.setDataNodeList(this.m_pBaseCurrencies);
	this.listBoxTermsCurrency.setDataNodeList(this.m_pBaseCurrencies);

	this.closeButton = new caplin.widget.formcontrols.ThreeImageButton(ct.i18n("cx.widget.dialog.fx.selector.close"), this.m_sImgDirectory + "/buttons/capbutton", "");
	var fButtonAction = caplin.core.Utility.getFunctionPointerFromMethod(this, "close");
	this.closeButton.addOnClickListener(fButtonAction);

	this.addButton = new caplin.widget.formcontrols.ThreeImageButton(ct.i18n("cx.widget.dialog.fx.selector.add"), this.m_sImgDirectory + "/buttons/capbutton", "");
	var faddButtonAction = caplin.core.Utility.getFunctionPointerFromMethod(this, "addResultsToGrid");
	this.addButton.addOnClickListener(faddButtonAction);
};

caplinx.widget.dialog.FXSelector.prototype.initialize = function() 
{
	this.reinitialize();
};

caplinx.widget.dialog.FXSelector.prototype.reinitialize = function() 
{
	this.selectedBaseCurrency="";
	this.selectedTermCurrency="";
	this.refreshCurrencyPair();
	this.listBoxBaseCurrency.deselectAll();
	this.listBoxTermsCurrency.deselectAll();
};

caplinx.widget.dialog.FXSelector.prototype.onClose = function() 
{
	this.closeButton.OnMouseOut();
	this.addButton.OnMouseOut();
};

caplinx.widget.dialog.FXSelector.prototype.getElement = function() 
{
	var div = document.createElement("div");
	div.className = "fxSelectorBody";
	if (window.suppress_js_embedded_stylesheets) {
		caplin.widget.utilities.StyleHelper.updateStyle(div, {"height": "100%", "width": "100%"});
	} else {
		caplin.widget.utilities.StyleHelper.updateStyle(div, {"height": "100%", "width": "100%", "background": "#687692"});
	}

	var contDiv = document.createElement("div");
	caplin.widget.utilities.StyleHelper.updateStyle(contDiv, {"height": "349px", "width": "570px", "position": "relative", "margin-left": "5px", "margin-bottom": "0px", "padding-bottom": "0px"});
	contDiv.appendChild(this.basecontainer);
	contDiv.appendChild(this.termscontainer);

	var buttondiv = document.createElement("div");
	buttondiv.className = "dialog_standard_button_panel";

	this.addButton.setClassName(this.addButton.getClassName() + " dialog_standard_button");
	this.closeButton.setClassName(this.closeButton.getClassName() + " dialog_standard_button");
	var addElem = this.addButton.getElement();
	var closeElem = this.closeButton.getElement();
	
	buttondiv.appendChild(closeElem);
	buttondiv.appendChild(addElem);

	this.listBoxBaseCurrency.setHeight(345);
	this.listBoxTermsCurrency.setHeight(345);

	div.appendChild(contDiv);
	buttondiv.appendChild(this.crossname);
	div.appendChild(buttondiv);

	return div;
};

caplinx.widget.dialog.FXSelector.prototype.setBaseCurrency = function() 
{
	this.selectedBaseCurrency = this.listBoxBaseCurrency.getSelectedKey();
	
	this.filterTerms();
	this.refreshCurrencyPair();
};

caplinx.widget.dialog.FXSelector.prototype.setTermsCurrency = function() 
{
	this.selectedTermCurrency = this.listBoxTermsCurrency.getSelectedKey();
	this.refreshCurrencyPair();
};

caplinx.widget.dialog.FXSelector.prototype.getSelectedCurrencyPair = function() 
{
	return "" + this.selectedBaseCurrency + this.selectedTermCurrency;
};

caplinx.widget.dialog.FXSelector.prototype.refreshCurrencyPair = function() 
{
	this.crossname.innerHTML = this.getSelectedCurrencyPair();
};

caplinx.widget.dialog.FXSelector.prototype.displayWarning = function(sWarning) 
{
	this.crossname.innerHTML = sWarning;
};

caplinx.widget.dialog.FXSelector.prototype.filterTerms = function() 
{
	var termCodes = this.m_oCurrencyProvider.getTermCurrencies(this.selectedBaseCurrency);
	var termCurrencyInfo = new Array(termCodes.length);

	for (var i=0, l=termCodes.length; i < l; i++) 
	{
		termCurrencyInfo[i] = this.m_oCurrencyProvider.getCurrencyInfo(termCodes[i]);
	}
	
	/*
	 * temp fix to performance issues in listbox component. If the list box has been re-written to be faster this should be removed
	 */
	if (this.m_oCurrencyProvider.fxSelectorRepaint != "false")
	{
		this.listBoxTermsCurrency.setDataNodeList(termCurrencyInfo);
	}

};

/**
 *	Allow the caller to register itself as a consumer of the search results
 *
 * @param {SearchResultConsumer} oSearchResultConsumer the searchResultConsumer which will accept the search results
 */
caplinx.widget.dialog.FXSelector.prototype.setSearchResultConsumer = function(oSearchResultConsumer)
{
    this.m_oSearchResultConsumer = oSearchResultConsumer;

	// mustdo: remove this hack!!! (see top of AbstractTradeTicket)
	if(oSearchResultConsumer && oSearchResultConsumer.iAmYourSearchWidget)
	{
		oSearchResultConsumer.iAmYourSearchWidget(this);
	}
};

caplinx.widget.dialog.FXSelector.prototype.getSearchResultConsumer = function()
{
	return this.m_oSearchResultConsumer;
};

caplinx.widget.dialog.FXSelector.prototype.getSearchConsumer = function()
{
  	var oSearchConsumer = null;
	var oSearchResultConsumer = this.getSearchResultConsumer();

	if(oSearchResultConsumer)
	{
		oSearchConsumer = oSearchResultConsumer;
	}
	else
	{

		var oComponent = webcentric.getActiveComponent();
		if (oComponent)
		// We must check if oComponent is null because webcentric.getActiveComponent() will return null in some cases
		{
			if(!oComponent.view)
			{
				caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(ct.i18n("cx.widget.dialog.fx.selector.alert.active_component"));
			}
			else
			{
				var oAdaptedWidget = oComponent.view.adaptedWidget;			
				if(oAdaptedWidget.getWrappedComponent)
				{			
					oAdaptedWidget = oAdaptedWidget.getWrappedComponent();
				}
	
				if(oAdaptedWidget && oAdaptedWidget.canReceive && oAdaptedWidget.canReceive())
				{
					oSearchConsumer = oAdaptedWidget;
				}
	
				if(!oSearchConsumer)
				{
					if(oComponent.canReceive && oComponent.canReceive())
					{
						oSearchConsumer = oComponent;
					}
					else
					{
						caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(ct.i18n("cx.widget.dialog.fx.selector.alert.cannot_receive"));
						return false;
					}
				}
			}
		}
		else
		{
			caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(ct.i18n("cx.widget.dialog.fx.selector.alert.no_active_component"));
		}		
	}

	return oSearchConsumer;
};

caplinx.widget.dialog.FXSelector.prototype.receiveObjects = function(oSearchConsumer, l_pObjects)
{
	oSearchConsumer.receiveObjects(l_pObjects);

	return true;
};

caplinx.widget.dialog.FXSelector.prototype.failReceiveObjects = function(e)
{
	caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(e);

	return false;
};

caplinx.widget.dialog.FXSelector.prototype.addResultsToGrid = function()
{		
	if(this.selectedTermCurrency === "" || this.selectedBaseCurrency === "") {
		this.displayWarning("");
		caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(ct.i18n("cx.widget.dialog.fx.selector.alert.select_base"),null);
	}
	else if (this.selectedTermCurrency === this.selectedBaseCurrency) {
		this.displayWarning("");
		caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(ct.i18n("cx.widget.dialog.fx.selector.alert.identical_currency"),null);
	}
	else {
		// Determine the search consumer
		var oSearchConsumer = this.getSearchConsumer();
		if (!oSearchConsumer) 
			return;
		
		var l_pObjects = [];
		
		var itm = caplin.framework.ApplicationFactory.getInstance().getSymbolMapper().getSymbol(this.getSelectedCurrencyPair());
		if (this.getSelectedCurrencyPair().length == 6) {
			l_pObjects.push(itm);
			var bCanReceive = oSearchConsumer.canReceiveObjects(l_pObjects);
			if (bCanReceive) {
				// Add the selected item to the selected grid
				var bResultsAdded = caplin.core.Utility.invokeGuardedMethod(this, "receiveObjects", [oSearchConsumer, l_pObjects], "failReceiveObjects");
				
				/* If the dialog has been set to remain open then do not close */
				if (this.m_bKeepOpenUntilCloseButtonPressed) {
					this.reinitialize();
				}
				else {
					this.close();
				}
				
			}
			else {
				caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(oSearchConsumer.getLastReceiveFailureMessage());
			}
		}
		else {
			caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(ct.i18n("cx.widget.dialog.fx.selector.alert.select_base"));
		}
	}
};

/**
 * Sets whether or not the dialog should stay open until the close button is pressed. If true, it will not close when a currency pair
 * is selected and the add button is pressed. 
 */
caplinx.widget.dialog.FXSelector.prototype.setKeepOpenUntilCloseButton = function(bKeepOpen)
{
	this.m_bKeepOpenUntilCloseButtonPressed = bKeepOpen;
};
