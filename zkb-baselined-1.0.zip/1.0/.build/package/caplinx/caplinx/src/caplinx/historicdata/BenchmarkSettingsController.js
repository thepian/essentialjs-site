/**
 * @fileoverview
 * Defines caplinx.historicdata.BenchmarkSettingsController class.
 */

caplin.namespace("caplinx.historicdata");

caplin.include("caplin.component.composite.CompositeComponentController", true);
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplin.component.form.SimpleFormListener", true);
caplin.include("caplin.core.DateExpressionParser");
caplin.include("caplin.core.Exception");
caplin.include("caplin.dom.Utility");
caplin.include("caplin.component.form.SimpleFormComponent");
/**
 * Constructs a new <code>BenchmarkController</code>.
 * @class
 * 
 * @param {caplin.component.form.SimpleFormComponent} oComponent The form component that this controller will
 * 			manipulate and add functionality to.
 * 
 * <p>The purpose of this class is to control the benchmark chart settings panel. The settings panel contains the following components</p>
 * 
 * <ul>
 * 	<li>A ComboBox used to select a benchmark. The combobox is populated following a &quot;subjectAdded&quot;
 * event being published over the OpenAjax hub.</li>
 * 	<li>A Date picker used to show or select a date for a benchmark. If a benchmark is selected within the ComboBox the
 * Date Picker populates with the date related to the selected benchmark.</li>
 * 	<li>An Add button. When it is clicked a &quot;addSubject&quot; event will be published over the OpenAjax hub with details of the benchmark
 * selected in the ComboBox and date selected in the Date Picker.</li>
 * 	<li>An Update button. When it is clicked a &quot;updateSubject&quot; event is published over the OpenAjax hub with details of the benchmark
 * selected in the ComboBox and date selected in the Date Picker.</li>
 * 	<li>A Remove button. When it is clicked a &quot;removeSubject&quot; event is published over the OpenAjax hub with details of the selected
 * benchmark.</li>
 * <ul>
 * 
 * <p>For more information on the OpenAjax hub see the
 * <a href="http://www.openajax.org/member/wiki/OpenAjax_Hub_1.0_Specification>OpenAjax hub 1.0 specification</a></p>
 * 
 * @implements caplin.component.form.SimpleFormListener
 */
caplinx.historicdata.BenchmarkSettingsController = function(oComponent)
{
	if((oComponent instanceof caplin.component.form.SimpleFormComponent) === false)
	{
		throw new caplin.core.Exception("oComponent must be an instance of caplin.component.form.SimpleFormComponent",
				"caplinx.historicdata.BenchmarkSettingsController");
	}
	
	/** @private */
	this.m_oAddButton = null;
	/** @private */
	this.m_oUpdateButton = null;
	/** @private */
	this.m_oRemoveButton = null;
	/** @private */
	this.m_oHideButton = null;
	/**@private*/
	this.m_oComboBox = null;
	/** @private */
	this.m_oDateField = null;
	/** @private */
	this.m_oComponent = oComponent;
	/** @private */
	this.m_pOpenAjaxSubscriptionHelpers = [];
	/** @private */
	this.m_nHideButtonListenerId = null;
	/**@private*/
	this.m_nRemoveButtonListenerId = null;
	/**@private*/
	this.m_nAddButtonListenerId = null;
	/**@private*/
	this.m_nUpdateButtonListenerId = null;
	/**@private*/
	this.m_nSeriesCount = 0;
	/** @private */
	this.m_mSubjectDataMap = {};
	/** @private */
	this.m_bParsedComponentsHaveBeenSetup = false;
	
	this.m_oComponent.addListener(this);
	
	if( this.m_oComponent.formComponentsHaveBeenParsed() === true )
	{
		this._setupParsedComponents( this.m_oComponent.getFormComponents() );
	}
	
	this._registerForEvents();
};
caplin.implement(caplinx.historicdata.BenchmarkSettingsController, caplin.component.form.SimpleFormListener);

/*******************************************************************************
 *      caplin.component.composite.CompositeComponentController Interface
 *******************************************************************************/

/**
 * Informs the instance that it should clean up.
 */
caplinx.historicdata.BenchmarkSettingsController.prototype.finalize = function()
{
	var nOpenAjaxHelpersCount = this.m_pOpenAjaxSubscriptionHelpers.length;
	if(nOpenAjaxHelpersCount > 0)
	{
		for(var i = 0; i < nOpenAjaxHelpersCount; i++)
		{
			this.m_pOpenAjaxSubscriptionHelpers[ i ].finalize();
		}
		this.m_pOpenAjaxSubscriptionHelpers = null;
	}
	
	this.m_oHideButton.removeOnClickListener( this.m_nHideButtonListenerId );
	this.m_oRemoveButton.removeOnClickListener( this.m_nRemoveButtonListenerId );
	this.m_oAddButton.removeOnClickListener( this.m_nAddButtonListenerId );
	this.m_oUpdateButton.removeOnClickListener( this.m_nUpdateButtonListenerId );
};

/*******************************************************************************
 *                      		Private Methods
 *******************************************************************************/

/**
 * @private
 * Register for certain events and alter the state of the settings panel when called.
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._registerForEvents = function()
{
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oComponent, "*", "subjectSelected", this, this._setComboboxValue));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oComponent, "*", "subjectSelected", this, this._setDateFieldValue));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oComponent, "*", "subjectAdded", this, this._updateStateOfComponents));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oComponent, "*", "subjectRemoved", this, this._subjectRemoved));
};

/** @private */
caplinx.historicdata.BenchmarkSettingsController.prototype._setComboboxValue = function(sEventNamespace, oEventData)
{
	if (this._isLineSeries(oEventData.data))
	{
		this.m_oComboBox.setValue(oEventData.title);
	}
};

/** @private */
caplinx.historicdata.BenchmarkSettingsController.prototype._setDateFieldValue = function(sEventNamespace, oEventData)
{
	if (this._isLineSeries(oEventData.data))
	{
		var sDate = this._getDate(oEventData.metaData.startDate);	
		this.m_oDateField.setValue(sDate);
	}
};

/** @private */
caplinx.historicdata.BenchmarkSettingsController.prototype._getDate = function(sDate)
{
	if (sDate)
	{
		return sDate.replace(/\-/g,"/");
	}
};

/**
 * This method is responsible for updating the state of components such as combobox in the settings panel
 * @private
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._updateStateOfComponents = function(sEventNamespace, oEventData)
{
	if(this._isLineSeries(oEventData.data))
	{
		this.m_nSeriesCount++;
		this.m_oComboBox.enable();
		this.m_oDateField.enable();
		
		var sTitle = oEventData.title;
		var sSubject = oEventData.subject;
		var sId = oEventData.id;
		var sStartDate = oEventData.metaData.startDate;
		var oDate = Date.parseDate(sStartDate, "d-m-Y") || new Date();

		this.m_mSubjectDataMap[ sTitle ] = { "id":sId, "subject":sSubject, "startDate":oDate };

		var oDataStore = this.m_oComboBox.getStore();
		oDataStore.loadData([[sTitle]], true);
		this.m_oComboBox.setValue( sTitle );
		
		this.m_oDateField.setValue(oDate);
		
		this._updateStateOfButtons();
	}
};

/**
 * @private
 * Handles the OpenAjax &quot;subjectRemoved&quot; event.
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._subjectRemoved = function(sEventNamespace, oEventData)
{
	if(this._isLineSeries(oEventData.data))
	{
		var sTitle = oEventData.title;
		var oStore = this.m_oComboBox.getStore();
		
		var nIndex = oStore.find( this.m_oComboBox.valueField, sTitle );
		oStore.removeAt( nIndex );
		delete this.m_mSubjectDataMap[ sTitle ];
		
		this.m_oComboBox.reset();
		this.m_oDateField.reset();
		this.m_nSeriesCount--;
		if(this.m_nSeriesCount === 0)
		{
			this.m_oComboBox.disable();
			this.m_oComboBox.getStore().removeAll();			
			this.m_oDateField.disable();
			this.m_oAddButton.setEnabled(false);
			this.m_oUpdateButton.setEnabled(false);
			this.m_oRemoveButton.setEnabled(false);
		}
		this._updateStateOfButtons();
	}
};

/*******************************************************************************
 *             caplin.component.form.SimpleFormListener Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.form.SimpleFormListener#onComponentsParsed
 */
caplinx.historicdata.BenchmarkSettingsController.prototype.onComponentsParsed = function(mParsedComponents)
{
	this._setupParsedComponents(mParsedComponents);
};

/**
 * @private
 * @see caplin.component.form.SimpleFormListener#onHide
 */
caplinx.historicdata.BenchmarkSettingsController.prototype.onHide = function()
{
	this.m_oComboBox.collapse();
	this.m_oComboBox.purgeListeners();
	this.m_oDateField.menu.hide();
	this.m_oDateField.purgeListeners();
};

/**
 * @private
 * @see caplin.component.form.SimpleFormListener#onOpen
 */
caplinx.historicdata.BenchmarkSettingsController.prototype.onOpen = function(nWidth, nHeight)
{
	this.m_oComboBox.setSize({width:164, height:20});
	this.m_oDateField.setSize({width:94, height:20});	
};


/*******************************************************************************
 *             					Private Methods
 *******************************************************************************/

/**
 * @private
 * @param {Map} mParsedComponents A map of name to component within the simple form. The controller needs to be aware of the contents of this
 * parameter in order to get access to buttons, a ComboBox and a Date Picker. 
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._setupParsedComponents = function(mParsedComponents)
{
	if (this.m_bParsedComponentsHaveBeenSetup === false) 
	{
		this.m_oHideButton = mParsedComponents.Hide;
		this.m_nHideButtonListenerId = this.m_oHideButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onHide"));
		
		this.m_oRemoveButton = mParsedComponents.Remove;
		this.m_nRemoveButtonListenerId = this.m_oRemoveButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onRemove"));
		
		this.m_oAddButton = mParsedComponents.Add;
		this.m_nAddButtonListenerId = this.m_oAddButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onAdd"));
		
		this.m_oUpdateButton = mParsedComponents.Update;
		this.m_nUpdateButtonListenerId = this.m_oUpdateButton.addOnClickListener(caplin.dom.Utility.createMethodEventListener(this, "_onUpdate"));
		
		this.m_oComboBox = mParsedComponents.ComboBox;
		this.m_oComboBox.disable();
		this.m_oComboBox.on("select", this._comboBoxValueSelected, this);
		
		var oYesterday = caplin.core.DateExpressionParser.convertExpressionToDate('-1d', new Date());
		this.m_oDateField = mParsedComponents.DatePicker;		
		this.m_oDateField.setMaxValue(oYesterday); 
		this.m_oDateField.disable();
		this.m_oDateField.on("select", this._dateValueSelected, this);
		this.m_oDateField.on("change", this._dateValueSelected, this);
		
		this._updateStateOfButtons();
		this.m_bParsedComponentsHaveBeenSetup = true;
	}
};

/** @private */
caplinx.historicdata.BenchmarkSettingsController.prototype._comboBoxValueSelected = function()
{
	var sSelectedTitle = this.m_oComboBox.getValue()[ 0 ];
	var oStartDate = this.m_mSubjectDataMap[ sSelectedTitle ].startDate;
	this.m_oDateField.setValue( oStartDate );
	
	this._updateStateOfButtons();
};

/** @private */
caplinx.historicdata.BenchmarkSettingsController.prototype._dateValueSelected = function(oDateField, oSelectedDate)
{
	var oYesterday = caplin.core.DateExpressionParser.convertExpressionToDate('-1d', new Date());
	var sSelectedDate = oSelectedDate.format('d-m-Y');
	
	if (oYesterday.format('d-m-Y') !== sSelectedDate  ) 
	{
		this.m_oAddButton.setEnabled(true);
	} 
	else 
	{
		this.m_oAddButton.setEnabled(false);
	}
};

/** @private */
caplinx.historicdata.BenchmarkSettingsController.prototype._updateStateOfButtons = function()
{
	var bEnableButton = ( this.m_oComboBox.getValue() !== "" && this.m_oDateField.getValue() );
	this.m_oRemoveButton.setEnabled(bEnableButton);
	
	var oYesterday = caplin.core.DateExpressionParser.convertExpressionToDate('-1d', new Date());
	var sTitle = this.m_oComboBox.getValue();
	if (this.m_mSubjectDataMap[sTitle])
	{
		var oSeries = this.m_mSubjectDataMap[sTitle];
		var oStartDate = oSeries.startDate;
		bEnableButton = (bEnableButton && (oYesterday.format('d-m-Y') !== oStartDate.format('d-m-Y')));
	}
	this.m_oAddButton.setEnabled(bEnableButton);
	this.m_oUpdateButton.setEnabled(bEnableButton);
};

/**
 * This function is executed when a user clicks on the Hide button of the Settings Menu.
 * The effect is that an open ajax toggleSettingsPanel event is raised.
 * @private
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._onHide = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined)
	{
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.BenchmarkSettingsController");
	}
	else
	{
		OpenAjax.hub.publish("settings." + sChannelId + ".toggleSettingsPanel");
	}	
};

/**
 * This function is executed when a user clicks on the Remove button of the Settings Menu.
 * The effect is that an open ajax removeSubject event is raised.
 * @private
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._onRemove = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined)
	{
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.BenchmarkSettingsController");
	}
	else
	{
		var oEvent = caplinx.historicdata.BenchmarkSettingsController._$createEventObject( this.m_oComboBox, this.m_oDateField, this.m_mSubjectDataMap );
		OpenAjax.hub.publish("settingsPanel." + sChannelId + ".removeSubject", oEvent);
	}	
};

/**
 * This function is executed when a user clicks on the Add button of the Settings Menu.
 * The effect is that an open ajax addSeriesToChart event is raised.
 * @private
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._onAdd = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined)
	{
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.BenchmarkSettingsController");
	}
	else
	{
		var oEvent = caplinx.historicdata.BenchmarkSettingsController._$createEventObject( this.m_oComboBox, this.m_oDateField, this.m_mSubjectDataMap );
		OpenAjax.hub.publish("settingsPanel." + sChannelId + ".addSubject", oEvent);
	}	
};

/**
 * This function is executed when a user clicks on the Update button of the Settings Menu.
 * The effect is that an open ajax removeSubject event is raised to indicate that the
 * selected series should be removed. Then, an addSeriesToChart event is raised to add a
 * series with the new benchmark and date.
 * @private
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._onUpdate = function()
{
	var sChannelId = this._getCurrentChannelId();
		
	if (sChannelId === undefined)
	{
		throw new caplin.core.Exception("Cannot find the component's channel id", "caplinx.historicdata.BenchmarkSettingsController");
	}
	else
	{
		var oEvent = caplinx.historicdata.BenchmarkSettingsController._$createEventObject( this.m_oComboBox, this.m_oDateField, this.m_mSubjectDataMap );
		
		// Initially remove so that the update draws a new line in affect replacing the old one
		OpenAjax.hub.publish("settingsPanel." + sChannelId + ".removeSubject", oEvent);
		OpenAjax.hub.publish("settingsPanel." + sChannelId + ".updateSubject", oEvent);
	}	
};

/**
 * @private
 * Used when publishing events over the OpenAjax hub.
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._getCurrentChannelId = function()
{
	var sChannel = caplin.component.comms.InterComponentComms.getComponentChannel( this.m_oComponent );
	return sChannel;
};

/**
 * @private
 * @type Boolean
 * Checks to see if the number of pieces of data within the supplied array indicate that
 * the benchmark consists of more than one point. If there is more than one piece of data
 * in the array then the array contains a series of data.
 * 
 * @return <code>true</code> if the data contains more than one piece of data; otherwise
 * <code>false</code>.
 */
caplinx.historicdata.BenchmarkSettingsController.prototype._isLineSeries = function(pData)
{
	return (pData.length > 1) ? true : false;	
};

/**
 * @private
 * Creates an event object to be sent over the OpenAjax hub.
 * @param {Ext.form.ComboBox} oComboBox
 * @param {Ext.form.DateField} oDatePicker
 * @param {Map} mDataMap Map of ComboBox title to user data object.
 */
caplinx.historicdata.BenchmarkSettingsController._$createEventObject = function(oComboBox, oDatePicker, mDataMap)
{
	var sTitle = oComboBox.getValue();
	var oData = mDataMap[ sTitle ];
	var oEvent = {};
	oEvent.id = oData.id;
	oEvent.title = sTitle;
	oEvent.subject = oData.subject;
	if (oDatePicker.getValue()) 
	{
		oEvent.snapshotDate = oDatePicker.getValue().format('d-m-Y');
	}
	return oEvent;
};