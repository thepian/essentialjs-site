caplin.namespace("caplinx.grid");

caplin.include("caplinx.CaplinFactory", true);

caplin.include("caplin.i18n.Translator", true);

caplin.include("caplin.framework.connection.ConnectionStatusFieldModel", true);

caplin.include("caplin.renderer.RendererCreationFactory", true);

caplin.include("caplin.renderer.control.BlankRendererTemplate", true);
caplin.include("caplin.renderer.control.ControlRendererTemplate", true);
caplin.include("caplin.renderer.control.TextControl");
caplin.include("caplin.renderer.control.TextBoxControl");
caplin.include("caplin.renderer.control.StatefulImageControl");
caplin.include("caplin.renderer.style.ReWriterStyler", true);
caplin.include("caplin.renderer.style.CssClassStyler", true);
caplin.include("caplin.renderer.style.ControlPropertyStyler", true);
caplin.include("caplin.renderer.style.RangeStyler", true);
caplin.include("caplin.renderer.style.TextStyler", true);
caplin.include("caplin.renderer.style.CombinedStyler", true);

caplin.include("caplinx.renderer.handler.FilterHandler", true);
caplin.include("caplinx.renderer.handler.RangeFilterHandler", true);
caplin.include("caplinx.renderer.handler.CombinedFilterHandler", true);

caplin.include("caplin.renderer.control.FilterRendererTemplate", true);

/**
 * @constructor
 */
caplinx.grid.TemporaryRendererFactoryInitializer = function()
{
};

/**
 * @private
 */
caplinx.grid.TemporaryRendererFactoryInitializer.onAfterClassLoad = function()
{
	/************************** default **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("default", new caplin.renderer.control.BlankRendererTemplate({
		formatters:[],
		stylers:[],
		parsers:[],
		handlers:[],
		control:"", config:{}
	}));
	
	/************************** inlineTextFilter **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("inlineTextFilter", new caplin.renderer.control.ControlRendererTemplate({
		formatters:[],
		stylers:[new caplin.renderer.style.CombinedStyler()],
		parsers:[],
		handlers:[caplinx.renderer.handler.CombinedFilterHandler],
		control:"TextBoxControl",
		config:{filterType:"WILDCARD"}
	}));
	caplin.renderer.RendererCreationFactory.addTemplateAlias("caseinsensitivetextfilter", "inlineTextFilter");
	
	/************************** inlineCaseSensitiveTextFilter **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("inlineCaseSensitiveTextFilter", new caplin.renderer.control.ControlRendererTemplate({
		formatters:[],
		stylers:[new caplin.renderer.style.CombinedStyler()],
		parsers:[],
		handlers:[caplinx.renderer.handler.CombinedFilterHandler],
		control:"TextBoxControl",
		config:{filterType:"WILDCARD_CASE_SENSITIVE"}
	}));
	caplin.renderer.RendererCreationFactory.addTemplateAlias("textfilter", "inlineCaseSensitiveTextFilter");
	
	/************************** inlineRangeFilter **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("inlineRangeFilter", new caplin.renderer.control.ControlRendererTemplate({
		formatters:[],
		stylers:[new caplin.renderer.style.CombinedStyler()],
		parsers:[],
		handlers:[caplinx.renderer.handler.CombinedFilterHandler],
		control:"TextBoxControl",
		config:{filterType:"WILDCARD"}
	}));
	caplin.renderer.RendererCreationFactory.addTemplateAlias("numericRangeFilter", "inlineRangeFilter");
	
	/************************** textFilter **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("textFilter", new caplin.renderer.control.FilterRendererTemplate(
		"inlineTextFilter"
	));
	caplin.renderer.RendererCreationFactory.addTemplateAlias("case-insensitive-text-filter-combo", "textFilter");
	
	/************************** caseSensitiveTextFilter **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("caseSensitiveTextFilter", new caplin.renderer.control.FilterRendererTemplate(
		"inlineCaseSensitiveTextFilter"
	));
	caplin.renderer.RendererCreationFactory.addTemplateAlias("text-filter-combo", "caseSensitiveTextFilter");
	
	/************************** rangeFilter **************************/
	caplin.renderer.RendererCreationFactory.addRendererTemplate("rangeFilter", new caplin.renderer.control.FilterRendererTemplate(
		"inlineRangeFilter"
	));
	caplin.renderer.RendererCreationFactory.addTemplateAlias("numeric-range-filter-combo", "rangeFilter");
	
	/************************** connectionStatusIndicator **************************/
	var oConfig = {};
	
	// config for stateful image control
	var fConnectionStatusFieldModel = caplin.framework.connection.ConnectionStatusFieldModel;
	var fStatefulImageControl = caplin.renderer.control.StatefulImageControl;
	/* TODO refactor path */
	oConfig[fStatefulImageControl.CONFIG_IMAGE] = "source/theme/areas/skeleton/images/connection_status/three_part_connection.gif";
	oConfig[fStatefulImageControl.CONFIG_VIEWABLE_HEIGHT] = "22";
	oConfig[fStatefulImageControl.CONFIG_STATES] = [fConnectionStatusFieldModel.CONNECTION_STATUS_OK,
		fConnectionStatusFieldModel.CONNECTION_STATUS_ERROR, fConnectionStatusFieldModel.CONNECTION_STATUS_LIMITED];
	
	// config for tool tip styler
	var fControlPropertyStyler = caplin.renderer.style.ControlPropertyStyler;
	oConfig[fControlPropertyStyler.FIELD] = fConnectionStatusFieldModel.FIELD_CONNECTION_MESSAGE;
	oConfig[fControlPropertyStyler.CONTROL_PROPERTY] = "title";
	
	caplin.renderer.RendererCreationFactory.addRendererTemplate("connectionStatusIndicator", new caplin.renderer.control.ControlRendererTemplate({
		formatters:[],
		stylers:[new caplin.renderer.style.ControlPropertyStyler()],
		parsers:[],
		handlers:[],
		control:"StatefulImageControl",
		config:oConfig
	}));
	
	/************************** connectionStatusTextIndicator **************************/
	var oConfig = {};
	
	var oRewiteMap = {};
	oRewiteMap[caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_OK] = ct.i18n("cx.grid.decorator.connection.status.ok");
	oRewiteMap[caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_ERROR] = ct.i18n("cx.grid.decorator.connection.status.error");
	oRewiteMap[caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_LIMITED] = ct.i18n("cx.grid.decorator.connection.status.limited");
	oConfig.rewriteMap = oRewiteMap;
	
	var oCssMap = {};
	oCssMap[caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_OK] = "green";
	oCssMap[caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_ERROR] = "red";
	oCssMap[caplin.framework.connection.ConnectionStatusFieldModel.CONNECTION_STATUS_LIMITED] = "orange";
	oConfig[caplin.renderer.style.CssClassStyler.CONFIG_CSS_MAP] = oCssMap;
	
	caplin.renderer.RendererCreationFactory.addRendererTemplate("connectionStatusTextIndicator", new caplin.renderer.control.ControlRendererTemplate({
		formatters:[],
		stylers:[new caplin.renderer.style.CssClassStyler(), new caplin.renderer.style.ReWriterStyler()],
		parsers:[],
		handlers:[],
		control:"TextControl",
		config:oConfig
	}));
};

caplin.notifyAfterClassLoad(caplinx.grid.TemporaryRendererFactoryInitializer);
