caplin.namespace("caplinx.trading.presentation");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplinx.trading.presentation.FxTradeTicket");
caplin.include("caplin.trading.trademodel.TradingStatus");
caplin.include("caplin.trading.trademodel.TradingStatusChangedListener", true);

caplinx.trading.presentation.FxTradeTicketController = function(oFxTradeTicket)
{
	this.m_bDisabledButtons = false;
	this.m_oFxTradeTicket = oFxTradeTicket;
	this.m_nTradingStatus = caplinx.trading.presentation.FxTradeTicketController.INITIAL_STATE;
};

caplin.implement(caplinx.trading.presentation.FxTradeTicketController, caplin.trading.trademodel.TradingStatusChangedListener);

caplinx.trading.presentation.FxTradeTicketController.INITIAL_STATE = -1;

caplinx.trading.presentation.FxTradeTicketController.prototype.getTradingStatus = function()
{
	return this.m_nTradingStatus;
};

caplinx.trading.presentation.FxTradeTicketController.prototype.tradingStatusChanged = function(nTradingStatus)
{
	this.m_nTradingStatus = this.m_oFxTradeTicket._$getTrade().getTradeChannelStatus();
	if (this.m_nTradingStatus == caplin.trading.trademodel.TradingStatus.UNAVAILABLE) 
	{
		this.m_bDisabledButtons = true;
		this.m_oFxTradeTicket._disableExecuteButtons(ct.i18n("cx.trading.presentation.fx.ticket.channel_down"));
	}
};

caplinx.trading.presentation.FxTradeTicketController.prototype.registerListeners = function()
{
	this.m_oFxTradeTicket._$getTrade().addTradingStatusChangedListener(this);
};

caplinx.trading.presentation.FxTradeTicketController.prototype.unregisterListeners = function()
{
	if(this.m_oFxTradeTicket._$getTrade())
	{
		this.m_oFxTradeTicket._$getTrade().removeTradingStatusChangedListener(this);
	}
};
