caplin.namespace("caplinx.fields");

caplin.include("caplin.widget.fields.FieldManager", true);
caplin.include("caplin.widget.fields.Field");
caplin.include("caplinx.widget.fields.IndicativeFields");
caplin.include("caplinx.widget.format.PriceTextFormatter");
caplin.include("caplin.widget.format.DateTextFormatter");
caplin.include("caplin.widget.format.TimeTextFormatter");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplin.widget.format.PipTextFormatter");
caplin.include("caplinx.widget.format.InstrumentDescriptionTextFormatter");
caplin.include("caplinx.widget.format.BlotterTradeIdTextFormatter");

caplin.include("caplin.widget.objectset.grid.ColumnInfo");
caplin.include("caplin.widget.objectset.grid.AbstractColumn");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.fields.FieldManager = function()
{
	caplin.widget.fields.FieldManager.call(this);

	this.initialiseFields();
};

caplin.extend(caplinx.fields.FieldManager, caplin.widget.fields.FieldManager);

caplinx.fields.FieldManager.prototype.initialiseFields = function()
{
	// create the text formatters that will be used
	var oTextFormatterFactory = caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory();
	var oNullTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.NullTextFormatter");
	var oDateTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.DateTextFormatter");
	var oPriceTextFormatter = oTextFormatterFactory.getTextFormatter("caplinx.widget.format.PriceTextFormatter");
	var oDecimalPlaceTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "3");
	var oFiveDecimalPlaceTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "5");
	var oSixDecimalPlaceTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "6");
	var oNoDecimalPlaceTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "0");
	var oInstrumentDescriptionTextFormatter = oTextFormatterFactory.getTextFormatter("caplinx.widget.format.InstrumentDescriptionTextFormatter");
	var oQuantityTextFormatter = oTextFormatterFactory.getQuantityFormatter("true");
	var oTierLimitTextFormatter = oTextFormatterFactory.getQuantityFormatter("true,3");
	var oTimeTextFormatter = oTextFormatterFactory.getTextFormatter("caplin.widget.format.TimeTextFormatter", "false");
	var oBlotterTradeIdTextFormatter = oTextFormatterFactory.getTextFormatter("caplinx.widget.format.BlotterTradeIdTextFormatter");

	// define the field mappings
	this.addFieldInfo("InstrumentDesc", oInstrumentDescriptionTextFormatter, "Text", false);
	this.addFieldInfo("CpnRate", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("MatD", oDateTextFormatter, "Text", false);
	this.addFieldInfo("StlmD", oDateTextFormatter, "Text", false);
	this.addFieldInfo("BidPrice", oPriceTextFormatter, "Relative", false);
	this.addFieldInfo("AskPrice", oPriceTextFormatter, "Relative", false);
	this.addFieldInfo("BidQty", oQuantityTextFormatter, "Relative", false);
	this.addFieldInfo("AskQty", oQuantityTextFormatter, "Relative", false);
	this.addFieldInfo("BidYld", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("AskYld", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("BidSprd", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("AskSprd", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("Amount", oQuantityTextFormatter, "Relative", false);
	this.addFieldInfo("TradeDate", oDateTextFormatter, "Text", false);
	this.addFieldInfo("TimeStamp", oTimeTextFormatter, "Text", false);
	this.addFieldInfo("YldChgOnDay", oFiveDecimalPlaceTextFormatter, "Absolute", false);
	this.addFieldInfo("TradeID", oBlotterTradeIdTextFormatter, "Text", false);
	this.addFieldInfo("LastUpdate", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("CAS", oDecimalPlaceTextFormatter, "Absolute", false);
	this.addFieldInfo("PV01", oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo("SPRtng", oNullTextFormatter, "Text", false);
	this.addFieldInfo("MDRtng", oNullTextFormatter, "Text", false);
	this.addFieldInfo("FIRtng", oNullTextFormatter, "Text", false);
	this.addFieldInfo("DealtCurrency", oNullTextFormatter, "Text", false);

    this.addFieldInfo("Deposits-Currency", oNullTextFormatter, "Text", false);
	this.addFieldInfo("Deposits-MaturityType", oNullTextFormatter, "Text", false);
	this.addFieldInfo("Deposits-Rate", oSixDecimalPlaceTextFormatter, "Relative", false);

    var FIELDS = caplin.fields.FieldNames;
	this.addFieldInfo(FIELDS.DISPLAY_NAME, oInstrumentDescriptionTextFormatter, "Text", false);
	this.addFieldInfo(FIELDS.INSTRUMENT, oInstrumentDescriptionTextFormatter, "Text", false);
	this.addFieldInfo(FIELDS.PRICE, oPriceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.BID_PRICE, oPriceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.ASK_PRICE, oPriceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.YIELD, oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.ASK_YIELD, oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.BID_YIELD, oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.BUY_OR_SELL, oNullTextFormatter, "Text", false);
	this.addFieldInfo(FIELDS.BENCHMARK_INSTRUMENT, oInstrumentDescriptionTextFormatter, "Text", false);
	this.addFieldInfo(FIELDS.BENCHMARK_PRICE, oPriceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.BENCHMARK_YIELD, oDecimalPlaceTextFormatter, "Relative", false);
	this.addFieldInfo(FIELDS.AMOUNT, oQuantityTextFormatter, "Text", true);
	this.addFieldInfo(FIELDS.SETTLEMENT_DATE, oDateTextFormatter, "Text", false);
	this.addFieldInfo(FIELDS.YIELD_CHANGE_ON_DAY, oFiveDecimalPlaceTextFormatter, "Absolute", false);
	this.addFieldInfo(FIELDS.TIER_LIMIT, oTierLimitTextFormatter, "Text", false);
	
	// add trade leg fields
	for (var i = 1; i <= 3; ++i)
	{
		this.addFieldInfo(FIELDS.LEG[i].DISPLAY_NAME, oInstrumentDescriptionTextFormatter, "Text", false);
		this.addFieldInfo(FIELDS.LEG[i].INSTRUMENT, oInstrumentDescriptionTextFormatter, "Text", false);
		this.addFieldInfo(FIELDS.LEG[i].PRICE, oPriceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].BID_PRICE, oPriceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].ASK_PRICE, oPriceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].YIELD, oDecimalPlaceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].ASK_YIELD, oDecimalPlaceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].BID_YIELD, oDecimalPlaceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].BUY_OR_SELL, oNullTextFormatter, "Text", false);
		this.addFieldInfo(FIELDS.LEG[i].BENCHMARK_INSTRUMENT, oInstrumentDescriptionTextFormatter, "Text", false);
		this.addFieldInfo(FIELDS.LEG[i].BENCHMARK_PRICE, oPriceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].BENCHMARK_YIELD, oDecimalPlaceTextFormatter, "Relative", false);
		this.addFieldInfo(FIELDS.LEG[i].AMOUNT, oQuantityTextFormatter, "Text", true);
		this.addFieldInfo(FIELDS.LEG[i].SETTLEMENT_DATE, oDateTextFormatter, "Text", false);
		this.addFieldInfo(FIELDS.LEG[i].YIELD_CHANGE_ON_DAY, oFiveDecimalPlaceTextFormatter, "Absolute", false);
		this.addFieldInfo(FIELDS.LEG[i].TIER_LIMIT, oTierLimitTextFormatter, "Text", false);
	}
};

caplinx.fields.FieldManager.prototype.addFieldInfo = function(l_sFieldName, l_oTextFormatter, l_sUpdateType, l_bHasCommas)
{
	this.addField(new caplin.widget.fields.Field(l_sFieldName, l_oTextFormatter, l_sUpdateType, l_bHasCommas));
};
