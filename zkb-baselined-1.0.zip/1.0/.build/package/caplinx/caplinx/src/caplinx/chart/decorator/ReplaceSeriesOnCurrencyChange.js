/**
 * @fileoverview
 * Defines the caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange class.
 */
caplin.namespace("caplinx.chart.decorator");

caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.filter.QueryFilterExpression");
caplin.include("caplin.core.DateExpressionParser");
caplin.include("caplin.chart.ChartSeriesRequest");
caplin.include("caplin.chart.decorator.ChartDecorator", true);

/**
 * Constructs a new <code>ReplaceSeriesOnCurrencyChange</code> with the specified arguments. End-users will never need to do
 * this themselves since charts are fully constructed based on their XML definition files by the
 * {@link caplin.chart.ChartGenerator ChartGenerator} class.
 * 
 * @class
 * The <code>caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange</code> is used to listen to
 * the currencyChanged event from the OpenAjax hub that may affect the contents of the chart.
 * 
 * <p>For more information on the OpenAjax hub see
 * the <a href="http://www.openajax.org/member/wiki/OpenAjax_Hub_1.0_Specification">OpenAjax hub 1.0 specification</a>.
 * </p>
 * 
 * @constructor
 * @implements caplin.chart.decorator.ChartDecorator
 */
caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange = function(oConfig)
{
	/** @private */
	this.m_oChartView = null;
	/** @private */
	this.m_oChartModel = null;
	/** @private */	
	this.m_oCurrencyChangedHelper = null;
	/** @private */	
	this.m_oCurrencyToSubject = this._getCurrencyToSubjectMap(oConfig.mappings);
	/** @private */
	this.m_oDate = this._getDate(oConfig.date);
};
caplin.implement(caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange, caplin.chart.decorator.ChartDecorator);

/**
 * @private
 * @see caplin.chart.decorator.ChartDecorator#setChartView
 */
caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange.prototype.setChartView = function(oChartView)
{	
	this.m_oChartView = oChartView;
	this.m_oCurrencyChangedHelper =
		new caplin.component.comms.OpenAjaxChannelSubscriptionHelper( this.m_oChartView, "*", "currencyChanged", this, this._replaceSeries);
		
	this.m_oChartModel = this.m_oChartView.getChartModel();						
};


/** @private */
caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange.prototype._replaceSeries = function(sName, oEvent)
{
	var oSeries = this.m_oChartModel.getSeriesSet()[0];
	this.m_oChartModel.removeSeries(oSeries.getId());

	var sSeries = this.m_oCurrencyToSubject[oEvent.currency];
	var oQuery = new caplin.component.filter.QueryFilterExpression();
	
	if (this.m_oDate) {
		oQuery.addFilter("snapshotDate", this.m_oDate.format('d-m-Y'));		
	}	
		
	var oRequest = new caplin.chart.ChartSeriesRequest(sSeries, oQuery);
	this.m_oChartModel.requestSeries(oRequest);	
};

/** @private */
caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange.prototype._getCurrencyToSubjectMap = function(oMappings)
{
	var oCurrencyToSubjectMap = {};
	var mapping = oMappings.mapping;
	if (mapping.length) {
		for (var i = 0, l = mapping.length; i < l; ++i) {
			var map = mapping[i];
			oCurrencyToSubjectMap[map['key']] = map['value'];
		}
	} else {
		oCurrencyToSubjectMap[mapping['key']] = mapping['value'];
	}
	return oCurrencyToSubjectMap;
};



/** @private */
caplinx.chart.decorator.ReplaceSeriesOnCurrencyChange.prototype._getDate = function(sDate)
{
	if (sDate) {
		var oParsedDate = caplin.core.DateExpressionParser.convertExpressionToDate(sDate);
		return oParsedDate;
	}
	return null;
};
