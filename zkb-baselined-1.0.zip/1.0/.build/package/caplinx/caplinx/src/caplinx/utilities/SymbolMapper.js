caplin.namespace("caplinx.utilities");

caplin.include("caplin.widget.utilities.AbstractSymbolMapper", true);


/**
 * @class <p>Provides a set of methods for mapping between a symbol (an RTTP object name) and the
 * various properties associated with the instrument that it represents, such as its asset class or
 * product group.</p>
 * 
 * <p>An instance of this class should be obtained from
 * {@link caplin.framework.ApplicationFactory#getSymbolMapper}.</p>
 */
caplinx.utilities.SymbolMapper = function()
{
	caplin.widget.utilities.AbstractSymbolMapper.call(this);
	
	// compile all regular expressions
	this.sSymbolPrefix = this._getSymbolPrefix();
	this.oSymbolRegExp = this._getSymbolRegExp();
	this.oInstrumentRegExp = this._getInstrumentRegExp();
};

caplin.extend(caplinx.utilities.SymbolMapper, caplin.widget.utilities.AbstractSymbolMapper);

/**
 * @return  flags for the symbol/instrument regular expressions.
 *
 * @private
 */
caplinx.utilities.SymbolMapper.prototype._getRegExpFlags = function()
{
	return this._isCaseSignificant() ? "" : "i";
};

/**
 * @return  the regular expression to match an FX symbol.
 *
 * @private
 */
caplinx.utilities.SymbolMapper.prototype._getSymbolRegExp = function()
{
	// NB: this is of the form ^(prefix)(instrument)$ so that RegExp.$2 extracts the instrument
	return new RegExp("^(" + this.sSymbolPrefix + ")([A-Z]{6})$", this._getRegExpFlags());
};

/**
 * @return  the regular expression to match an FX instrument.
 *
 * @private
 */
caplinx.utilities.SymbolMapper.prototype._getInstrumentRegExp = function()
{
	return new RegExp("^[A-Z]{6}$", this._getRegExpFlags());
};

/**
 * Defines the symbol prefix: designed to be overriden by sub-classing.
 * 
 * @return  the FX symbol prefix to be used in all mapping operations.
 * 
 * @private
 */
caplinx.utilities.SymbolMapper.prototype._getSymbolPrefix = function()
{
	return "/FX/";
};

/**
 * Defines case sensitivity: designed to be overriden by sub-classing.
 * 
 * @return  true if case is significant in the symbol/instrument mapping.
 * 
 * @private
 */
caplinx.utilities.SymbolMapper.prototype._isCaseSignificant = function()
{
	return true;
};

/**
 * @return  true if and only if the instrument is a valid FX instrument.
 * 
 * @public
 */
caplinx.utilities.SymbolMapper.prototype.isValidInstrument = function(sInstrument)
{
	return this.oInstrumentRegExp.test(sInstrument);
};

/**
 * @param {l_sObjectName} The RTTP object name.
 * @type boolean
 * @return <code>true</code> if the symbol represents a foreign exchange instrument, otherwise
 *         <code>false</code>.
 */
caplinx.utilities.SymbolMapper.prototype.isFxSymbol = function(l_sObjectName)
{
	return this.oSymbolRegExp.test(l_sObjectName);
};

/**
 * @param {l_sObjectName} The RTTP object name.
 * @type boolean
 * @return <code>true</code> if the symbol represents a fixed income instrument, otherwise
 *         <code>false</code>.
 */
caplinx.utilities.SymbolMapper.prototype.isFiSymbol = function(l_sObjectName)
{
	if(l_sObjectName.indexOf('/FI/') == 0) {
		return true;
	} else {
		return false;
	}
};

/**
 * Identifies if the symbol is a FI US symbol
 * 
 * @param {String} l_sObjectName
 * 		The object name to be checked.
 * 
 * @return {Boolean} <code>true</code> if the object name identifies the symbol to be a FI US symbol; otherwise <code>false</code>.
 */
caplinx.utilities.SymbolMapper.prototype.isFiUSSymbol = function(l_sObjectName)
{
	return false;
};

/**
 * @param {l_sObjectName} The RTTP object name.
 * @type boolean
 * @return <code>true</code> if the symbol represents an interest rate swap instrument, otherwise
 *         <code>false</code>.
 */
caplinx.utilities.SymbolMapper.prototype.isIrsSymbol = function(l_sObjectName)
{
	return false;
};

caplinx.utilities.SymbolMapper.prototype.isMmSymbol = function(l_sObjectName)
{
	return l_sObjectName.length >= 4 && l_sObjectName.substring(0,4) == "/MM/";
};

/**
 * @return  the symbol corresponding to the FX instrument.
 * 
 * @param {sInstrument}  the FX instrument
 * 
 * @public
 */
caplinx.utilities.SymbolMapper.prototype.getSymbol = function(sInstrument)
{
	return this.isValidInstrument(sInstrument) ? this.sSymbolPrefix + sInstrument : null;
};

/**
 * @return  the FX instrument corresponding to the symbol.
 * 
 * @param {sInstrument}  the FX symbol
 * 
 * @public
 */
caplinx.utilities.SymbolMapper.prototype.getInstrument = function(sSymbol)
{
	// NB: if the FX symbol RegExp matches, then RegExp.$2 contains the instrument
	return this.isFxSymbol(sSymbol) ? RegExp.$2 : null;
};

/**
 * @param {l_sObjectName} The RTTP object name.
 * 
 * @type String
 * @return A short description of the underlying instruments asset class.
 *         {@link caplin.trading.InstrumentTypes#UNSUPPORTED} should be returned if an unknown
 *         symbol is specified.
 */
caplinx.utilities.SymbolMapper.prototype.getAssetClass = function(l_sObjectName)
{		
	var l_sInstrumentType;
	
	if (this.isFxSymbol(l_sObjectName))
	{
		l_sInstrumentType = caplin.trading.InstrumentTypes.FX;
	}
	else if (this.isFiSymbol(l_sObjectName))
	{
		l_sInstrumentType = caplin.trading.InstrumentTypes.FI;
	}
	else if (this.isIrsSymbol(l_sObjectName))
	{
		l_sInstrumentType = caplin.trading.InstrumentTypes.IRS;
	}
    else if (this.isMmSymbol(l_sObjectName))
    {
        l_sInstrumentType = "MM";
    }
    else
	{
		SL4B_Accessor.getLogger().log(SL4B_DebugLevel.WARN,"SymbolMapper.getInstrumentType: symbol '" + l_sObjectName + "' is unsupported");
		l_sInstrumentType = caplin.trading.InstrumentTypes.UNSUPPORTED;
	}
	
	return l_sInstrumentType;
};

/**
 * @param {l_sObjectName} The RTTP object name.
 * 
 * @type String
 * @return A short description of the underlying instruments product group or sector. The asset
 *         class may be returned if the instrument does not have a specific product group.
 *         {@link caplin.trading.InstrumentTypes#UNSUPPORTED} should be returned if an unknown
 *         symbol is specified.
 */
caplinx.utilities.SymbolMapper.prototype.getProductGroup = function(l_sObjectName)
{
	return this.getAssetClass(l_sObjectName);
};