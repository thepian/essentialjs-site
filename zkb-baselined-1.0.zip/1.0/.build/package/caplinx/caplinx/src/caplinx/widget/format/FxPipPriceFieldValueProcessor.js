caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.AbstractFieldValueProcessor", true);
caplin.include("caplin.core.Logger");
caplin.include("caplin.core.LogLevel");

caplinx.widget.format.FxPipPriceFieldValueProcessor = function(nPricePart)
{
    this.m_sPricePart = nPricePart;

	this.m_nBigPipLength = 2;
	this.m_nSmallPipLength = 1;
	this.m_nTotalPipLength = this.m_nBigPipLength + this.m_nSmallPipLength;

	this.m_bShowSmallPip;
};
caplin.extend(caplinx.widget.format.FxPipPriceFieldValueProcessor, caplin.widget.format.AbstractFieldValueProcessor);

caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_ONE = 0;
caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_TWO = 1;
caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_THREE = 2;
caplinx.widget.format.FxPipPriceFieldValueProcessor.ALL_PARTS = -1;

caplinx.widget.format.FxPipPriceFieldValueProcessor.prototype.getValue = function(sBasePrice, oUpdateMetaData)
{
    var sPrice = null;

    if (oUpdateMetaData) 
    {
        if (sBasePrice != null) 
        {
            this.m_bShowSmallPip = oUpdateMetaData.bShowSmallPip;

            switch (this.m_sPricePart)
            {
                case caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_ONE:
					sPrice = this._getPartOneValue(sBasePrice);
                    break;
                case caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_TWO:
					sPrice = this._getPartTwoValue(sBasePrice);
                    break;
                case caplinx.widget.format.FxPipPriceFieldValueProcessor.PART_THREE:
					sPrice = this._getPartThreeValue(sBasePrice);
                    break;
                default:
                    caplin.core.Logger.log(caplin.core.LogLevel.WARNING, "FxPipPriceFieldValueProcessor: No Part defined");
                    break;
            }
        }
    }

    return sPrice;
};

caplinx.widget.format.FxPipPriceFieldValueProcessor.prototype._getPartOneValue = function(sPrice)
{
	if (this.m_bShowSmallPip === true)
	{
    	return sPrice.substr(0, sPrice.length - this.m_nTotalPipLength);
	}
    return sPrice.substr(0, sPrice.length - this.m_nBigPipLength);
};

caplinx.widget.format.FxPipPriceFieldValueProcessor.prototype._getPartTwoValue = function(sPrice)
{
	if (this.m_bShowSmallPip === true) 
	{
	    return sPrice.substr(sPrice.length - this.m_nTotalPipLength, this.m_nBigPipLength);
	}
	return sPrice.substr(sPrice.length - this.m_nBigPipLength, this.m_nBigPipLength);
};

caplinx.widget.format.FxPipPriceFieldValueProcessor.prototype._getPartThreeValue = function(sPrice)
{
	if (this.m_bShowSmallPip)
	{
	    return sPrice.charAt(sPrice.length - 1);
	}
    return "";
};
