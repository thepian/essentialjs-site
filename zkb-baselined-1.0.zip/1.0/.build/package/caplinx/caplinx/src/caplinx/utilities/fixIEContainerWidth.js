caplin.namespace("caplinx.utilities");

caplinx.utilities.fixIEContainerWidth = function(eElement)
{ 
	if(document.all){ 
		eElement.style.width = eElement.parentNode.clientWidth + 'px';
	}
}
	
