caplin.namespace("caplinx.chat")
caplin.include("caplinx.chat.LanguageFactory", true);
// add the English language to the Factory
caplinx.chat.English = caplinx.chat.LanguageFactory.addLanguage('English');


// Chatroom
caplinx.chat.English.addText("caplinx.chat.Chat.LogIn", "Log In");
caplinx.chat.English.addText("caplinx.chat.Chat.LogOut", "Log Out");
caplinx.chat.English.addText("caplinx.chat.Chat.Send", "Send");
caplinx.chat.English.addText("caplinx.chat.Chat.UserJoined", "{0} has joined {1}");
caplinx.chat.English.addText("caplinx.chat.Chat.UserLeft", "{0} has left {1}");
caplinx.chat.English.addText("caplinx.chat.Chat.SpecifyValidName", "You must specify a valid name.");
caplinx.chat.English.addText("caplinx.chat.Chat.JoinPublicChatRoom", "Join public room : {0}");
caplinx.chat.English.addText("caplinx.chat.Chat.ChatRoomAlreadyExists", "Chat room '{0}' already exists.");
caplinx.chat.English.addText("caplinx.chat.Chat.ChatRoomRemoved", "Chat room '{0}' has been closed, please choose or create another chatroom.");
caplinx.chat.English.addText("caplinx.chat.Chat.ConfirmUserWantsPrivateChat", "User '{0}' invites you to join private chat room '{1}' ({2}), click OK to proceed");
caplinx.chat.English.addText("caplinx.chat.Chat.UserLoggedOutPrivateChat", "User '{0}' has logged out of your private chat, please login again.");
caplinx.chat.English.addText("caplinx.chat.Chat.NoPrivateChatToSelf","Cannot start private chat to self, Please select a different user.");
caplinx.chat.English.addText("caplinx.chat.Chat.UserBlockedPrivateChat","blocked your invitation for private chat");
caplinx.chat.English.addText("caplinx.chat.Chat.UserConfirmedPrivateChat","accepted your invitation for private chat");
caplinx.chat.English.addText("caplinx.chat.Chat.UserNotLoggedIn","User {0} is currently not logged in, please wait until user receives your invitation");
caplinx.chat.English.addText("caplinx.chat.Chat.InviteUser","Invite user: {0}");
caplinx.chat.English.addText("caplinx.chat.Chat.NeedToInviteUsers","Please select users to invite to private chat {0}");
caplinx.chat.English.addText("caplinx.chat.Chat.UserDeletedChatRoom","Chat room owner '{0}' has deleted your private chat room '{1}'");
