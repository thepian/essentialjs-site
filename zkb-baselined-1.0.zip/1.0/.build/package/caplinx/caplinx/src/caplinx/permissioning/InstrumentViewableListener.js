caplin.namespace("caplinx.permissioning");

caplin.include("caplinx.permissioning.CaplinPermissionService");
caplin.include("caplin.security.permissioning.PermissionService");
caplin.include("caplin.security.permissioning.PermissionServiceListener");

/**
 * @private
 * @implements caplin.security.permissioning.PermissionServiceListener
 */
caplinx.permissioning.InstrumentViewableListener = function(sInstrument, oListener)
{
	this.m_oListener = oListener;

	this.m_nTradeTypeListenerId = caplin.security.permissioning.PermissionService.addPermissionListener(sInstrument, null, "VIEW", this);
};
caplin.implement(caplinx.permissioning.InstrumentViewableListener, caplin.security.permissioning.PermissionServiceListener);

/**
 * @see caplin.security.permissioning.PermissionServiceListener#onSinglePermissionChanged
 */
caplinx.permissioning.InstrumentViewableListener.prototype.onSinglePermissionChanged = function(bIsAuthorized, sProduct, sNamespace, sAction)
{
	//TODO this prop is not used
	this.m_bCanTradeInTile = bIsAuthorized;
	this.m_oListener.onViewPermissionsChanged(bIsAuthorized);
};

/**
 * @private
 */
caplinx.permissioning.InstrumentViewableListener.prototype._$cancelSubscription = function()
{
	caplin.security.permissioning.PermissionService.removeListener(this.m_nTradeTypeListenerId);
};