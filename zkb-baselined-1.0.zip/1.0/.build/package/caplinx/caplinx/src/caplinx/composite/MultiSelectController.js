caplin.namespace("caplinx.composite");

caplin.include("caplin.component.composite.CompositeComponentController", true);
/**
 * Constructs a new <code>MultiSelectController</code>.
 * 
 * @constructor
 * 
 * @class
 * TODO
 * 
 * @implements caplin.component.composite.CompositeComponentController
 */
caplinx.composite.MultiSelectController = function()
{
	this.m_mComponents = null;
};
caplin.implement(caplinx.composite.MultiSelectController, caplin.component.composite.CompositeComponentController);


/*******************************************************************************
 *      caplin.component.tree.CompositeComponentController Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.tree.CompositeComponentController#initialize
 */
caplinx.composite.MultiSelectController.prototype.initialize = function(mComponents)
{
};

/**
 * @private
 * @see caplin.component.tree.CompositeComponentController#finalize
 */
caplinx.composite.MultiSelectController.prototype.finalize = function(){
};