caplin.namespace("caplinx.renderer.handler");

caplin.include("caplin.renderer.handler.Handler", true);
caplin.include("caplin.grid.GridColumnFilter");
caplin.include("caplin.core.Exception");

caplinx.renderer.handler.FilterHandler = function()
{
};
caplin.implement(caplinx.renderer.handler.FilterHandler, caplin.renderer.handler.Handler);

caplinx.renderer.handler.FilterHandler.prototype.onChange = function(sNewValue, oControlRenderer)
{
	var oColumn = oControlRenderer.getFieldModel();
	var sFilterType = oControlRenderer.getConfig().getAttribute("filterType");
	var nSearchType = (sFilterType) ? caplin.grid.GridColumnFilter[sFilterType] : caplin.grid.GridColumnFilter.EXACT_MATCH;
	
	if(nSearchType === undefined)
	{
		throw new caplin.core.Exception("'" + sFilterType + "' is not a valid filter type.");
	}
	else if((nSearchType == caplin.grid.GridColumnFilter.WILDCARD) || (nSearchType == caplin.grid.GridColumnFilter.WILDCARD_CASE_SENSITIVE))
	{
		// uncommenting the line below would mean that wildcard searches are partial, and do not need to match from the start
		//sNewValue = "*" + sNewValue;
	}
	
	oColumn.clearFilters();
	oColumn.addFilter(nSearchType, sNewValue);
};

caplin.singleton("caplinx.renderer.handler.FilterHandler");
