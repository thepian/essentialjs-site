caplin.namespace("caplinx.trading.trademodel");

caplin.include("caplin.trading.trademodel.AbstractTradeFactory", true);

caplinx.trading.trademodel.FxTradeFactory = function(oTradeSubscriber)
{
	caplin.trading.trademodel.AbstractTradeFactory.call(this, oTradeSubscriber);
};
caplin.implement(caplinx.trading.trademodel.FxTradeFactory, caplin.trading.trademodel.AbstractTradeFactory);

caplinx.trading.trademodel.FxTradeFactory.prototype.createNewTrade = function(mTradeFields)
{
	if(mTradeFields.AssetClass != "FX"){
		throw new caplin.core.Exception( "caplinx.trading.trademodel.FxTradeFactory.createNewTrade expected AssetClass of 'FX'");
	}
	
	var sTradingProtocol = mTradeFields.TradingProtocol;
	var sTradingType = "SPOT";
	var sInstrumentName = mTradeFields.InstrumentName;
	
	if(sTradingProtocol !== "ESP" && sTradingProtocol !== "RFS")
	{
		throw new caplin.core.Exception("Do not support trade protocol: " + sTradingProtocol);
	}
	
	var oCaplinFactory = caplin.framework.ApplicationFactory.getInstance();
	var oStateMachine = oCaplinFactory.getStateMachine(sTradingProtocol);
	var oTrade = new caplin.trading.trademodel.FxTrade(oCaplinFactory, oStateMachine, this.m_oTradeSubscriber, sTradingProtocol, sTradingType);
	
	if(sTradingProtocol === "ESP")
	{
		var oTierDerivation = new caplin.trading.derivation.TierDerivation();
		oTrade.addDerivation(oTierDerivation);
		
		var oDerivation = new caplin.trading.derivation.SimpleDerivation("L1_BidSpotPrice");
		oDerivation.setInputFieldName("L1_BidPrice");
		oTrade.addDerivation(oDerivation);
		
		oDerivation = new caplin.trading.derivation.SimpleDerivation("L1_AskSpotPrice");
		oDerivation.setInputFieldName("L1_AskPrice");
		oTrade.addDerivation(oDerivation);
	}
	
	var oLeg = oTrade.getLeg(0);
	
	if(sInstrumentName !== undefined )
	{
		oLeg.setInstrument(sInstrumentName);
	}
	oLeg.setAmount("500000");
	return oTrade;
};
