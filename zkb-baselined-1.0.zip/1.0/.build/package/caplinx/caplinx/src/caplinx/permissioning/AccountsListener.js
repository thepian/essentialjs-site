caplin.namespace("caplinx.permissioning");

caplin.include("caplinx.permissioning.CaplinPermissionService");
caplin.include("caplin.security.permissioning.PermissionService");
caplin.include("caplin.security.permissioning.PermissionServiceListener");

/**
 * @private
 * @implements caplin.security.permissioning.PermissionServiceListener
 */
caplinx.permissioning.AccountsListener = function(sInstrument, oListener)
{
	this.m_oListener = oListener;

	this.m_nTradeTypeListenerId = caplin.security.permissioning.PermissionService.addPermissionSetListener('/FX/.*', 'Account', 'ALL', this);
};
caplin.implement(caplinx.permissioning.AccountsListener, caplin.security.permissioning.PermissionServiceListener);

/**
 * @private
 */
caplinx.permissioning.AccountsListener.prototype._$cancelSubscription = function()
{
	caplin.security.permissioning.PermissionService.removeListener(this.m_nTradeTypeListenerId);
};

caplinx.permissioning.AccountsListener.prototype.onPermissionsChanged = function(pPermissions, sProduct, sNamespace)
{
	if(pPermissions.length > 0)
	{
		this.m_oListener.onAccountsPermissionsChanged(true, pPermissions);
	}
	else
	{
		this.m_oListener.onAccountsPermissionsChanged(false);
	}
}