/**
 * @fileoverview
 * Defines caplinx.historicdata.ChartPrintHelper class.
 */

caplin.namespace("caplinx.historicdata");

caplin.include("caplin.chart.ChartViewListener", true);

/**
 * Constructs a new <code>ChartPrintHelper</code>.
 * <p>This class contains helper methods used by chart print templates.</p>
 * @class
 */
caplinx.historicdata.ChartPrintHelper = function()
{
};

/**
 * @private
 */
caplinx.historicdata.ChartPrintHelper.prototype.getParameters = function()
{
	var sSearch = document.location.search.substring(1);
	if( sSearch.length > 1 )			
	{
		var mParams = {};
		var pAllNameValues = sSearch.split("&");
		var pSingleNameValue;
		for(var i = 0, l = pAllNameValues.length; i < l; i++)
		{
			pSingleNameValue = pAllNameValues[ i ].split("=");
			mParams[ pSingleNameValue[ 0 ] ] = pSingleNameValue[ 1 ];
		}
	}
	return mParams;
};	

/**
 * @private
 */
caplinx.historicdata.ChartPrintHelper.prototype.init = function()
{
	if (!caplin.m_bPageLoaded) {
		caplin.notifyAfterClassLoad(new caplinx.historicdata.ChartPrintHelper.ListenerLoader());	
	} else {
		bPrintSetup = true;
		setupPrintPage();
	}
};

/***************** inner class *********************/

caplinx.historicdata.ChartPrintHelper.ListenerLoader = function()
{
};

caplinx.historicdata.ChartPrintHelper.ListenerLoader.prototype.onAfterClassLoad = function()
{
	var bPrintSetup = false;
	if (!bPrintSetup) {
		setupPrintPage();
	}
};

/***************** inner class *********************/

caplinx.historicdata.ChartPrintHelper.Timer = function(nNumberOfSeries)
{
	this.sTimeoutId = null;
	this.m_nWaitingNumberOfSeries = nNumberOfSeries;
	this.m_nNumberOfSeries = 0;
};
caplin.implement(caplinx.historicdata.ChartPrintHelper.Timer, caplin.chart.ChartViewListener);

caplinx.historicdata.ChartPrintHelper.Timer.prototype.onSeriesAddedToView = function(oSeries)
{
	this.m_nNumberOfSeries++;
	if (this.sTimeoutId) {
		window.clearTimeout(this.sTimeoutId);
	}
	if (this.m_nWaitingNumberOfSeries === this.m_nNumberOfSeries) {
		window.setTimeout("window.print()", 500);
	} else {
		// If we dont receive anything for 5 seconds assume we will never get back all our series
		// perhaps due to a connetion / network error
		this.sTimeoutId = window.setTimeout("window.print()", 5000);
	}
};










