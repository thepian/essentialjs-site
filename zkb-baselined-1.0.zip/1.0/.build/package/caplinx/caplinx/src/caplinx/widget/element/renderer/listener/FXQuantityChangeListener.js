caplin.namespace("caplinx.widget.element.renderer.listener");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.widget.element.renderer.listener.ChangeListener", true);
caplin.include("caplin.widget.element.renderer.listener.ViewInformingQuantityChangeListener", true);

/**
 * @constructor
 * 
 * Change listener that notifies any views that implement the {@link caplin.widget.containers.View} interface of the change in value.
 * 
 * @param {String} sFieldIdentifier
 * 		The field value identifier.
 * @param {Boolean} l_bNotifyPanels
 * 		A flat that determines if the panels should be informed of any updated.
 */
caplinx.widget.element.renderer.listener.FXQuantityChangeListener = function(sFieldIdentifier, l_bNotifyPanels, oTierLimitSource)
{
	caplin.widget.element.renderer.listener.ViewInformingQuantityChangeListener.apply(this, [sFieldIdentifier, l_bNotifyPanels]);
	this.m_oTierLimitSource = oTierLimitSource;
};
caplin.implement(caplinx.widget.element.renderer.listener.FXQuantityChangeListener, caplin.widget.element.renderer.listener.ChangeListener);
caplin.extend(caplinx.widget.element.renderer.listener.FXQuantityChangeListener, caplin.widget.element.renderer.listener.ViewInformingQuantityChangeListener);

/**
 * @see caplin.widget.element.renderer.listener.ChangeListener#isValidChange
 */
caplinx.widget.element.renderer.listener.FXQuantityChangeListener.prototype.isValidChange = function(oObject, sNewValue)
{	
	var sFailMessage = caplin.widget.element.renderer.listener.QuantityChangeListener.prototype.isValidChange.apply(this, [oObject, sNewValue]);
	if(!sFailMessage)
	{
		var sTierLimit = this.m_oTierLimitSource.getMaxTierLimit();
		if(sTierLimit && sNewValue > sTierLimit)
		{
			sFailMessage = ct.i18n("cx.widget.element.renderer.fx.quantity.error");
		}
	}
	
	if(sFailMessage === null)
	{
		if(this.m_oTierLimitSource.m_oTileView)
		{
			this.m_oTierLimitSource.m_oTileView.setViewModified(true);
		}
	}
	
	return sFailMessage;
};

/**
 * @see caplin.widget.element.renderer.listener.ChangeListener#shouldPropagateUpdate
 */
caplinx.widget.element.renderer.listener.FXQuantityChangeListener.prototype.shouldPropagateUpdate = function(oObject, sNewValue)
{
	oObject.setAmount(0, sNewValue);
	return false;
};
