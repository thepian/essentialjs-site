// MUSTDO: document

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.AbstractFieldValueProcessor", true);
caplin.include("caplinx.widget.format.PriceTextFormatter");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplinx.widget.format.FxPriceFieldValueProcessor");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.widget.format.PriceFieldValueProcessor = function(l_sPricingTypeFieldName, l_oFxPriceFieldValueProcessor)
{
	this.m_sPricingTypeFieldName = (l_sPricingTypeFieldName?l_sPricingTypeFieldName:"PricingType");
	this.m_oFxPriceFieldValueProcessor = (l_oFxPriceFieldValueProcessor?l_oFxPriceFieldValueProcessor:new caplinx.widget.format.FxPriceFieldValueProcessor());

	var l_oFormatterFactory = caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory();
	this.m_oBondNotationFormatter = l_oFormatterFactory.getTextFormatter("caplinx.widget.format.PriceTextFormatter");
	this.m_o3DpFormatter = l_oFormatterFactory.getTextFormatter("caplin.widget.format.DecimalPlaceTextFormatter", "3");
	
	this.m_oUsInstrumentRegExp = new RegExp("/FT/FI/((UST)|(AG)|(HG))");
};

caplin.extend(caplinx.widget.format.PriceFieldValueProcessor, caplin.widget.format.AbstractFieldValueProcessor);

caplinx.widget.format.PriceFieldValueProcessor.prototype.getValue = function(l_oObject, l_sFieldName)
{
	var l_sValue = l_oObject.getFieldValue(l_sFieldName);
	var l_sPricingType = l_oObject.getFieldValue(this.m_sPricingTypeFieldName);
	
	if (l_sValue != null)
	{
		switch (l_sPricingType)
		{
		case "PRC":
			var l_sObjectName = l_oObject.getName();
			if (l_sObjectName.match(this.m_oUsInstrumentRegExp))
			{
				l_sValue = this.m_oBondNotationFormatter.formatText(l_sValue);
			}
			else
			{
				l_sValue = this.m_o3DpFormatter.formatText(l_sValue);
			}
			break;
		case "RAT":
			l_sValue = this.m_oFxPriceFieldValueProcessor.getValue(l_oObject, l_sFieldName);
			break;
		case "YLD":
		default:
			l_sValue = this.m_o3DpFormatter.formatText(l_sValue);
		}
	}
	
	return l_sValue;
};
