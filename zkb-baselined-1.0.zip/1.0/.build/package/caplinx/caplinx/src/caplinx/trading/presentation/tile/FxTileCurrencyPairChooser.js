caplin.namespace("caplinx.trading.presentation.tile");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.dom.controls.form.AutoCompleteComboBox");
caplin.include("caplin.services.AbstractFactory");

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser = function(sTileElementLookupIdPrefix, oFxTile)
{
	this.m_oCurrencyPairEditEvent = null;
	this.m_oFxTile = oFxTile;
	this.m_oAutoCompleteProvider = caplin.services.AbstractFactory.getInstance().getCurrencyPairAutoCompleteProvider();
	this.m_sInstrumentName = oFxTile.m_sInstrumentName;
	this._createTileAutoComplete(sTileElementLookupIdPrefix, this);
};

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.onAfterClassLoad = function()
{
	caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.CURRENCY_ALERT_TEXT = ct.i18n("cx.trading.presentation.fx.tile.currency.pair.chooser.alert");
};
caplin.notifyAfterClassLoad(caplinx.trading.presentation.tile.FxTileCurrencyPairChooser);

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.prototype.setValue = function(sInstrumentName)
{
	this.m_oAutoCompleteBox.setValue(sInstrumentName);
	this.m_eCurrencyLabel.innerHTML = sInstrumentName;
	this.m_sInstrumentName = sInstrumentName;
};

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.prototype._createTileAutoComplete = function(sTileElementLookupIdPrefix, self)
{
	var oElem = document.getElementById(sTileElementLookupIdPrefix + "_tileTitle");
	
	var l_mProperties = {
		inputClassName: 'AutoCompleteInput',
		listClassName: 'AutoCompleteList',
		listItemClassName: 'AutoCompleteListItem',
		inputSize: 8,
		inputMaxLength: 6,
		autoCompleteText: false,
		displayListOnSingleResult: true,
		blurFiresSelect: true
	};
	
	this.m_oAutoCompleteBox = new caplin.dom.controls.form.AutoCompleteComboBox(oElem, this.m_oAutoCompleteProvider, this, l_mProperties);
	this.m_eAutoCompleteBoxElement = this.m_oAutoCompleteBox.getInputElement();
	
		var fEditKeyPress = function(){
        if (self.m_oCurrencyPairEditEvent == null) {
			self.m_oCurrencyPairEditEvent = {
				bWasEnabledAtEditStart: self.m_oFxTile.m_bIsButtonsEnabled
            };
            if (self.m_oFxTile.m_bIsButtonsEnabled == true) {
                self.m_oFxTile.disableButtons(caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.CURRENCY_ALERT_TEXT);
                self.m_oFxTile.m_oController.editingCurrencyPairChooser(true);
            }
        }
    };
    this.m_oAutoCompleteBox.setEditStartedListener(fEditKeyPress);
		
	this.m_eCurrencyLabel = document.createElement("p");
	
	this.m_eCurrencyLabel.onmouseover = function() {
		self.m_eCurrencyLabel.className = "hover";
	};
	this.m_eCurrencyLabel.onmouseout = function() {
		self.m_eCurrencyLabel.className = "";
	};
	this.m_eCurrencyLabel.onclick = function() {
		self._showCurrencyInput(true);
	};
	
	oElem.appendChild(this.m_eCurrencyLabel);
	
	this._showCurrencyInput(false);
	this.setValue(this.m_sInstrumentName);
};

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.prototype._showCurrencyInput = function(bShow)
{
	if (bShow) 
	{
		this.m_eCurrencyLabel.style.display = "none";
		this.m_eAutoCompleteBoxElement.style.display = "";
		this.m_oAutoCompleteBox.focus();
		this.m_eAutoCompleteBoxElement.select();
	}
	else 
	{
		this.m_eCurrencyLabel.style.display = "";
		this.m_eAutoCompleteBoxElement.style.display = "none";
	}
};

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.prototype.onSelect = function(l_sValue, sTriggeringEvent)
{
	l_sValue = l_sValue.replace(/</g,"&lt;").replace(/>/g,"&gt;");
	if (l_sValue.toUpperCase() != this.m_sInstrumentName || document.activeElement !== this.m_eAutoCompleteBoxElement || sTriggeringEvent === "EnterKeyDown") 
	{
		if (l_sValue.length == 3) 
		{
			return caplin.dom.controls.form.AutoCompleteComboBox.SELECT_STATUS.REPOPULATE;
		}
		this.m_oFxTile.m_oController.editingCurrencyPairChooser(false);
		this.m_oFxTile._clearPrices(true);
		this.m_oFxTile._setCurrency(l_sValue.toUpperCase());
		this.m_oCurrencyPairEditEvent = null;
		this.m_oFxTile._resetCurrency();
		this._fireSetButtonStateAfterEdit(this);
		this._showCurrencyInput(false);
		if (!this.m_oAutoCompleteProvider.isValidCurrencyPair(l_sValue)) 
		{
			this.m_oFxTile.m_oPermissionModel.onViewPermissionsChanged(false);
		}
	}
	else
	{
		this.m_oAutoCompleteBox.m_bHasfocus = true;
	}
};

caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.prototype._fireSetButtonStateAfterEdit = function(self){
	var nStart = (new Date()).valueOf();
	var fnSetButtonStateAfterEdit = function(){
		if (self.m_oCurrencyPairEditEvent && self.m_oCurrencyPairEditEvent.bWasEnabledAtEditStart == true) {
			var end = (new Date()).valueOf();
			var delta = end - nStart;
			self.m_oFxTile.enableButtons();
		}
		self.m_oCurrencyPairEditEvent = null;	
	}
	//use timeout to stop click on bid/ask buttons being processed
	window.setTimeout(fnSetButtonStateAfterEdit, 200);
}
