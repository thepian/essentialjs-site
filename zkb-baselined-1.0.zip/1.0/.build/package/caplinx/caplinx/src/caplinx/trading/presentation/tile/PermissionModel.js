caplin.namespace("caplinx.trading.presentation.tile");
caplin.include("caplinx.permissioning.CaplinPermissionService");


caplinx.trading.presentation.tile.PermissionModel = function(m_oController)
{
	this.m_oController = m_oController;
	this.m_bTileTradingPermissioned = false;
	this.m_bTileViewingPermissioned = false;
	this.m_bHasAccounts  = false;
	this.m_nCurrentPermission = 0;
	this.m_sInstrumentName = null;
};

caplinx.trading.presentation.tile.PermissionModel.VIEW_PERMISSION = 1;
caplinx.trading.presentation.tile.PermissionModel.ACCOUNTS_PERMISSION = 2;
caplinx.trading.presentation.tile.PermissionModel.ACCOUNT_SELECTED = 4;
caplinx.trading.presentation.tile.PermissionModel.RFS_PERMISSIONED = 8;
caplinx.trading.presentation.tile.PermissionModel.ESP_PERMISSIONED = 16;

caplinx.trading.presentation.tile.PermissionModel.prototype.setInstrumentName = function(sInstrumentName){

	if(this.m_sInstrumentName != null){
		this.deregisterPermissioningListeners();
	}
	this.m_sInstrumentName = sInstrumentName;
	this.registerPermissioningListeners();
}

caplinx.trading.presentation.tile.PermissionModel.prototype._changePermissionValue = function(bIsPermitted, nPermission)
{
	if (bIsPermitted) 
	{
		this.m_nCurrentPermission |= nPermission;
	}
	else
	{
		var nPermissionValue = this.m_nCurrentPermission;
		this.m_nCurrentPermission ^= nPermission;
		if (this.m_nCurrentPermission > nPermissionValue) 
		{
			this.m_nCurrentPermission ^= nPermission;
		}
	}
};

caplinx.trading.presentation.tile.PermissionModel.prototype.registerPermissioningListeners = function()
{
	var sInstrument = "/FX/" + this.m_sInstrumentName;
	this.m_nTileTradableListenerID = caplinx.permissioning.CaplinPermissionService.addTileTradableListener(sInstrument, this);
	this.m_nTicketTradableListenerID = caplinx.permissioning.CaplinPermissionService.addTicketTradableListener(sInstrument, this);
	this.m_nTileViewableListenerID = caplinx.permissioning.CaplinPermissionService.addInstrumentViewableListener(sInstrument, this);
	this.m_nAcccountsListenerID = caplinx.permissioning.CaplinPermissionService.addAccountsListener(sInstrument, this);
};

caplinx.trading.presentation.tile.PermissionModel.prototype.deregisterPermissioningListeners = function()
{
	caplinx.permissioning.CaplinPermissionService.removeListener(this.m_nTileTradableListenerID);
	this.m_bTileTradingPermissioned = false;
	caplinx.permissioning.CaplinPermissionService.removeListener(this.m_nTicketTradableListenerID);
	this.m_bTicketTradingPermissioned = false;
	caplinx.permissioning.CaplinPermissionService.removeListener(this.m_nTileViewableListenerID);
	this.m_bTileViewingPermissioned = false;
};

// The event handler/callback method that is called when tile permissions (ESP permissions) change
caplinx.trading.presentation.tile.PermissionModel.prototype.onTilePermissionsChanged = function(bIsPermitted)
{
	this._changePermissionValue(bIsPermitted, caplinx.trading.presentation.tile.PermissionModel.ESP_PERMISSIONED);
	this.m_bTileTradingPermissioned = bIsPermitted;
	this.m_oController.updateTileState();
};

// The event handler/callback method that is called when ticket permissions (RFS permissions) change
caplinx.trading.presentation.tile.PermissionModel.prototype.onTicketPermissionsChanged = function(bIsPermitted)
{
	this._changePermissionValue(bIsPermitted, caplinx.trading.presentation.tile.PermissionModel.RFS_PERMISSIONED);
	this.m_bTicketTradingPermissioned = bIsPermitted;
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.PermissionModel.prototype.onViewPermissionsChanged = function(bIsPermitted)
{
	this._changePermissionValue(bIsPermitted, caplinx.trading.presentation.tile.PermissionModel.VIEW_PERMISSION);
	this.m_bTileViewingPermissioned = bIsPermitted;
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.PermissionModel.prototype.onAccountsPermissionsChanged = function(bIsPermitted)
{
	this._changePermissionValue(bIsPermitted, caplinx.trading.presentation.tile.PermissionModel.ACCOUNTS_PERMISSION);
	this.m_bHasAccounts = bIsPermitted;
	this.m_oController.updateTileState();
};

caplinx.trading.presentation.tile.PermissionModel.prototype.getCurrentPermission = function()
{
	return this.m_nCurrentPermission;
};
