caplin.namespace("caplinx.utilities");

caplinx.utilities.createCaptionAccessor = function(oContext, sMethodName, sCaptionRef)
{
	var sCaptionParsed = sCaptionRef.toLowerCase().replace(/ /gim, '_');
	var sWebCentricTabId = 'tab_item_id_' + sCaptionParsed;
	var eTabCaption = document.getElementById(sWebCentricTabId).getElementsByTagName('span')[0]
	oContext[sMethodName] = function(sCaption){ 
		eTabCaption = caplin.dom.Utility.setInnerHtml(eTabCaption, sCaption);
	}
};
 