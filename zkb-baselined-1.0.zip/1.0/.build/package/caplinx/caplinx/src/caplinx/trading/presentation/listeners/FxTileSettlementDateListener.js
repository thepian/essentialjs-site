caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxTileSettlementDateListener = function(oFxTile)
{
	this.m_oFxTile = oFxTile;	
};

caplinx.trading.presentation.listeners.FxTileSettlementDateListener.prototype.dataFieldChanged  = function(oValue, oOldValue)
{
	this.m_oFxTile.settlementDateEventHandler();
};