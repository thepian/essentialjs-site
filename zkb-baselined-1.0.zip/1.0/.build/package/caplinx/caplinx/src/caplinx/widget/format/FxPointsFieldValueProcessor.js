caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.AbstractFieldValueProcessor", true);
caplin.include("caplinx.widget.format.PriceTextFormatter");
caplin.include("caplin.framework.ApplicationFactory");


caplinx.widget.format.FxPointsFieldValueProcessor = function()
{
	this.m_sPrecisionFieldName = "L1_PointsPrecision";
	this.m_sPointScaleFactorFieldName = "L1_PointsScaleFactor";

	this.m_oFormatterFactory = caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory();
	
	this.m_oBracketNegativeAmountFormatter = this.m_oFormatterFactory.getTextFormatter("caplinx.widget.format.BracketNegativeAmountsTextFormatter");
	
	this.m_sNegativeChar = "-";
};

caplin.extend(caplinx.widget.format.FxPointsFieldValueProcessor, caplin.widget.format.AbstractFieldValueProcessor);

caplinx.widget.format.FxPointsFieldValueProcessor.prototype.getValue = function(l_oObject, l_sFieldName)
{
	var l_sPrecisionValue = l_oObject.getFieldValue(this.m_sPrecisionFieldName);
	var l_sScaleFactorValue = l_oObject.getFieldValue(this.m_sPointScaleFactorFieldName);
	var l_sPrice = l_oObject.getFieldValue(l_sFieldName);
	
	if (!isNaN(l_sPrice) && l_sPrice !== "")
	{
		if (!(l_sPrecisionValue === undefined) && !(l_sScaleFactorValue === undefined))
		{
			var l_bIsNegative = (l_sPrice.substring(0, 1) == this.m_sNegativeChar);
			if (l_bIsNegative)
			{
				l_sPrice = l_sPrice.substring(1);
			}
			l_sPrice = (Math.round(l_sPrice * Math.pow(10, l_sPrecisionValue)) / Math.pow(10, l_sScaleFactorValue)) + "";
			if (l_bIsNegative && l_sPrice != 0)
			{
				l_sPrice = this.m_sNegativeChar + l_sPrice;
			}
		}
		
		// always convert negative numbers to bracketed values
		l_sPrice = this.m_oBracketNegativeAmountFormatter.formatText(l_sPrice);
	}
	else if (l_sPrice === undefined)
	{
		l_sPrice = null;
	}
	
	return l_sPrice;
};
