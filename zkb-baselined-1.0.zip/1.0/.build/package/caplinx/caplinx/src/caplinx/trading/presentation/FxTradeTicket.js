caplin.namespace("caplinx.trading.presentation");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.widget.formcontrols.GraphicalDivButton");
caplin.include("caplin.widget.formcontrols.ThreeImageButton");
caplin.include("caplin.widget.formcontrols.CaplinImageButton");
caplin.include("caplin.widget.formcontrols.ImageButton");
caplin.include("caplin.widget.message.MessageManager");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");
caplin.include("caplin.element.formatter.DateFormatter");
caplin.include("caplin.widget.format.TimeTextFormatter");
caplin.include("caplin.widget.calendar.CalendarButton");
caplin.include("caplin.widget.utilities.StyleHelper");

caplin.include("caplin.trading.presentation.TradeModelToRendererAdapter");
caplin.include("caplin.dom.controls.form.AutoCompleteComboBox");
caplin.include("caplin.services.AbstractFactory");
caplin.include("caplin.services.CurrencyPairAutoCompleteProvider");
caplin.include("caplin.core.Logger");
caplin.include("caplin.core.LogLevel");
caplin.include("caplinx.trading.presentation.listeners.TradeTypeListener");
caplin.include("caplinx.trading.presentation.FxTradeTicketController");
caplin.include("caplinx.trading.presentation.listeners.StateChangedListener");
caplin.include("caplinx.tobo.TOBOUserManagerListener",true);
caplin.include("caplinx.tobo.TOBOUserManager",true);
caplin.include("caplinx.component.userselect.UserSelectorComponent");

caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplinx.widget.format.QuantityTextFormatter");
caplin.include("caplin.core.Utility");
caplin.include("caplin.core.ApplicationProperties");
caplin.include("caplin.widget.element.IdentifierFactory");
caplin.include("caplin.widget.format.StandardFieldValueProcessor");
caplin.include("caplin.core.Exception");
caplin.include("caplin.widget.element.renderer.ElementRenderer");
caplin.include("caplin.dom.AbstractFactory");
caplin.include("caplin.security.permissioning.PermissionService");
caplin.include("caplin.dom.Utility");
/**
 * @class  A user form which allows spot, forward and swap trades foreign exchange to be executed.
 * @param {Map} l_oParams  Configuration parameters.
 */
caplinx.trading.presentation.FxTradeTicket = function(l_oParams)
{
	// sequence number for this FX Trade Ticket instance
	/** @private */
	this.m_nSequenceNumber = caplinx.trading.presentation.FxTradeTicket.counter++;
	// HTML template (imported by webcentric);
	/** @private */
	this.m_sHtml = l_oParams.sHtmlTemplate;
	/** @private */
	this.m_oFactory = caplin.framework.ApplicationFactory.INSTANCE;
	/** @private */
	this.m_oFieldManager = this.m_oFactory.getFieldManager();
	/** @private */
	this.m_oRootTicketElement = null;
	/** @private */
	this.m_bCreateNewTradeOnCancel = false;
	/** @private */
	this.m_sTradingProtocol = null;
	/** @private */
	this.m_oLeg1Adapter = null;
	/** @private */
	this.m_oTradeModel = null;
	/** @private */
	this.m_oTradeModelListener = null;
	/** @private */
	this.m_oTextFormatterFactory = this.m_oFactory.getTextFormatterFactory();
	/** @private */
	this.m_oZeroDecimalPlaceTextFormatter = new caplin.widget.format.DecimalPlaceTextFormatter(0, true);
	/** @private */
	this.m_oAutoCompleteCurrencyProvider = caplin.services.AbstractFactory.getInstance().getCurrencyPairAutoCompleteProvider();
	/** @private */
	this.m_oQuantityTextFormatter = this.m_oTextFormatterFactory.getTextFormatter("caplinx.widget.format.QuantityTextFormatter");
	/** @private */
	this.m_oTimeTextFormatter = new caplin.widget.format.TimeTextFormatter();
	/** @private */
	this.m_mDateFormatParams = { inputFormat:"Ymd", outputFormat: "localize" };
	/** @private */
	this.m_fCountdownFunction = caplin.core.Utility.getFunctionPointerFromMethod(this, "_updateTimeout");
	///////////////////////////
	// Widgets
	///////////////////////////
	/** @private */
	this.m_oRequestQuoteButton = null;
	/** @private */
	this.m_oStatusTimerHolder = null;
	/** @private */
	this.m_oStatusMessageHolder = null;
	/** @private */
	this.m_oInstrumentNameWidget = null;
	/** @private */
	this.m_oProductSearchWidget = null;
	/** @private */
	this.m_oTradeTypeControl = null;
	/** @private */
	this.m_oAccountWidget = null;
	/** @private */
	this.m_oFlipCurrencyControl = null;
	/** @private */
	this.m_oDealtAmountLeg1Widget = null;
	/** @private */
	this.m_oDealtAmountLeg2Widget = null;
	/** @private */
	this.m_oAmountDisplayLeg1 = null;
	/** @private */
	this.m_oDetailsDisplayLeg2 = null;
	/** @private */
	this.m_nDefaultAmount = 500000;
	
	/** @private */
	this.m_oExecuteButtonLeft = null;
	/** @private */
	this.m_oExecuteButtonRight = null;
	
	/** @private */
	this.m_oSettlementTenorLeg1Control = null;
	/** @private */
	this.m_oSettlementTenorLeg2Control = null;
	
	/** @private */
	this.m_oFooterCancelButton = null;
	/** @private */
	this.m_oFooterCloseButton = null;
	
	/** @private */
	this.m_oSettlementDateCalendarLeg1Control = null;
	/** @private */
	this.m_oSettlementDateCalendarLeg2Control = null;
	
	/** @private */
	this.m_bSettlementDateSet = false;
	/** @private */
	this.m_bTenorSet = false;
	/** @private */
	this.m_nOverallTimeOut = null;
	
	/** @private */
	this.m_mExternalConfirmationData = null;
	/** @private */
	this.m_sGlobalImgRoot = caplin.core.ApplicationProperties.getProperty('image.source');
	this.m_sLocalImgRoot = "source/theme/packages/trading/presentation/images/";
	
	this.m_mTemplateElements = {};
	this.m_mFieldControlHolders = {};
	
	/** @private */
	this.m_bSwapLegsAreCoupled = true;
	/** @private */
	this.m_bIsInitialised = false;
	/** @private */
	this.m_bIsFooterInitialised = false;
	this.m_bValidCurrencyPair = true;
	
	this.openToolTipMessage = ct.i18n("cx.trading.presentation.fx.ticket.decouple");
	this.closedToolTipMessage = ct.i18n("cx.trading.presentation.fx.ticket.couple");
	
    /** @private */
	this.m_bInitialized = false;
	/** @private */
	this.m_nOriginalHeight = 0;
	/** @private */
	this.m_nOriginalWidth = 0;
	/** @private */
	this.m_nFwdSizeIncrease = 0;
	/** @private */
	this.m_nSwapSizeIncrease = 0;
	
	// Some storage fields for TOBO user/account
	this.m_sCurrentlySelectedMainAccount;
	this.m_sCurrentlySelectedToboUser;
	
};
caplinx.trading.presentation.FxTradeTicket.prototype.name = "FxTradeTicket";

caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SPOT = "SPOT";
caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_FORWARD = "FWD";
caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SWAP = "SWAP";
caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SWAPFWD = "FWDFWDSWAP";

caplinx.trading.presentation.FxTradeTicket.COUPLED_IMAGE = "link-close.gif";
caplinx.trading.presentation.FxTradeTicket.UNCOUPLED_IMAGE = "link-open.gif";

caplin.implement(caplinx.trading.presentation.FxTradeTicket,caplinx.tobo.TOBOUserManagerListener);

/**
 * A counter used for ticket panel uniquness
 */
caplinx.trading.presentation.FxTradeTicket.counter = 0;

/**
 * Sets the state based variables for the fx trade ticket to be the default values.
 * The purpose of this method is to ensure state variables are give the correct default values
 * during initialisation and re-initialisation
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setDefaultStateValue = function()
{
	// Default these to spot. They will be used for recycling the ticket with the previous values selected
	// for tenor and trading type.
	this.m_sCurrentTradingType = caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SPOT;
	
};

caplinx.trading.presentation.FxTradeTicket.prototype.setObjectName = function(name)
{
	this.m_sObjectName = name;
	this.m_bValidState = true;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setBuySell = function(l_sBuyOrSell)
{
	this.m_sBuyOrSell = l_sBuyOrSell;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setProtocol = function(l_sProtocol)
{
	this.m_sTradingProtocol = l_sProtocol;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setAmount = function(l_nAmount)
{
	this.m_nAmount = l_nAmount;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setInitialDealtCurrency = function(l_sDealtCurrency)
{
	this.m_sInitialDealtCurrency = l_sDealtCurrency;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setAccount = function(l_sAccount)
{
	this.m_sAccount = l_sAccount;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setConfirmationData = function(l_mConfirmationData)
{
	this.m_mExternalConfirmationData = l_mConfirmationData;
};

caplinx.trading.presentation.FxTradeTicket.prototype.setFwdSizeIncrease = function(nSizeIncrease)
{
	this.m_nFwdSizeIncrease = parseInt(nSizeIncrease);
};

caplinx.trading.presentation.FxTradeTicket.prototype.setSwapSizeIncrease = function(nSizeIncrease)
{
	this.m_nSwapSizeIncrease = parseInt(nSizeIncrease);
};



/////////////////////////////////////////////
// Webcentric methods implementations
// For First time open:
// getElement()-> attach()-> initialise()
// Thereafter:
//	reinitialise() ->
//
// The HTML page that this ticket integrates with is loaded by
// webcentric when the ticket is opened for the first time.
// The page is defined in: CaplinTrader/source/dialogs/dialog_fxticket.html
// This method should ONLY be called from webcentric it creates the DOM elements
// contained within the ticket.
///////////////////////////////////////////////////////////////////////
caplinx.trading.presentation.FxTradeTicket.prototype.initialize = function(l_oParameters)
{
	this.m_oController = new caplinx.trading.presentation.FxTradeTicketController(this);
	this.m_nOriginalHeight = l_oParameters.height;
	this.m_nOriginalWidth = l_oParameters.width;
	
	this.m_oTicketBodyElement = document.getElementById("FX_TICKET_" + this.m_nSequenceNumber);
	
	if (this.m_oTicketBodyElement == null) 
	{
		return;
	}
	
	this.m_bInitialized = true;
	
	if (this.m_bIsFooterInitialised == false) 
	{
		this._initialiseFooterButtons();
		this._setButtonsForInitial();
		this.m_bIsFooterInitialised = true;
	}
	
	if (this.m_mExternalConfirmationData != null) 
	{
		this.m_oTicketBodyElement.className = this._getConfirmedClassName("spot");
		this._displayConfirmation(this.m_mExternalConfirmationData, true);
		this._setButtonsForTradeAgain();
		return;
	}
	
	this._setDefaultStateValue();
	var sInstrumentName = this.m_sObjectName.substring(4);
	this.m_nId = caplin.widget.element.IdentifierFactory.getIdentifier();
	
	this.m_oTradeTypeListener = new caplinx.trading.presentation.listeners.TradeTypeListener(this);
	this.m_oStateChangedListener = new caplinx.trading.presentation.listeners.StateChangedListener(this);
	
	this._bindTrade(sInstrumentName, false);
	this._initialiseRenderers(this.m_oLeg1Adapter, sInstrumentName);
	this._setTicketDisplay(false);
	this._setTimerMessage("");
	this.m_bIsInitialised = true;
	
	try 
	{
		this.m_oAutoCompleteCurrencyProvider.validateEntry(sInstrumentName.slice(0,6));
		this.m_bValidCurrencyPair = true;
		this._checkIfGetQuoteIsEnabled();
	} 
	catch (e) 
	{
		caplin.widget.message.MessageManager.getInstance().alert(e.getMessage());
		this._disableGetQuoteButton(e.getMessage());
		this.m_bValidCurrencyPair = false;
	}
};

/*
 * Called by webcentric
 */
caplinx.trading.presentation.FxTradeTicket.prototype.reinitialize = function(l_oParameters)
{
	if (this.m_bInitialized === false) 
	{
		this.initialize(l_oParameters);
		return;
	}
	
	if (this.m_mExternalConfirmationData != null) 
	{
		this.m_oTicketBodyElement.className = this._getConfirmedClassName("spot");
		this._displayConfirmation(this.m_mExternalConfirmationData, true);
		this._setButtonsForTradeAgain();
		return;
	}
	
	if (this.m_bIsInitialised != true) 
	{
		this.initialize(l_oParameters);
		return;
	}
	var sInstrumentName = this.m_sObjectName.substring(4);
	this._bindTrade(sInstrumentName, false);
	this._setTicketDisplay(false);
	this._setTimerMessage("");
	
	try 
	{
		this.m_oAutoCompleteCurrencyProvider.validateEntry(sInstrumentName);
		this.m_bValidCurrencyPair = true;
		this._checkIfGetQuoteIsEnabled();
	} 
	catch (e) 
	{
		caplin.widget.message.MessageManager.getInstance().alert(e.getMessage());
		this._disableGetQuoteButton(e.getMessage());
		this.m_bValidCurrencyPair = false;
	}
};

/**
 * Binds a trade model to the ticket.
 * This method will be called every time the ticket is recycled. Takes the instrument the trade model will be based on.
 * Takes a boolean which when true will keep the current models type and trade values. This is required for some recycle methods.
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._bindTrade = function(sInstrumentName, bPersistType, bPersistAccount)
{
	this.m_oController.unregisterListeners();
	// If bPersistAccount has not been defined, then use the value specified for bPersistType. This allows some legacy support
	// from when these two options were a single option to set both.
	if(bPersistAccount === undefined)
	{
		bPersistAccount = bPersistType;
	}
	
	// if the trade model has been prev set then we need to cache a few values for later use
	var oOldTradeModel = this.m_oTradeModel;
	this.m_oTradeModel = this.m_oFactory.createFXTrade("RFS", sInstrumentName);
	
	this.m_oTradeModel.setUserTradedOnBehalfOf(this.m_sCurrentlySelectedToboUser);
	
	// check and reclaim previous account
	if (oOldTradeModel != null && oOldTradeModel.getAccount() != undefined && bPersistAccount == true) 
	{
		this.m_oTradeModel.setAccount(oOldTradeModel.getAccount());
	}
	// check and reclaim trade type
	if (oOldTradeModel != null && oOldTradeModel.getTradingType() != undefined && bPersistType == true) 
	{
		this.m_oTradeModel.setTradingType(oOldTradeModel.getTradingType());
	}
	if (oOldTradeModel != null) 
	{
		oOldTradeModel.stop();
	}
	
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var oLeg2 = this.m_oTradeModel.getLeg(1);
	
	if (this.m_sInitialDealtCurrency) 
	{
		oLeg1.setDealtCurrency(this.m_sInitialDealtCurrency);
		this.m_sInitialDealtCurrency = null;
	}
	
	this.m_oLeg1Adapter = this._bindLeg(this.m_oLeg1Adapter, oLeg1);
	this.m_oLeg2Adapter = this._bindLeg(this.m_oLeg2Adapter, oLeg2);
	
	if (this.m_oAccountWidget != null && bPersistAccount == false) 
	{
		this._setSelectedAccount(this.m_sCurrentlySelectedMainAccount);
	}
	
	this.m_oTradeTypeListener.setModel(this.m_oTradeModel);
	this.m_oStateChangedListener.setModel(this.m_oTradeModel);
	this.m_oController.registerListeners();
};

caplinx.trading.presentation.FxTradeTicket.prototype._$getTrade = function()
{
	return this.m_oTradeModel;
};

caplinx.trading.presentation.FxTradeTicket.prototype._setSelectedAccount = function(sValue)
{
		this.m_oTradeModel.setAccount(this.m_sCurrentlySelectedMainAccount);
		this.m_oAccountWidget.setValue(this.m_sCurrentlySelectedMainAccount);
};

/*
 * Sets ticket display to a default state. To be used with spot/fwd trade types
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTicketDisplay = function(bPersistValues)
{
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	
	if (bPersistValues == false) 
	{
		var nAmount = this.m_nAmount ? this.m_nAmount : this.m_nDefaultAmount;
		this._setLegToDefaults(0, "SPOT", nAmount);
	}
	
	this.m_oInstrumentNameWidget.getInputElement().value = oLeg1.getFXInstrument().slice(0,6);
	
	// There is no need to convert the dealt currency to an upper-case value, as
	// it is converted and stored as an upper-case value.
	this.m_oFlipCurrencyControl.setCaption(oLeg1.getDealtCurrency());
	//this.m_oCurrencyDisplayLeg1.innerHTML = oLeg1.getDealtCurrency();
	
	var sTradeType = this.m_oTradeModel.getTradingType();
	if (sTradeType == "SPOT" || sTradeType == "FWD") 
	{
		this.m_oTradeTypeControl.setValue("SPOT/FWD");
	}
	
	this.m_oDealtAmountLeg1Widget.value = this.m_oQuantityTextFormatter.insertCommas(oLeg1.getAmount());
	this.m_oAccountWidget.setValue(this.m_oTradeModel.getAccount());
	oLeg1.initialisePrices();
	
	this._resetTradeView();
	this.resizeTicket(sTradeType);
};

/*
 * Sets ticket display to a default state. To be used with swap/fwdfwdswap trade types
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTicketDisplayFwd = function(bPersistValues)
{
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var oLeg2 = this.m_oTradeModel.getLeg(1);
	
	if (bPersistValues == false) 
	{
		this._setLegToDefaults(0, "SPOT", this.m_nDefaultAmount);
		this._setLegToDefaults(1, "1M", this.m_nDefaultAmount);
	}
	else 
	{
		var l_oDate = oLeg2.getSettlementDate();
		if (l_oDate) 
		{
			this.m_oSettlementDateLeg2Widget.innerHTML = caplin.element.formatter.DateFormatter.format(l_oDate, this.m_mDateFormatParams);
		}
	}
	
	this.m_oInstrumentNameWidget.getInputElement().value = oLeg1.getFXInstrument();
	
	// There is no need to convert the dealt currency to an upper-case value, as
	// it is converted and stored as an upper-case value.
	this.m_oFlipCurrencyControl.setCaption(oLeg1.getDealtCurrency());
	this.m_oFarlegFlipCurrencyControl.setCaption(oLeg1.getDealtCurrency());
	this._setButtonsForTradeAgain();
	//this.m_oCurrencyDisplayLeg2.innerHTML = oLeg1.getDealtCurrency();
	
	this.m_oDealtAmountLeg2Widget.value = this.m_oQuantityTextFormatter.insertCommas(oLeg2.getAmount());
	//this.m_oAmountDisplayLeg2.innerHTML = this.m_oQuantityTextFormatter.insertCommas(oLeg2.getAmount());
	oLeg2.initialisePrices();
	
	this._resetTradeView();
};

caplinx.trading.presentation.FxTradeTicket.prototype._setLegToDefaults = function(sLegId, sTenor, sAmount)
{
	var l_oLeg = this.m_oTradeModel.getLeg(sLegId);
	if (l_oLeg != undefined) 
	{
		l_oLeg.setTenor(sTenor);
		l_oLeg.setAmount(sAmount);
	}
};

/*
 * Removes status message and trade id. Enables all data fields and sets up all button to the inital state.
 */
caplinx.trading.presentation.FxTradeTicket.prototype._resetTradeView = function()
{
	this._setTradeIdTitle("");
	this._setTimerMessage("");
	this._setStatusMessage("");
	this._setTicketDataFieldsDisabled(false);
	this._setButtonsForInitial();
	this.m_oTicketBodyElement.className = this._getTicketClassname();
};

/** @private */
caplinx.trading.presentation.FxTradeTicket.prototype._setTradeValuesToLastTrade = function(l_oOldTradeModel)
{
	var l_sTradeType = l_oOldTradeModel.getTradingType();
	this.m_oTradeModel.setAccount(l_oOldTradeModel.getAccount());
	
	var l_oOldLeg = l_oOldTradeModel.getLeg(0);
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	oLeg1.setInstrument(l_oOldLeg.getFXInstrument());
	oLeg1.setAmount(l_oOldLeg.getAmount());
	oLeg1.setTenor(l_oOldLeg.getTenor());
	oLeg1.setSettlementDate(l_oOldLeg.getSettlementDate());
	oLeg1.setDealtCurrency(l_oOldLeg.getDealtCurrency());
	
	if (l_sTradeType == "SWAP" || l_sTradeType == "FWDFWDSWAP") 
	{
		var l_oOldLeg = l_oOldTradeModel.getLeg(1);
		var oLeg2 = this.m_oTradeModel.getLeg(1);
		
		oLeg2.setInstrument(l_oOldLeg.getFXInstrument());
		oLeg2.setAmount(l_oOldLeg.getAmount());
		oLeg2.setTenor(l_oOldLeg.getTenor());
		oLeg2.setSettlementDate(l_oOldLeg.getSettlementDate());
		oLeg2.setDealtCurrency(l_oOldLeg.getDealtCurrency());
	}
};


/** @private */
caplinx.trading.presentation.FxTradeTicket.prototype._bindLeg = function(l_oLegAdapter, l_oLeg)
{
	if (l_oLeg == null) 
	{
		return l_oLegAdapter;
	}
	if (l_oLegAdapter == null) 
	{
		l_oLegAdapter = new caplin.trading.presentation.TradeModelToRendererAdapter(l_oLeg, this.m_nId);
	}
	else 
	{
		l_oLegAdapter.setLeg(l_oLeg);
		l_oLegAdapter.removeAllDataFieldChangedListener();
		l_oLegAdapter.applyAllDataFieldChangedListener();
	}
	return l_oLegAdapter;
};

////////////////////////////////
// Private rendering methods
/////////////////////////////////
/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTradeIdTitle = function(title)
{
	if (typeof webcentric != "undefined") 
	{
		this.setTitle(title);
	}
	else
 	{
		window.alert(title); // used for demo ticket
	}
};

//regex to find id="xxxx"
caplinx.trading.presentation.FxTradeTicket.m_oIdRegExp = new RegExp(" *id=[\"']([^\"']*)[\"']", "g");

/*
 * Called by webcentric to get the element that is placed inside the dialog.
 */
caplinx.trading.presentation.FxTradeTicket.prototype.getElement = function()
{
	this.m_oRootTicketElement = document.createElement("div");
	//Replaces id="xxx" with id="xxx_#" where # is the sequence number
	//This means every instance of the ticket has unique dom id's
	var l_sReplace = " id=\"$1_" + this.m_nSequenceNumber + "\"";
	var l_sHtml = this.m_sHtml.replace(caplinx.trading.presentation.FxTradeTicket.m_oIdRegExp, l_sReplace);
	
	this.m_oRootTicketElement.innerHTML = l_sHtml;
	return this.m_oRootTicketElement;
};

caplinx.trading.presentation.FxTradeTicket.prototype.onMinimize = function()
{
};

caplinx.trading.presentation.FxTradeTicket.prototype.onClose = function()
{
	this.m_nAmount = null;
	this.m_sAccount = null;
	
	//if we were displaying external(blotter) data then no need to clean up
	if (this.m_mExternalConfirmationData != null) 
	{
		this.m_mExternalConfirmationData = null;
		return;
	}
	
	var oCalendar = this.m_oSettlementDateCalendarLeg1Control.getCalendar();
	if (oCalendar.isVisible()) 
	{
		oCalendar.hideCalendar();
	}

	var oLeg2CalendarControl = this.m_oSettlementDateCalendarLeg2Control; 
	if (oLeg2CalendarControl) {
		var oLeg2Calendar = oLeg2CalendarControl.getCalendar();
		if (oLeg2Calendar.isVisible()) {
			oLeg2Calendar.hideCalendar();
		}
	}	
	
	if (this.m_oTradeModel.isEventAllowed("ClientClose"))
	{
		this.m_oTradeModel.processClientEvent("ClientClose");
		
	}
	
	if (this.m_oSearchWidget && this.m_oSearchWidget.getSearchResultConsumer() == this) 
	{
		this.m_oSearchWidget.setSearchResultConsumer(null);
	}
	this.m_oLeg1Adapter.removeAllDataFieldChangedListener();
	
	if(this.m_oTradeModel.getLeg(0))
	{
		this.m_oInstrumentNameWidget.setValue(this.m_oTradeModel.getLeg(0).getFXInstrument());
	}
	this._cleanUpTicket();
};

caplinx.trading.presentation.FxTradeTicket.prototype.onResize = function()
{
};

/**
 * Renderers must NOT hold references to the trade model. This is because
 * when the trade ticket is re-used it gets a new instance of ...
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._initialiseRenderers = function(oLeg1Adapter, sInstrumentName)
{
	var FIELDS = caplin.fields.FieldNames.TRADING.FX;
	var NO_PAUSE = true;
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	//HEADER
	
	var l_oInstrumentNameHolder = document.getElementById("DEAL_INSTRUMENT_NAME_" + this.m_nSequenceNumber);
	this.m_oInstrumentNameWidget = this._getInstrumentNameControl(l_oInstrumentNameHolder, sInstrumentName);
	
	var l_oProductSearchHolder = document.getElementById("DEAL_PRODUCT_SEARCH_" + this.m_nSequenceNumber);
	this.m_oProductSearchWidget = this._getProductSearchControl(l_oProductSearchHolder);
	
	var l_oTradeTypeHolder = document.getElementById("DEAL_INSTRUMENT_TYPE_" + this.m_nSequenceNumber);
	this.m_oTradeTypeControl = this._getTradeTypeControl(l_oTradeTypeHolder);
	
	//SPOT\FWD
//	this.m_oCurrencyDisplayLeg1 = this._getTemplateElement("DETAILS_DISPLAY_CURRENCY");
//	this.m_oCurrencyDisplayLeg1.innerHTML = oLeg1.getDealtCurrency();
	
	//this.m_oAmountDisplayLeg1 = this._getTemplateElement("DETAILS_DEALT_AMOUNT_DISPLAY");
	
	l_oTemplateElem = this._getTemplateElement("DETAILS_DEALT_AMOUNT");
	this.m_oDealtAmountLeg1Widget = this._getDealtAmountControl(l_oTemplateElem, oLeg1Adapter, 0);
	
	l_oTemplateElem = this._getTemplateElement("DETAILS_SETTLEMENT_TENOR"); //drop down list of tenors
	this.m_oSettlementTenorLeg1Control = this._getSettlementTenorWidget(l_oTemplateElem, oLeg1Adapter, 0);
	
	l_oTemplateElem = this._getTemplateElement("DETAILS_SETTLEMENT_DATE");
	this.m_oSettlementDateLeg1Widget = this._getSettlementDateElement(l_oTemplateElem, oLeg1Adapter);
	
	l_oTemplateElem = this._getTemplateElement("DETAILS_SETTLEMENT_DATE_CALENDAR");
	this.m_oSettlementDateCalendarLeg1Control = this._getCalendarControl(l_oTemplateElem, 0);
	
	/////// MIDDLE ////////
	l_oTemplateElem = this._getTemplateElement("DETAILS_FLIP_CURRENCY");
	this.m_oFlipCurrencyControl = this._getFlipCurrencyButton(l_oTemplateElem, oLeg1Adapter, 1);
	
	////////////////
	// TRADE
	////////////////
	var l_oTradeRequestQuoteHolder = document.getElementById("TRADE_REQUEST_QUOTE_" + this.m_nSequenceNumber);
	this.m_oRequestQuoteButton = this._getTradeRequestQuoteButton(l_oTradeRequestQuoteHolder);
	var l_oNullSFVP = new caplin.widget.format.StandardFieldValueProcessor(this.m_oNullTextFormatter);
	
	// SPOT //
	var l_oHolder = this._createFieldControlHolder("L1_BidSpotPrice", "L1_BID_SPOT_PRICE");
	this.m_oBidSpotPriceRenderer = this._getStandardElementControl(l_oHolder, FIELDS.BID_SPOT_PRICE, oLeg1Adapter);
	l_oHolder = this._createFieldControlHolder("L1_AskSpotPrice", "L1_ASK_SPOT_PRICE");
	this.m_oAskSpotPriceRenderer = this._getStandardElementControl(l_oHolder, FIELDS.ASK_SPOT_PRICE, oLeg1Adapter);
	
	// FORWARD //
	var l_oHolder = this._createFieldControlHolder("L1_BidFwdPrice", "L1_BID_FWD_PRICE");
	this.m_oBidFwdPriceRenderer = this._getStandardElementControl(l_oHolder, FIELDS.BID_FWD_PRICE, oLeg1Adapter);
	l_oHolder = this._createFieldControlHolder("L1_AskFwdPrice", "L1_ASK_FWD_PRICE");
	this.m_oAskFwdPriceRenderer = this._getStandardElementControl(l_oHolder, FIELDS.ASK_FWD_PRICE, oLeg1Adapter);
	
	//POINTS //
	var l_oHolder = this._createFieldControlHolder("L1_BidPoints", "L1_BID_POINTS");
	this.m_oBidPointsRenderer = this._getStandardElementControl(l_oHolder, FIELDS.BID_POINTS, oLeg1Adapter);
	l_oHolder = this._createFieldControlHolder("L1_AskPoints", "L1_ASK_POINTS");
	this.m_oAskPointsRenderer = this._getStandardElementControl(l_oHolder, FIELDS.ASK_POINTS, oLeg1Adapter);
	
	//EXECUTE BUTTONS
	var eTradeBidExecuteHolder = document.getElementById("TRADE_BID_EXECUTE_" + this.m_nSequenceNumber);
	this.m_oExecuteButtonLeft = this._getExecuteTradeButton(eTradeBidExecuteHolder, 'LEFT');
	
	var eTradeAskExecuteHolder = document.getElementById("TRADE_ASK_EXECUTE_" + this.m_nSequenceNumber);
	this.m_oExecuteButtonRight = this._getExecuteTradeButton(eTradeAskExecuteHolder, 'RIGHT');
	
	//STATUS
	this.m_oStatusTimerHolder = document.getElementById("FOOTER_TIMER_" + this.m_nSequenceNumber);
	this.m_oStatusTimerHolder.innerHTML = "";
	this.m_oStatusMessageHolder = document.getElementById("STATUS_MESSAGE_" + this.m_nSequenceNumber);
	
	// Account
	var l_oAccountHolder = document.getElementById("DEAL_ACCOUNT_NAME_" + this.m_nSequenceNumber);
	this.m_oAccountWidget = this._getAccountsControl(l_oAccountHolder, sInstrumentName);
	
	caplinx.tobo.TOBOUserManager.addObserver(this);
	
	this._setSelectedAccount(this.m_sCurrentlySelectedMainAccount);
};

caplinx.trading.presentation.FxTradeTicket.prototype._initialiseFooterButtons = function(oLeg2Adapter)
{
	var l_oFooterCancelHolder = this._getTemplateElement("FOOTER_CANCEL");
	var l_fCallbackFunction = caplin.core.Utility.getFunctionPointerFromMethod(this, "_cancel");
	this.m_oFooterCancelButton = this._getButton(l_oFooterCancelHolder, l_fCallbackFunction);
	
	var l_oFooterCloseHolder = this._getTemplateElement("FOOTER_CLOSE");
	l_fCallbackFunction = caplin.core.Utility.getFunctionPointerFromMethod(this, "_close");
	this.m_oFooterCloseButton = this._getButton(l_oFooterCloseHolder, l_fCallbackFunction);
	
	var l_oFooterPrintHolder = this._getTemplateElement("FOOTER_PRINT");
	l_fCallbackFunction = caplin.core.Utility.getFunctionPointerFromMethod(this, "_printButtonAction");
	this.m_oFooterPrintButton = this._getButton(l_oFooterPrintHolder, l_fCallbackFunction);
	
};

caplinx.trading.presentation.FxTradeTicket.prototype._close = function()
{
	this.close();
};

caplinx.trading.presentation.FxTradeTicket.prototype._initialiseSwapRenderers = function(oLeg2Adapter)
{
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var oLeg2 = this.m_oTradeModel.getLeg(1);
	
//	this.m_oAmountDisplayLeg2 = this._getTemplateElement("FARLEG_DEALT_AMOUNT_DISPLAY");
	
//	this.m_oCurrencyDisplayLeg2 = this._getTemplateElement("FARLEG_DISPLAY_CURRENCY");
//	this.m_oCurrencyDisplayLeg2.innerHTML = oLeg1.getDealtCurrency();
	
	var eTemplate = this._getTemplateElement("FARLEG_DEALT_AMOUNT");
	this.m_oDealtAmountLeg2Widget = this._getDealtAmountControl(eTemplate, oLeg2Adapter, 1);
	this.m_oDealtAmountLeg2Widget.disabled = true;
	
	eTemplate = this._getTemplateElement("FARLEG_FLIP_CURRENCY");
	this.m_oFarlegFlipCurrencyControl = this._getFlipCurrencyButton(eTemplate, oLeg2Adapter, 2);
	this.m_oFarlegFlipCurrencyControl.setEnabled(false);
	
	eTemplate = this._getTemplateElement("FARLEG_SETTLEMENT_TENOR");
	this.m_oSettlementTenorLeg2Control = this._getSettlementTenorWidget(eTemplate, oLeg2Adapter, 1);
	
	eTemplate = this._getTemplateElement("FARLEG_SETTLEMENT_DATE");
	this.m_oSettlementDateLeg2Widget = this._getSettlementDateElement(eTemplate, oLeg2Adapter);
	
	eTemplate = this._getTemplateElement("FARLEG_SETTLEMENT_DATE_CALENDAR");
	this.m_oSettlementDateCalendarLeg2Control = this._getCalendarControl(eTemplate, 1);
	
	eTemplate = this._getTemplateElement("DETAILS_COUPLING_BUTTON");
	this.m_oCouplingButton = this._getCouplingButton(eTemplate);
	
	var eHolder = this._createFieldControlHolder("L2_BidFwdPrice", "L2_BID_FWD_PRICE");
	this.m_oBidFwdSwapPriceRenderer = this._getStandardElementControl(eHolder, "BidFwdPrice", oLeg2Adapter);
	eHolder = this._createFieldControlHolder("L2_AskFwdPrice", "L2_ASK_FWD_PRICE");
	this.m_oAskFwdSwapPriceRenderer = this._getStandardElementControl(eHolder, "AskFwdPrice", oLeg2Adapter);
	
	eHolder = this._createFieldControlHolder("L2_BidPoints", "L2_BID_POINTS");
	this.m_oBidSwapFwdPointsRenderer = this._getStandardElementControl(eHolder, "BidPoints", oLeg2Adapter);
	eHolder = this._createFieldControlHolder("L2_AskPoints", "L2_ASK_POINTS");
	this.m_oAskSwapFwdPointsRenderer = this._getStandardElementControl(eHolder, "AskPoints", oLeg2Adapter);
	
	eHolder = this._createFieldControlHolder("L2_BidSwapPoints", "L2_BID_SWAP_POINTS");
	this.m_oBidSwapPointsRenderer = this._getStandardElementControl(eHolder, "BidSwapPoints", oLeg2Adapter);
	eHolder = this._createFieldControlHolder("L2_AskSwapPoints", "L2_ASK_SWAP_POINTS");
	this.m_oAskSwapPointsRenderer = this._getStandardElementControl(eHolder, "AskSwapPoints", oLeg2Adapter);
};

caplinx.trading.presentation.FxTradeTicket.prototype._resetSwapRenderers = function(oLeg2Adapter) {
	var pResetFields = [
		"m_oBidFwdSwapPriceRenderer",
		"m_oAskFwdSwapPriceRenderer",
		"m_oBidSwapFwdPointsRenderer",
		"m_oAskSwapFwdPointsRenderer",
		"m_oBidSwapPointsRenderer",
		"m_oAskSwapPointsRenderer",
		"m_oBidSpotPriceRenderer",
		"m_oAskSpotPriceRenderer",
		"m_oBidFwdPriceRenderer",
		"m_oAskFwdPriceRenderer",
		"m_oBidPointsRenderer",
		"m_oAskPointsRenderer"
	];

	for (var i=0, sField; sField = pResetFields[i]; i++) {
		this[sField].reset();		
	}
};

/** @private
 * 	called when entering executable state
 */
caplinx.trading.presentation.FxTradeTicket.prototype._displayTradeFields = function()
{
	this._clearFieldControlHolders([
		"L1_BidSpotPrice", 
		"L1_AskSpotPrice", 
		"L1_BidPoints", 
		"L1_AskPoints", 
		"L1_BidFwdPrice", 
		"L1_AskFwdPrice", 
		"L2_BidPoints", 
		"L2_AskPoints", 
		"L2_BidSwapPoints", 
		"L2_AskSwapPoints"
	]);
	
	var l_sTradeType = this.m_oTradeModel.getTradingType();
	if (l_sTradeType == "SPOT") 
	{
		this._joinFieldControlHolderToElement(["TRADE_SUMMARY_BID", "TRADE_SUMMARY_ASK"], ["L1_BidSpotPrice", "L1_AskSpotPrice"]);
		this._joinFieldControlHolderToElement(["TRADE_SUMMARY_LABEL"], [ct.i18n("cx.trading.presentation.fx.ticket.spot_rate")], true);
	}
	
	if (l_sTradeType == "FWD" || l_sTradeType == "SWAP" || l_sTradeType == "FWDFWDSWAP") 
	{
		this._joinFieldControlHolderToElement(["TRADE_LINE1_BID", "TRADE_LINE1_ASK"], ["L1_BidSpotPrice", "L1_AskSpotPrice"]);
		this._joinFieldControlHolderToElement(["TRADE_LINE1_LABEL"], [ct.i18n("cx.trading.presentation.fx.ticket.spot")], true);
	}
	
	if (l_sTradeType == "FWD") 
	{
		this._joinFieldControlHolderToElement([
			"TRADE_LINE2_BID", 
			"TRADE_LINE2_ASK", 
			"TRADE_SUMMARY_BID", 
			"TRADE_SUMMARY_ASK"
		], [
			"L1_BidPoints", 
			"L1_AskPoints", 
			"L1_BidFwdPrice", 
			"L1_AskFwdPrice"
		]);
		
		this._joinFieldControlHolderToElement([
			"TRADE_LINE2_LABEL", 
			"TRADE_LINE3_LABEL", 
			"TRADE_LINE3_BID", 
			"TRADE_LINE3_ASK", 
			"TRADE_SUMMARY_LABEL"
		], [
			"Fwd Points", 
			"&nbsp;", 
			"&nbsp;", 
			"&nbsp;", 
			"Forward Rate"
		], true);
	}
	
	if (l_sTradeType == "SWAP") 
	{
		this._joinFieldControlHolderToElement([
			"TRADE_LINE1_BID", 
			"TRADE_LINE1_ASK", 
			"TRADE_LINE2_BID", 
			"TRADE_LINE2_ASK", 
			"TRADE_SUMMARY_BID", 
			"TRADE_SUMMARY_ASK"
		], [
			"L1_AskSpotPrice", 
			"L1_BidSpotPrice", 
			"L2_BidFwdPrice", 
			"L2_AskFwdPrice", 
			"L2_BidSwapPoints", 
			"L2_AskSwapPoints"
		]);
		
		this._joinFieldControlHolderToElement([
			"TRADE_LINE2_LABEL", 
			"TRADE_LINE3_LABEL", 
			"TRADE_LINE3_BID", 
			"TRADE_LINE3_ASK", 
			"TRADE_SUMMARY_LABEL"
		], [
			"Far Rate", 
			"&nbsp;", 
			"&nbsp;", 
			"&nbsp;", 
			"Swap Points"
		], true);
	}
	
	if (l_sTradeType == "FWDFWDSWAP") 
	{
		this._joinFieldControlHolderToElement([
			"TRADE_LINE1_BID", 
			"TRADE_LINE1_ASK", 
			"TRADE_LINE2_BID", 
			"TRADE_LINE2_ASK", 
			"TRADE_LINE3_BID", 
			"TRADE_LINE3_ASK", 
			"TRADE_SUMMARY_BID", 
			"TRADE_SUMMARY_ASK"
		], [
			"L1_AskSpotPrice", 
			"L1_BidSpotPrice", 
			"L1_AskPoints", 
			"L1_BidPoints", 
			"L2_BidPoints", 
			"L2_AskPoints", 
			"L2_BidSwapPoints", 
			"L2_AskSwapPoints"
		]);
		
		this._joinFieldControlHolderToElement([
			"TRADE_LINE2_LABEL", 
			"TRADE_LINE3_LABEL", 
			"TRADE_SUMMARY_LABEL"
		], [
			"Near Leg Points", 
			"Far Leg Points", 
			"Swap Points"
		], true);
	}
};

caplinx.trading.presentation.FxTradeTicket.prototype._joinFieldControlHolderToElement = function(pElementNames, pFieldControlHolders, bHTMLToInsert)
{
	for (var x = 0; pElementNames[x]; x++) 
	{
		var l_oTemplateElem = this._getTemplateElement(pElementNames[x]);
		if (bHTMLToInsert) 
		{
			l_oTemplateElem.innerHTML = pFieldControlHolders[x];
		}
		else 
		{
			this._moveFieldControlHolder(pFieldControlHolders[x], l_oTemplateElem);
		}
	}
};

caplinx.trading.presentation.FxTradeTicket.prototype._createFieldControlHolder = function(l_sFieldName, l_sId, l_sParentElement)
{
	var l_oHolder = document.createElement("DIV");
	l_oHolder.id = l_sId + "_" + this.m_nSequenceNumber;
	if (l_sParentElement !== undefined) 
	{
		l_sParentElement.appendChild(l_oHolder);
	}
	this.m_mFieldControlHolders[l_sFieldName] = l_oHolder;
	return l_oHolder;
};

caplinx.trading.presentation.FxTradeTicket.prototype._moveFieldControlHolder = function(l_sFieldName, l_sNewParentElement)
{
	var l_oHolder = this.m_mFieldControlHolders[l_sFieldName];
	if (l_oHolder === undefined) 
	{
		throw new caplin.core.Exception("Cannot find holder for field: " + l_sFieldName);
	}
	// remove all children from the field we are moving the control into
	while (l_sNewParentElement.firstChild) 
	{
		l_sNewParentElement.removeChild(l_sNewParentElement.firstChild);
	}
	// add the new control to the parent
	l_sNewParentElement.appendChild(l_oHolder);
};

caplinx.trading.presentation.FxTradeTicket.prototype._clearFieldControlHolders = function(pFieldNames)
{
	for (var x = 0; pFieldNames[x]; x++) 
	{
		var l_oHolder = this.m_mFieldControlHolders[pFieldNames[x]];
		pFieldNames[x] = l_oHolder ? l_oHolder.innerHTML = "&nbsp;" : x = pFieldNames.length;
	}
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getTemplateElement = function(l_sElemId)
{
	var l_sElemId = l_sElemId + "_" + this.m_nSequenceNumber;
	var l_oElem = this.m_mTemplateElements[l_sElemId];
	
	if (l_oElem === undefined) 
	{
		l_oElem = document.getElementById(l_sElemId);
		if (l_oElem === undefined || l_oElem === null) 
		{
			throw new caplin.core.Exception("Cannot find element with id:" + l_sElemId);
		}
		this.m_mTemplateElements[l_sElemId] = l_oElem;
	}
	return l_oElem;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getStandardElementControl = function(l_sHolder, l_sFieldName, l_oDataSource)
{
	var l_oNullTextFormatter = this.m_oTextFormatterFactory.getTextFormatter("caplin.widget.format.NullTextFormatter");
	var l_oNullSFVP = new caplin.widget.format.StandardFieldValueProcessor(l_oNullTextFormatter);
	var l_oControl = new caplin.widget.element.renderer.ElementRenderer([l_oNullSFVP], [l_sFieldName], this.m_oFieldManager);
	l_oControl.setFlashStrategy(caplin.widget.element.renderer.ElementRenderer.getRateFlash);
	l_oControl.setUseRawValueForChangeChecking(true);
	l_oControl.setDataModel(l_oDataSource, "\u00A0");
	
	l_oControl.createElement(l_oDataSource, l_sHolder);
	return l_oControl;
};
/////////////////////
// HEADER
////////////////////

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getInstrumentNameControl = function(l_oHolderElement, sInstrumentName)
{
	var l_mProperties = {
		inputClassName: 'AutoCompleteInput',
		listClassName: 'AutoCompleteList',
		listItemClassName: 'AutoCompleteListItem',
	//	inputSize: 8, // noir 25,
		inputMaxLength: 6,
		blurFiresSelect: true,
		autoCompleteText: false,
		displayListOnSingleResult: true
	};
	
	var l_oControl = null;
	
	var l_oFxTradeTicket = this;
	var l_oAutoCompleteListener = {};
	
	l_oAutoCompleteListener.onSelect = function(sNewInstrument)
	{
		// The currency must be converted and stored as an upper-case string
		// to prevent continual conversion to upper-case representation in the rest of the code.
		sNewInstrument = sNewInstrument.toUpperCase().slice(0,6);
		var sOldInstrument = l_oFxTradeTicket.m_oTradeModel.getLeg(0).getFXInstrument();
		try 
		{
			l_oFxTradeTicket.m_oAutoCompleteCurrencyProvider.validateEntry(sNewInstrument);
			l_oFxTradeTicket.m_bValidCurrencyPair = true;
			l_oFxTradeTicket._checkIfGetQuoteIsEnabled();
			if (sOldInstrument != sNewInstrument) 
			{
				// set the new instrument in model. resetTradeModel() will pick up the new instrument.
				l_oFxTradeTicket.m_oTradeModel.getLeg(0).setInstrument(sNewInstrument);
				l_oFxTradeTicket._resetTradeModel(true, true, false);
			}
			
		} 
		catch (e) 
		{
			if (!caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().isAlertShowing()) 
			{
				var sCleanInstrument = sNewInstrument.replace(/</g,"&lt;").replace(/>/g,"&gt;");
				caplin.dom.AbstractFactory.getInstance().getAlertDispatcher().alert(sCleanInstrument + " is not a valid currency pair.");
			}
		}
	};
	
	l_oControl = new caplin.dom.controls.form.AutoCompleteComboBox(
			l_oHolderElement, this.m_oAutoCompleteCurrencyProvider, l_oAutoCompleteListener, l_mProperties);
	
	l_oControl.setEditStartedListener(function() {
		l_oFxTradeTicket._setTicketDataFieldsDisabledExcludingInstrumentName(true);
	});
	
	return l_oControl;
};

caplinx.trading.presentation.FxTradeTicket.prototype._doFocusInstrumentName = function()
{
	this.m_oInstrumentNameWidget.focus();
};

/*
 * @private
 * Sets new model but keeps ticket settings, ie instrument, account and type
 * Resets tickets values back to default, ie amount and settlement date
 */
caplinx.trading.presentation.FxTradeTicket.prototype._resetTradeModel = function(bPersistType, bPersistAccount, bPersistValues)
{
	// Get initial values
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var sInstrumentName = oLeg1.getFXInstrument();
	var oldTradeAmount = oLeg1.getAmount();
	var oOldTradeModel = this.m_oTradeModel;
	
	// new trade model, if bPersistSettings is true bind keeps instrument, account and type
	this._bindTrade(sInstrumentName, bPersistType, bPersistAccount);
	
	if (bPersistValues) 
	{
		this._setTradeValuesToLastTrade(oOldTradeModel);
	}
	else 
	{
		this._setLegToDefaults(0, "SPOT", oldTradeAmount);
		this._setLegToDefaults(1, "1M", oldTradeAmount);
	}
	
	// reset the ticket controls and labels back to default values
	var sTradeType = this.m_oTradeModel.getTradingType();
	if (sTradeType === 'SWAP' || sTradeType === 'FWDFWDSWAP') 
	{
		this._setTicketDisplayFwd(true);
		this._resetSwapRenderers();
	}
	else 
	{
		this._setTicketDisplay(true);
	}
	
};

var tradableDatesCallback = function(oTicket, oCalendar, sLegNumber)
{
	this.m_oTicket = oTicket;
	this.m_oCalendar = oCalendar;
	this.m_sLegNumber = sLegNumber;
};
caplin.implement(tradableDatesCallback, caplin.services.date.BusinessDateRequest);

tradableDatesCallback.prototype.getInstrument = function()
{
	return this.m_oTicket.m_sObjectName.substring(4);
};
		
tradableDatesCallback.prototype.getTenor = function()
{
	return this.m_oTicket.m_oTradeModel.getLeg(this.m_sLegNumber).getTenor();
};

tradableDatesCallback.prototype.getSettlementDate = function()
{
	return this.m_oTicket.m_oTradeModel.getLeg(this.m_sLegNumber).getSettlementDate();
};
		
tradableDatesCallback.prototype.businessCalendarCallback = function(l_sInstrument, l_nMonth, l_nYear, l_pDates)
{
	this.m_oCalendar.fillValidDaysInCalendar(l_nYear, l_nMonth, l_pDates);
};	

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getCalendarControl = function(eHolder, l_sLegNumber)
{
	var oCalendarButton = new caplin.widget.calendar.CalendarButton('trade-ticket-calendar');
	oCalendarButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.select_date"));
	eHolder.appendChild(oCalendarButton.getElement());
	
	var oThis = this;
	var oCalendar = oCalendarButton.getCalendar();
	
	oCalendar.setTradableDatesCallback(new tradableDatesCallback(this, oCalendar, l_sLegNumber));
	var fSetChosenDateCallback = function(sChosenDate)
	{
		oThis.m_oTradeModel.getLeg(l_sLegNumber).setSettlementDate(sChosenDate);
	};
	
	oCalendarButton.addOnClickListener(fSetChosenDateCallback);
	return oCalendarButton;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getProductSearchControl = function(eHolder)
{
	var oSearchButton = new caplin.widget.formcontrols.GraphicalDivButton('trade-ticket-search', 
		this.m_sLocalImgRoot + 'search-button.gif', 'absolute', 'absolute');
			
	oSearchButton.setTitle(ct.i18n("cx.trading.presentation.fx.ticket.search_title"));
	oSearchButton.addOnClickListener(obfuscator_gotcha_productSearchClickHandler(this));
	
	eHolder.appendChild(oSearchButton.getElement());
	
	return oSearchButton;
};

/*
 * currencyPairChangeHandler
 * this function needs to be implemented - it is aimed at pushing a change in the currency pairing back to the model
 */
obfuscator_gotcha_productSearchClickHandler = function(l_oTradeTicket)
{
	return function() 
	{
		webcentric.showDialog("fx-selector", {
			setSearchResultConsumer: l_oTradeTicket,
			setKeepOpenUntilCloseButton: false
		});
	};
};


caplinx.trading.presentation.FxTradeTicket.prototype.iAmYourSearchWidget = function(searchWidget)
{
	this.m_oSearchWidget = searchWidget;
};

// Search Result Consumer

caplinx.trading.presentation.FxTradeTicket.prototype.canConsumeResults = function()
{
	return true;
};
caplinx.trading.presentation.FxTradeTicket.prototype.canReceiveObjects = function()
{
	return true;
};
caplinx.trading.presentation.FxTradeTicket.prototype.canConsumeMultipleResults = function()
{
	return false;
};
caplinx.trading.presentation.FxTradeTicket.prototype.getConsumerName = function()
{
	return "FxTradeTicket";
};

/*
 * This method called by the product search panel
 */
caplinx.trading.presentation.FxTradeTicket.prototype.receiveObjects = function(pObjects)
{
	var sObjectName = pObjects[0];
	this.setObjectName(sObjectName);
	var sInstrumentName = sObjectName.substring(4);
	
	// set the trade to what it will be
	this.m_oTradeModel.getLeg(0).setInstrument(sInstrumentName);
	// reset all values but keep ticket settings
	this._resetTradeModel(true, true, false);
};

/**
 * Returns a drop down box for changing the trading type.
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getTradeTypeControl = function(eHolder)
{
	var oTradeTypes = new Ext.data.SimpleStore({
		"fields": ['value', 'label'],
		"data" : this._getPermissionedTradeTypes()
	});
	var oComboBox = new Ext.form.ComboBox({
		"displayField": "label",
		"triggerAction": 'all',
		"editable": false,
		"mode": 'local',
		"forceSelection": true,
//		"width": 95, // noir 164
		"shadow": false,
		"disabledClass": 'x-item-disabled',
		"store": oTradeTypes
	});
	oComboBox.render(eHolder);

	var sFirstRecord = oTradeTypes.getAt(0);
	if (sFirstRecord)
	{
		oComboBox.setValue(sFirstRecord.get("label"));
	}
	oComboBox.on('select', this._onTradeTypeChanged, this);
	return oComboBox;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getPermissionedTradeTypes = function()
{
	var oPermissionService = caplin.security.permissioning.PermissionService;
	var pTradeTypes =[];
	if (oPermissionService.canUserPerformAction('.*', 'TradeType', 'SPOT')) 
	{
		pTradeTypes.push(["SPOTFWD", "SPOT/FWD"]);
	}
	if (oPermissionService.canUserPerformAction('.*', 'TradeType', 'SWAP')) 
	{
		pTradeTypes.push(["SWAP", "SWAP"]);
	}
	return pTradeTypes;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._onTradeTypeChanged = function(oTradeTypeWidget)
{
	var oStore = oTradeTypeWidget.getStore();
	var oRecord = oStore.query("label", oTradeTypeWidget.getValue()).first();
	var sTradingType = oRecord.get("value");
	
	var oLeg = this.m_oTradeModel.getLeg(0);
	var oFxTradeTicket = caplinx.trading.presentation.FxTradeTicket;
	
	if (sTradingType === "SPOTFWD") 
	{
		sTradingType = oLeg.getTenor() === "SPOT" ? oFxTradeTicket.TRADING_TYPE_SPOT : oFxTradeTicket.TRADING_TYPE_FORWARD;
	}
	
	if (sTradingType === "SWAP") 
	{
		sTradingType = oLeg.getTenor() === "SPOT" ? oFxTradeTicket.TRADING_TYPE_SWAP : oFxTradeTicket.TRADING_TYPE_SWAPFWD;
	}
	
	this.m_oTradeModel.setTradingType(sTradingType);
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype.resizeTicket = function(sTradingType)
{
	var nHeight = this.m_nOriginalHeight;
	switch (sTradingType) {
		case caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_FORWARD:
				nHeight += this.m_nFwdSizeIncrease;
			break;
		case caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SWAP:
		case caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SWAPFWD:
				nHeight += this.m_nSwapSizeIncrease;
			break;
	}
	
	this.resize(this.m_nOriginalWidth, nHeight);
		
}

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getAccountsControl = function(eHolder, sInstrumentName)
{
	var oStore = new Ext.data.SimpleStore({"fields": ["value", "label"]});
	var oComboBox = new Ext.form.ComboBox({
		"displayField": "label",
//		"width": 95,
		"minListWidth": 112,
		"triggerAction": 'all',
		"editable": false,
		"mode": 'local',
		"forceSelection": true,
		"shadow": false,
		"disabledClass": 'x-item-disabled',
		"store" : oStore
	}); 
	
	oComboBox.render(eHolder);
	oComboBox.on('select', this._onAccountChanged, this);
	
	return oComboBox;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._onAccountChanged = function(oComboBox)
{
	this.m_sAccount = oComboBox.getValue();
	this.m_oTradeModel.setAccount(oComboBox.getValue());
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._createAccountsDataStore = function(sInstrumentName)
{
	var oPermissionService = caplin.security.permissioning.PermissionService;

	var fToDataFormat = function(pData) {
		var pFormated = [];
		for (var i = 0, nLength = pData.length; i < nLength; ++i)
		{
			pFormated.push([pData[i], pData[i]]);
		}
		return pFormated;
	};
	
	//The function used to sort the array of account names.(Alphabetical).
	var fSortFunction = function(a,b)
	{
		if(a < b)
		{
			return -1;
		}
		else if(a > b)
		{
			return 1;
		}
		return 0;
	};
	
	var pAllowPermissions = oPermissionService.getAllowPermissions("/FX/" + sInstrumentName, "Account", fSortFunction);
	
	var oTradeTypes = new Ext.data.SimpleStore({
		"fields": ["value", "label"],
		"data" : fToDataFormat(pAllowPermissions)
	});
	var oPermissionListener = {
		onAttributeChanged: function(sAttributeName, sAttributeValue)
		{
		},
		onSinglePermissionChanged: function(bIsAuthorized, sProduct, sNamespace, sAction)
		{
		},
		onPermissionsChanged: function(pPermissions, sProduct, sNamespace)
		{
			oTradeTypes.loadData(fToDataFormat(pPermissions), false);
		}
	};
	oPermissionService.addPermissionSetListener("/FX/" + sInstrumentName, "Account", oPermissionService.ALL, oPermissionListener);
	
	return oTradeTypes;
};

caplinx.trading.presentation.FxTradeTicket.prototype._setAccountDropDownOptions = function(oAccountControl)
{
	var sCurrentAccount = this.m_oTradeModel.getAccount();
	if (typeof sCurrentAccount === "String") 
	{
		this.m_oTradeModel.setAccount(sCurrentAccount);
	}
	else if (this.m_sAccount) 
	{
		this.m_oTradeModel.setAccount(this.m_sAccount);
	}
	else
	{
		var oRecord = oAccountControl.getStore().getAt(0);
		var sValue = oRecord.get("label");
		this.m_oTradeModel.setAccount(sValue);
	}
};

/////////////////////
// SPOT
////////////////////

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._resetCouplingButton = function()
{
	if (this.m_oCouplingButton !== undefined)
    {
        this.m_bSwapLegsAreCoupled = true;
        this.m_oCouplingButton.changeCaptionImage(this.m_sLocalImgRoot, caplinx.trading.presentation.FxTradeTicket.COUPLED_IMAGE);
        this.m_oCouplingButton.setTooltip(this.openToolTipMessage);
		this.m_oCouplingButton.disable(false);
    }
};

caplinx.trading.presentation.FxTradeTicket.prototype._getCouplingButton = function(eHolder)
{
	var oFxTradeTicket = caplinx.trading.presentation.FxTradeTicket;

	var oButton = new caplin.widget.formcontrols.ThreeImageButton('', this.m_sGlobalImgRoot + "buttons/capbutton");
	oButton.setTooltip(this.openToolTipMessage);
	oButton.setCaptionImage(this.m_sLocalImgRoot, oFxTradeTicket.COUPLED_IMAGE);
	oButton.setWidth('32');
	oButton.setHeight('16');
		
	eHolder.appendChild(oButton.getElement());
	
	var oThis = this;
	// onclick handler to set the amounts on both legs to be the same if coupled.
	var fDecoupleHandler = function()
	{
		var oLeg1 = oThis.m_oTradeModel.getLeg(0);
		var oLeg2 = oThis.m_oTradeModel.getLeg(1);
		
		oThis.m_bSwapLegsAreCoupled = !oThis.m_bSwapLegsAreCoupled;
		
		if (oThis.m_bSwapLegsAreCoupled === true)//coupled 
		{
	
			oLeg2.setAmount(oLeg1.getAmount());
			//legs are coupled so change middle-coupling icon to coupled
			oButton.changeCaptionImage(oThis.m_sLocalImgRoot, oFxTradeTicket.COUPLED_IMAGE);
			oButton.setTooltip(oThis.openToolTipMessage);
			//oThis.m_oAmountDisplayLeg2.innerHTML = oThis.m_oQuantityTextFormatter.insertCommas(oLeg2.getAmount());
			oThis.m_oFarlegFlipCurrencyControl.setEnabled(false);
			oThis.m_oDealtAmountLeg2Widget.disabled = true;
			
			
		}
		else 
		{
			//set default toggle coupling icon to decouple
			oButton.changeCaptionImage(oThis.m_sLocalImgRoot, oFxTradeTicket.UNCOUPLED_IMAGE);
			oButton.setTooltip(oThis.closedToolTipMessage);
			oThis.m_oDealtAmountLeg2Widget.value = oThis.m_oQuantityTextFormatter.insertCommas(oLeg2.getAmount());
			oThis.m_oFarlegFlipCurrencyControl.setEnabled(true);
			oThis.m_oDealtAmountLeg2Widget.disabled = false;
			
		}
		oThis.m_oTicketBodyElement.className = oThis._getTicketClassname();
	};
	
	oButton.addOnClickListener(fDecoupleHandler);
	return oButton;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getFlipCurrencyButton = function(eHolder, oLegAdapter, nLegId)
{
	var oButton = new caplin.widget.formcontrols.ThreeImageButton('', this.m_sGlobalImgRoot + "buttons/capbutton");
	oButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.toggle"));
	var eButton = oButton.getElement();
	caplin.widget.utilities.StyleHelper.updateStyle(eButton, {
		"position": "relative",
		"top": "1px"
	});
	eHolder.appendChild(eButton);
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var oLeg2 = this.m_oTradeModel.getLeg(1);
	oButton.setCaption(oLeg1.getDealtCurrency());
	
	var oThis = this;
	var toggleCurrencyFn = function()
	{
		var oLeg1 = oThis.m_oTradeModel.getLeg(0);
		var oLeg2 = oThis.m_oTradeModel.getLeg(1);
		var bCoupledCurrencies = oThis.m_bSwapLegsAreCoupled; 
		if (bCoupledCurrencies && oLeg2 != null)
		{
			oLeg1.toggleDealtCurrency();
			oLeg2.toggleDealtCurrency();
		}
		else if (oLeg2 == null || nLegId === 1)
		{
			oLeg1.toggleDealtCurrency();
		}
		else if (nLegId === 2)
		{
			oLeg2.toggleDealtCurrency();
		}
	};
	oButton.addOnClickListener(toggleCurrencyFn);
	
	//Add listener to model that sets button label dependent on dealt currency
	var oDealtCurrencyListener = {};
	oDealtCurrencyListener.dataFieldChanged = function(sDealtCcy)
	{
		oButton.setCaption(sDealtCcy);
		//oThis.m_oCurrencyDisplayLeg1.innerHTML = sDealtCcy;
		if (oThis.m_oCurrencyDisplayLeg2 != null) 
		{
			oThis.m_oCurrencyDisplayLeg2.innerHTML = sDealtCcy;
		}
	};
	oLegAdapter.addDataFieldChangedListener(oDealtCurrencyListener, "DealtCurrency");
	return oButton;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getDealtAmountControl = function(eHolder, oLegAdapter, nLegId)
{
	var eContainer = document.createElement("div");
	var eControl = document.createElement("INPUT");
	
	eControl.style.cursor = "Text";
	eContainer.appendChild(eControl);
	eHolder.appendChild(eContainer);
	
	var oLeg = this.m_oTradeModel.getLeg(nLegId);
	if (oLeg) 
	{
		eControl.value = this.m_oQuantityTextFormatter.insertCommas(oLeg.getAmount());
	}
	var oUtility = caplin.dom.Utility;
	eControl.m_nKeyUpListenerId = oUtility.addEventListener(eControl, "keyup", oUtility.createMethodEventListener(this, "_fireAmountBlurOnEnter", [eControl]));
	eControl.m_nBlurListenerId = oUtility.addEventListener(eControl, "blur", oUtility.createMethodEventListener(this, "_AmountFormatter", [nLegId]));
	
	var oQuantityTextFormatter = this.m_oQuantityTextFormatter;
	var fAmountListener = {};
	fAmountListener.dataFieldChanged = function(sAmount)
	{
		eControl.value = oQuantityTextFormatter.insertCommas(sAmount);
	};
	oLegAdapter.addDataFieldChangedListener(fAmountListener, "Amount");
	return eControl;
};

//Is this called?
caplinx.trading.presentation.FxTradeTicket.prototype._AmountListener = function(oEvent, nLegId, eControl)
{
	var oLeg = this.m_oTradeModel.getLeg(nLegId);
	try 
	{
		var sNoCommas = this.m_oQuantityTextFormatter.stripCommas(eControl.value);
		var nConvertedAmount = this.m_oQuantityTextFormatter.parseUserInput(sNoCommas);
		
		if (nConvertedAmount != oLeg.getAmount()) 
		{
			eControl.value = this.m_oQuantityTextFormatter.insertCommas(nConvertedAmount);
			
			if (this.m_bSwapLegsAreCoupled == true && nLegId == 0) 
			{
				var sTradeType = this.m_oTradeModel.getTradingType();
				if (sTradeType == "SWAP" || sTradeType == "FWDFWDSWAP") 
				{
					var oLeg2 = this.m_oTradeModel.getLeg(1);
					oLeg2.setAmount(nConvertedAmount);
					//this.m_oAmountDisplayLeg2.innerHTML = this.m_oQuantityTextFormatter.insertCommas(nConvertedAmount);
				}
			}
			oLeg.setAmount(nConvertedAmount);
		}
		
		eControl.value = this.m_oQuantityTextFormatter.insertCommas(oLeg.getAmount());
	} 
	catch (e) 
	{
		var fSetFocusCont = caplin.dom.Utility.createMethodEventListener(this, "_setAmountFocus", [eControl]);
		caplin.widget.message.MessageManager.getInstance().alert(e, fSetFocusCont);
	}
};


caplinx.trading.presentation.FxTradeTicket.prototype._AmountFormatter = function(oEvent, nLegId)
{
    var oDealtAmountLegWidget = nLegId === 0 ? this.m_oDealtAmountLeg1Widget : this.m_oDealtAmountLeg2Widget;
	try 
	{
	    this._AmountValidator(nLegId, oDealtAmountLegWidget);		
	} 
	catch (oIgnore) 
	{
        var oLeg = this.m_oTradeModel.getLeg(nLegId);
        oDealtAmountLegWidget.value = this.m_oQuantityTextFormatter.insertCommas(oLeg.getAmount());        
	}
};


caplinx.trading.presentation.FxTradeTicket.prototype._AmountValidator = function(nLegId, eControl)
{
	var oLeg = this.m_oTradeModel.getLeg(nLegId);
	var bValid = true;
	
	try 
	{
		var sNoCommas = this.m_oQuantityTextFormatter.stripCommas(eControl.value);
		var nConvertedAmount = this.m_oQuantityTextFormatter.parseUserInput(sNoCommas);
		
		if (nConvertedAmount != oLeg.getAmount()) 
		{
			eControl.value = this.m_oQuantityTextFormatter.insertCommas(nConvertedAmount);
			if (this.m_bSwapLegsAreCoupled == true && nLegId == 0) 
			{
				var sTradeType = this.m_oTradeModel.getTradingType();
				if (sTradeType == "SWAP" || sTradeType == "FWDFWDSWAP") 
				{
					var oLeg2 = this.m_oTradeModel.getLeg(1);
					oLeg2.setAmount(nConvertedAmount);
					//this.m_oAmountDisplayLeg2.innerHTML = this.m_oQuantityTextFormatter.insertCommas(nConvertedAmount);
				}
			}
			oLeg.setAmount(nConvertedAmount);
		}
		eControl.value = this.m_oQuantityTextFormatter.insertCommas(oLeg.getAmount());
	} 
	catch (e) 
	{
		bValid = false;
        var oUtility = caplin.dom.Utility;
        oUtility.removeEventListenerById(eControl.m_nBlurListenerId);
		var setFocusCont = oUtility.createMethodEventListener(this, "_setAmountFocus", [eControl, nLegId]);
		caplin.widget.message.MessageManager.getInstance().alert(e, setFocusCont);
		throw e;
	}
	
	return bValid;
};

/**
 * Callback function used by the control in _getDealtAmountControl. Sets focus back to the input box control after an error alert
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setAmountFocus = function(oEvent, eControl, nLegId)
{
    var oUtility = caplin.dom.Utility;
    eControl.m_nBlurListenerId = oUtility.addEventListener(eControl, "blur", oUtility.createMethodEventListener(this, "_AmountFormatter", [nLegId]));
	eControl.focus();
};
/**
 * Callback function used by the control in _getDealtAmountControl. Causes the control to lose focus when enter is pressed.
 * @private
 * @param {Object} oEvent
 * @param {Object} eControl
 */
caplinx.trading.presentation.FxTradeTicket.prototype._fireAmountBlurOnEnter = function(oEvent, eControl)
{
	if (oEvent.keyCode == 13) 
	{
		eControl.blur();
	}
};
/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getSettlementDateElement = function(eHolder, oLegAdapter)
{
	var eControl = document.createElement("DIV");
	eControl.className = "fxticket-datebox";
	eHolder.appendChild(eControl);
	
	var oThis = this;
	var oListener = {};
	oListener.dataFieldChanged = function(sValue)
	{
		oThis.m_bSettlementDateSet = sValue != "";
		oThis._checkIfGetQuoteIsEnabled();
		
		eControl.innerHTML = caplin.element.formatter.DateFormatter.format(sValue, oThis.m_mDateFormatParams);
	};
	oLegAdapter.addDataFieldChangedListener(oListener, "SettlementDate");
	return eControl;
};
/////////////////////
// FORWARD
////////////////////

/**
 * @private  
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getSettlementTenorWidget = function(eHolder, oLegAdapter, nLegId)
{
	var oTradeTypes = new Ext.data.SimpleStore({
		"fields": ['value', 'label'],
		"data" : this._getPermissionedSettlementTenors(nLegId)
	});
	
	var oComboBox = new Ext.form.ComboBox({
		"displayField": "label",
		"width": 74,
		"triggerAction": 'all',
		"editable": false,
		"mode": 'local',
		"forceSelection": true,
		"shadow": false,
		"disabledClass":'x-item-disabled',
		"store" : oTradeTypes
   }); 
	oComboBox.render(eHolder);
	
	var oPreventEventCascade = false;
	
	var fOnTenorChanged = function()
	{
		oPreventEventCascade = true;
		var oLeg = this.m_oTradeModel.getLeg(nLegId);
		var sTenorLabel = oComboBox.getValue();
		var oRecord = oTradeTypes.query("label", sTenorLabel).first();
		oLeg.setTenor(oRecord.get("value"));
		oPreventEventCascade = false;
	};

	oComboBox.on('select', fOnTenorChanged, this);
	
	var sDefaultTenor = caplinx.trading.presentation.FxTradeTicket.TRADING_TYPE_SPOT;
	oComboBox.setValue(sDefaultTenor);
	this.m_bTenorSet = sDefaultTenor !== "";
	
	var oThis = this;
	var oTenorListener = {
		dataFieldChanged: function(sValue) 
		{
			oThis.m_bTenorSet = sValue !== "";
			
			if (oThis.m_bTenorSet === true && nLegId === 0) 
			{
				oThis._setTradeTypeFromTenor(sValue, oThis.m_oTradeModel);
			}
			oThis._checkIfGetQuoteIsEnabled();
			
			if (!oPreventEventCascade) 
			{
				oComboBox.setValue(sValue);
			}
		}
	};
	oLegAdapter.addDataFieldChangedListener(oTenorListener, "Tenor");
	
	return oComboBox;
	
};

/**
 * @private  
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getPermissionedSettlementTenors = function()
{
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var oTradingTenors = oLeg1.getTenors();
	var pTradingTenors = [];
	for (var sKey in oTradingTenors) 
	{
		var sValue = oTradingTenors[sKey];
		pTradingTenors.push([sKey, sValue]);
	}
	pTradingTenors.push(["Broken", ct.i18n("fxtile.tenor.brkn")]);
	return pTradingTenors;
};

/**
 * @private  
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTradeTypeFromTenor = function(l_sTenor, l_oTradeModel)
{
	var l_bSettlementDateIsSpot = false;
	if (l_sTenor == "SPOT") 
	{
		l_bSettlementDateIsSpot = true;
	}
	
	var l_sCurrentTradingType = l_oTradeModel.getTradingType();
	
	if (l_sCurrentTradingType == "SPOT" && l_bSettlementDateIsSpot == false) 
	{
		l_oTradeModel.setTradingType("FWD");
	}
	if (l_sCurrentTradingType == "FWD" && l_bSettlementDateIsSpot == true) 
	{
		l_oTradeModel.setTradingType("SPOT");
	}
	if (l_sCurrentTradingType == "SWAP" && l_bSettlementDateIsSpot == false) 
	{
		l_oTradeModel.setTradingType("FWDFWDSWAP");
	}
	if (l_sCurrentTradingType == "FWDFWDSWAP" && l_bSettlementDateIsSpot == true) 
	{
		l_oTradeModel.setTradingType("SWAP");
	}
};

/**
 * Checks if both the m_bTenorSet and m_bSettlementDateSet flags are true, and if so enables the
 * "get quote" button, otherwise disables it.
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._checkIfGetQuoteIsEnabled = function()
{
	if (this.m_oRequestQuoteButton != null) 
	{
		if (this.m_bValidCurrencyPair && this.m_bValidCurrencyPair === true) 
		{
			this.m_oRequestQuoteButton.setEnabled(this.m_bTenorSet && this.m_bSettlementDateSet);
			this.m_oRequestQuoteButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.get_quote"));
		}
		
	}
};

/**
 * Disables the "get quote" button. This function is called when an InvalidSettlementDates callback
 * is received, indicating that the settlement date for the near leg is after the settlement date
 * for the far leg.
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._disableGetQuoteButton = function(sDisabledMessage)
{
	if (this.m_oRequestQuoteButton != null) 
	{
		this.m_oRequestQuoteButton.setEnabled(false);
		this.m_oRequestQuoteButton.setDisabledAlertMsg(sDisabledMessage);
		this.m_oRequestQuoteButton.setTooltip(sDisabledMessage);
	}
};

////////////////////
// TRADE
////////////////////

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getTradeRequestQuoteButton = function(l_oHolderElement)
{
	
	var l_oButton = new caplin.widget.formcontrols.ThreeImageButton(ct.i18n("theme.fx.ticket.get_quote"), this.m_sGlobalImgRoot + "buttons/capbutton");
	l_oButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.request_quote"));
	
	var l_oHtmlButton = l_oButton.getElement();
	caplin.widget.utilities.StyleHelper.updateStyle(l_oHtmlButton, 
	{
		"position": "relative"
	});
	l_oHolderElement.appendChild(l_oHtmlButton);
	
	var l_fClickHandler = caplin.core.Utility.getEventListenerFromMethod(this, "_handleGetQuoteButtonClick");
	
	l_oButton.addOnClickListener(l_fClickHandler);
	return l_oButton;
};

/**
 * Handles the get quote button being clicked. Event handling method.
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._handleGetQuoteButtonClick = function()
{
	// Check that there's actually an account set
	if (this.m_oTradeModel.getAccount())
	{
		var l_sTradeType = this.m_oTradeModel.getTradingType();
		var oDealtAmountLeg1Widget = this.m_oDealtAmountLeg1Widget;
		
		try {
			this._AmountValidator(0, oDealtAmountLeg1Widget);
			
			oDealtAmountLeg1Widget = this.m_oDealtAmountLeg2Widget;
			
			if (l_sTradeType == "SWAP") {
				this._AmountValidator(1, oDealtAmountLeg1Widget);
			}
		} 
		catch (oDontOpenTrade) {
			return;
		}
		
		var l_bValueCurrentPair = this.m_oAutoCompleteCurrencyProvider.isValidCurrencyPair(this.m_oInstrumentNameWidget.getValue());
		// Check to see if the curreny pair is valid.
		if (l_bValueCurrentPair !== true) {
			caplin.widget.message.MessageManager.prototype.alert(ct.i18n("cx.trading.presentation.fx.ticket.cannot_trade"));
			return;
		}
		
		var nearLeg = this.m_oTradeModel.getLeg(0);
		
		if (this.m_oTradeModel.getTradingType() == "SWAP" || this.m_oTradeModel.getTradingType() == "FWDFWDSWAP") {
			var farLeg = this.m_oTradeModel.getLeg(1);
			
			var sNearLegDate = nearLeg.getSettlementDate();
			var sFarLegDate = farLeg.getSettlementDate();
			
			if (!this._isValidSettlementDatePair(sNearLegDate, sFarLegDate)) {
				caplin.widget.message.MessageManager.prototype.alert(ct.i18n("cx.trading.presentation.fx.ticket.leg_date"));
				return;
			}
		}
		
		this.m_oRequestQuoteButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.requesting_quote"));
		nearLeg.setBuySell2Way();
		this.m_oTradeModel.processClientEvent("Open");
	}
	else
	{
		caplin.widget.message.MessageManager.prototype.alert(ct.i18n("cx.trading.presentation.fx.ticket.select_account"));
	}
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._isValidSettlementDatePair = function(sNearLegDate, sFarLegDate)
{
	return sNearLegDate < sFarLegDate;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getExecuteTradeButton = function(eHolder, sSide)
{
	var sInitialButtonImagePath = this.m_sLocalImgRoot + (sSide === "LEFT" ? "sell" : "buy");
	var oButton = new caplin.widget.formcontrols.CaplinImageButton(sInitialButtonImagePath, "png");
	var eButton = oButton.getElement();
	eButton.className = "ImageButton";
	caplin.widget.utilities.StyleHelper.updateStyle(eButton,  {
		"position": "relative",
		"margin-left": "auto",
		"margin-right": "auto"
	});
	eHolder.appendChild(eButton);
	
	oButton.addOnClickListener(this._getExecuteTradeCallbackFunction(sSide, this));
	return oButton;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getExecuteTradeCallbackFunction = function(sSide, oThis)
{
	return function()
	{
		var oTradeType = oThis.m_oTradeModel.getTradingType();
		var oLeg1 = oThis.m_oTradeModel.getLeg(0);
		oLeg1.setSide(sSide === 'LEFT' ? "Bid" : "Ask");

		if (oTradeType == "SWAP" || oTradeType == "FWDFWDSWAP")
		{
            var oLeg2 = oThis.m_oTradeModel.getLeg(1);
			oLeg2.setSide(sSide === 'LEFT' ? "Ask" : "Bid");
		}
		//This if added because of PCTD-492 - else it throws an exception if someone clicks the execute button too soon.
		if (oThis._getTicketClassname().match('executable')) 
		{
			oThis.m_oTradeModel.processClientEvent("Execute");
		}
	};
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTradeExecuteButtonCaptions = function()
{
	var oLeg1 = this.m_oTradeModel.getLeg(0);
	var sDealtCurrency = oLeg1.getDealtCurrency();
	var sBaseCurrency = oLeg1.getBaseCurrency();
	var oTradeType = this.m_oTradeModel.getTradingType();
	
	if (oTradeType == "SWAP" || oTradeType == "FWDFWDSWAP") 
	{
		if (sDealtCurrency == sBaseCurrency) 
		{
			this._makeBuyThenSellButton(this.m_oExecuteButtonLeft, sDealtCurrency);
			this._makeSellThenBuyButton(this.m_oExecuteButtonRight, sDealtCurrency);
		}
		else
		{
			this._makeSellThenBuyButton(this.m_oExecuteButtonLeft, sDealtCurrency);
			this._makeBuyThenSellButton(this.m_oExecuteButtonRight, sDealtCurrency);
		}
	}
    else
    {
        if (sDealtCurrency == sBaseCurrency)
        {
        	this._makeSellButton(this.m_oExecuteButtonLeft, sDealtCurrency);
        	this._makeBuyButton(this.m_oExecuteButtonRight, sDealtCurrency);
        }
        else
        {
            this._makeBuyButton(this.m_oExecuteButtonLeft, sDealtCurrency);
            this._makeSellButton(this.m_oExecuteButtonRight, sDealtCurrency);
        }
    }
	// PCTD-712 - alert the user if they click on the buttons before a price update has been received
	// and the trade is executable
	this.m_oExecuteButtonLeft.setDisabledAlertMsg(ct.i18n("cx.trading.presentation.fx.ticket.unable_to_trade"));
	this.m_oExecuteButtonRight.setDisabledAlertMsg(ct.i18n("cx.trading.presentation.fx.ticket.unable_to_trade"));
};

caplinx.trading.presentation.FxTradeTicket.prototype._makeSellButton = function(oExecuteButton, sDealtCurrency)
{
	oExecuteButton.setCaption("<span style='font-size:1.3em'>" + ct.i18n("cx.trading.presentation.fx.ticket.sell") + "<br/>" + sDealtCurrency + "</span>");
	oExecuteButton.setImage(this.m_sLocalImgRoot + "sell");
	oExecuteButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_sell"));
};

caplinx.trading.presentation.FxTradeTicket.prototype._makeBuyButton = function(oExecuteButton, sDealtCurrency)
{
	oExecuteButton.setCaption("<span style='font-size:1.3em'>" + ct.i18n("cx.trading.presentation.fx.ticket.buy") + "<br/>" + sDealtCurrency + "</span>");
	oExecuteButton.setImage(this.m_sLocalImgRoot + "buy");
	oExecuteButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_buy"));
};

caplinx.trading.presentation.FxTradeTicket.prototype._makeSellThenBuyButton = function(oExecuteButton, sDealtCurrency)
{
	oExecuteButton.setCaption("<span style='font-size:1.1em'>" + ct.i18n("cx.trading.presentation.fx.ticket.sell_buy") + "<br/>" + sDealtCurrency + "</span>");
	oExecuteButton.setImage(this.m_sLocalImgRoot + "buy");
	oExecuteButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_sell_buy"));
};

caplinx.trading.presentation.FxTradeTicket.prototype._makeBuyThenSellButton = function(oExecuteButton, sDealtCurrency)
{
	oExecuteButton.setCaption("<span style='font-size:1.1em'>" + ct.i18n("cx.trading.presentation.fx.ticket.buy_sell") + "<br/>" + sDealtCurrency + "</span>");
	oExecuteButton.setImage(this.m_sLocalImgRoot + "sell");
	oExecuteButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_buy_sell"));
};

caplinx.trading.presentation.FxTradeTicket.prototype._disableExecuteButtons = function(sTooltip)
{
	this.m_oExecuteButtonLeft.m_oCaption.style.color = 'gray';
	this.m_oExecuteButtonRight.m_oCaption.style.color = 'gray';
	
	this.m_oExecuteButtonLeft.setEnabled(false);
	this.m_oExecuteButtonRight.setEnabled(false);

	if(sTooltip)
	{
		this.m_oExecuteButtonLeft.setTooltip(sTooltip);
		this.m_oExecuteButtonRight.setTooltip(sTooltip);
		
		this.m_oExecuteButtonLeft.setDisabledAlertMsg(sTooltip);
		this.m_oExecuteButtonRight.setDisabledAlertMsg(sTooltip);
	}
};

caplinx.trading.presentation.FxTradeTicket.prototype._enableExecuteButtons = function()
{
	this.m_oExecuteButtonLeft.m_oCaption.style.color = 'white';
	this.m_oExecuteButtonRight.m_oCaption.style.color = 'white';
	
	this.m_oExecuteButtonLeft.setEnabled(true);
	this.m_oExecuteButtonRight.setEnabled(true);
};

////////////////////////////
// BUTTONS
////////////////////////////

caplinx.trading.presentation.FxTradeTicket.prototype._cancel = function(l_sFieldname)
{
	if (this.m_mExternalConfirmationData != null) 
	{
		var FIELDS = caplin.fields.FieldNames.TRADING.FX;
		var sInstrumentName = this.m_mExternalConfirmationData["L1_" + FIELDS.INSTRUMENT];
		this.setObjectName("/FX/" + sInstrumentName);
		this.m_mExternalConfirmationData = null;
		
		if (this.m_bIsInitialised == true) 
		{
			this.reinitialize();
		}
		else 
		{
			this.initialize();
		}
	}
    else
    {
        var l_sState = this.m_oTradeModel.getCurrentState().getName();

        // if TradeConfirmed then we have successfully traded and so reset everything so the ticket is as new
        if (l_sState == "TradeConfirmed")
        {
            //persist the account but not the type or values
            this._resetTradeModel(false, true, false);
        }
        else // the user has cancelled the trade midway through so keep all values and re enable the display
        {
            if (this.m_oTradeModel.isEventAllowed("ClientClose"))
            {
                this.m_oTradeModel.processClientEvent("ClientClose");
            }
		
            this._resetTradeModel(true, true, false);
        }
		
    }
};

caplinx.trading.presentation.FxTradeTicket.PRINT_INNERHTML = "";

caplinx.trading.presentation.FxTradeTicket.prototype._printButtonAction = function(l_sFieldname)
{
	var l_oConfirmation = this._getTemplateElement("CONFIRMATION_TICKET");
	
	//If there is a blotter trading type use that
	if (this.m_sBlotterTradingType != null) 
	{
		var l_sTradeType = this.m_sBlotterTradingType;
	}
	else 
	{
		var l_sTradeType = this.m_oTradeModel.getTradingType();
	}
	
	var l_sHtml = "<div class='" + this._getConfirmedClassName(l_sTradeType) + "'>";
	l_sHtml += l_oConfirmation.innerHTML;
	l_sHtml += "</div>";
	caplinx.trading.presentation.FxTradeTicket.PRINT_INNER_HTML = l_sHtml;
	
	//Set the domain as a parameter, the html page picks it up using location.href.
	//It then picks up the html from the PRINT_INNER_HTML variable.
	var l_sUrl = "blades/FxGrids/src/fxticket_print_template.html?domain=" + window.document.domain;
	
	var l_sName = "caplinprintwindow";
	var l_sFeatures = "width=600,height=500,left=10,top=10";
	l_sFeatures += ",menubar=0,toolbar=0,status=0,scrollbars=1,resizable=1";
	var l_oPrintWindow = window.open(l_sUrl, l_sName, l_sFeatures);
};

/** @private */
caplinx.trading.presentation.FxTradeTicket.prototype._getButton = function(l_oHolderElement, l_fCallback)
{
	var l_oButton = new caplin.widget.formcontrols.ThreeImageButton('', this.m_sGlobalImgRoot + "buttons/capbutton");
	var l_oHtmlButton = l_oButton.getElement();
	caplin.widget.utilities.StyleHelper.updateStyle(l_oHtmlButton, 
	{
		"position": "relative"
	});
	l_oHolderElement.appendChild(l_oHtmlButton);
	l_oButton.addOnClickListener(l_fCallback);
	return l_oButton;
};

////////////////////
// utilities
////////////////////

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getElementId = function(l_sFieldname)
{
	return "FxTicket-" + this.m_nSequenceNumber + "-" + l_sFieldname;
};

/*
 *
 * Work out if the  trade model needs resetting. it should only be reset if moving from a 1 leg trade to a 2 leg trade
 * Assume that it does need resetting until a case is proved otherwise
 */
caplinx.trading.presentation.FxTradeTicket.prototype._doResetTradeModelValues = function(sTradingType, sOldTradingType)
{
	if (sTradingType == 'FWD' && sOldTradingType == 'SPOT') 
	{
		return false;
	}
	
	if (sTradingType == 'SPOT' && sOldTradingType == 'FWD') 
	{
		return false;
	}
	
	if (sTradingType == 'SWAP' && sOldTradingType == 'FWDFWDSWAP') 
	{
		return false;
	}
	
	if (sTradingType == 'FWDFWDSWAP' && sOldTradingType == 'SWAP') 
	{
		return false;
	}
	// check to see if the ticket has been init
	if (this.m_bIsInitialised == false) 
	{
		return false;
	}
	if (sTradingType == sOldTradingType) 
	{
		return false;
	}
	return true;
};

caplinx.trading.presentation.FxTradeTicket.prototype._getConfirmedClassName = function(l_sTradeType)
{
	return "fxticket fxticket-" + l_sTradeType.toLowerCase() + " fxticket-confirmed";
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._getTicketClassname = function()
{
	var l_sTradeTypeClassname = this.m_oTradeModel.getTradingType().toLowerCase();
	var classname = "fxticket fxticket-" + l_sTradeTypeClassname + " fxticket-";
	
	var l_sStatename = this.m_oTradeModel.getCurrentState().getName();
	
	var stateClassname = l_sStatename.toLowerCase();
	switch (l_sStatename)
	{
		case "Initial": //0 Trade class instantiated
			stateClassname = "beforeopen";
			stateClassname += this.m_bSwapLegsAreCoupled ? " swaplegcoupled" : " swapleguncoupled";
			break;
		case "OpenSent": // 1 open message sent to server
			stateClassname = "opening";
			break;
		case "Opened": // 2 Open ack received from server
			stateClassname = "open";
			break;
		case "Executable": // 3 first price update received  from server
			stateClassname = "executable";
			break;
		case "ExecuteSent": //4 Execute message sent to server
			stateClassname = "executing";
			break;
		case "Executed": //5 Execute Ack message received from server
			stateClassname = "executing";
			break;
		case "TradeConfirmed": // 6 TradeConfirmed message received from server
			stateClassname = "confirmed";
			break;
			
		case "Withdrawn":
			stateClassname = "open";
			break;
		case "ClientCloseSent":
			stateClassname = "initialising";
			break;
		case "ClientClosed":
			stateClassname = "initialising";
			break;
		case "TradePassed":
			stateClassname = "cancelled";
			break;
		case "ExecuteExpired":
			stateClassname = "cancelled";
			break;
		case "Expired":
			stateClassname = "cancelled";
			break;
	}
	classname += stateClassname;
	
	return classname;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setStatusMessage = function(l_sMessage)
{
	this.m_oStatusMessageHolder.innerHTML = l_sMessage;
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTimerMessage = function(l_sMessage)
{
	if (this.m_oStatusTimerHolder != undefined && l_sMessage != undefined) 
	{
		this.m_oStatusTimerHolder.innerHTML = l_sMessage;
	}
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._displayAmountAsText = function(l_sMessage)
{
	var l_nAmount = this.m_oTradeModel.getLeg(0).getAmount();
	var l_sHtml = this._formatWithCommas(l_nAmount);
	//this.m_oAmountDisplayLeg1.innerHTML = l_sHtml;
	
	var l_sTradingType = this.m_oTradeModel.getTradingType();
	if (l_sTradingType == "SWAP" || l_sTradingType == "FWDFWDSWAP") 
	{
		var l_nAmount2 = this.m_oTradeModel.getLeg(1).getAmount();
		var l_sHtml = this._formatWithCommas(l_nAmount2);
		//this.m_oAmountDisplayLeg2.innerHTML = l_sHtml;
	}
};

/**
 * @private
 */
//Should be in a utils class/lib?
caplinx.trading.presentation.FxTradeTicket.prototype._formatWithCommas = function(l_nAmount)
{
	var l_sAmount = new String(l_nAmount);
	for (var i = l_sAmount.length - 3; i > 0; i -= 3) 
	{
		l_sAmount = l_sAmount.substr(0, i) + "," + l_sAmount.substr(i);
	}
	return l_sAmount;
};

/**
 * @private
 *
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTimeoutMessageAndRecycle = function(l_sMessage)
{
	this._cancel();
	this._setTimerMessage(l_sMessage);
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setButtonsForTradeAgain = function()
{
	this.m_oFooterCloseButton.disable(false);
	this.m_oFooterCancelButton.disable(false);
	this.m_oFooterPrintButton.disable(false);
	this.m_oFooterCancelButton.setCaption(ct.i18n("cx.trading.presentation.fx.ticket.new_trade"));
	this.m_oFooterCancelButton.setWidth(83);
	this.m_oFooterCancelButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.trade_again"));
	this.m_bCreateNewTradeOnCancel = true;
	this._resetCouplingButton();
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setButtonsForInitial = function()
{
	this.m_oFooterCancelButton.disable(true);
	this.m_oFooterCancelButton.setCaption(ct.i18n("cx.trading.presentation.fx.ticket.cancel"));
	this.m_oFooterCancelButton.setWidth(50);
	this.m_oFooterCancelButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_cancel"));
	
	this.m_oFooterCloseButton.disable(false);
	this.m_oFooterCloseButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_close"));
	this.m_oFooterCloseButton.setCaption(ct.i18n("cx.trading.presentation.fx.ticket.close"));
	
	this.m_oFooterPrintButton.setTooltip(ct.i18n("cx.trading.presentation.fx.ticket.click_to_print"));
	this.m_oFooterPrintButton.setCaption(ct.i18n("cx.trading.presentation.fx.ticket.print"));
	this.m_oFooterPrintButton.disable(true);
	
	this._checkIfGetQuoteIsEnabled();
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._setTicketDataFieldsDisabled = function(bDisabled)
{
	this.m_oInstrumentNameWidget.setEnabled(!bDisabled);
	this._setTicketDataFieldsDisabledExcludingInstrumentName(bDisabled);
};

caplinx.trading.presentation.FxTradeTicket.prototype._setTicketDataFieldsDisabledExcludingInstrumentName = function(bDisabled)
{
	this.m_oProductSearchWidget.disable(bDisabled);
	this.m_oRequestQuoteButton.setEnabled(!bDisabled);
	this.m_oDealtAmountLeg1Widget.disabled = bDisabled;
	if (this.m_oDealtAmountLeg2Widget != null) 
	{
		this.m_oDealtAmountLeg2Widget.disabled = bDisabled;
	}
	
	if (bDisabled) 
	{
		this.m_oTradeTypeControl.disable();
		this.m_oAccountWidget.disable();
		this.m_oSettlementTenorLeg1Control.disable();
		if (this.m_oSettlementTenorLeg2Control != null) 
		{
			this.m_oSettlementTenorLeg2Control.disable();
		}
	}
	else
	{
		this.m_oTradeTypeControl.enable();
		this.m_oAccountWidget.enable();
		this.m_oSettlementTenorLeg1Control.enable();
		if (this.m_oSettlementTenorLeg2Control != null) 
		{
			this.m_oSettlementTenorLeg2Control.enable();
		}
	}
	this.m_oFlipCurrencyControl.disable(bDisabled);
	
	if (this.m_oCouplingButton) {
		this.m_oCouplingButton.disable(bDisabled);	
	}
	
	this.m_oSettlementDateCalendarLeg1Control.setEnabled(!bDisabled);
	if (this.m_oSettlementDateCalendarLeg2Control != null) 
	{
		this.m_oSettlementDateCalendarLeg2Control.setEnabled(!bDisabled);
	}
};

// generic error handling allows any type of error with a friendly and complete description
caplinx.trading.presentation.FxTradeTicket.prototype.showTradingFailedMessage = function(sFriendlyError, sCompleteError)
{
	var sErrorMessage = sCompleteError;
	sErrorMessage = sErrorMessage.replace("'", "");
	sErrorMessage = sErrorMessage.replace('"', '');
	sErrorMessage = sErrorMessage.replace(/\n/, '\n');
	
	if (this.m_oElementCache[this.m_sSTATUS]) 
	{
		this.m_oElementCache[this.m_sSTATUS].innerHTML = 
				"<span class='trade-ticket-error' onclick='caplin.widget.message.MessageManager.getInstance().alert(\"" +
				sErrorMessage + "\");'>error</>";
	}
	else 
	{
		caplin.widget.message.MessageManager.getInstance().alert(ct.i18n("cx.trading.presentation.fx.ticket.trade_failed") + ' ' + sFriendlyError);
		caplin.core.Logger.log(caplin.core.LogLevel.WARN, ct.i18n("cx.trading.presentation.fx.ticket.trade_failed")+ ' ' + sErrorMessage);
	}
	
	return sErrorMessage;
};

caplinx.trading.presentation.FxTradeTicket.prototype._displayConfirmation = function(l_oTradeData, l_bIsFromBlotter)
{
	var FIELDS = caplin.fields.FieldNames.TRADING.FX;
	
	//Stub data to display in confirmation ticket until blotter provides actual data
	if (l_bIsFromBlotter)
	{
		var l_sCcyPair = l_oTradeData["L1_" + FIELDS.INSTRUMENT];
		l_oTradeData[FIELDS.BASE_CURRENCY] = l_sCcyPair.substring(0, 3);
		l_oTradeData[FIELDS.TERM_CURRENCY] = l_sCcyPair.substring(3, 6);
	}
	else 
	{
		this.m_sBlotterTradingType = null;
	}

	// process trade
    switch (l_oTradeData[FIELDS.TRADING_TYPE]) {
        case "SPOT" :
        case "FWD"  : this._processSpotOrForwardTradeConfirmation(l_oTradeData);
                      break;
        default     : this._processSwapTradeConfirmation(l_oTradeData);
    }
    this._processSubmittedInformation(l_oTradeData);
};

caplinx.trading.presentation.FxTradeTicket.prototype._processSpotOrForwardTradeConfirmation = function (l_oTradeData)
{
    var FIELDS = caplin.fields.FieldNames.TRADING.FX;

    var l_sTradeType = l_oTradeData[FIELDS.TRADING_TYPE];
	var l_sBaseCcy = l_oTradeData[FIELDS.BASE_CURRENCY];
    var l_sTermCcy = l_oTradeData[FIELDS.TERM_CURRENCY];
    var l_sDealtCcy = l_oTradeData[FIELDS.DEALT_CURRENCY];

    var l_sBuyHtml = "";
	var l_sSellHtml = "";

	/* Process spot trades and forwards*/
    var l_oElem = this._getTemplateElement("CONFIRMATION_SPOTFWD_LABEL");

    l_oElem.innerHTML = l_sTradeType == "SPOT" ? "Spot " : "Forward ";

    var l_sAmount = l_oTradeData["L1_" + FIELDS.LEG.AMOUNT];
    if (this._isDealtCurrencySold(l_oTradeData))
    {
        l_sSellHtml = l_sDealtCcy;
        l_sBuyHtml = l_sDealtCcy == l_sBaseCcy ? l_sTermCcy : l_sBaseCcy;
        l_sSellHtml += "\u00A0";
        l_sSellHtml += this.m_oZeroDecimalPlaceTextFormatter.formatText(l_sAmount);
    }
    else
    {
        l_sBuyHtml = l_oTradeData[FIELDS.DEALT_CURRENCY];
        l_sSellHtml = l_sDealtCcy == l_sBaseCcy ? l_sTermCcy : l_sBaseCcy;
        l_sBuyHtml += "\u00A0";
        l_sBuyHtml += this.m_oZeroDecimalPlaceTextFormatter.formatText(l_sAmount);
    }

    /*Refresh tradeid in case we have come off the blotter and this isn't set*/
    this._setTradeIdTitle("ID: " + l_oTradeData[FIELDS.TRADE_ID]);

    l_oElem = this._getTemplateElement("CONFIRMATION_SPOTFWD_SOLD_AMOUNT");
    l_oElem.innerHTML = l_sSellHtml;

    l_oElem = this._getTemplateElement("CONFIRMATION_SPOTFWD_BOUGHT_AMOUNT");
    l_oElem.innerHTML = l_sBuyHtml;

    l_oElem = this._getTemplateElement("CONFIRMATION_SPOTFWD_RATE");
    l_oElem.innerHTML = l_oTradeData["L1_" + FIELDS.LEG.PRICE];

    l_oElem = this._getTemplateElement("CONFIRMATION_SPOTFWD_VALUE_DATE");
    var l_sDate = l_oTradeData["L1_" + FIELDS.LEG.SETTLEMENT_DATE];
    l_oElem.innerHTML = caplin.element.formatter.DateFormatter.format(l_sDate, this.m_mDateFormatParams);
};

caplinx.trading.presentation.FxTradeTicket.prototype._processSwapTradeConfirmation = function (l_oTradeData)
{
    var FIELDS = caplin.fields.FieldNames.TRADING.FX;

    var l_sBaseCcy = l_oTradeData[FIELDS.BASE_CURRENCY];
    var l_sTermCcy = l_oTradeData[FIELDS.TERM_CURRENCY];
	var l_sDealtCcy = l_oTradeData[FIELDS.DEALT_CURRENCY];

    /* We already know the dealt currency. We also need to know what isn't the dealt currency.
	 * The inverse of the dealt currency */
    var l_oInverseDealtCcy = l_sDealtCcy == l_sBaseCcy ? l_sTermCcy : l_sBaseCcy;

	//DO SWAP AND SWAP-FWD
    var l_sNearAction = "SOLD";
    var l_sFarAction = "BOUGHT";

	if (l_oTradeData[FIELDS.BUY_OR_SELL] === "SELL")
    {
        l_sNearAction = "BOUGHT";
        l_sFarAction = "SOLD";
    }

    var l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_DIRECTION");
    l_oElem.innerHTML = l_sNearAction + "-" + l_sFarAction;

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_SUMMARY");

    var sLegOneTradeSide = l_oTradeData["L1_" + FIELDS.LEG.SIDE];
    if (sLegOneTradeSide == "Bid")
	{
		var l_sPoints = l_oTradeData["L2_" + "BidSwapPoints"];
	}
	else
	{
		var l_sPoints = l_oTradeData["L2_" + "AskSwapPoints"];
	}

    /*l_oElem.innerHTML = oLeg1.getDealtCurrency() + " against " + oLeg1.getNotDealtCurrency() + " " + l_sPoints;*/
    l_oElem.innerHTML = l_sDealtCcy + " against " + l_oInverseDealtCcy + " " + l_sPoints;

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_NEAR_ACTION");
    l_oElem.innerHTML = l_sNearAction;

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_FAR_ACTION");
    l_oElem.innerHTML = l_sFarAction;

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_NEAR_AMOUNT");
    l_oElem.innerHTML = l_sDealtCcy + " " + this.m_oZeroDecimalPlaceTextFormatter.formatText(l_oTradeData["L1_" + FIELDS.LEG.AMOUNT]);

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_FAR_AMOUNT");
    l_oElem.innerHTML = l_sDealtCcy + " " + this.m_oZeroDecimalPlaceTextFormatter.formatText(l_oTradeData["L2_" + FIELDS.LEG.AMOUNT]);

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_NEAR_VALUE_DATE");
    l_oElem.innerHTML = caplin.element.formatter.DateFormatter.format(l_oTradeData["L1_" + FIELDS.LEG.SETTLEMENT_DATE], this.m_mDateFormatParams);

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_FAR_VALUE_DATE");
    l_oElem.innerHTML = caplin.element.formatter.DateFormatter.format(l_oTradeData["L2_" + FIELDS.LEG.SETTLEMENT_DATE], this.m_mDateFormatParams);

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_NEAR_RATE");
    l_oElem.innerHTML = l_oTradeData["L1_" + FIELDS.LEG.PRICE];

    l_oElem = this._getTemplateElement("CONFIRMATION_SWAP_FAR_RATE");
    l_oElem.innerHTML = l_oTradeData["L2_" + FIELDS.LEG.PRICE];
};

caplinx.trading.presentation.FxTradeTicket.prototype._processSubmittedInformation = function(l_oTradeData)
{
	try
	{
		var l_oElem = this._getTemplateElement("CONFIRMATION_SUBMITTED_FOR");
		if(l_oTradeData.TOBOUser)
		{
			l_oElem.innerHTML = l_oTradeData.TOBOUser;
		}
		else
		{
			l_oElem.parentNode.className = "no-tobo-user";
		}
		
		l_oElem = this._getTemplateElement("CONFIRMATION_SUBMITTED_BY");
		l_oElem.innerHTML = l_oTradeData.UserName;
		
		l_oElem = this._getTemplateElement("CONFIRMATION_ACCOUNT");
		l_oElem.innerHTML = l_oTradeData.Account;
	} 
	catch(e){}
};

caplinx.trading.presentation.FxTradeTicket.prototype._isDealtCurrencySold = function(l_oTradeData)
{
	var FIELDS = caplin.fields.FieldNames.TRADING.FX;
	var l_sBuySell = l_oTradeData[FIELDS.BUY_OR_SELL];
	return l_sBuySell == "SELL";
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._startOverallTimeout = function(l_nTimeout)
{
	// the end time is the time now, plus the overall timeout
	this.m_nEndTime = (new Date()).valueOf() + (l_nTimeout * 1000);
	this._updateTimeout();
};

/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._updateTimeout = function()
{
	if (this.m_oTradeModel.getCurrentState().getName() != "Executable") 
	{
		return;
	}
	
	if (this.m_nEndTime != -1) 
	{
		var l_nRemainingTime = Math.floor((this.m_nEndTime - (new Date()).valueOf()) / 1000);
		this.m_oStatusTimerHolder.innerHTML = Math.max(0, l_nRemainingTime);
		
		if (l_nRemainingTime > 0) 
		{
			window.setTimeout(this.m_fCountdownFunction, this.m_nOverallTimeOut || 500);
		}
	}
};
/**
 * @private
 */
caplinx.trading.presentation.FxTradeTicket.prototype._cleanUpTicket = function()
{
	if (this.m_oTradeTypeControl)
	{
		this.m_oTradeTypeControl.collapse();
	}
	if (this.m_oAccountWidget)
	{
		this.m_oAccountWidget.collapse();
	}
	if (this.m_oSettlementTenorLeg1Control)
	{
		this.m_oSettlementTenorLeg1Control.collapse();
	}
	if (this.m_oSettlementTenorLeg2Control)
	{
		this.m_oSettlementTenorLeg2Control.collapse();
	}

	this.m_oFooterCloseButton.OnMouseOut();
	this.m_oFooterCancelButton.OnMouseOut();
	this.m_oFooterPrintButton.OnMouseOut();
};

caplinx.trading.presentation.FxTradeTicket.prototype.onTOBOUserChanged = function(sUser)
{
	if(sUser === caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT)
	{
		this._close();
	}
	else 
	{
		this.m_sCurrentlySelectedToboUser = sUser;
		this._setTradeIdTitle("");
		this.m_oAccountWidget.clearValue();
		this.m_oTradeModel.setUserTradedOnBehalfOf(sUser);
		this.m_oTradeModel.setAccount(undefined);
		var eSubmittedElement = this._getTemplateElement("SUBMITTED_FOR");
		eSubmittedElement.innerHTML = sUser;
		eSubmittedElement.parentNode.className = "";
	}
}

caplinx.trading.presentation.FxTradeTicket.prototype.onTOBOAccountChanged = function(sAccount)
{
	this.m_sCurrentlySelectedMainAccount = sAccount;
}

caplinx.trading.presentation.FxTradeTicket.prototype.onTOBOAccountListChanged = function(pAccountList)
{
	// Populate the accounts list
	var pFormattedAccountData = this._formatDataForExtComponent(pAccountList);
	this.m_oAccountWidget.getStore().loadData(pFormattedAccountData, false);
};

caplinx.trading.presentation.FxTradeTicket.prototype._formatDataForExtComponent = function(pData)
{
	var pFormatedData = [];
	for (var i = 0, nLength = pData.length; i < nLength; ++i)
	{
		pFormatedData.push([pData[i], pData[i]]);
	}
	return pFormatedData;
};
