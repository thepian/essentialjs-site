caplin.namespace("caplinx.trading.presentation.tile");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.trading.presentation.tile.TileViewHeader", true);
caplin.include("caplin.services.AbstractFactory");
caplin.include("caplin.dom.AbstractFactory");
caplin.include("caplin.dom.controls.form.AutoCompleteComboBox");
caplin.include("caplin.security.permissioning.PermissionService");

/**
 * @see caplin.trading.presentation.tile.TileViewHeader
 */
caplinx.trading.presentation.tile.FxTileViewHeader = function(oPersistenceModel)
{
	this.m_oPersistenceModel = oPersistenceModel;
	this.m_oTileView = null;
	
	this.m_oCurrencyAutoCompleteBox = null;
	this.m_pTiles = [];
	
	this.m_oAutoCompleteCurrencyProvider = caplin.services.AbstractFactory.getInstance().getCurrencyPairAutoCompleteProvider();
};
caplin.implement(caplinx.trading.presentation.tile.FxTileViewHeader, caplin.trading.presentation.tile.TileViewHeader);

/**
 * @see caplin.trading.presentation.tile.TileViewHeader#generateHtml
 */
caplinx.trading.presentation.tile.FxTileViewHeader.prototype.generateHtml = function()
{
	return this._getMainContent();
};

caplinx.trading.presentation.tile.FxTileViewHeader.prototype.setTileView = function(oTileView)
{
	this.m_oTileView = oTileView;
};

caplinx.trading.presentation.tile.FxTileViewHeader.prototype.onTileAdded = function(oTile)
{
	this.m_pTiles.push(oTile);
};

caplinx.trading.presentation.tile.FxTileViewHeader.prototype.getSerializedState = function()
{
	return this.m_oPersistenceModel.getSerializedState();
};

/**
 * Function called by AutoCompleteBox when the enter key is hit
 * @param {Object} sValue
 */
caplinx.trading.presentation.tile.FxTileViewHeader.prototype.onSelect = function(sValue)
{
	this.m_oTileView.addTile('/FX/' + sValue.toUpperCase());
};

/*********************************************************************
 *********************** Private Methods *****************************
 *********************************************************************/

/**
 * @private
 */
caplinx.trading.presentation.tile.FxTileViewHeader.prototype._validateNewTileName = function(sName)
{	
	var pValidCurrencies = this.m_oAutoCompleteCurrencyProvider.getAutoCompleteList(sName);
	
	return (pValidCurrencies.length !== 0);
};

/**
 * @private
 * @param {Object} eCurrencyPairContainer
 */
caplinx.trading.presentation.tile.FxTileViewHeader.prototype._createAutoCompleteBox = function(eCurrencyPairContainer){
	eCurrencyPairContainer.className = "TraderPanel_QuickSearch";
	var oPairText = eCurrencyPairContainer.appendChild(document.createElement("span"));
	oPairText.innerHTML = ct.i18n("cx.trading.presentation.fx.tile.add_currency_pair");

	var mProperties =  {
		inputClassName: 'AutoCompleteInput',
		listClassName: 'AutoCompleteList',
		listItemClassName: 'AutoCompleteListItem',
		inputSize: 8,
		inputMaxLength: 6,
		autoCompleteText: false,
		blurFiresSelect: false,
		clearOnSelect: true,
		displayListOnSingleResult: true
	};
	
	var oAutoCompleteBox = new caplin.dom.controls.form.AutoCompleteComboBox(eCurrencyPairContainer, this.m_oAutoCompleteCurrencyProvider, this, mProperties);
	
	return oAutoCompleteBox;
};

/**
 *  @private
 */
caplinx.trading.presentation.tile.FxTileViewHeader.prototype._getMainContent = function()
{
	var oHeaderContainerElem = document.createElement("div");
	oHeaderContainerElem.className = "TraderPanel_accountBoxArea";
	oHeaderContainerElem.style.cssText = "clear:both;";
	
	var eCurrencyPairContainer = document.createElement("div");
	this.m_oCurrencyAutoCompleteBox = this._createAutoCompleteBox(eCurrencyPairContainer);
	oHeaderContainerElem.appendChild(eCurrencyPairContainer);    

	var eClearDiv = document.createElement("div");
	eClearDiv.style.cssText = "clear:both;";
	oHeaderContainerElem.appendChild(eClearDiv);
	
	return oHeaderContainerElem;
};
