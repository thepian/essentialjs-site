/**
 * @fileoverview
 * Defines caplinx.historicdata.BenchmarkController class.
 */

caplin.namespace("caplinx.historicdata");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.component.composite.CompositeComponentController", true);
caplin.include("caplin.component.comms.OpenAjaxChannelSubscriptionHelper");
caplin.include("caplin.component.comms.InterComponentComms");
caplin.include("caplinx.historicdata.BenchmarkSettingsController");
caplin.include("caplin.chart.menu.ContextMenu");
caplin.include("caplin.chart.TableFormatter");
caplin.include("caplin.chart.HTMLTableGenerator");
caplin.include("caplin.core.Utility");

/**
 * Constructs a new <code>BenchmarkController</code>.
 * @class
 * 
 * <p>This class is a {@link caplin.component.composite.CompositeComponentController}. The component it controls
 * is composed of a Chart (see {@link caplin.chart.ChartView}), a Grid (see {@link caplin.grid.GridView}),
 * and a Form (see {@link caplin.component.form.SimpleFormComponent}). The controller handles the showing and hiding
 * of the Chart, Grid and settings form.</p>
 * 
 * <p>The Chart displays benchmark yield curves for instruments and the Grid displays the benchmark yield curve data
 * in a tabular format. The Form component is used to create a settings panel that allows a user to remove yield curves
 * from the chart, update an existing curve, and add a new curve. For more information on the settings panel see 
 * {@link caplinx.historicdata.BenchmarkSettingsController}.</p>
 * 
 * <p>The <code>BenchmarkController</code> does not interact directly with the components. All communication is performed over
 * the OpenAjax message hub. So, although the composite controller knows that it contains a Chart, a Grid, and a Form, the components
 * do not need to know that they are within a composite component. The controller will only ever interact with the components as 
 * {@link caplin.component.Component} and not as their specific type. For example, the controller should never interact with the
 * Grid component as a {@link caplin.grid.GridView}. This has been done to reduce the coupling between components. For more
 * information on the OpenAjax hub see the
 * <a href="http://www.openajax.org/member/wiki/OpenAjax_Hub_1.0_Specification>OpenAjax hub 1.0 specification</a></p>
 * 
 * @implements caplin.component.composite.CompositeComponentController
 */
caplinx.historicdata.BenchmarkController = function()
{
	/**
	 * @private
	 * @type Map
	 * The components held within this composite component.
	 */
	this.m_mComponents = null;
	
	/** 
	 * @private
	 * @type caplin.component.composite.CompositeComponent
	 */
	this.m_oCompositeComponent = null;
	
	/**
	 * An Array of caplin.component.comms.OpenAjaxChannelSubscriptionHelper
	 * @type Array
	 * @private
	 */
	this.m_pOpenAjaxSubscriptionHelpers = [];
	
	/**
	 * @private
	 * @type caplinx.historicdata.BenchmarkSettingsController
	 * Object that handles the form settings panel.
	 */
	this.m_oBenchmarkSettingsController = null;
	
	/**
	 * @private
	 * @type caplin.chart.menu.HDCContextMenu
	 * Object used to display a context menu
	 */
	this.m_oContextMenu = this._getContextMenu();
};
caplin.implement(caplinx.historicdata.BenchmarkController, caplin.component.composite.CompositeComponentController);

/*******************************************************************************
 *      caplin.component.composite.CompositeComponentController Interface
 *******************************************************************************/

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#initialize
 */
caplinx.historicdata.BenchmarkController.prototype.initialize = function(mComponents, oCompositeComponent)
{
	this.m_mComponents = mComponents;
	for(sComponentName in this.m_mComponents)
	{
		if(sComponentName === "chartSettingsPanel")
		{
			this.m_oBenchmarkSettingsController =
				new caplinx.historicdata.BenchmarkSettingsController( this.m_mComponents[sComponentName] );
		}
	}	
	
	if(!OpenAjax)
	{
		throw new caplin.core.Exception("The OpenAjax hub is not defined", "caplinx.historicdata.BenchmarkController.initialize");
	}
		
	this.m_oCompositeComponent = oCompositeComponent;

	this._setupChannels();	
	this._setupContextMenu(this.m_oCompositeComponent);
};	

/**
 * @private
 * @see caplin.component.composite.CompositeComponentController#finalize
 */
caplinx.historicdata.BenchmarkController.prototype.finalize = function()
{
	if(this.m_pOpenAjaxSubscriptionHelpers.length > 0)
	{
		for(var i = 0, l = this.m_pOpenAjaxSubscriptionHelpers.length ; i < l ; i++)
		{
			this.m_pOpenAjaxSubscriptionHelpers[ i ].finalize();
		}
		this.m_pOpenAjaxSubscriptionHelpers = null;
	}
	
	this.m_oBenchmarkSettingsController.finalize();
	
	this.m_mComponents = null;
	this.m_oContextMenu.finalize();
};

/*******************************************************************************
 *             					Public Methods
 *******************************************************************************/

/**
 * @private
 * Hides and shows the Chart and Grid. Only one is shown at any one time.
 */
caplinx.historicdata.BenchmarkController.prototype.toggleView = function()
{
	var nChartSize = this.m_oCompositeComponent.getComponentSize("chart");
	if (nChartSize === 0) {
		this.m_oCompositeComponent.hideComponent("grid");
		this.m_oContextMenu.setItemText("showComponent", ct.i18n("cx.historic.data.context.menu.show_data"));
	} else {
		this.m_oCompositeComponent.hideComponent("chart");
		this.m_oContextMenu.setItemText("showComponent", ct.i18n("cx.historic.data.context.menu.show_chart"));
	}
};

/**
 * This method is responsible for showing/hiding the settings panel
 */
caplinx.historicdata.BenchmarkController.prototype.toggleSettingsPanel = function()
{
	var nSettingsPanelSize = this.m_oCompositeComponent.getComponentSize("chartSettingsPanel");
	if(nSettingsPanelSize > 0)
	{
		this.m_oCompositeComponent.hideComponent("chartSettingsPanel");
	}
	else
	{
		this.m_oCompositeComponent.$setComponentSize("chartSettingsPanel", 74);
	}
};

/**
 * This method is responsible for printing the chart
 */
caplinx.historicdata.BenchmarkController.prototype.print = function()
{
	var nChartSize = this.m_oCompositeComponent.getComponentSize("chart");
	if (nChartSize === 0)
	{
		var oGridView = this.m_mComponents.grid;
		var oGridRowModel = oGridView.getGridRowModel();
		var oDataProvider = oGridRowModel._$getDataProvider();
		var pTableData = oDataProvider.getDataForAllRows();
		var mRendererTypes = oGridView.getRendererTypesIndexedByColumnName();
		var oTableFormatter = new caplin.chart.TableFormatter();
		var pData = oTableFormatter.formatTable(pTableData, mRendererTypes);
		var pFields = oDataProvider.getDataSetFields();
		
		var htmlTableGenerator = new caplin.chart.HTMLTableGenerator();
		var sTable = htmlTableGenerator.generateHTMLTable(pFields, pData);
		
		var sUrl = "gridPrintPage.html?domain=" + window.document.domain;
		var nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
		var l_sFeatures = "width=650,height=800,left=10,top=10";
		l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
		l_oPrintWindow = window.open(sUrl, nWindowId, l_sFeatures);
		
		setTimeout(function(){
			if(l_oPrintWindow){
				l_oPrintWindow.document.body.innerHTML = sTable;
			}
		}, 1000);
		return false;		
	}
	else
	{
		var oChart = this.m_mComponents.chart;
		caplinx.historicdata.BenchmarkController.Chart = oChart;
	
		//Set the domain and chart title as parameters. The html page picks it up using location.href.
		var sTitle = webcentric.getActiveComponent().get("caption");
		var l_sUrl = "benchmark_chart_print_template.html?domain=" + window.document.domain + "&title=" + sTitle;
	
		var nWindowId = caplin.core.Utility.createApplicationInstanceUniqueId();
		var l_sFeatures = "width=650,height=910,left=10,top=10";
		l_sFeatures += ",menubar=1,location=0,toolbar=0,status=0,scrollbars=1,resizable=1";
		l_oPrintWindow = window.open(l_sUrl, nWindowId, l_sFeatures);
	}
};

/**
 * @private
 */
caplinx.historicdata.BenchmarkController.prototype._generateTable = function()
{
	var pTable = [];
	var oGridView = this.m_mComponents.grid;
	var oGridRowModel = oGridView.getGridRowModel();
	for(var i = 0, n = oGridRowModel.getSize() ; i < n ; ++i)
	{
		var oRowData = oGridRowModel.getRowData(i);
		pTable.push(oRowData);
	}
	return pTable;
};

/**
 * This method is responsible for showing and hiding the context menu
 */
caplinx.historicdata.BenchmarkController.prototype.toggleContextMenu = function()
{
	this._refreshContextMenu();
	this.m_oContextMenu.toggle();
};

/*******************************************************************************
 *             					Private Methods
 *******************************************************************************/

/**
 * @private
 * Sets up objects that help with the listening for events over the OpenAjax hub.
 */
caplinx.historicdata.BenchmarkController.prototype._setupChannels = function()
{
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "toggle", this, this.toggleView));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "toggleSettingsPanel", this, this.toggleSettingsPanel));
	this.m_pOpenAjaxSubscriptionHelpers.push(new caplin.component.comms.OpenAjaxChannelSubscriptionHelper(this.m_oCompositeComponent, "settings", "print", this, this.print));
		
	var pComponentsToLink = [this.m_oCompositeComponent];
	
	for (var sKey in this.m_mComponents)
	{
		pComponentsToLink.push(this.m_mComponents[sKey]);
	}
	
	caplin.component.comms.InterComponentComms.linkComponents(pComponentsToLink);
};

/**
 * @private
 */
caplinx.historicdata.BenchmarkController.prototype._setupContextMenu = function(oComponent)
{	
	var eCompositeComponentElement = this.m_oCompositeComponent.getElement();	
	eCompositeComponentElement.appendChild(this.m_oContextMenu.getElement());
	this.m_oContextMenu.setRelativeElement(eCompositeComponentElement);
	this.m_oContextMenu.setComponent(oComponent);
};

/**
 * This function is executed when a user clicks on the Cancel button of the Settings Menu.
 * The effect is that the Settings Menu is toggled (i.e. closed)
 * @private
 */
caplinx.historicdata.BenchmarkController.prototype._onClose = function()
{
	this._toggleSettingsPanel();
};

/**
 * @private
 */
caplinx.historicdata.BenchmarkController.prototype._getContextMenu = function()
{
	var oContextMenuConfig = {
		showComponent: {
			text:ct.i18n("cx.historic.data.context.menu.show_data"),
			disabled:false,
			event:"toggle"
		},
		settings: {
			text:ct.i18n("cx.historic.data.context.menu.show_settings"),
			disabled:false,
			event:"toggleSettingsPanel"
		},
		exportToExcel: {
			text:ct.i18n("cx.historic.data.context.menu.export_to_excel"),
			disabled:false,
			event:"export",
			separate: true
		},
		print: {
			text:ct.i18n("cx.historic.data.context.menu.print"),
			disabled:false,
			event:"print"
		},
		clearAllData: {
			text:ct.i18n("cx.historic.data.context.menu.clear_all_data"),
			disabled:false,
			event:"clear"
		}
	};
	
	return new caplin.chart.menu.ContextMenu(oContextMenuConfig);
};

/**
 * @private
 */
caplinx.historicdata.BenchmarkController.prototype._refreshContextMenu = function()
{
	var nChartSize = this.m_oCompositeComponent.getComponentSize("chart");
	if (nChartSize === 0) {
		this.m_oContextMenu.setItemText("showComponent", ct.i18n("cx.historic.data.context.menu.show_chart"));
	} else {
		this.m_oContextMenu.setItemText("showComponent", ct.i18n("cx.historic.data.context.menu.show_data"));
	}
	
	var nSettingPanelSize = this.m_oCompositeComponent.getComponentSize("chartSettingsPanel");
	if (nSettingPanelSize === 0) {
		this.m_oContextMenu.setItemText("settings", ct.i18n("cx.historic.data.context.menu.show_settings"));
	} else {
		this.m_oContextMenu.setItemText("settings", ct.i18n("cx.historic.data.context.menu.hide_settings"));
	}
};
