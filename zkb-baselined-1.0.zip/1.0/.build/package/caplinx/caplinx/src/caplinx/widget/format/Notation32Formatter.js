
/**
 * @fileoverview Provides the {@link caplinx.widget.format.Notation32Formatter}
 * Class that formats a decimal figure into a percentage
 */

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.core.Logger");
caplin.include("caplin.widget.format.DecimalPlaceTextFormatter");

/**
 * @class - formats a decimal figure into 32nd Notation.
 * 
 * @param {int} nNumberOfDecimalPlaces The number of decimal places that prices will be formatted
 *        to.
 *
 * @class Responsible for restricting a decimal to the specific number of decimal places and adding
 * a percentage sign '%'.
 * @extends caplin.widget.format.DecimalPlaceTextFormatter
 * @constructor
 */
caplinx.widget.format.Notation32Formatter = function()
{

};

caplinx.widget.format.Notation32Formatter.prototype.m_oRegExp = new RegExp("^(-?)(\\d*)(\\.\\d*)?$");
caplinx.widget.format.Notation32Formatter.prototype.m_n32nd = 1 / 32;
caplinx.widget.format.Notation32Formatter.prototype.m_s32ndSeparator = "-";
caplinx.widget.format.Notation32Formatter.prototype.m_sNonBreakingSpace = "\u00a0";
caplinx.widget.format.Notation32Formatter.prototype.m_s64thIndicator = "+";
/**
 * Converts the specified price to a specific number of decimal places with a percent. If a non number is
 * specified, then the value will be returned without any formatting.
 *
 * @param {String} sValue The price to be formatted.
 * @type String
 * @return The formatted price.
 */
caplinx.widget.format.Notation32Formatter.prototype.formatText = function(sValue)
{
	var sFormattedValue;
	var oMatch = sValue.match(this.m_oRegExp);

	if (oMatch && (oMatch[2] || oMatch[3]))
	{

		// the value is a valid number
		var sFractionalPart;
		if (oMatch[3] && oMatch[3] != "" && oMatch[3] != ".")
		{
			// we have a fraction part
			var n32nds = oMatch[3] / this.m_n32nd;
			var n32 = Math.floor(n32nds);
			// process the last symbol
			var sSymbol = this.getTrailingSymbol(n32nds - n32);

			// we have a valid fraction part
			sFractionalPart = ((n32 < 10)?"0":"") + n32;
			if (sSymbol)
			{
				sFractionalPart += sSymbol;
			}

		}
		else
		{
			// there are no numbers after the decimal - the value is a whole number only
			sFractionalPart = "00" + this.getTrailingSymbol(0);
		}

		if (sFractionalPart)
		{
			// construct the final bond notation format value
			sFormattedValue = oMatch[1] + ((oMatch[2] == "")?"0":oMatch[2]) + this.m_s32ndSeparator + sFractionalPart;
		}
		else
		{
			// the number could not be displayed in bond notation format - convert it to a decimal
			// with 3 decimal places instead
			sFormattedValue = this.getBackupFormatter().formatText(sValue);
			if (caplin.widget.logging)
			{
				caplin.widget.logging.Logger.logWarning("Backup formatting for price: "+sValue);
			}
		}
	}
	else
	{
		// the value was not a number, return it unchanged
		sFormattedValue = sValue;
	}

	return sFormattedValue;
};


caplinx.widget.format.Notation32Formatter.prototype.getTrailingSymbol = function (n32ndsLeftover) {
	var n256ths = Math.floor(n32ndsLeftover * 8);
	switch (n256ths) {
		case 1: return this.m_sNonBreakingSpace + "01";
		case 2: return this.m_sNonBreakingSpace + "02";
		case 3: return this.m_sNonBreakingSpace + "03";
		case 4: return this.m_s64thIndicator;
		case 5: return this.m_sNonBreakingSpace + "05";
		case 6: return this.m_sNonBreakingSpace + "06";
		case 7: return this.m_sNonBreakingSpace + "07";
		default: return this.m_sNonBreakingSpace + "00";
	}
}

caplinx.widget.format.Notation32Formatter.prototype.getBackupFormatter = function()
{
	if (this.m_oDecimalPlaceFormatter == undefined)
	{
		this.m_oDecimalPlaceFormatter = new caplin.widget.format.DecimalPlaceTextFormatter(3);
	}
	return this.m_oDecimalPlaceFormatter;
}
