caplin.namespace("caplinx.tobo");

caplinx.tobo.TOBOUserManagerListener = function()
{
	
};

caplinx.tobo.TOBOUserManagerListener.prototype.onTOBOUserChanged = function(sUser)
{
	//Optional interface method
};

caplinx.tobo.TOBOUserManagerListener.prototype.onTOBOAccountChanged = function(sAccount)
{
	//Optional interface method
};

caplinx.tobo.TOBOUserManagerListener.prototype.onTOBOUserTypeChanged = function(sUserType)
{
	//Optional interface method
};

caplinx.tobo.TOBOUserManagerListener.prototype.onTOBOUserListChanged = function(pUserList)
{
	//Optional interface method
};

caplinx.tobo.TOBOUserManagerListener.prototype.onTOBOAccountListChanged = function(pAccountList)
{
	//Optional interface method
};

caplinx.tobo.TOBOUserManagerListener.prototype.onLockChanged = function(bLocked)
{
	//Optional interface method
};