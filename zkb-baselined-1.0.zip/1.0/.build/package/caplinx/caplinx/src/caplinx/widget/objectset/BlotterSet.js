caplin.namespace("caplinx.widget.objectset");

caplin.include("caplin.widget.objectset.DataPanelSet", true);
caplin.include("caplin.widget.objectset.RttpObject");
caplin.include("caplin.widget.serialization.Serializer");

caplinx.widget.objectset.BlotterSet = function(l_pObjects, l_pViews)
{
	// call super constructor
	caplin.widget.objectset.DataPanelSet.apply(this, [l_pObjects, l_pViews]);
	
};
caplin.extend(caplinx.widget.objectset.BlotterSet, caplin.widget.objectset.DataPanelSet);

// documented in Panel
caplinx.widget.objectset.BlotterSet.prototype.getSerializer = function()
{
	var l_oSerializer = new caplin.widget.serialization.Serializer();
	
	l_oSerializer.setConstructor("caplinx.widget.objectset.BlotterSet", [this.getObjects().getSerializerArray(), this.getViews().getSerializerArray()]);
	
	return l_oSerializer;
};

// return an object type for identifying this type of object 
caplinx.widget.objectset.BlotterSet.prototype.getObjectName = function()
{
	return 'BlotterSet';
};

/**
 * @return <code>false</code> since <code>BlotterSet</code>s cannot have search results added.
 */
caplinx.widget.objectset.BlotterSet.prototype.canReceive = function()
{
	return false;
};
