/**
 * @fileoverview
 * Defines the caplinx.chart.decorator.TicketLauncher class.
 */

caplin.namespace("caplinx.chart.decorator");

caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplin.chart.decorator.ChartDecorator", true);
caplin.include("caplin.chart.ChartViewListener", true);

/**
 * Constructs a new <code>TicketLanucher</code>. End-users will never need to do
 * this themselves since charts are fully constructed based on their XML definition files by the
 * {@link caplin.chart.ChartGenerator ChartGenerator} class.
 * 
 * @class
 * The <code>caplinx.chart.decorator.TicketLauncher</code> class gives a
 * {@link caplin.chart.ChartView ChartView} series point the ability to launch a 
 * trade ticket upon clicking.
 * 
 * @constructor
 * @implements caplin.chart.decorator.ChartDecorator
 * @implements caplin.chart.ChartViewListener
 */
caplinx.chart.decorator.TicketLauncher = function()
{
};
caplin.implement(caplinx.chart.decorator.TicketLauncher, caplin.chart.decorator.ChartDecorator);
caplin.implement(caplinx.chart.decorator.TicketLauncher, caplin.chart.ChartViewListener);

/** --------------------------------------------------------------------------------------------------------
 *                            caplin.chart.decorator.ChartDecorator Interface
 ---------------------------------------------------------------------------------------------------------- */

/** 
 * @param {Object} oChartView
 */
caplinx.chart.decorator.TicketLauncher.prototype.setChartView = function(oChartView)
{
	oChartView.addChartViewListener(this);
};


/** --------------------------------------------------------------------------------------------------------
 *                            caplin.chart.ChartViewListener Interface
 ---------------------------------------------------------------------------------------------------------- */

/** 
 * @see caplin.chart.ChartViewListener#onPointDoubleClicked
 */
caplinx.chart.decorator.TicketLauncher.prototype.onPointDoubleClicked = function(oPoint)
{
	// if this is a single point, and not a point on a line series
	if (oPoint.getSeriesData().length == 1) {
		caplin.framework.ApplicationFactory.getInstance().launchFxTradeTicket(oPoint.getId(), "Bid", "RFS");		
	}
};