caplin.namespace("caplinx.renderer");

caplin.include("caplin.dom.renderer.ElementRenderer", true);
caplin.include("caplinx.permissioning.CaplinPermissionService");
caplin.include("caplin.dom.Utility");
caplin.include("caplin.security.AbstractFactory");
caplin.include("caplin.framework.ApplicationFactory");
caplin.include("caplin.core.ObjectUtility");
caplin.include("caplin.dom.renderer.TextElementRendererUpdate");
caplin.include("caplin.core.Exception");

/**
 * @implements caplin.dom.renderer.ElementRenderer
 */
caplinx.renderer.TradableElementRenderer = function(pFields, nDecimalPlaces)
{
	if(!pFields || pFields.join === undefined || pFields.join() === undefined)
	{
		throw new caplin.core.Exception("You must enter a Field Value Array for the Element Render", "TradableElementRenderer.Constructor");
	}

	/** @private */
	this.m_pFields = pFields;
	/**
	 * Optional - in the real renderers this will be handled via a text formatter
	 * @private
	 */
	this.m_nDecimalPlaces = nDecimalPlaces;

	this.m_nId = "tradeableRenderer" + caplinx.renderer.TradableElementRenderer.id++;
	this.m_eElement = null;
	this.m_sCurrentValue = null;
	this.m_oFieldModel = null;
	this.m_oPermission = null;
	this.m_eHtmlElement = null;
	/** @private */
	this.m_bIsPermissioned = false;
	/** @private */
	this.m_bAuthorizedForSpot = false;
	/** @private */
	this.m_bAuthorizedForEsp = false;
	/** @private */
	this.m_nPermissionListenerId = null;
	/** @private */
	this.m_nPriceClickId = null;
	/** @private */
	this.m_oCaplinPermissionService = caplinx.permissioning.CaplinPermissionService;
};
caplin.implement(caplinx.renderer.TradableElementRenderer, caplin.dom.renderer.ElementRenderer);

/** @private */
caplinx.renderer.TradableElementRenderer.id = 1;

/** @private */
caplinx.renderer.TradableElementRenderer.TRADABLE_PRICES_CLASS = 'tradablePrices';

/**
 * @see ElementRenderer#setFieldModel
 */
caplinx.renderer.TradableElementRenderer.prototype.setFieldModel = function(oFieldModel)
{
	this.m_oFieldModel = oFieldModel;
	oFieldModel.addFieldListener(this, this.m_pFields);
};

// todo: remove this -- it is now the responsiblity of the element renderer to subscribe itself
caplinx.renderer.TradableElementRenderer.prototype.getFieldNames = function()
{
	return this.m_pFields;
};

caplinx.renderer.TradableElementRenderer.prototype.setSubject = function(sSubject)
{
	this.m_sSubject = sSubject;
};

/**
 * Called if you wish to have renderer register itself with the permissioning system - if part of SpreadElementRenderer there is no need to do that
 * as the SpreadElementRenderer will handle permissions for this renderer.
 */
caplinx.renderer.TradableElementRenderer.prototype.registerAsPermissionListener = function()
{
	if (this.m_sSubject)
	{
		// de-register the previous listeners if any exist
		this._removePermissionListener();
		// register permission listener
		this.m_nPermissionListenerId = this.m_oCaplinPermissionService.addTicketTradableListener(this.m_sSubject, this);
	}
};

/**
 * @see ElementRenderer#createElementHtml
 */
caplinx.renderer.TradableElementRenderer.prototype.createElementHtml = function(mRecord, sSubject)
{
	this.setSubject(sSubject);

	this.m_sCurrentValue = mRecord ? this._encodeWhitespace(mRecord[this.m_pFields[0]]) : "&nbsp;";
	var sClass = "";
	if(this.m_bIsPermissioned)
	{
		sClass = ' class="' + caplinx.renderer.TradableElementRenderer.TRADABLE_PRICES_CLASS + '"';
	}

	this.m_eHtmlElement = '<span'+ sClass + '>' + this._formatValue(this.m_sCurrentValue) + '</span>';

	return this.m_eHtmlElement;
};

/**
 * @see ElementRenderer#setDomElement
 */
caplinx.renderer.TradableElementRenderer.prototype.setDomElement = function(eElement)
{
	this.m_eElement = eElement.firstChild;
	this.m_eElementNode = this.m_eElement.firstChild;
	if (this.m_bIsPermissioned)
	{
		var oUtility = caplin.dom.Utility;

		this.m_nPriceClickId = oUtility.addEventListener(eElement, 'click', oUtility.createMethodEventListener(this, '_priceClick'));
	}
};

/**
 * @see ElementRenderer#renderDataUpdate
 */
caplinx.renderer.TradableElementRenderer.prototype.renderDataUpdate = function(mRecord)
{
	var sValue = mRecord ? mRecord[this.m_pFields[0]] : "\u00A0";

	if (this.m_sCurrentValue != sValue)
	{
		RTSL_DisplayUpdate(new caplin.dom.renderer.TextElementRendererUpdate(this.m_nId, this._formatValue(sValue), 500, this.m_eElement, this.m_eElementNode, this.m_sCurrentValue));
		this.m_sCurrentValue = sValue;
	}
};

/**
 * @see ElementRenderer#renderGeneralUpdate
 */
caplinx.renderer.TradableElementRenderer.prototype.renderGeneralUpdate = function(nType, vUpdate)
{
	// todo...
};

/**
 * @see ElementRenderer#forceDraw
 */
caplinx.renderer.TradableElementRenderer.prototype.forceDraw = function(mRecord)
{
	if(this.m_eElementNode)
	{
		this.m_sCurrentValue = this._encodeWhitespace(mRecord[this.m_pFields[0]]);
		this.m_eElementNode.nodeValue = this._formatValue(this.m_sCurrentValue);
	}
};

/**
 * @see ElementRenderer#clear
 */
caplinx.renderer.TradableElementRenderer.prototype.clear = function(mRecord)
{
	// replace with unicode nbsp
	if(this.m_eElementNode)
	{
		this.m_eElementNode.nodeValue = "\u00A0";
		this.m_sCurrentValue = null;
	}
};

/**
 * @see ElementRenderer#destruct
 */
caplinx.renderer.TradableElementRenderer.prototype.destruct = function()
{
	caplin.dom.Utility.removeEventListenerById(this.m_nPriceClickId);
	this._removePermissionListener();
	
	caplin.core.ObjectUtility.assertObjectIsNeverUsed(this);
};



// *********************** Permissioning Listener ***********************
caplinx.renderer.TradableElementRenderer.prototype.onTicketPermissionsChanged = function(bIsPermitted)
{
	this.m_bIsPermissioned = bIsPermitted;
};

// *********************** private methods ***********************

/**
 * @private
 */
caplinx.renderer.TradableElementRenderer.prototype._removePermissionListener = function()
{
	if(this.m_nPermissionListenerId !== null)
	{
		this.m_oCaplinPermissionService.removeListener(this.m_nPermissionListenerId);
	}
	this.m_nPermissionListenerId = null;
};

/**
 * @private
 */
caplinx.renderer.TradableElementRenderer.prototype._formatValue = function(sValue)
{
	if (this.m_nDecimalPlaces !== undefined && !isNaN(sValue))
	{
		sValue = parseFloat(sValue);
		sValue = sValue.toFixed(this.m_nDecimalPlaces);
	}
	return sValue;
};

/**
 * Onclick function
 * @param {Object} evt
 */
caplinx.renderer.TradableElementRenderer.prototype._priceClick = function(evt)
{
	if(this.m_bIsPermissioned)
	{

		caplin.framework.ApplicationFactory.getInstance().openTradeTicket(this);
	}
};

/**
 * If the data we are passed only contains whitespace then represent this as an &amp;nbsp; entity
 *
 * @private
 */
caplinx.renderer.TradableElementRenderer.prototype._encodeWhitespace = function(sValue)
{
	return sValue.replace(/^\W*$/, "\u00A0");
};
