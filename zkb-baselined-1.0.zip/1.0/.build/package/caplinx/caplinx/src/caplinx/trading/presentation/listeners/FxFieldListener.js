caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxFieldListener = function(oThis, fCallbackFunction)
{
	this.oThis = oThis;
	this.fCallbackFunction = fCallbackFunction;	
};

caplinx.trading.presentation.listeners.FxFieldListener.prototype.dataFieldChanged = function(oValue, oOldValue)
{
	this.fCallbackFunction.call(this.oThis, oValue, oOldValue);
};
