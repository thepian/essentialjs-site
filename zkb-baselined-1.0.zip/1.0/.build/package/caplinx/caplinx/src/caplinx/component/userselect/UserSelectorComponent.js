caplin.namespace("caplinx.component.userselect");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.component.Component", true);
caplin.include("caplin.component.ComponentFactory", true);
caplin.include("caplinx.tobo.TOBOUserManager",true);
caplin.include("caplinx.tobo.TOBOUserManagerListener",true);

caplinx.component.userselect.UserSelectorComponent = function(oUserDropDownBox, oAccountDropDownBox)
{
	this.m_oUserDropDownBox = oUserDropDownBox;
	this.m_oUserDropDownBox.on("select",this._onUserSelect,this);

	this.m_oAccountDropDownBox = oAccountDropDownBox;
	this.m_oAccountDropDownBox.on("select",this._onAccountSelect,this);
	
	this.m_eRootElement = document.createElement("div");
	this.m_eRootElement.className = "toboSelector";
	this.m_eUserHolder = document.createElement("div");
	this.m_eUserHolder.className = "userSelector";
	this.m_eAccountHolder = document.createElement("div");
	this.m_eAccountHolder.className = "accountSelector";
	
    this.m_eUserLabel = document.createElement('div');
    this.m_eUserLabel.className = "userSelectLabel";
    this.m_eUserLabel.innerHTML = ct.i18n("cx.component.user.selector.trade_for");
    
    this.m_eUserContainer = document.createElement('div');
    this.m_eUserContainer.className = "UserContainer";
    this.m_eUserContainer.appendChild(this.m_eUserLabel);
    this.m_eUserContainer.appendChild(this.m_eUserHolder);

	this.m_eAccountLabel = document.createElement('div');
	this.m_eAccountLabel.className = "userSelectLabel";
	this.m_eAccountLabel.innerHTML = ct.i18n("cx.component.user.selector.account");
	
	this.m_eAccountContainer = document.createElement('div');
	this.m_eAccountContainer.className = "AccountContainer";
	this.m_eAccountContainer.appendChild(this.m_eAccountLabel);
	this.m_eAccountContainer.appendChild(this.m_eAccountHolder);
	
	this.m_eRootElement.appendChild(this.m_eUserContainer);
	this.m_eRootElement.appendChild(this.m_eAccountContainer);
	
	caplinx.tobo.TOBOUserManager.initialise();
	caplinx.tobo.TOBOUserManager.addObserver(this);
}; 

caplin.implement(caplinx.component.userselect.UserSelectorComponent, caplin.component.Component);
caplin.implement(caplinx.component.userselect.UserSelectorComponent, caplinx.tobo.TOBOUserManagerListener);

/******************************************************************************
 *      private methods 
 ******************************************************************************/

caplinx.component.userselect.UserSelectorComponent.prototype._formatDataForExtComponent = function(pData)
{
	var pFormatedData = [];
	for (var i = 0, nLength = pData.length; i < nLength; ++i)
	{
		pFormatedData.push([pData[i], pData[i]]);
	}
	return pFormatedData;
};

caplinx.component.userselect.UserSelectorComponent.prototype._onUserSelect = function()
{
	caplinx.tobo.TOBOUserManager.updateUser(this.m_oUserDropDownBox.getValue());
};

caplinx.component.userselect.UserSelectorComponent.prototype._onAccountSelect = function()
{
	caplinx.tobo.TOBOUserManager.updateAccount(this.m_oAccountDropDownBox.getValue());
};

caplinx.component.userselect.UserSelectorComponent.prototype._resetAccountText = function()
{
	var sAccountText = ""; 	
	var oFirstItemInStore = this.m_oAccountDropDownBox.store.getAt(0);
	if (oFirstItemInStore !== undefined) 
	{
		sAccountText = oFirstItemInStore.get("value");
	}
	this.m_oAccountDropDownBox.setValue(sAccountText);
	this.m_oAccountDropDownBox.fireEvent("select");
};

/******************************************************************************
 *      caplinx.tobo.TOBOUserManagerListener Interface 
 ******************************************************************************/

caplinx.component.userselect.UserSelectorComponent.prototype.onTOBOUserChanged = function(sUser)
{
	if(sUser == null && this.m_sUserType  === "SALES") 
	{
		sUser = caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT;
		this.m_oAccountDropDownBox.setValue("");
		this.m_oAccountDropDownBox.disable();
		this.m_canEditAccounts = false;
	}
	this.m_oUserDropDownBox.setValue(sUser);
};

caplinx.component.userselect.UserSelectorComponent.prototype.onTOBOAccountChanged = function(sAccount)
{
	this.m_oAccountDropDownBox.setValue(sAccount);
};

caplinx.component.userselect.UserSelectorComponent.prototype.onTOBOUserTypeChanged = function(sUserType)
{
	this.m_sUserType = sUserType;
	
	this._resetAccountText();
	
	if (sUserType === "SALES") 
	{
		this.m_oAccountDropDownBox.setValue("");
		this.m_oAccountDropDownBox.disable();
		this.m_oUserDropDownBox.setValue(caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT);
		this.m_oUserDropDownBox.render(this.m_eUserHolder);
		this.m_canEditAccounts = false;
	}
	else
	{
	   caplin.dom.Utility.addClassName(this.m_eRootElement, 'noSales');
	   this.m_eUserContainer.style.display = "none";
	}
	this.m_oAccountDropDownBox.render(this.m_eAccountHolder);
};

caplinx.component.userselect.UserSelectorComponent.prototype.onTOBOUserListChanged = function(pUserData)
{
	var pUserDataPlusEmpty = [caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT].concat(pUserData); 
	var pFormattedUserData = this._formatDataForExtComponent(pUserDataPlusEmpty);
	this.m_oUserDropDownBox.getStore().loadData(pFormattedUserData, false);
};

caplinx.component.userselect.UserSelectorComponent.prototype.onTOBOAccountListChanged = function(pAccountData)
{
	var pFormattedAccountData = this._formatDataForExtComponent(pAccountData);
	this.m_oAccountDropDownBox.getStore().loadData(pFormattedAccountData, false);
	
	if(this.m_oUserDropDownBox.getValue() === caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT)
	{
		this.m_oAccountDropDownBox.setValue("");
		this.m_oAccountDropDownBox.disable();
		this.m_canEditAccounts = false;
	}
	else
	{
		this._resetAccountText();
		this.m_oAccountDropDownBox.enable();
		this.m_canEditAccounts = true;
	}
};

caplinx.component.userselect.UserSelectorComponent.prototype.onLockChanged = function(bLocked)
{
	this.m_oUserDropDownBox.setDisabled(bLocked);
	
	//dont enable account dropdown if it's not editable
	if(bLocked == false && this.m_canEditAccounts == false){
		bLocked = true;
	}
	this.m_oAccountDropDownBox.setDisabled(bLocked);
};

/******************************************************************************
 *      caplin.component.Component Interface 
 ******************************************************************************/

caplinx.component.userselect.UserSelectorComponent.prototype.getElement = function()
{
	return this.m_eRootElement;
};

caplinx.component.userselect.UserSelectorComponent.prototype.getSerializedState = function()
{
	return "<userSelector />";
};

caplinx.component.userselect.UserSelectorComponent.createFromSerializedState = function()
{
	var oUserDropDownBox = new Ext.form.ComboBox({
		"displayField": "label",
		"width": 131,
		"listWidth": 135,
		"triggerAction": 'all',
		"editable": false,
		"mode": 'local',
		"forceSelection": true,
		"shadow": false,
		"disabledClass": 'x-item-disabled',
		"store" : new Ext.data.SimpleStore({"fields": ["value", "label"]})
    });
	
	
	var onChange = function()
	{
	   caplinx.tobo.TOBOUserManager.editingUser();
	};
	
	var oAccountDropDownBox = new Ext.form.ComboBox({
		"displayField": "label",
		"width": 131,
		"listWidth": 135,
		"triggerAction": 'all',
		"editable": false,
		"mode": 'local',
		"forceSelection": true,
		"shadow": false,
		"disabledClass":'x-item-disabled',
		"store" : new Ext.data.SimpleStore({"fields": ["value", "label"]})
    });
	return new caplinx.component.userselect.UserSelectorComponent(oUserDropDownBox, oAccountDropDownBox);
};

caplinx.component.userselect.UserSelectorComponent.onAfterClassLoad = function()
{
	caplinx.component.userselect.UserSelectorComponent.BASE_RATES_TEXT = ct.i18n("cx.component.user.selector.base.rates");
	
	caplin.component.ComponentFactory.registerComponent('userSelector', caplinx.component.userselect.UserSelectorComponent.createFromSerializedState);
};
caplin.notifyAfterClassLoad(caplinx.component.userselect.UserSelectorComponent);
