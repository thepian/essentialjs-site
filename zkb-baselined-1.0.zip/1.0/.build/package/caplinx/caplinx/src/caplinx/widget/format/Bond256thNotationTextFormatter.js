caplin.namespace("caplinx.widget.format");

caplin.include("caplinx.widget.format.Bond32ndNotationTextFormatter", true);

/**
 * Converts the specified price to the equivalent value in the bond (256th) notation format. If a
 * number is specified that does not map directly to a bond notation value, it will be formatted as
 * a decimal to 3 decimal places, whilst if a non number is specified, then the value will be
 * returned without any formatting.
 * 
 * <p>The bond notation format follows these rules:</p>
 * <table>
 * <tr> <th>Display</th> <th>Notes</th>                                                                        </tr>
 * <tr> <td>-</td>       <td>Indicator of a negative value, if the value is positive this will be omitted</td> </tr>
 * <tr> <td>number</td>  <td>The whole number (e.g. <b>100</b> for the number 100.5)</td>                      </tr>
 * <tr> <td>-</td>       <td>Separator character between whole number and 32nd value</td>                      </tr>
 * <tr> <td>two digit number</td>  <td>The number of 32nds (e.g. <b>16</b> for the number 100.5); this value is
 *                            padded with zeros to ensure it is exactly 2 characters long</td>                 </tr>
 * <tr> <td>one diget number</td>  <td>The number of 256ths left over (e.g. <b>0</b> for the number 100.5)</td></tr>
 * </table>
 * 
 * <p>Examples:</p>
 * <table>
 * <tr> <th>Decimal Price</th> <th>Bond Notation Price</th> </tr>
 * <tr> <td>100</td>           <td>100-000</td>             </tr>
 * <tr> <td>100.00390625</td>  <td>100-001</td>             </tr>
 * <tr> <td>100.25</td>        <td>100-080</td>             </tr>
 * <tr> <td>100.5</td>         <td>100-160</td>             </tr>
 * <tr> <td>100.75</td>        <td>100-240</td>             </tr>
 * <tr> <td>100.99609375</td>  <td>100-317</td>             </tr>
 * </table>
 * 
 * @param {String} sValue The price to be formatted.
 * @type String
 * @return The formatted price.
 */
caplinx.widget.format.Bond256thNotationTextFormatter = function() {};

caplin.extend(caplinx.widget.format.Bond256thNotationTextFormatter, caplinx.widget.format.Bond32ndNotationTextFormatter);

caplinx.widget.format.Bond256thNotationTextFormatter.prototype.getTrailingSymbol = function (n32ndsLeftover) {
	switch (n32ndsLeftover) {
		case 0: return "0";
		case 0.125: return "1";
		case 0.25: return "2";
		case 0.375: return "3";
		case 0.5: return "4";
		case 0.625: return "5";
		case 0.75: return "6";
		case 0.875: return "7";
		default: return null;
	}
}