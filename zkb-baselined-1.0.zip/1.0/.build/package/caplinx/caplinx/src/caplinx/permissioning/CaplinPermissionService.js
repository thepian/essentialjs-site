caplin.namespace("caplinx.permissioning");

caplin.include("caplin.security.permissioning.PermissionService", true);  // required by the constructor of this singleton class.

caplin.include("caplin.core.MapFactory", true);
caplin.include("caplinx.permissioning.TradableListener");
caplin.include("caplinx.permissioning.InstrumentViewableListener");
caplin.include("caplinx.permissioning.AccountsListener");

/**
 * A helper class that fronts {@link caplin.security.permissioning.PermissionService}, and provides higher level
 * permissioning information that can be used throughout the application.
 */
caplinx.permissioning.CaplinPermissionService = function()
{
	this.m_mListeners = caplin.core.MapFactory.createMap();
	this.m_oPermissionService = caplin.security.permissioning.PermissionService;
};

/**
 * Determine whether the user is permitted to trade the given instrument within a ticket.
 *
 * @param {String} sInstrument the instrument to be traded.
 */
caplinx.permissioning.CaplinPermissionService.prototype.canTradeInTicket = function(sInstrument)
{
	return this.m_oPermissionService.getAllowPermissions(sInstrument, "TradeType").length > 0 &&
		this.m_oPermissionService.canUserPerformAction(sInstrument, "TradeProtocol", "RFS");
};

/**
 * Returns a filtered array of currency pairs, filtering pListOfPairs, letting through the filter
 * only the currency pairs that are VIEW permitted.
 * 
 * @param {Array} pListOfPairs an array of the possible currencies.
 */
caplinx.permissioning.CaplinPermissionService.prototype.filterOutNonViewPermissionedCurrencyPairs = function(pListOfPairs)
{
	var pResult = [];
	var size = pListOfPairs.length;

	for(var i = 0; i < size; i++){
		var sProduct = "/FX/" + pListOfPairs[i];
		var bAllowed = this.m_oPermissionService.canUserPerformAction(sProduct, null , "VIEW");
		if(bAllowed == true){
			pResult.push(pListOfPairs[i]);
		}
	}
	return pResult;
};

/**
 * Returns a filtered array of currency bases, filtering pListOfBaseCurrencies, letting through the filter
 * only the currency bases that are VIEW permitted.
 * 
 * @param {Array} pListOfBaseCurrencies an array of the possible currency bases.
 * @param {Array} pCompleteList an array containing all possible currencies.
 */
caplinx.permissioning.CaplinPermissionService.prototype.filterOutNonViewPermissionedBaseCurrencies = function(pListOfBaseCurrencies, pCompleteList)
{
	var pResult = [];
	var size = pListOfBaseCurrencies.length;

	for(var i = 0; i < size; i++)
	{
		var sProduct = "/FX/" + pListOfBaseCurrencies[i];
		var bAllowed = this._hasBaseCurrencyAnyPermittedTermCurrencies(sProduct, pCompleteList);
		if(bAllowed === true){
			pResult.push(pListOfBaseCurrencies[i]);
		}
	}
	return pResult;
};

/**
 * Determine whether the user is permitted to trade the given instrument within a tile.
 *
 * @param {String} sInstrument the instrument to be traded.
 */
caplinx.permissioning.CaplinPermissionService.prototype.canTradeInTile = function(sInstrument)
{
	return this.m_oPermissionService.canUserPerformAction(sInstrument, "TradeType", "SPOT") &&
		this.m_oPermissionService.canUserPerformAction(sInstrument, "TradeProtocol", "ESP");
};

/**
 * Add a listener that will be called back each time the permission on the given instrument changes in respect to
 * whether ticket trading is possible.
 *
 * @param {String} sInstrument
 * @param {Object} oListener Listener to receive onTicketPermissionsChanged() callbacks
 * @return a unique identifier for this listener so it can later be removed using {@link #removeListener}
 * @type int
 */
caplinx.permissioning.CaplinPermissionService.prototype.addTicketTradableListener = function(sInstrument, oListener)
{
    if (/\/FX\/.*/.test(sInstrument))
    {
	   return this._addListener(new caplinx.permissioning.TradableListener(sInstrument, oListener, "RFS"));
    }
    else if (/\/FI\/.*/.test(sInstrument))
    {
	   return this._addListener(new caplinx.permissioning.TradableListener(sInstrument, oListener, "RFQ"));
	}
};

/**
 * Add a listener that will be called back each time the permission on the given instrument changes in respect to
 * whether tile trading is possible.
 *
 * @param {String} sInstrument
 * @param {Object} oListener Listener to receive onTilePermissionsChanged() callbacks
 * @return a unique identifier for this listener so it can later be removed using {@link #removeListener}
 * @type int
 */
caplinx.permissioning.CaplinPermissionService.prototype.addTileTradableListener = function(sInstrument, oListener)
{
	return this._addListener(new caplinx.permissioning.TradableListener(sInstrument, oListener, "ESP", "SPOT"));
};

/**
 * Add a listener that will be called back each time the permission on the given instrument changes in respect to
 * whether is it is viewable.
 *
 * @param {String} sInstrument
 * @param {Object} oListener Listener to receive onViewPermissionsChanged() callbacks
 * @return a unique identifier for this listener so it can later be removed using {@link #removeListener}
 * @type int
 */
caplinx.permissioning.CaplinPermissionService.prototype.addInstrumentViewableListener = function(sInstrument, oListener)
{
	return this._addListener(new caplinx.permissioning.InstrumentViewableListener(sInstrument, oListener));
};

/**
 * Add a listener that will be called back each time the permission on the given instrument changes in respect to
 * the set of accounts the user has.
 *
 * @param {String} sInstrument
 * @param {Object} oListener Listener to receive onAccountsPermissionsChanged() callbacks
 * @return a unique identifier for this listener so it can later be removed using {@link #removeListener}
 * @type int
 */
caplinx.permissioning.CaplinPermissionService.prototype.addAccountsListener = function(sInstrument, oListener)
{
	return this._addListener(new caplinx.permissioning.AccountsListener(sInstrument, oListener));
};

/**
 * Remove a previously registered listener using the given identifier
 *
 * @param {int} nListenerId
 */
caplinx.permissioning.CaplinPermissionService.prototype.removeListener = function(nListenerId)
{
	var listener = this.m_mListeners[nListenerId];
	this.m_mListeners = caplin.core.MapFactory.removeItem(this.m_mListeners, nListenerId);
	if(listener)
	{
		listener._$cancelSubscription();
	}
};

/** @private */
caplinx.permissioning.CaplinPermissionService.nListenerId = 1;

/**
 * @private
 */
caplinx.permissioning.CaplinPermissionService.prototype._addListener = function(oListener)
{
	var nNextListenerId = caplinx.permissioning.CaplinPermissionService.nListenerId++;

	this.m_mListeners[nNextListenerId] = oListener;

	return nNextListenerId;
};

/**
 * @private
 */
caplinx.permissioning.CaplinPermissionService.prototype._hasBaseCurrencyAnyPermittedTermCurrencies = function(sBaseCurrency, pCompleteList)
{
	for(var nCurrentCurrency = 0, nCompleteSize = pCompleteList.length; nCurrentCurrency < nCompleteSize; nCurrentCurrency++)
	{
		var sProduct = sBaseCurrency + pCompleteList[nCurrentCurrency];
		var bAllowed = this.m_oPermissionService.canUserPerformAction(sProduct, null , "VIEW");
		if(bAllowed)
		{
			return true;
		}
	}
	return false;
};

caplin.singleton("caplinx.permissioning.CaplinPermissionService");
