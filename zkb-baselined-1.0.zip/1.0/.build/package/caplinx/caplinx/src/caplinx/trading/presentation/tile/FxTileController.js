caplin.namespace("caplinx.trading.presentation.tile");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.trading.trademodel.TradingStatusChangedListener", true);
caplin.include("caplinx.trading.presentation.tile.FxTile", true);
caplin.include("caplinx.trading.presentation.tile.FxTileStatus", true);
caplin.include("caplin.trading.trademodel.TradingStatus");

caplinx.trading.presentation.tile.FxTileController = function(oFxTile)
{
	this.m_oFxTile = oFxTile;
	this.m_bTradeInProgress = false;
	this.m_nTradingStatus = caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE;
	this.m_mErrorInfo = null;
	this.m_nSetPricingStaleTimeout = null;
	
	this.m_mLastStatusInfo = caplinx.trading.presentation.tile.FxTileController.NULL_STATUS_INFO;
	this.m_mLastEspStatusInfo = { enabled: null };
	this.m_mLastRfsStatusInfo = { enabled: null };
	this.m_sLastLayoutClass = null;
	this.m_bCurrencyPairBeingEdited = false;
};

caplin.implement(caplinx.trading.presentation.tile.FxTileController, caplin.trading.trademodel.TradingStatusChangedListener);

caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE = -1;
caplinx.trading.presentation.tile.FxTileController.PRICING_STALE_PROCESSING_TIMEOUT = 1000;

caplinx.trading.presentation.tile.FxTileController.onAfterClassLoad = function()
{
	caplinx.trading.presentation.tile.FxTileController.NULL_STATUS_INFO = {
		statusMessage: "-", messageType: caplinx.trading.presentation.tile.FxTileStatus.INFO
	};
	
	// TODO: check whether these are actually used any more (SWITCH_CURRENCIES and NO_VIEW_PERMISSIONS are)
	caplinx.trading.presentation.tile.FxTileController.MESSAGE = {
		SELECT_ACCOUNT: ct.i18n("cx.trading.presentation.fx.tile.message.select_account"),
		MISSING_ACCOUNTS: ct.i18n("cx.trading.presentation.fx.tile.message.missing_accounts"),
		MISSING_PERMISSIONS: ct.i18n("cx.trading.presentation.fx.tile.message.missing_permissions"),
		SWITCH_CURRENCIES: ct.i18n("cx.trading.presentation.fx.tile.message.switch_currencies"),
		NO_VIEW_PERMISSIONS: ct.i18n("cx.trading.presentation.fx.tile.message.no_view_permissions")
	};

	// messages that appear within the tile's "status bar" 
	caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE = {
		EXECUTING_TRADE: ct.i18n("cx.trading.presentation.fx.tile.status.message.executing_trade"),
		RFS_ONLY: ct.i18n("cx.trading.presentation.fx.tile.status.message.rfs_only"),
		NOT_TRADABLE: ct.i18n("cx.trading.presentation.fx.tile.status.message.not_tradable"),
		TRADING_UNAVAILABLE: ct.i18n("cx.trading.presentation.fx.tile.status.message.trading_unavaialble"),
		PRICING_UNAVAILABLE: ct.i18n("cx.trading.presentation.fx.tile.status.message.pricing_unavailable"),
		MISSING_ACCOUNTS: ct.i18n("cx.trading.presentation.fx.tile.status.message.missing_accounts"),
		SELECT_ACCOUNT: ct.i18n("cx.trading.presentation.fx.tile.status.message.select_account"),
		INITIALIZING_CONNECTION: ct.i18n("cx.trading.presentation.fx.tile.status.message.inititalizing_connection")
	};

	// tooltips that appear for the RFS button
	caplinx.trading.presentation.tile.FxTileController.RFS_TOOLTIP = {
		NOT_PERMISSIONED: ct.i18n("cx.trading.presentation.fx.tile.rfs.tooltip.not_permissioned"),
		TRADE_IN_PROGRESS: ct.i18n("cx.trading.presentation.fx.tile.rfs.tooltip.trade_in_progress"),
		TRADING_UNAVAILABLE: ct.i18n("cx.trading.presentation.fx.tile.rfs.tooltip.trading_unavailable"),
		OPEN_TICKET: ct.i18n("cx.trading.presentation.fx.tile.rfs.tooltip.open_ticket"),
		INITIALIZING_CONNECTION: ct.i18n("cx.trading.presentation.fx.tile.rfs.tooltip.inititializing_connection")
	};

	// tooltips that appear for the ESP button
	caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP = {
		NOT_PERMISSIONED: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.not_permissioned"),
		TRADE_IN_PROGRESS: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.trade_in_progress"),
		TRADING_UNAVAILABLE: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.trading_unavailable"),
		PRICING_UNAVAILABLE: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.pricing_unavailable"),
		MISSING_ACCOUNTS: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.missing_accounts"),
		SELECT_ACCOUNT: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.select_account"),
		INITIALIZING_CONNECTION: ct.i18n("cx.trading.presentation.fx.tile.esp.tooltip.initializing_connection")
	};
};
caplin.notifyAfterClassLoad(caplinx.trading.presentation.tile.FxTileController);

caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES = {
	NOT_VIEWABLE: "not-viewable",
	NOT_CONNECTED: "not-connected",
	SHOW_STATUS: "status-message",
	ERROR: "error",
	VIEWABLE: "viewable"
};

caplinx.trading.presentation.tile.FxTileController.prototype.setTradeInProgress = function(bTradeInProgress)
{
	this.m_bTradeInProgress = bTradeInProgress;
};

caplinx.trading.presentation.tile.FxTileController.prototype.getTradingStatus = function()
{
	return this.m_nTradingStatus;
};

caplinx.trading.presentation.tile.FxTileController.prototype._setTradingStatus = function(nTradingStatus)
{
	if (this.m_nSetPricingStaleTimeout !== null)
	{
		clearTimeout(this.m_nSetPricingStaleTimeout);
		this.m_nSetPricingStaleTimeout = null;
	}
	
	this.m_nTradingStatus = nTradingStatus;
};

caplinx.trading.presentation.tile.FxTileController.prototype.setError = function(sTitle, sErrorHtml)
{
	this.m_mErrorInfo = { title: sTitle, message: sErrorHtml };
};

caplinx.trading.presentation.tile.FxTileController.prototype.clearError = function()
{
	this.m_mErrorInfo = null;
};

caplinx.trading.presentation.tile.FxTileController.prototype.tradingStatusChanged = function(nTradingStatus)
{
	if (nTradingStatus == caplin.trading.trademodel.TradingStatus.PRICING_STALE) 
	{
		var oThis = this;
		this.m_nSetPricingStaleTimeout = window.setTimeout(function() {
			oThis._setTradingStatus(nTradingStatus);
			oThis.updateTileState();
		}, caplinx.trading.presentation.tile.FxTileController.PRICING_STALE_PROCESSING_TIMEOUT);
	}
	else
	{
		this._setTradingStatus(nTradingStatus);
		this.updateTileState();
	}
};

caplinx.trading.presentation.tile.FxTileController.prototype.editingCurrencyPairChooser = function(bEditingCurrencyPairChooser)
{
	this.m_bCurrencyPairBeingEdited = bEditingCurrencyPairChooser;
};

caplinx.trading.presentation.tile.FxTileController.prototype.registerListeners = function()
{
	this.m_oFxTile._$getTrade().addTradingStatusChangedListener(this);
};

caplinx.trading.presentation.tile.FxTileController.prototype.unregisterListeners = function()
{
	this.m_oFxTile._$getTrade().removeTradingStatusChangedListener(this);
};

caplinx.trading.presentation.tile.FxTileController.prototype.updateTileState = function()
{
	if (!this.m_oFxTile._$isTileRendered()) 
	{
		// This condition is necessary because the method may execute before the tile is ready to be rendered
		return;
	}
	
	if (this.m_mErrorInfo !== null) 
	{
		this.m_oFxTile.showError(this.m_mErrorInfo.title, this.m_mErrorInfo.message);
	}
	else
	{
		var mStatusInfo = this.getStatusInfo();
		if (mStatusInfo.statusMessage != this.m_mLastStatusInfo.statusMessage) 
		{
			this.m_mLastStatusInfo = mStatusInfo;
			this.m_oFxTile.setStatusMessage(mStatusInfo.messageType, mStatusInfo.statusMessage);
		}
		
		var mEspStatusInfo = this.getEspStatusInfo();
		if (mEspStatusInfo.enabled != this.m_mLastEspStatusInfo.enabled || mEspStatusInfo.tooltip != this.m_mLastEspStatusInfo.tooltip)
		{
			this.m_mLastEspStatusInfo = mEspStatusInfo;
			if (mEspStatusInfo.enabled || mEspStatusInfo.tooltip === caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.NOT_PERMISSIONED)
			{
				this.m_oFxTile.m_oAskButton.setButtonBlank(false);
				this.m_oFxTile.m_oBidButton.setButtonBlank(false);
				if(mEspStatusInfo.enabled && this.m_bCurrencyPairBeingEdited === false)
				{
					this.m_oFxTile.enableButtons();
				}
				else if(this.m_bCurrencyPairBeingEdited === false)
				{
					this.m_oFxTile.setDisabledAlertMessage(mEspStatusInfo.tooltip);
					this.m_oFxTile.disableButtons(mEspStatusInfo.tooltip);
				}
				else if(this.m_bCurrencyPairBeingEdited === true)
				{
					this.m_oFxTile.disableButtons(caplinx.trading.presentation.tile.FxTileCurrencyPairChooser.CURRENCY_ALERT_TEXT);
				}
			}
			else
			{
				if(this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.PRICING_STALE)
				{
					this.m_oFxTile.m_oAskButton.setButtonBlank(true);
					this.m_oFxTile.m_oBidButton.setButtonBlank(true);
				}
				this.m_oFxTile.disableButtons(mEspStatusInfo.tooltip);				
			}
		}
		
		var mRfsStatusInfo = this.getRfsStatusInfo();
		if (mRfsStatusInfo.enabled != this.m_mLastRfsStatusInfo.enabled || mRfsStatusInfo.tooltip != this.m_mLastRfsStatusInfo.tooltip)
		{
			this.m_mLastRfsStatusInfo = mRfsStatusInfo;
			if (mRfsStatusInfo.enabled) 
			{
				this.m_oFxTile.enableRFSButton(mRfsStatusInfo.tooltip);
			}
			else
			{
				this.m_oFxTile.disableRFSButton(mRfsStatusInfo.tooltip);
			}
		}
	}
	
	var sLayoutClass = this.getTileLayoutClass();
	if (sLayoutClass !== this.m_sLastLayoutClass)
	{
		this.m_sLastLayoutClass = sLayoutClass;
		this.m_oFxTile.setFxTileLayout(sLayoutClass);
	}
};

caplinx.trading.presentation.tile.FxTileController.prototype.getTileLayoutClass = function()
{
	if (this.m_mErrorInfo !== null)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.ERROR;
	}
	else if (this.m_bTradeInProgress)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.SHOW_STATUS;
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.VIEW_PERMISSION) == 0)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.NOT_VIEWABLE;
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ESP_PERMISSIONED) == 0 &&
			this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.AVAILABLE
		)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.SHOW_STATUS;
	}
	else if (this.m_nTradingStatus === caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.SHOW_STATUS;
	}
	else if (this.m_nTradingStatus !== caplin.trading.trademodel.TradingStatus.AVAILABLE)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.NOT_CONNECTED;
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ACCOUNTS_PERMISSION) == 0 ||
				(this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ACCOUNT_SELECTED) == 0)
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.SHOW_STATUS;
	}
	else
	{
		return caplinx.trading.presentation.tile.FxTileController.LAYOUT_CLASSES.VIEWABLE;
	}
};

caplinx.trading.presentation.tile.FxTileController.prototype.getStatusInfo = function()
{
	if (this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.UNAVAILABLE ||
			this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.PRICING_STALE)
	{
		return { statusMessage: this.getTradingStatusErrorMessage(),
					messageType: caplinx.trading.presentation.tile.FxTileStatus.NOT_CONNECTED };
	}
	else if (this.m_bTradeInProgress)
	{
		return { statusMessage: caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.EXECUTING_TRADE,
					messageType: caplinx.trading.presentation.tile.FxTileStatus.INFO };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ESP_PERMISSIONED) == 0 &&
				(this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.RFS_PERMISSIONED) != 0)
	{
		return { statusMessage: caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.RFS_ONLY,
					messageType: caplinx.trading.presentation.tile.FxTileStatus.NOT_PERMISSIONED };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ESP_PERMISSIONED) == 0 &&
				(this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.RFS_PERMISSIONED) == 0)
	{
		return { statusMessage: caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.NOT_TRADABLE,
					messageType: caplinx.trading.presentation.tile.FxTileStatus.NOT_PERMISSIONED };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ACCOUNTS_PERMISSION) == 0)
	{
		return { statusMessage: caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.MISSING_ACCOUNTS,
					messageType: caplinx.trading.presentation.tile.FxTileStatus.ERROR };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ACCOUNT_SELECTED) == 0)
	{
		return { statusMessage: caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.SELECT_ACCOUNT,
					messageType: caplinx.trading.presentation.tile.FxTileStatus.INFO };
	}
	else if (this.m_nTradingStatus === caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE)
	{
		return { statusMessage: this.getTradingStatusErrorMessage(),
					messageType: caplinx.trading.presentation.tile.FxTileStatus.INFO };
	}
	else
	{
		return caplinx.trading.presentation.tile.FxTileController.NULL_STATUS_INFO;
	}
};

caplinx.trading.presentation.tile.FxTileController.prototype.getEspStatusInfo = function()
{
	if (this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.UNAVAILABLE)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.TRADING_UNAVAILABLE };
	}
	else if (this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.PRICING_STALE)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.PRICING_UNAVAILABLE };
	}
	else if (this.m_bTradeInProgress)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.TRADE_IN_PROGRESS };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.VIEW_PERMISSION) == 0 ||
				(this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ESP_PERMISSIONED) == 0)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.NOT_PERMISSIONED };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ACCOUNTS_PERMISSION) == 0)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.MISSING_ACCOUNTS };
	}
	else if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.ACCOUNT_SELECTED) == 0)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.SELECT_ACCOUNT };
	}
	else if (this.m_nTradingStatus === caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE || 
				(!this.m_oFxTile.hadPriceBeenReceived("Bid") && !this.m_oFxTile.hadPriceBeenReceived("Ask")))
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.ESP_TOOLTIP.INITIALIZING_CONNECTION };
	}
	else
	{
		return { enabled: true };
	}
	return { enabled: false };
};

caplinx.trading.presentation.tile.FxTileController.prototype.getRfsStatusInfo = function()
{
	if ((this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.VIEW_PERMISSION) == 0 ||
			(this.m_oFxTile.getCurrentPermission() & caplinx.trading.presentation.tile.PermissionModel.RFS_PERMISSIONED) == 0)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.RFS_TOOLTIP.NOT_PERMISSIONED };
	}
	else if (this.m_bTradeInProgress)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.RFS_TOOLTIP.TRADE_IN_PROGRESS };
	}
	else if (this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.UNAVAILABLE)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.RFS_TOOLTIP.TRADING_UNAVAILABLE };
	}
	else if (this.m_nTradingStatus === caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE)
	{
		return { enabled: false, tooltip: caplinx.trading.presentation.tile.FxTileController.RFS_TOOLTIP.INITIALIZING_CONNECTION };
	}
	else
	{
		return { enabled: true, tooltip: caplinx.trading.presentation.tile.FxTileController.RFS_TOOLTIP.OPEN_TICKET };
	}
};

caplinx.trading.presentation.tile.FxTileController.prototype.getTradingStatusErrorMessage = function()
{
	if (this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.UNAVAILABLE) 
	{
		return caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.TRADING_UNAVAILABLE;
	}
	else if (this.m_nTradingStatus === caplin.trading.trademodel.TradingStatus.PRICING_STALE) 
	{
		return caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.PRICING_UNAVAILABLE;
	}
	else if (this.m_nTradingStatus === caplinx.trading.presentation.tile.FxTileController.INITIAL_STATE)
	{
		return caplinx.trading.presentation.tile.FxTileController.STATUS_MESSAGE.INITIALIZING_CONNECTION;
	}
	else
	{
		return "-";
	}
};
