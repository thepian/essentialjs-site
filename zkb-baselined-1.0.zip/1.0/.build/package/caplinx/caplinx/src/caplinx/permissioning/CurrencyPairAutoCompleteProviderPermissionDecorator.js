caplin.namespace("caplinx.permissioning");

caplin.include("caplin.services.CurrencyPairAutoCompleteProvider", true);
caplin.include("caplin.dom.controls.form.AutoCompleteComboBoxProvider", true);
caplin.include("caplin.security.permissioning.PermissionService");

/**
 */
caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator = function(currencyPairAutoCompleteProvider, permissioningService)
{
	/** @private */
	this.m_oCurrencyPairAutoCompleteProvider = currencyPairAutoCompleteProvider;
	/** @private */
	this.m_oPermissioningService = permissioningService;
	
};

caplin.implement(caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator, caplin.dom.controls.form.AutoCompleteComboBoxProvider);

/**
 * Returns a list of currency pairs for the specified auto complete value.
 * @param {String} sValue The value inputted into the auto complete text box.
 * @type Array
 * @return An array of currency pairs as strings.
 */
caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator.prototype.getAutoCompleteList = function(sValue)
{
	var pList = this.m_oCurrencyPairAutoCompleteProvider.getAutoCompleteList(sValue);
	if(sValue.length < 3)
	{
		var pCompleteList = this.m_oCurrencyPairAutoCompleteProvider.getAutoCompleteList('');
		var pFilteredList = this.m_oPermissioningService.filterOutNonViewPermissionedBaseCurrencies(pList, pCompleteList);
	}
	else
	{
		var pFilteredList = this.m_oPermissioningService.filterOutNonViewPermissionedCurrencyPairs(pList);
	}
	return pFilteredList;
};

caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator.prototype.validateEntry = function(sValue)
{
	this.m_oCurrencyPairAutoCompleteProvider.validateEntry(sValue);
	var pPermittedCurrency = this.m_oPermissioningService.filterOutNonViewPermissionedCurrencyPairs([sValue]);
	var bCanTradeInTicket = this.m_oPermissioningService.canTradeInTicket('/FX/' + sValue);
	
	if(pPermittedCurrency.length === 0 || bCanTradeInTicket === false)
	{
		throw new caplin.core.Exception("Currency pair not view permitted.");
	}
};

caplinx.permissioning.CurrencyPairAutoCompleteProviderPermissionDecorator.prototype.isValidCurrencyPair = function(sCurrencyPair)
{
	return this.m_oCurrencyPairAutoCompleteProvider.isValidCurrencyPair(sCurrencyPair);
};

