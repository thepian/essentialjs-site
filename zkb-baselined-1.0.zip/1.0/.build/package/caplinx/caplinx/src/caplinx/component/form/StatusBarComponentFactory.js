caplin.namespace("caplinx.component.form");

caplin.include("caplin.component.ComponentFactory", true);
caplin.include("caplinx.component.form.StatusBarComponent");
caplin.include("caplin.core.XmlParser");
caplin.include("caplin.core.Exception");
caplin.include("caplin.i18n.Translator");

caplinx.component.form.StatusBarComponentFactory = function()
{
	caplin.notifyAfterClassLoad(this);
};

caplinx.component.form.StatusBarComponentFactory.XML_TAGS = { SOURCE: "src", EXTRA_CLASSES: "extraClasses" };

caplinx.component.form.StatusBarComponentFactory.prototype._createFromSerializedState = function(sXml)
{
	var eXmlModel = caplin.core.XmlParser.parse(sXml);
	var sTemplate = "";
	var sSourceUrl = eXmlModel.getAttribute(caplinx.component.form.StatusBarComponentFactory.XML_TAGS.SOURCE);
	
	if(sSourceUrl !== null)
	{
		try
		{
			sTemplate = caplin.getFileContents(sSourceUrl);
			sTemplate = caplin.i18n.getTranslator().translate(sTemplate);
		}
		catch (e)
		{
			throw new caplin.core.Exception("Failed to load HTML Template file \"" + sSourceUrl + "\" (error: " + e.message + ")", "StatusBarComponentFactory._createFromSerializedState");
		}
	}
	
	return new caplinx.component.form.StatusBarComponent(sTemplate, eXmlModel);
};

caplinx.component.form.StatusBarComponentFactory.prototype.onAfterClassLoad = function()
{
	caplin.component.ComponentFactory.registerComponent('statusBar', this._createFromSerializedState);
};

caplin.singleton("caplinx.component.form.StatusBarComponentFactory");
