caplin.namespace("caplinx.latency");

caplinx.latency.LatencySubscriber = function()
{
	this.m_nLatency = 99999;
	this.m_pListeners = [];
	this.m_pThresholdListeners = {};
	this.m_pLatencies = [];
	this.m_nBrowserTimeQuantizationOffset = caplinx.latency.LatencySubscriber._getBrowserTimeQuantization() / 2;
	this.m_oStatisticsObject = (window.SL4B && window.SL4B_Accessor && SL4B_Accessor.getStatistics)? SL4B.getStatistics() : null;
	this.m_nLatencyThreshold = caplinx.latency.LatencySubscriber.LatencyThreshold;
	
	this.m_nTimeSinceLastLatencyPulse = -1;
	this.m_nMessagesProcessedAtLastPulse = -1;
	this.m_bDataStopped = false;
	
	this.initialise();
};
caplin.extend(caplinx.latency.LatencySubscriber, SL4B_AbstractSubscriber);

caplinx.latency.LatencySubscriber.LatencyThreshold = 250;

caplinx.latency.LatencySubscriber.prototype.ready = function()
{
	SL4B_Accessor.getRttpProvider().getObject(this, "/LATENCY/PULSE", "LATENCY_TIMESTAMP");
};

caplinx.latency.LatencySubscriber.prototype.recordMultiUpdated = function(Objectname, fields, cachedimage) 
{
	var nLatency = this.m_oStatisticsObject.getLatency() + this.m_nBrowserTimeQuantizationOffset;
	
	if( nLatency !== this.m_nLatency)
	{
		this.m_nLatency = nLatency;
		this._notifyListeners(nLatency);
	}
};

caplinx.latency.LatencySubscriber.prototype.recordLatencyInfo = function(fields, nAverageLatency)
{
//	var oStatistics = SL4B_Accessor.getStatistics();
//	var nLatency = oStatistics.getLatency() + this.m_nBrowserTimeQuantizationOffset;
//	
//	var nTimeNow = (new Date()).valueOf();
//	var oResponseQueueStatistics = oStatistics.getResponseQueueStatistics();
//	var sMessage = ">>>>>>>>>\t" + nAverageLatency + "\t" + nLatency + "\t" + oResponseQueueStatistics.getQueuedMessageCount() + "\t" + oResponseQueueStatistics.getQueuedBatchCount();
//	
//	if (this.m_nTimeSinceLastLatencyPulse === -1)
//	{
//		this.m_nTimeSinceFirstLatencyPulse = nTimeNow;
//		this.m_nFirstServerTimeStamp = fields.getFieldMap()["LATENCY_TIMESTAMP"];
//	
//	    var sHeader = ">>>>>>>>>\tAvg Latency\tLatency\tQueued Msgs\tQueued Batches\tServer Time\tElapsed Time\tTime Diff\tTime Since Last Pulse\tMessages Processed Since Last Pulse\tUpdate Rate";
//		caplin.core.Logger.log(caplin.core.LogLevel.CRITICAL, sHeader);
//	
//		sMessage += "\t0\t0\t0\t0\t0";
//	}
//	else
//	{
//		var nElapsedServerTime = fields.getFieldMap()["LATENCY_TIMESTAMP"] - this.m_nFirstServerTimeStamp;
//		var nElapsedTime = nTimeNow - this.m_nTimeSinceFirstLatencyPulse;
//		var nTimeDiff = nElapsedTime - nElapsedServerTime;
//		var nTimeSinceLastPulse = nTimeNow - this.m_nTimeSinceLastLatencyPulse;
//		var nMessagesProcessedSinceLastPulse = oResponseQueueStatistics.getProcessedMessageCount() - this.m_nMessagesProcessedAtLastPulse;
//		var nUpdateRate = nMessagesProcessedSinceLastPulse / (nTimeSinceLastPulse / 1000);
//		sMessage += "\t" + nElapsedServerTime + "\t" + nElapsedTime + "\t" + nTimeDiff + "\t" + nTimeSinceLastPulse + "\t" + nMessagesProcessedSinceLastPulse + "\t" + nUpdateRate;
//	}
//	
//	caplin.core.Logger.log(caplin.core.LogLevel.CRITICAL, sMessage);
//	
//	this.m_nTimeSinceLastLatencyPulse = nTimeNow;
//	this.m_nMessagesProcessedAtLastPulse = oResponseQueueStatistics.getProcessedMessageCount();
//	
//	if (false)
//	{
//		if (oResponseQueueStatistics.getQueuedBatchCount() > 8 && !this.m_bDataStopped)
//		{
//			caplin.core.Logger.log(caplin.core.LogLevel.CRITICAL, "Stopping market data");
//			SL4B_Accessor.getRttpProvider().setGlobalThrottle(SL4B_ThrottleLevel.STOP);
//			this.m_bDataStopped = true;
//		}
//		else if (oResponseQueueStatistics.getQueuedBatchCount() === 1 && this.m_bDataStopped === true)
//		{
//			caplin.core.Logger.log(caplin.core.LogLevel.CRITICAL, "Starting market data");
//			SL4B_Accessor.getRttpProvider().setGlobalThrottle(SL4B_ThrottleLevel.START);
//			this.m_bDataStopped = false;
//		}
//	}
};

caplinx.latency.LatencySubscriber.prototype.addListener = function(fCallback)
{
	this.m_pListeners.push(fCallback);
};

caplinx.latency.LatencySubscriber.prototype.addThresholdListener = function(fCallback, sRowId)
{
	this.m_pThresholdListeners[sRowId] = fCallback;
};

caplinx.latency.LatencySubscriber.prototype.removeThresholdListener = function(sRowId)
{
	delete this.m_pThresholdListeners[sRowId];
};

caplinx.latency.LatencySubscriber.prototype.isLatencyWithin = function()
{
	return this.m_nLatency <= this.m_nLatencyThreshold;
};

caplinx.latency.LatencySubscriber.getInstance = function()
{
	return caplinx.latency.LatencySubscriber.INSTANCE;
};

caplinx.latency.LatencySubscriber.prototype._getLatencyInterquartileMean  = function(pLatencies)
{
	var nQuartileLength = Math.floor(pLatencies.length / 4);
	var pSortedLatencies = pLatencies.slice(0).sort(caplinx.latency.LatencySubscriber._compare);
	var pInterquartileSortedLatencies = pSortedLatencies.slice(nQuartileLength , -nQuartileLength);
	var nInterquartileSum = 0;
	for (var i = 0, nLength = pInterquartileSortedLatencies.length; i < nLength; ++i) 
	{
		nInterquartileSum += pInterquartileSortedLatencies[i];
	}
	return Math.round(nInterquartileSum / nLength);
};

caplinx.latency.LatencySubscriber._compare  = function(nLatency1, nLatency2)
{
	return nLatency1 - nLatency2;
};

//returns the browser time quantization length (time is always rounded down)
caplinx.latency.LatencySubscriber._getBrowserTimeQuantization = function()
{
	var nCurrentTime;
	var nStartTime = new Date().getTime();
	do
	{
		nCurrentTime = new Date().getTime();
	} while(nCurrentTime === nStartTime);
	
	return nCurrentTime - nStartTime;
};

caplinx.latency.LatencySubscriber.prototype._notifyListeners = function(nNewLatency, nLatency)
{
	this._notifyThresholdListeners(nNewLatency, nLatency);
	this.m_nLatency = nNewLatency;
	for(var i = 0, l = this.m_pListeners.length; i < l; ++i)
	{
		this.m_pListeners[i].latencyUpdated(nNewLatency, nLatency);
	}
};

caplinx.latency.LatencySubscriber.prototype._notifyThresholdListeners = function(nNewLatency, nLatency)
{
	if((this.m_nLatencyThreshold - this.m_nLatency > 0) && (nNewLatency - this.m_nLatencyThreshold > 0)) {
		for(var i in this.m_pThresholdListeners)
		{
			this.m_pThresholdListeners[i].thresholdBreached(nNewLatency, nLatency);
		}
	} else if((this.m_nLatency - this.m_nLatencyThreshold > 0) && (this.m_nLatencyThreshold - nNewLatency > 0)) {
		for(var i in this.m_pThresholdListeners)
		{
			this.m_pThresholdListeners[i].thresholdRestored(nNewLatency, nLatency);
		}
	}
};

caplinx.latency.LatencySubscriber.onAfterClassLoad = function()
{
	caplinx.latency.LatencySubscriber.INSTANCE = new caplinx.latency.LatencySubscriber();
};
caplin.notifyAfterClassLoad(caplinx.latency.LatencySubscriber);
