caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxTileInstrumentListener = function(oFxTile)
{
	this.m_oFxTile = oFxTile;
};

caplinx.trading.presentation.listeners.FxTileInstrumentListener.prototype.dataFieldChanged  = function(oValue, oOldValue)
{
	this.m_oFxTile.instrumentEventHandler(oValue, oOldValue);
};