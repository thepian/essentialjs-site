caplin.namespace("caplinx.renderer");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.dom.renderer.TextElementRenderer", true);

caplinx.renderer.DateElementRenderer = function(pFields)
{
	caplin.dom.renderer.TextElementRenderer.call(this, pFields);
};
caplin.implement(caplinx.renderer.DateElementRenderer, caplin.dom.renderer.TextElementRenderer);

caplinx.renderer.DateElementRenderer.onAfterClassLoad = function()
{
	caplinx.renderer.DateElementRenderer.DATE_REG_EXP = /(\d\d\d\d)([0-1]\d)([0-3]\d)/;
	caplinx.renderer.DateElementRenderer.MONTH_MAP = { "01": ct.i18n("ct.i18n.date.month.short.january"), "02": ct.i18n("ct.i18n.date.month.short.february"), "03": ct.i18n("ct.i18n.date.month.short.march"), "04": ct.i18n("ct.i18n.date.month.short.april"), "05": ct.i18n("ct.i18n.date.month.short.may"), "06": ct.i18n("ct.i18n.date.month.short.june"), "07": ct.i18n("ct.i18n.date.month.short.july"), "08": ct.i18n("ct.i18n.date.month.short.august"), "09": ct.i18n("ct.i18n.date.month.short.september"), "10": ct.i18n("ct.i18n.date.month.short.october"), "11": ct.i18n("ct.i18n.date.month.short.november"), "12": ct.i18n("ct.i18n.date.month.short.december") };
};
caplin.notifyAfterClassLoad(caplinx.renderer.DateElementRenderer);

caplinx.renderer.DateElementRenderer.prototype.formatValue = function(sValue)
{
	var oMatch = sValue.match(caplinx.renderer.DateElementRenderer.DATE_REG_EXP);
	if (oMatch !== null)
	{
		sValue = oMatch[3] + "-" + caplinx.renderer.DateElementRenderer.MONTH_MAP[oMatch[2]] + "-" + oMatch[1];
	}
	return sValue;
};