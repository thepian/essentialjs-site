// MUSTDO: document

caplin.namespace("caplinx.widget.format");

caplin.include("caplin.widget.format.AbstractFieldValueProcessor", true);
caplin.include("caplinx.widget.format.PriceTextFormatter");
caplin.include("caplin.framework.ApplicationFactory");

caplinx.widget.format.FxSwapPriceDiffValueProcessor = function(l_sDecimalPlaceFieldName, l_bBracketNegativeAmounts)
{
	// see if this is created using a number
	l_bUsingDecimalPlaceField = ( typeof l_sDecimalPlaceFieldName == 'number' ) ? false : true;

    switch( typeof( l_sDecimalPlaceFieldName ) ){
		case "string":
			this.m_sDecimalPlaceFieldName	= l_sDecimalPlaceFieldName;
			this.m_nDecimalPlaces			= 2;
			break;
		case "number":
			this.m_sDecimalPlaceFieldName	= null;
			this.m_nDecimalPlaces			= l_sDecimalPlaceFieldName;
			break;
		default:
			this.m_sDecimalPlaceFieldName	= 'pntsPrcsn';
			this.m_nDecimalPlaces			= 2;
	}

    this.m_oFormatterFactory =  caplin.framework.ApplicationFactory.getInstance().getTextFormatterFactory();

    this.m_bBracketNegativeAmounts = (l_bBracketNegativeAmounts)?l_bBracketNegativeAmounts:false;
};

caplin.extend(caplinx.widget.format.FxSwapPriceDiffValueProcessor, caplin.widget.format.AbstractFieldValueProcessor);

caplinx.widget.format.FxSwapPriceDiffValueProcessor.prototype.getValue = function(l_oObject, l_sFieldName)
{
	var l_sPrecisionValue = ( this.m_sDecimalPlaceFieldName ) ? l_oObject.getFieldValue( this.m_sDecimalPlaceFieldName ) : this.m_nDecimalPlaces;
	var l_sPrice = l_oObject.getFieldValue(l_sFieldName);
	
	if (l_sPrice != null )
	{
		if (l_sPrecisionValue != null)
		{
			l_sPrice = this.formatText( l_sPrice, parseInt( l_sPrecisionValue, 10 ) );
		}
		else
		{
			// if a precision has not been defined, then use 5 significant figures (requiring a value
			// of 6 in this call since the decimal point must be ignored)
			l_sPrice = this.formatText( l_sPrice, 0 );
		}

         if (this.m_bBracketNegativeAmounts)
	        l_sPrice = this.getBracketNegativeAmountsTextFormatter().formatText(l_sPrice);
    }   

    return l_sPrice;
};

caplinx.widget.format.FxSwapPriceDiffValueProcessor.prototype.getBracketNegativeAmountsTextFormatter = function(l_sPrice, l_nPrecisionValue)
{
	if (this.m_oBracketNegativeAmountsTextFormatter === undefined)
	{
		this.m_oBracketNegativeAmountsTextFormatter = this.m_oFormatterFactory.getTextFormatter("caplinx.widget.format.BracketNegativeAmountsTextFormatter");
	}
	return this.m_oBracketNegativeAmountsTextFormatter;
};

/*
 * current formatting is a number with a maximum number of decimal places.
 * this does not force a specific number of decimal places to be appended to the number - should it?
 * TODO : Should this not be a text formatter?
 */
caplinx.widget.format.FxSwapPriceDiffValueProcessor.prototype.formatText = function( l_sPrice, l_nPrecisionValue )
{
	var l_nReturn = parseFloat( l_sPrice );
	var l_nMultiple = Math.pow( 10, l_nPrecisionValue );
	
	if( isNaN( l_nReturn ) ){
		l_nReturn = l_sPrice;
	}
	else{
		l_nReturn = Math.round( l_nReturn * l_nMultiple ) / l_nMultiple;
	}
	return l_nReturn;
};
