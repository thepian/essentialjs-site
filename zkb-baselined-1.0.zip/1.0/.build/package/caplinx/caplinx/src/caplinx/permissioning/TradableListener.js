caplin.namespace("caplinx.permissioning");

caplin.include("caplinx.permissioning.CaplinPermissionService");
caplin.include("caplin.security.permissioning.PermissionService");
caplin.include("caplin.security.permissioning.PermissionServiceListener");

/**
 * @private
 * Returns permissioning decisions based on the conjunction of the specified trade protocol (e.g ESP, RFS) and trade type (e.g. SPOT, FWD). 
 *
 * @param {String} sInstrument the instrument to be traded. 
 * @param {Object} oListener the Listener to receive callbacks
 * @param {String} sProtocol the trade protocol that this permission listener should listen for permission changes on.
 * @param {String} sTradeType (Optional) The trade type that this permission listener should listen for permission changes on. If
 * the argument is null or does not exist then the item will be permissioned if the user is permissioned on at least one 
 * item in the tradeType namespace (e.g. ticket trades are only allowed if the user has RFS protocol and one of SPOT, FWD or SWAP).
 */
caplinx.permissioning.TradableListener = function(sInstrument, oListener, sProtocol, sTradeType)
{
	this.m_bCanTradeWithProtocol = null;
	this.m_bCanTradeOnType = null;
	this.m_bPreviousResult = null;
	this.m_sTradeType = null;
	
	this.m_oListener = oListener;

	var oPermissionService = caplin.security.permissioning.PermissionService;

	if(sTradeType)
	{
		this.m_sTradeType = sTradeType; 
		this.m_nTradeTypeListenerId = oPermissionService.addPermissionListener(sInstrument, "TradeType", sTradeType, this);	
	} else {
		this.m_nTradeTypeListenerId = oPermissionService.addPermissionSetListener(sInstrument, "TradeType", oPermissionService.ALLOW, this);
	}
	this.m_nTradeProtocolListenerId = oPermissionService.addPermissionListener(sInstrument, "TradeProtocol", sProtocol, this);
};

caplin.implement(caplinx.permissioning.TradableListener, caplin.security.permissioning.PermissionServiceListener);

/**
 * @see caplin.security.permissioning.PermissionServiceListener#onSinglePermissionChanged
 */
caplinx.permissioning.TradableListener.prototype.onSinglePermissionChanged = function(bIsAuthorized, sProduct, sNamespace, sAction)
{
	if (sNamespace == "TradeType"){
		this.m_bCanTradeOnType = bIsAuthorized;
	} else if (sNamespace == "TradeProtocol"){
		this.m_bCanTradeWithProtocol = bIsAuthorized;
	}
	this._propagatePermissions();
};

/**
 * @see caplin.security.permissioning.PermissionServiceListener#onPermissionsChanged
 */
caplinx.permissioning.TradableListener.prototype.onPermissionsChanged = function(pPermissions, sProduct, sNamespace)
{
	this.m_bCanTradeOnType = pPermissions.length !== 0;
	this._propagatePermissions();
};

/**
 * @private
 */
caplinx.permissioning.TradableListener.prototype._$cancelSubscription = function()
{
	caplin.security.permissioning.PermissionService.removeListener(this.m_nTradeTypeListenerId);
	caplin.security.permissioning.PermissionService.removeListener(this.m_nTradeProtocolListenerId);
};

/**
 * @private
 */
caplinx.permissioning.TradableListener.prototype._propagatePermissions = function()
{
	if (this.m_bCanTradeWithProtocol === null || this.m_bCanTradeOnType === null) 
	{
		return;
	}
	
	var bCurrentResult = this.m_bCanTradeWithProtocol && this.m_bCanTradeOnType;
	if (bCurrentResult !== this.m_bPreviousResult) 
	{
		this.m_bPreviousResult = bCurrentResult;
		if(this.m_sTradeType) {
			this.m_oListener.onTilePermissionsChanged(bCurrentResult);
		} else {
			this.m_oListener.onTicketPermissionsChanged(bCurrentResult);
		}
	}
};
