caplin.namespace("caplinx.widget.element.renderer");

caplin.include("caplin.widget.element.renderer.ElementRenderer");

/**
 * Constructs a new <code>TileButtonElementRenderer</code> with the specified {@link caplin.widget.format.AbstractFieldValueProcessor}s,
 * field names, and {@link caplin.widget.fields.FieldManager}.
 *
 * @param {Array} l_pFieldValueProcessors An array of {@link caplin.widget.format.AbstractFieldValueProcessor}s
 *                to be used to construct the field derivations that will be used by the <code>ElementRenderer</code>.
 *                this element renderer expects just a single {@link caplin.widget.format.AbstractFieldValueProcessor}
 *                within the array.
 * @param {Array} l_pFieldNames An array of field names
 * @param {caplin.widget.fields.FieldManager} oFieldManager The field manager to use to get information about the given fields
 * @throws {@link caplin.widget.Exception} If the specified FieldValueProcessor array does not contain exactly one element.
 *
 * @class
 * <p>Extends caplin.widget.element.renderer.ElementRenderer to enable Tile updates to be paused and resumed.</p>
 */
caplinx.widget.element.renderer.TileButtonElementRenderer = function(sInstrumentName, pFieldValueProcessors, pFieldNames, oFieldManager)
{
	caplin.widget.element.renderer.ElementRenderer.apply(this, [pFieldValueProcessors, pFieldNames, oFieldManager]);

	this.pFieldValueProcessors = pFieldValueProcessors;
	this.m_sInstrumentName = sInstrumentName;
};
caplin.extend(caplinx.widget.element.renderer.TileButtonElementRenderer, caplin.widget.element.renderer.ElementRenderer);

caplinx.widget.element.renderer.TileButtonElementRenderer.formatStore = {};

/**
 * This method seems to be some hacky way to reduce the length of the forwarding chain that updates are passed through.
 * It is currently only being used within FXTile.
 *
 * @private
 * @param {Object} oDataModel
 * @param {String} sDefaultValue
 */
caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.setDataModel = function(oDataModel, sDefaultValue)
{
	this.m_sDefaultValue = sDefaultValue;
	this.m_oDataModel = oDataModel;
};

/**
 * Renders the HTML necessary to display this and subsequent updates.
 *
 * <p>The default implementation of this method adds a text node to the element that is passed in, and this can be used
 * to display the text that will be passed in the subequent calls to {@link #updateElement}.</p>
 *
 * @param {caplin.widget.objectset.DataObject} oObject The object that the element is being created for.
 * @param {HtmlElement} oElement The HTML element that updates for the given object will be displayed in.
 */
caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.createElement = function(oObject, oElement)
{
	this.m_sId = this.getElementIdentifier(oObject);
	
	var ePrices = document.createElement("div");
	ePrices.className = "prices";
	
	var ePart1 = document.createElement("DIV");
	ePart1.className = "price1 label-pips";
	this.m_oElementFactory.setElementText(ePart1, this.m_sDefaultValue);
	ePrices.appendChild(ePart1);

	var ePart2 = document.createElement("DIV");
	ePart2.className = "price2 label-pips";
	this.m_oElementFactory.setElementText(ePart2, this.m_sDefaultValue);
	ePrices.appendChild(ePart2);
	
	var ePart3 = document.createElement("DIV");
	ePart3.className = "price3 label-pips";
	ePrices.appendChild(ePart3);
	this.m_oElementFactory.setElementText(ePart3, this.m_sDefaultValue);

	var eArrowElementHolder = this.m_oElementFactory.createElement("DIV");
	eArrowElementHolder.className = "arrow";
	
	var eArrowElement = this.m_oElementFactory.createElement("DIV");
	eArrowElement.className = "arrowimage";
	eArrowElementHolder.appendChild(eArrowElement);
	
	oElement.appendChild(ePrices);
	oElement.appendChild(eArrowElementHolder);

	this.m_pElements = [ePart1.firstChild, ePart2.firstChild, ePart3.firstChild, eArrowElement.style, oElement.style, oElement];
	this.m_oDataModel.addDataFieldsChangedListener(this, this.m_pFieldNames);
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.destruct = function()
{
	//cleanup in here.
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.dataFieldChanged = function(oValue, oOldValue, mLegValues)
{
	var sPriceId = mLegValues["TRACE-CalculatedPriceId"];
    RTSL_DisplayUpdate(new caplinx.widget.element.renderer.TileButtonUpdate(this.m_pFieldValueProcessors, this.m_pElements, oValue, oOldValue, this.m_sId, this.m_fFunctionToBeCalledOnRender, this.getUpdateMetaData(), sPriceId));
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.getUpdateMetaData = function()
{
	return {
		bShowSmallPip: this.getSmallPipToBeShown()
	};
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.setSmallPipToBeShown = function(bShowSmallPip)
{
	this.getFormatStore().bShowSmallPip = bShowSmallPip;
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.getSmallPipToBeShown = function()
{
	return this.getFormatStore().bShowSmallPip;
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.getFormatStore = function()
{
	var oFormatStore = caplinx.widget.element.renderer.TileButtonElementRenderer.formatStore;
	if (oFormatStore[this.m_sInstrumentName] == null)
	{
		oFormatStore[this.m_sInstrumentName] = {};
	}
	return oFormatStore[this.m_sInstrumentName];
};

caplinx.widget.element.renderer.TileButtonElementRenderer.prototype.getFieldValue = function(sFieldName)
{
	return this.m_oDataModel.getFieldValue(sFieldName);
};

caplinx.widget.element.renderer.TileButtonUpdate = function(pFieldValueProcessors, pElements, sCurrentValue, sOldValue, sIdentifier, fRenderFunc, oUpdateMetaData, sPriceId)
{
	this.m_pFieldValueProcessors = pFieldValueProcessors;
	this.m_pElements = pElements;
	// PCTD-2292
	// This is purely a visual presentation fix. It doesn't address underlying trading model issues
	if (/e-\d+/.test(sCurrentValue)) {
		sCurrentValue = "0.00000";
	}
	this.m_sCurrentValue = sCurrentValue;
	this.m_sOldValue = sOldValue;
	this.m_sIdentifier = sIdentifier;
	this.m_bFirstDraw = true;
	this.m_fFunctionToBeCalledOnRender = fRenderFunc;
	this.m_oUpdateMetaData = oUpdateMetaData;
	this.m_mTraceData = this._createTraceData(sPriceId);
};
caplin.extend(caplinx.widget.element.renderer.TileButtonUpdate, SL4B_Update);

caplinx.widget.element.renderer.TileButtonUpdate.prototype._createTraceData = function(sPriceId)
{
	var nUpdatedCreatedTime = (new Date()).valueOf();
	
	
	if(SL4B_Accessor && SL4B_Accessor.getStatistics && SL4B_Accessor.getStatistics().getResponseQueueStatistics)
	{
		var statistics = SL4B_Accessor.getStatistics().getResponseQueueStatistics();
		var bIsNull = statistics.getTimeOldestBatchBeganExecution() === null;
		if(bIsNull === false){
			this.m_nBatchQTime =  statistics.getTimeOldestBatchWasQueued().valueOf();
			var nBatchQExecTime = statistics.getTimeOldestBatchBeganExecution().valueOf();
		}
		
		var m_mTraceData = {
			"TRACE-TimeTradedUpdateBatchWasQueued": (bIsNull ? "???" : this.m_nBatchQTime + ""),
			"TRACE-TimeTradedUpdateBatchWasStarted": (bIsNull ? "???" : nBatchQExecTime + ""),
			"TRACE-TimeTradedPriceWasQueuedForDisplay": nUpdatedCreatedTime + "",
			"TRACE-CalculatedTradedPriceId": sPriceId + ""
		};
	}
		
	return m_mTraceData || {};
};

caplinx.widget.element.renderer.TileButtonUpdate.prototype.drawUpdate = function()
{
    var oElementStyle = this.m_pElements[4];
    var eElement =  this.m_pElements[5];
    
    if(this.m_bFirstDraw)
    {
		var bFirstDraw = this.m_bFirstDraw;
	    this.m_bFirstDraw = false;
		var sValue = this.m_sCurrentValue;
		this.m_bIsUp = (parseFloat(this.m_sOldValue, 10) < parseFloat(sValue, 10));
		
        if(this.m_bIsUp)
        {
            this.m_pElements[3].top = "";
            eElement.className = "ButtonContents recentUp";
        }
        else
        {
            this.m_pElements[3].top = "-15px";
            eElement.className = "ButtonContents recentDown";
        }

		var nTimeWrittenToTheDOM = (new Date()).valueOf();
		this.m_mTraceData["TRACE-TimeTradedPriceWasWrittenToTheDom"] = nTimeWrittenToTheDOM + "";
		        
        this.setTileValues(sValue);
		this.m_fFunctionToBeCalledOnRender(sValue, this.m_mTraceData);
    }
    else
    {
    	if(this.m_bIsUp)
        {
            eElement.className = "ButtonContents previousUp";
        }
        else
        {
            eElement.className = "ButtonContents previousDown";
        }
    }
    
    return bFirstDraw ? this : null;
};

caplinx.widget.element.renderer.TileButtonUpdate.prototype.setTileValues = function(sValue)
{
	for (var x = 0, l = 3; x < l; x++)
	{
		var nFieldValue = "";
		if (sValue != null) {
			nFieldValue = this.m_pFieldValueProcessors[x].getValue(sValue, this.m_oUpdateMetaData);
		}
        var eDomNode = this.m_pElements[x];
        if (nFieldValue !== eDomNode.nodeValue)
        {
            eDomNode.nodeValue = nFieldValue;
        }
    }
};

caplinx.widget.element.renderer.TileButtonUpdate.prototype.getFlashTime = function()
{
	return 500;
};
