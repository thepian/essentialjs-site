caplin.namespace("caplinx.trading.presentation.listeners");

caplinx.trading.presentation.listeners.FxTileMaxTierLimitListener = function(oFxTile)
{
	this.m_oFxTile = oFxTile;
};

caplinx.trading.presentation.listeners.FxTileMaxTierLimitListener.prototype.dataFieldChanged  = function(oValue, oOldValue)
{
	this.m_oFxTile.maxTierLimitHandler(oValue);
};