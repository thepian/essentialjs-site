caplin.namespace("caplinx.renderer.handler");

caplin.include("caplin.renderer.handler.Handler", true);
caplin.include("caplin.grid.GridColumnFilter");
caplin.include("caplinx.renderer.handler.FilterHandler");
caplin.include("caplinx.renderer.handler.RangeFilterHandler");
caplin.include("caplin.core.Exception");

caplinx.renderer.handler.CombinedFilterHandler = function()
{
};
caplin.implement(caplinx.renderer.handler.CombinedFilterHandler, caplin.renderer.handler.Handler);

caplinx.renderer.handler.CombinedFilterHandler.prototype.onChange = function(sNewValue, oControlRenderer)
{
	var oColumn = oControlRenderer.getFieldModel();
	
	if(oColumn.getPrimaryFieldType() == "text")
	{
		caplinx.renderer.handler.FilterHandler.onChange(sNewValue, oControlRenderer);
	}
	else if(oColumn.getPrimaryFieldType() == "tenor")
	{
		if(caplinx.renderer.handler.RangeFilterHandler.applyFilterIfValidRequest(sNewValue, oControlRenderer) === false)
		{
			caplinx.renderer.handler.FilterHandler.onChange(sNewValue, oControlRenderer);
		}
	}
	else if(oColumn.getPrimaryFieldType() == "number")
	{
		caplinx.renderer.handler.RangeFilterHandler.onChange(sNewValue, oControlRenderer);
	}
	else
	{
		throw new caplin.core.Exception("todo...");
	}
};

caplin.singleton("caplinx.renderer.handler.CombinedFilterHandler");
