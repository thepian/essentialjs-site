caplin.namespace("caplinx.trading.presentation.tile");

caplinx.trading.presentation.tile.FxTileStatus = function() {
	this.NOT_PERMISSIONED = "status-permission";
	this.NOT_CONNECTED = "status-no-connection";
	this.ERROR = "status-error";
	this.INFO = "status-info";
};

caplin.singleton("caplinx.trading.presentation.tile.FxTileStatus");
