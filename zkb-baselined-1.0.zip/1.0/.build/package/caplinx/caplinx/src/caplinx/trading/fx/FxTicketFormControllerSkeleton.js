caplin.namespace("caplinx.trading.fx");

/**
 * Skeleton for an FX ticket controller
 * 
 * Illustrates how to wire up an FX ticket
 */
caplinx.trading.fx.FxTicketFormControllerSkeleton = function( )
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "constructed FxTicketFormControllerSkeleton");
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.initialize = function(mFormProperties,mPropertyByName,mPropertyBySetter)
{
	var pProp = [];
	if (mPropertyByName) for(var n in mPropertyByName) pProp.push(n+"="+mPropertyByName[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "initialized by name ["+pProp.join(" ")+"] ");
	var pProp = [];
	if (mPropertyBySetter) for(var n in mPropertyBySetter) pProp.push(n+"="+mPropertyBySetter[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "(!!) initialized by setter ["+pProp.join(" ")+"] ");
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.reinitialize = function(mFormProperties,mPropertyByName,mPropertyBySetter)
{
	var pProp = [];
	if (mPropertyByName) for(var n in mPropertyByName) pProp.push(n+"="+mPropertyByName[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "reinitialized by name ["+pProp.join(" ")+"] ");
	var pProp = [];
	if (mPropertyBySetter) for(var n in mPropertyBySetter) pProp.push(n+"="+mPropertyBySetter[n]);
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "reinitialized by setter ["+pProp.join(" ")+"] ");
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.initializeView = function(oView,mFormProperties,mPropertyByName,mPropertyBySetter)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "initialized view ");
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.MORE_CLASS_MAPPING = {};
caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.MORE_CLASS_MAPPING[undefined] = { formatted: "show-less" };
caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.MORE_CLASS_MAPPING[true] = { formatted: "show-more" };
caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.MORE_CLASS_MAPPING[false] = { formatted: "show-less" };

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.more_less_textMapping = function(oView,vValue,sNamespace) {
	return vValue? "Less" : "More";
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.more_less_rotateMapping = function(oView,vValue,sNamespace) {
	return vValue? "rotate-right-90" : "rotate-left-90";
};


caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.preset = function(oView,sNamespace,sName,vValue,sStage)
{
	switch(sName) {
		case "show-more": return false;
	}
	return vValue == undefined? "" : vValue;
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.toggle = function(oView,sNamespace,sName,vValue)
{
	return !vValue; 
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.increase = function(oView,sNamespace,sName,vValue,vStep)
{
	if (typeof vValue == "string") vValue = parseFloat(vValue) || 0;
	return vValue + vStep; 
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.decrease = function(oView,sNamespace,sName,vValue,vStep)
{
	if (typeof vValue == "string") vValue = parseFloat(vValue) || 0;
	return vValue - vStep; 
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.editdone = function(oView, sNamespace,sName, vValue)
{
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.set = function(oView, sNamespace,sName, vValue)
{
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.command = function(oView,sNamespace,sCommand)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "command triggered "+ sCommand);
};


caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.onOpen = function(oView)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onOpen "+oView);
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.onShow = function()
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onShow called");
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.onResize = function(mParams)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onResize "+ (window.JSON? JSON.stringify(mParams) : ""));
};


caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.onClose = function(oView)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onClose "+oView);
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.onBeforeClose = function(oView)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "onBeforeClose "+oView);
};




caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.setProtocol = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "protocol = "+ sValue);
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.setObjectName = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "object name = "+ sValue);
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.setBuySell = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "buy/sell = "+ sValue);
};

caplinx.trading.fx.FxTicketFormControllerSkeleton.prototype.setAmount = function(sValue)
{
	caplin.core.Logger.log(caplin.core.LogLevel.ERROR, "amount = "+ sValue);
};

/*

	<property setter="setInitialDealtCurrency"/>
	<property setter="setAccount"/>
	<property setter="setFwdSizeIncrease" value="41"/>
	<property setter="setSwapSizeIncrease" value="171"/>  
 */
