caplin.namespace("caplinx.widget.tradeticket");

caplin.include("caplin.i18n.Translator", true);
caplin.include("caplin.security.AbstractFactory");
caplin.include("caplin.widget.message.MessageManager");
caplin.include("caplin.security.permissioning.PermissionService");


caplinx.widget.tradeticket.TradeTicketCreator = function()
{
};

caplinx.widget.tradeticket.TradeTicketCreator.INSTANCE = new caplinx.widget.tradeticket.TradeTicketCreator();

caplinx.widget.tradeticket.TradeTicketCreator.getInstance = function() { return caplinx.widget.tradeticket.TradeTicketCreator.INSTANCE; };

caplinx.widget.tradeticket.TradeTicketCreator.prototype.openTicketFromTrade = function(oTradeModel)
{
  //TODO: Check for valid arguments (is FI)
 	var sDialogTemplate = "bonds-trade-ticket";
	var oPropertyValues = {
		properties:
		{
			setTrade: oTradeModel
		}
	};  
	webcentric.showDialog(sDialogTemplate, oPropertyValues);
};



caplinx.widget.tradeticket.TradeTicketCreator.prototype.openTicket = function(l_sObjectName, l_sBuyOrSell, l_sTradeProtocol, l_nAmount, l_sDealtCurrency, l_sAccount)
{
	/*
	 * PCTD-1274
	 * if we try and open a ticket without having an object name
	 * (which does sometimes happen due to bugs in the grid),
	 * we just return from the method without opening the ticket.
	 */
	if(!l_sObjectName || l_sObjectName.length === 0)
	{
		return;
	}
	
	var l_sDialogTemplate;
	var bIsBond = false; 
	
	if (l_sTradeProtocol == "ORD")
	{
		l_sDialogTemplate = "fx-order-trade-ticket";
	}
	else if (l_sObjectName.indexOf("/FI/") != -1)
	{
		bIsBond = true;
		l_sDialogTemplate = "bonds-trade-ticket";
	}
	else
	{
		l_sDialogTemplate = "fx-trade-ticket";
	}	
	
	//if the user is permissioned for the given protocol and they are permissioned for at least one trading type
	if (caplin.security.permissioning.PermissionService.canUserPerformAction(l_sObjectName, "TradeProtocol", l_sTradeProtocol)
		&& caplin.security.permissioning.PermissionService.getAllowPermissions(l_sObjectName, "TradeType").length > 0)
	{
		if (bIsBond)
		{	
			// Personal FI Grid returns BUY/SELL instead of Ask/Bid
			if (l_sBuyOrSell == "BUY" || l_sBuyOrSell == "SELL") {
				l_sBuyOrSell = (l_sBuyOrSell == "BUY") ? "Ask" : "Bid";
			}
		
			var l_oPropertyValues = {
				properties: {
					setStructureType: l_sObjectName,
					setSide: l_sBuyOrSell
				}
			};
		}  
		else
		{
			l_oPropertyValues = {
				properties:
				{
					setProtocol: l_sTradeProtocol,
					setBuySell:  (l_sBuyOrSell == "Bid") ? "Sell" : "Buy",
					setObjectName:l_sObjectName,
					setAmount:l_nAmount,
					setInitialDealtCurrency:l_sDealtCurrency,
					setAccount:l_sAccount
				}
			};  
		}
		webcentric.showDialog(l_sDialogTemplate, l_oPropertyValues);
	}
	else
	{
		caplin.widget.message.MessageManager.getInstance().alert(ct.i18n("cx.widget.tradeticket.creator.not_permissioned_alert"));
	}
};