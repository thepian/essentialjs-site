use caplinusers;

insert into users (user_name,user_pass)
	VALUES ("user1@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("user1@caplin.com", "fitrader");
insert into user_roles (user_name, role_name) 
	VALUES ("user1@caplin.com", "pluto");

insert into users (user_name,user_pass)
	VALUES ("user2@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("user2@caplin.com", "fitrader");

insert into users (user_name,user_pass)
	VALUES ("user3@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("user3@caplin.com", "fitrader");

insert into users (user_name,user_pass)
	VALUES ("user4@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("user4@caplin.com", "fitrader");

insert into users (user_name,user_pass)
	VALUES ("user5@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("user5@caplin.com", "fitrader");

-- start permissioning test users	
insert into users (user_name,user_pass)
	VALUES ("cannotlogin@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("cannotlogin@caplin.com", "fitrader");

insert into users (user_name,user_pass)
	VALUES ("cannotviewanything@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("cannotviewanything@caplin.com", "fitrader");

insert into users (user_name,user_pass)
	VALUES ("viewonly@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("viewonly@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("basicuser@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("basicuser@caplin.com", "fitrader");	
	
insert into users (user_name,user_pass)
	VALUES ("quicktrader@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("quicktrader@caplin.com", "fitrader");	

insert into users (user_name,user_pass)
	VALUES ("alltradetypes@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("alltradetypes@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("view-only@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("view-only@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("spotfwd-only@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("spotfwd-only@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("esp-only@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("esp-only@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("rfs-only@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("rfs-only@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("no-perms@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-perms@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("no-metals@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-metals@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("no-accounts@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-accounts@caplin.com", "fitrader");
	
insert into users (user_name,user_pass)
	VALUES ("no-usd@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-usd@caplin.com", "fitrader");	

insert into users (user_name,user_pass)
	VALUES ("no-eurgbp@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-eurgbp@caplin.com", "fitrader");	

insert into users (user_name,user_pass)
	VALUES ("no-view-usd@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-view-usd@caplin.com", "fitrader");	

insert into users (user_name,user_pass)
	VALUES ("no-view-eurgbp@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("no-view-eurgbp@caplin.com", "fitrader");	
		
insert into users (user_name,user_pass)
	VALUES ("sales1@caplin.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("sales1@caplin.com", "fitrader");	

-- end permissioning test users			

insert into users (user_name,user_pass)
	VALUES ("testtochecklongusernamesareok@evenlongerdomainname.com", "cappass");
insert into user_roles (user_name, role_name) 
	VALUES ("testtochecklongusernamesareok@evenlongerdomainname.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("selenium@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium@caplin.com", "fitrader");

insert into users (user_name,user_pass) VALUES ("selenium.sales@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium.sales@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("selenium.load@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium.load@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("selenium.noir@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium.noir@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("selenium.deck@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium.deck@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("selenium.charting@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium.charting@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("selenium.select@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("selenium.select@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("performance@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("performance@caplin.com", "fitrader");

insert into users (user_name,user_pass)	VALUES ("blank-sheet@caplin.com", "cappass");
insert into user_roles (user_name, role_name) VALUES ("blank-sheet@caplin.com", "fitrader");

insert into users (user_name,user_pass)
	VALUES ("admin1@caplin.com", "admin");
insert into user_roles (user_name, role_name) 
	VALUES ("admin1@caplin.com", "admin");
insert into user_roles (user_name, role_name) 
	VALUES ("admin1@caplin.com", "manager");
insert into user_roles (user_name, role_name) 
	VALUES ("admin1@caplin.com", "pluto");